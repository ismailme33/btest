// import 'dart:convert';

// class DbQuotationData {
//   String quotNo;
//   String createdBy;
//   String selectedCustomerID;
//   String discountPercentage;
//   String discountValue;
//   DateTime createdDate;
//   String totalQty;

//   DateTime? fbModifiedDate;
//   DateTime? fbUploadedDate;
//   String selectedStoreDocId;

//   List<dynamic> selectedItems;

//   String taxPer;
//   String taxValue;

//   String docId;

//   String receiptTotal;
//   String receiptDue;
//   String receiptBalance;
//   Map<dynamic, dynamic> allPaymentMethodAmountsInfo;
//   DbQuotationData(
//       {this.fbUploadedDate,
//       this.fbModifiedDate,
//       required this.quotNo,
//       required this.receiptTotal,
//       required this.createdBy,
//       required this.selectedCustomerID,
//       required this.discountPercentage,
//       required this.discountValue,
//       required this.createdDate,
//       required this.totalQty,
//       required this.selectedItems,
//       required this.taxPer,
//       required this.taxValue,
//       required this.docId,
//       required this.receiptDue,
//       required this.receiptBalance,
//       required this.selectedStoreDocId,
//       required this.allPaymentMethodAmountsInfo});

//   Map<String, dynamic> toMap() {
//     final result = <String, dynamic>{};

//     result.addAll({
//       'fbUploadedDate': fbUploadedDate == null ? '' : fbUploadedDate.toString()
//     });
//     result.addAll({
//       'fbModifiedDate': fbModifiedDate == null ? '' : fbModifiedDate.toString()
//     });
//     result.addAll({'receiptNo': quotNo});
//     result.addAll({'createdBy': createdBy});
//     result.addAll({'selectedCustomerID': selectedCustomerID});
//     result.addAll({'discountPercentage': discountPercentage});
//     result.addAll({'discountValue': discountValue});
//     result.addAll({'createdDate': createdDate.millisecondsSinceEpoch});
//     result.addAll({'totalQty': totalQty});
//     result.addAll({'selectedItems': selectedItems});
//     result.addAll({'taxPer': taxPer});
//     result.addAll({'taxValue': taxValue});
//     result.addAll({'docId': docId});

//     result.addAll({'selectedStoreDocId': selectedStoreDocId});

//     result.addAll({'receiptTotal': receiptTotal});
//     result.addAll({'receiptDue': receiptDue});
//     result.addAll({'receiptBalance': receiptBalance});
//     result.addAll({'allPaymentMethodAmountsInfo': allPaymentMethodAmountsInfo});
//     return result;
//   }

//   factory DbQuotationData.fromMap(Map<dynamic, dynamic> map) {
//     return DbQuotationData(
//         fbUploadedDate: DateTime.tryParse(map['fbUploadedDate'] ?? ''),
//         fbModifiedDate: DateTime.tryParse(map['fbModifiedDate'] ?? ''),
//         quotNo: map['receiptNo'] ?? '',
//         createdBy: map['createdBy'] ?? '',
//         selectedCustomerID: map['selectedCustomerID'] ?? '',
//         discountPercentage: map['discountPercentage'] ?? '',
//         discountValue: map['discountValue'] ?? '',
//         createdDate: DateTime.tryParse(map['createdDate'].toString()) ??
//             DateTime.fromMillisecondsSinceEpoch(map['createdDate'] as int),
//         totalQty: map['totalQty'] ?? '',
//         selectedItems: List<dynamic>.from(map['selectedItems']),
//         taxPer: map['taxPer'] ?? '',
//         taxValue: map['taxValue'] ?? '',
//         docId: map['docId'] ?? '',
//         selectedStoreDocId: map['selectedStoreDocId'],
//         //
//         receiptTotal: map['receiptTotal'] ?? '',
//         receiptDue: map['receiptDue'] ?? '',
//         receiptBalance: map['receiptBalance'] ?? '',
//         allPaymentMethodAmountsInfo: map['allPaymentMethodAmountsInfo'] ?? '');
//   }

//   String toJson() => json.encode(toMap());

//   factory DbQuotationData.fromJson(String source) =>
//       DbQuotationData.fromMap(json.decode(source));
// }
