// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class StoreData {
  String docId;
  String storeCode;
  String storeName;
  String subName;
  String address;
  String phone1;
  String phone2;
  String email;
  String vatNumber;
  String crNumber;
  String priceLevel;
  String bankName;
  String accountNumber;
  String note;
  bool isEnabled;

  String logoPath;

  String storeArabicName;

  List<StoreDocumentData> storeDocumentData;

  String street;
  String area;
  String country;
  String city;
  String buildingNumber;
  String postCode;
  String additionalNumber;
  String shortAddress;
  StoreData({
    required this.docId,
    required this.storeCode,
    required this.storeName,
    required this.subName,
    required this.address,
    required this.phone1,
    required this.phone2,
    required this.email,
    required this.vatNumber,
    required this.crNumber,
    required this.priceLevel,
    required this.bankName,
    required this.accountNumber,
    required this.note,
    required this.isEnabled,
    required this.logoPath,
    required this.storeArabicName,
    required this.storeDocumentData,
    required this.street,
    required this.area,
    required this.country,
    required this.city,
    required this.buildingNumber,
    required this.postCode,
    required this.additionalNumber,
    required this.shortAddress,
  });

  Map<dynamic, dynamic> toMap() {
    return <dynamic, dynamic>{
      'docId': docId,
      'storeCode': storeCode,
      'storeName': storeName,
      'subName': subName,
      'address': address,
      'phone1': phone1,
      'phone2': phone2,
      'email': email,
      'vatNumber': vatNumber,
      'crNumber': crNumber,
      'priceLevel': priceLevel,
      'bankName': bankName,
      'accountNumber': accountNumber,
      'isEnabled': isEnabled,
      'logoPath': logoPath,
      'note': note,
      'storeArabicName': storeArabicName,
      'storeDocumentData': storeDocumentData.map((x) => x.toMap()).toList(),
      'street': street,
      'area': area,
      'country': country,
      'city': city,
      'buildingNumber': buildingNumber,
      'postCode': postCode,
      'additionalNumber': additionalNumber,
      'shortAddress': shortAddress,
    };
  }

  factory StoreData.fromMap(Map<dynamic, dynamic> map) {
    return StoreData(
      docId: map['docId'] as String,
      note: map['note'] ?? '',
      storeCode: map['storeCode'] as String,
      storeName: map['storeName'] as String,
      subName: map['subName'] as String,
      address: map['address'] as String,
      phone1: map['phone1'] as String,
      phone2: map['phone2'] as String,
      email: map['email'] as String,
      vatNumber: map['vatNumber'] as String,
      crNumber: map['crNumber'] as String,
      priceLevel: map['priceLevel'] as String,
      bankName: map['bankName'] as String,
      accountNumber: map['accountNumber'] as String,
      isEnabled: map['isEnabled'] as bool,
      logoPath: map['logoPath'] as String,
      storeDocumentData: List<StoreDocumentData>.from(
        (map['storeDocumentData'] as List).map<StoreDocumentData>(
          (x) => StoreDocumentData.fromMap(x as Map<dynamic, dynamic>),
        ),
      ),
      storeArabicName: map['storeArabicName'] ?? '',
      //new fields
      street: map['street'] ?? '',
      area: map['area'] ?? '',
      country: map['country'] ?? '',
      city: map['city'] ?? '',
      buildingNumber: map['buildingNumber'] ?? '',
      postCode: map['postCode'] ?? '',
      additionalNumber: map['additionalNumber'] ?? '',
      shortAddress: map['shortAddress'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory StoreData.fromJson(String source) =>
      StoreData.fromMap(json.decode(source) as Map<dynamic, dynamic>);
}

class StoreDocumentData {
  String docId;
  String documentName;
  String? documentNumber;
  String? documentIssueDate;
  String? documentExpiryDate;
  String? documentFilePath;
  bool saveit;
  bool donNotAllowDeleting;
  StoreDocumentData(
      {required this.documentName,
      required this.docId,
      required this.documentNumber,
      required this.documentIssueDate,
      required this.documentExpiryDate,
      required this.documentFilePath,
      this.saveit = false,
      this.donNotAllowDeleting = false});

  Map<dynamic, dynamic> toMap() {
    return <dynamic, dynamic>{
      'docId': docId,
      'documentName': documentName,
      'documentNumber': documentNumber,
      'documentIssueDate': documentIssueDate,
      'documentExpiryDate': documentExpiryDate,
      'documentFilePath': documentFilePath,
      'saveit': saveit,
    };
  }

  factory StoreDocumentData.fromMap(Map<dynamic, dynamic> map) {
    return StoreDocumentData(
      docId: map['docId'] as String,
      documentName: map['documentName'] as String,
      documentNumber: map['documentNumber'] != null
          ? map['documentNumber'] as String
          : null,
      documentIssueDate: map['documentIssueDate'] != null
          ? map['documentIssueDate'] as String
          : null,
      documentExpiryDate: map['documentExpiryDate'] != null
          ? map['documentExpiryDate'] as String
          : null,
      documentFilePath: map['documentFilePath'] != null
          ? map['documentFilePath'] as String
          : null,
      saveit: map['saveit'] as bool,
    );
  }

  String toJson() => json.encode(toMap());

  factory StoreDocumentData.fromJson(String source) =>
      StoreDocumentData.fromMap(json.decode(source) as Map<dynamic, dynamic>);
}
