// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class LicenseSettingData {
  String key;
  String auth;
  String windownsProductId;
  DateTime expiry_date;
  bool showLicenseKeyError;
  bool showLicenseAuthError;
  LicenseSettingData(
      {required this.key,
      required this.auth,
      required this.expiry_date,
      required this.windownsProductId,
      required this.showLicenseAuthError,
      required this.showLicenseKeyError});

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'key': key,
      'auth': auth,
      'expiry_date': expiry_date.toString(),
      'windownsProductId': windownsProductId,
    };
  }

  factory LicenseSettingData.fromMap(Map<dynamic, dynamic> map) {
    return LicenseSettingData(
      key: map['key'] as String,
      auth: map['auth'] as String,
      windownsProductId: map['windownsProductId'],
      showLicenseAuthError: false,
      showLicenseKeyError: false,
      expiry_date: DateTime.parse(map['expiry_date'].toString()),
    );
  }

  String toJson() => json.encode(toMap());

  factory LicenseSettingData.fromJson(String source) =>
      LicenseSettingData.fromMap(json.decode(source) as Map<String, dynamic>);
}
