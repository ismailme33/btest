import 'dart:convert';

// ignore_for_file: public_member_api_docs, sort_constructors_first
class TaxSettingsData {
  double taxPercentage;
  TaxSettingsData({
    required this.taxPercentage,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'taxPercentage': taxPercentage,
    };
  }

  factory TaxSettingsData.fromMap(Map<dynamic, dynamic> map) {
    return TaxSettingsData(
      taxPercentage: double.tryParse(map['taxPercentage'].toString()) ?? 0,
    );
  }

  String toJson() => json.encode(toMap());

  factory TaxSettingsData.fromJson(String source) =>
      TaxSettingsData.fromMap(json.decode(source) as Map<String, dynamic>);
}
