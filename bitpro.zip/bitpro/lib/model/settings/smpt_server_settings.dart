import 'dart:convert';

// ignore_for_file: public_member_api_docs, sort_constructors_first
class SmptServerSettings {
  String server;
  String username;
  String password;
  String port;
  bool isSSLEnabled;
  String senderEmailName;

  //
  bool enableSaveAndSendEmailButton;
  bool sendToEmailWhilePrintAndUpdate;
  SmptServerSettings({
    required this.server,
    required this.username,
    required this.password,
    required this.port,
    required this.isSSLEnabled,
    required this.senderEmailName,
    required this.enableSaveAndSendEmailButton,
    required this.sendToEmailWhilePrintAndUpdate,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'server': server,
      'username': username,
      'password': password,
      'port': port,
      'isSSLEnabled': isSSLEnabled,
      'senderEmailName': senderEmailName,
      'enableSaveAndSendEmailButton': enableSaveAndSendEmailButton,
      'sendToEmailWhilePrintAndUpdate': sendToEmailWhilePrintAndUpdate,
    };
  }

  factory SmptServerSettings.fromMap(Map<dynamic, dynamic> map) {
    return SmptServerSettings(
      server: map['server'] as String,
      username: map['username'] as String,
      password: map['password'] as String,
      port: map['port'] as String,
      isSSLEnabled: map['isSSLEnabled'] as bool,
      senderEmailName: map['senderEmailName'] as String,
      enableSaveAndSendEmailButton: map['enableSaveAndSendEmailButton'] as bool,
      sendToEmailWhilePrintAndUpdate:
          map['sendToEmailWhilePrintAndUpdate'] as bool,
    );
  }

  String toJson() => json.encode(toMap());

  factory SmptServerSettings.fromJson(String source) =>
      SmptServerSettings.fromMap(json.decode(source) as Map<String, dynamic>);
}
