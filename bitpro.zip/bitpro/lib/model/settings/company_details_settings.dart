// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class CompanyDetailsSettings {
  String companyName;
  int? selectedStoreCode;
  int? workstationNumber;
  CompanyDetailsSettings(
      {required this.companyName,
      required this.selectedStoreCode,
      required this.workstationNumber});

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'companyName': companyName,
      'selectedStoreCode': selectedStoreCode,
      'workstationNumber': workstationNumber
    };
  }

  factory CompanyDetailsSettings.fromMap(Map<dynamic, dynamic> map) {
    return CompanyDetailsSettings(
      companyName: map['companyName'] as String,
      selectedStoreCode: map['workstationNumber'],
      workstationNumber: map['workstationNumber'],
    );
  }

  String toJson() => json.encode(toMap());

  factory CompanyDetailsSettings.fromJson(String source) =>
      CompanyDetailsSettings.fromMap(
          json.decode(source) as Map<String, dynamic>);
}
