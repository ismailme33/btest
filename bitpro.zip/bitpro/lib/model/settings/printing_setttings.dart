import 'package:printing/printing.dart';

class PrintingSetttings {
  Printer? selectedPrinter;
  String selectedReceiptTemplate;
  String selectedQuotationTemplate;

  String receiptTitleEng;
  String receiptTitleArb;

  String receiptFotterEng;
  String receiptFotterArb;

  String headerImgPath;
  String fotterImgPath;
  PrintingSetttings({
    this.selectedPrinter,
    required this.selectedReceiptTemplate,
    required this.selectedQuotationTemplate,
    required this.receiptTitleEng,
    required this.receiptTitleArb,
    required this.receiptFotterEng,
    required this.receiptFotterArb,
    required this.headerImgPath,
    required this.fotterImgPath,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'selectedPrinter': selectedPrinter?.toMap(),
      'selectedReceiptTemplate': selectedReceiptTemplate,
      'receiptTitleEng': receiptTitleEng,
      'receiptTitleArb': receiptTitleArb,
      'receiptFotterEng': receiptFotterEng,
      'receiptFotterArb': receiptFotterArb,
      'headerImgPath': headerImgPath,
      'fotterImgPath': fotterImgPath,
      'selectedQuotationTemplate': selectedQuotationTemplate
    };
  }

  factory PrintingSetttings.fromMap(Map<dynamic, dynamic> map,
      {required List<Printer> allPrinterLst}) {
    Printer selectedPrinter = const Printer(
        url: 'Select Printer While Printing',
        name: 'Select Printer While Printing');
    if (allPrinterLst.isNotEmpty && map['selectedPrinter'] != null) {
      Printer mp = Printer.fromMap(map['selectedPrinter']);
      for (var t in allPrinterLst) {
        if (t.name == mp.name) {
          selectedPrinter = t;
        }
      }
    }
    return PrintingSetttings(
      selectedQuotationTemplate:
          map['selectedQuotationTemplate'] ?? 'DES0003-A4',
      selectedPrinter: selectedPrinter,
      selectedReceiptTemplate: map['selectedReceiptTemplate'] as String,
      receiptTitleEng: map['receiptTitleEng'] as String,
      receiptTitleArb: map['receiptTitleArb'] as String,
      receiptFotterEng: map['receiptFotterEng'] as String,
      receiptFotterArb: map['receiptFotterArb'] as String,
      headerImgPath: map['headerImgPath'] ?? '',
      fotterImgPath: map['fotterImgPath'] ?? '',
    );
  }
}
