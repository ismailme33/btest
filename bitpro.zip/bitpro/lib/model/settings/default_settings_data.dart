import 'dart:convert';

class GeneralSettingsData {
  int expiryNotificationDays;
  bool isHijriDateEnable;
  //
  bool showBarcodeInReceiptCreate;
  bool showItemCodeInReceiptCreate;

  bool showOriginalPriceInReceiptCreate;

  bool showOverallDiscountInReceiptCreate;
  bool showOverallDiscountPerTabInReceiptCreate;

  GeneralSettingsData({
    required this.expiryNotificationDays,
    required this.isHijriDateEnable,
    required this.showBarcodeInReceiptCreate,
    required this.showItemCodeInReceiptCreate,
    required this.showOriginalPriceInReceiptCreate,
    required this.showOverallDiscountInReceiptCreate,
    required this.showOverallDiscountPerTabInReceiptCreate,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'expiryNotificationDays': expiryNotificationDays,
      'isHijriDateEnable': isHijriDateEnable,
      'showBarcodeInReceiptCreate': showBarcodeInReceiptCreate,
      'showItemCodeInReceiptCreate': showItemCodeInReceiptCreate,
      'showOriginalPriceInReceiptCreate': showOriginalPriceInReceiptCreate,
      'showOverallDiscountInReceiptCreate': showOverallDiscountInReceiptCreate,
      'showOverallDiscountPerTabInReceiptCreate':
          showOverallDiscountPerTabInReceiptCreate,
    };
  }

  factory GeneralSettingsData.fromMap(Map<dynamic, dynamic> map) {
    return GeneralSettingsData(
      expiryNotificationDays: map['expiryNotificationDays'] as int,
      isHijriDateEnable: map['isHijriDateEnable'] as bool,
      showBarcodeInReceiptCreate: map['showBarcodeInReceiptCreate'] as bool,
      showItemCodeInReceiptCreate: map['showItemCodeInReceiptCreate'] as bool,
      showOriginalPriceInReceiptCreate:
          map['showOriginalPriceInReceiptCreate'] as bool,
      showOverallDiscountInReceiptCreate:
          map['showOverallDiscountInReceiptCreate'] as bool,
      showOverallDiscountPerTabInReceiptCreate:
          map['showOverallDiscountPerTabInReceiptCreate'] as bool,
    );
  }

  String toJson() => json.encode(toMap());

  factory GeneralSettingsData.fromJson(String source) =>
      GeneralSettingsData.fromMap(json.decode(source) as Map<String, dynamic>);
}
