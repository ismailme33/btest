// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class ReceiptSettingData {
  Map<dynamic, dynamic> paymentTypeList;
  bool inTenderUseAdvancePayment;
  int priceCanChangeSelectTabIndex;
  bool isVendorMandatory;
  bool isDepartmentMandatory;
  bool showCustomCrateDate;
  ReceiptSettingData({
    required this.paymentTypeList,
    required this.inTenderUseAdvancePayment,
    required this.priceCanChangeSelectTabIndex,
    required this.isVendorMandatory,
    required this.isDepartmentMandatory,
    required this.showCustomCrateDate,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'paymentTypeList': paymentTypeList,
      'inTenderUseAdvancePayment': inTenderUseAdvancePayment,
      'priceCanChangeSelectTabIndex': priceCanChangeSelectTabIndex,
      'isVendorMandatory': isVendorMandatory,
      'isDepartmentMandatory': isDepartmentMandatory,
      'showCustomCrateDate': showCustomCrateDate,
    };
  }

  factory ReceiptSettingData.fromMap(Map<dynamic, dynamic> map) {
    return ReceiptSettingData(
      paymentTypeList: map['paymentTypeList'],
      inTenderUseAdvancePayment: map['inTenderUseAdvancePayment'] as bool,
      priceCanChangeSelectTabIndex: map['priceCanChangeSelectTabIndex'] as int,
      isVendorMandatory: map['isVendorMandatory'] as bool,
      isDepartmentMandatory: map['isDepartmentMandatory'] as bool,
      showCustomCrateDate: map['showCustomCrateDate'] ?? false,
    );
  }

  String toJson() => json.encode(toMap());

  factory ReceiptSettingData.fromJson(String source) =>
      ReceiptSettingData.fromMap(json.decode(source) as Map<String, dynamic>);
}
