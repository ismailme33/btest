import 'dart:convert';

class FormerZOutData {
  String formerZoutNo;
  String cashierName;
  String openDate;
  String closeDate;
  String docId;

  String total;
  String overShort;

  String totalCashOnSystem;
  String totalCashEntered;

  String creditCardTotalInSystem;

  DateTime? fbUploadedDate;
  DateTime? fbModifiedDate;
  String selectedStoreDocId;
  Map<dynamic, dynamic> allPaymentMethodsTotals;
  //not used
  String totalCashDifferences;
  String totalNCDifferences;
  FormerZOutData({
    required this.formerZoutNo,
    required this.total,
    required this.cashierName,
    required this.overShort,
    required this.totalCashOnSystem,
    required this.totalCashEntered,
    required this.totalCashDifferences,
    required this.totalNCDifferences,
    required this.openDate,
    required this.closeDate,
    required this.creditCardTotalInSystem,
    required this.docId,
    this.fbUploadedDate,
    this.fbModifiedDate,
    required this.selectedStoreDocId,
    required this.allPaymentMethodsTotals,
  });

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};

    result.addAll({
      'fbUploadedDate': fbUploadedDate == null ? '' : fbUploadedDate.toString()
    });
    result.addAll({
      'fbModifiedDate': fbModifiedDate == null ? '' : fbModifiedDate.toString()
    });
    result.addAll({
      'selectedStoreDocId': selectedStoreDocId,
    });

    result.addAll({'allPaymentMethodsTotals': allPaymentMethodsTotals});

    result.addAll({'formerZoutNo': formerZoutNo});
    result.addAll({'total': total});
    result.addAll({'cashierName': cashierName});
    result.addAll({'overShort': overShort});
    result.addAll({'totalCashOnSystem': totalCashOnSystem});
    result.addAll({'totalCashEntered': totalCashEntered});
    result.addAll({'totalCashDifferences': totalCashDifferences});
    result.addAll({'totalNCDifferences': totalNCDifferences});
    result.addAll({'openDate': openDate});
    result.addAll({'closeDate': closeDate});
    result.addAll({'creditCardTotalInSystem': creditCardTotalInSystem});

    result.addAll({'docId': docId});

    return result;
  }

  factory FormerZOutData.fromMap(Map<dynamic, dynamic> map) {
    return FormerZOutData(
      allPaymentMethodsTotals: map['allPaymentMethodsTotals'],
      fbUploadedDate: DateTime.tryParse(map['fbUploadedDate'] ?? ''),
      fbModifiedDate: DateTime.tryParse(map['fbModifiedDate'] ?? ''),
      selectedStoreDocId: map['selectedStoreDocId'],
      formerZoutNo: map['formerZoutNo'] ?? '',
      total: map['total'] ?? '',
      cashierName: map['cashierName'] ?? '',
      overShort: map['overShort'] ?? '',
      totalCashOnSystem: map['totalCashOnSystem'] ?? '',
      totalCashEntered: map['totalCashEntered'] ?? '',
      totalCashDifferences: map['totalCashDifferences'] ?? '',
      totalNCDifferences: map['totalNCDifferences'] ?? '',
      openDate: map['openDate'] ?? '',
      closeDate: map['closeDate'] ?? '',
      creditCardTotalInSystem: map['creditCardTotalInSystem'] ?? '',
      docId: map['docId'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory FormerZOutData.fromJson(String source) =>
      FormerZOutData.fromMap(json.decode(source));
}
