import 'dart:convert';
import 'package:bitpro_hive/model/voucher/db_voucher_data.dart';

class VendorPaymentData {
  String docId;
  String vendorId;
  String paymentType;
  double amount;
  DateTime createdDate;
  String comment;
  String documentNo;

  DateTime? fbModifiedDate;
  DateTime? fbUploadedDate;
  String selectedStoreDocId;

  VendorPaymentData({
    this.fbUploadedDate,
    required this.selectedStoreDocId,
    required this.docId,
    required this.vendorId,
    required this.paymentType,
    required this.amount,
    required this.createdDate,
    required this.comment,
    required this.documentNo,
    this.fbModifiedDate,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'fbUploadedDate': fbUploadedDate == null ? '' : fbUploadedDate.toString(),
      'docId': docId,
      'selectedStoreDocId': selectedStoreDocId,
      'vendorId': vendorId,
      'paymentType': paymentType,
      'fbModifiedDate': fbModifiedDate == null ? '' : fbModifiedDate.toString(),
      'amount': amount,
      'createdDate': createdDate.millisecondsSinceEpoch,
      'comment': comment,
      'documentNo': documentNo,
    };
  }

  factory VendorPaymentData.fromMap(Map<dynamic, dynamic> map) {
    return VendorPaymentData(
      selectedStoreDocId: map['selectedStoreDocId'],
      fbUploadedDate: DateTime.tryParse(map['fbUploadedDate'] ?? ''),
      fbModifiedDate: DateTime.tryParse(map['fbModifiedDate'] ?? ''),
      docId: map['docId'] as String,
      vendorId: map['vendorId'] as String,
      paymentType: map['paymentType'] as String,
      amount: map['amount'] as double,
      createdDate: DateTime.tryParse(map['createdDate'].toString()) ??
          DateTime.fromMillisecondsSinceEpoch(map['createdDate'] as int),
      comment: map['comment'] as String,
      documentNo: map['documentNo'] as String,
    );
  }

  String toJson() => json.encode(toMap());

  factory VendorPaymentData.fromJson(String source) =>
      VendorPaymentData.fromMap(json.decode(source) as Map<String, dynamic>);
}

class VendorPaymentTempModel {
  DateTime dateTime;
  VendorPaymentData? vendorPaymentData;
  DbVoucherData? dbVoucherData;
  VendorPaymentTempModel({
    required this.dateTime,
    this.vendorPaymentData,
    this.dbVoucherData,
  });
}
