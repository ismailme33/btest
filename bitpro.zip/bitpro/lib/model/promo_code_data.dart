import 'dart:convert';

class PromoData {
  String promoNo;

  DateTime startDate;
  DateTime endDate;

  String barcode;
  String percentage;

  String docId;

  DateTime? fbModifiedDate;
  DateTime? fbUploadedDate;
  String selectedStoreDocId;

  PromoData({
    required this.selectedStoreDocId,
    this.fbUploadedDate,
    this.fbModifiedDate,
    required this.promoNo,
    required this.startDate,
    required this.endDate,
    required this.barcode,
    required this.percentage,
    required this.docId,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'selectedStoreDocId': selectedStoreDocId,
      'fbUploadedDate': fbUploadedDate == null ? '' : fbUploadedDate.toString(),
      'fbModifiedDate': fbModifiedDate == null ? '' : fbModifiedDate.toString(),
      'promoNo': promoNo,
      'startDate': startDate.millisecondsSinceEpoch,
      'endDate': endDate.millisecondsSinceEpoch,
      'barcode': barcode,
      'percentage': percentage,
      'docId': docId,
    };
  }

  factory PromoData.fromMap(Map<dynamic, dynamic> map) {
    return PromoData(
      fbUploadedDate: DateTime.tryParse(map['fbUploadedDate'] ?? ''),
      fbModifiedDate: DateTime.tryParse(map['fbModifiedDate'] ?? ''),
      selectedStoreDocId: map['selectedStoreDocId'],
      promoNo: map['promoNo'] as String,
      startDate: DateTime.tryParse(map['startDate'].toString()) ??
          DateTime.fromMillisecondsSinceEpoch(map['startDate'] as int),
      endDate: DateTime.tryParse(map['endDate'].toString()) ??
          DateTime.fromMillisecondsSinceEpoch(map['endDate'] as int),
      barcode: map['barcode'] as String,
      percentage: map['percentage'] as String,
      docId: map['docId'] as String,
    );
  }

  String toJson() => json.encode(toMap());

  factory PromoData.fromJson(String source) =>
      PromoData.fromMap(json.decode(source) as Map<String, dynamic>);
}
