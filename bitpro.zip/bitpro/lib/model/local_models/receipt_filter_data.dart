class ReceiptFilterData {
  DateTime? rangeStartDate;
  DateTime? rangeEndDate;
  String selectedReturnTypeName;
  String selectedStoreDocId;
  String customerName;
  String receiptId;
  ReceiptFilterData({
    this.rangeStartDate,
    this.rangeEndDate,
    required this.selectedReturnTypeName,
    required this.selectedStoreDocId,
    required this.customerName,
    required this.receiptId,
  });
}
