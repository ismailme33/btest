import 'dart:convert';

class DepartmentData {
  String docId;
  String departmentName;
  String departmentId;

  DateTime createdDate;

  DateTime? fbModifiedDate;
  DateTime? fbUploadedDate;
  String selectedStoreDocId;

  String createdBy;

  DepartmentData({
    this.fbUploadedDate,
    required this.docId,
    this.fbModifiedDate,
    required this.selectedStoreDocId,
    required this.departmentName,
    required this.departmentId,
    required this.createdDate,
    required this.createdBy,
  });

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};
    result.addAll({
      'fbUploadedDate': fbUploadedDate == null ? '' : fbUploadedDate.toString()
    });
    result.addAll({
      'fbModifiedDate': fbModifiedDate == null ? '' : fbModifiedDate.toString()
    });
    result.addAll({
      'selectedStoreDocId': selectedStoreDocId,
    });
    result.addAll({'docId': docId});
    result.addAll({'departmentName': departmentName});
    result.addAll({'departmentId': departmentId});
    result.addAll({'createdDate': createdDate.toString()});
    result.addAll({'createdBy': createdBy});

    return result;
  }

  factory DepartmentData.fromMap(Map<dynamic, dynamic> map) {
    return DepartmentData(
      fbUploadedDate: DateTime.tryParse(map['fbUploadedDate'] ?? ''),
      fbModifiedDate: DateTime.tryParse(map['fbModifiedDate'] ?? ''),
      selectedStoreDocId: map['selectedStoreDocId'],
      docId: map['docId'] ?? '',
      departmentName: map['departmentName'] ?? '',
      departmentId: map['departmentId'] ?? '',
      createdDate: DateTime.tryParse(map['createdDate'].toString()) ??
          DateTime.fromMillisecondsSinceEpoch(map['createdDate'] as int),
      createdBy: map['createdBy'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory DepartmentData.fromJson(String source) =>
      DepartmentData.fromMap(json.decode(source));
}
