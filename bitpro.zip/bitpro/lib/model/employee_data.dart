// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

class EmployeeData {
  EmpBasicInfoData empBasicInfoData;
  EmpWorkAndRolesData empWorkAndRolesData;
  EmpPersonalData empPersonalData;
  List<EmpDocumentData> empDocumentDataLst;
  List<EmpCertificateData> empCertificateDataLst;
  List<EmpEducationData> empEducationDataLst;
  List<EmpDependentData> empDependentDataLst;
  List<EmpWorkExperienceData> empWorkExperienceDataLst;

  DateTime? openRegister;
  String docId;
  EmployeeData(
      {required this.empBasicInfoData,
      required this.empWorkAndRolesData,
      required this.empPersonalData,
      required this.empDocumentDataLst,
      required this.empCertificateDataLst,
      required this.empEducationDataLst,
      required this.empDependentDataLst,
      required this.empWorkExperienceDataLst,
      required this.openRegister,
      required this.docId});

  Map<dynamic, dynamic> toMap() {
    return <dynamic, dynamic>{
      'empBasicInfoData': empBasicInfoData.toMap(),
      'empWorkAndRolesData': empWorkAndRolesData.toMap(),
      'empPersonalData': empPersonalData.toMap(),
      'empDocumentDataLst': empDocumentDataLst.map((x) => x.toMap()).toList(),
      'empCertificateDataLst':
          empCertificateDataLst.map((x) => x.toMap()).toList(),
      'empEducationDataLst': empEducationDataLst.map((x) => x.toMap()).toList(),
      'empDependentDataLst': empDependentDataLst.map((x) => x.toMap()).toList(),
      'empWorkExperienceDataLst':
          empWorkExperienceDataLst.map((x) => x.toMap()).toList(),
      'openRegister': openRegister?.millisecondsSinceEpoch,
      'docId': docId,
    };
  }

  factory EmployeeData.fromMap(Map<dynamic, dynamic> map) {
    return EmployeeData(
      empBasicInfoData: EmpBasicInfoData.fromMap(
          map['empBasicInfoData'] as Map<dynamic, dynamic>),
      empWorkAndRolesData: EmpWorkAndRolesData.fromMap(
          map['empWorkAndRolesData'] as Map<dynamic, dynamic>),
      empPersonalData: EmpPersonalData.fromMap(
          map['empPersonalData'] as Map<dynamic, dynamic>),
      empDocumentDataLst: List<EmpDocumentData>.from(
        (map['empDocumentDataLst'] as List).map<EmpDocumentData>(
          (x) => EmpDocumentData.fromMap(x as Map<dynamic, dynamic>),
        ),
      ),
      empCertificateDataLst: List<EmpCertificateData>.from(
        (map['empCertificateDataLst'] as List).map<EmpCertificateData>(
          (x) => EmpCertificateData.fromMap(x as Map<dynamic, dynamic>),
        ),
      ),
      empEducationDataLst: List<EmpEducationData>.from(
        (map['empEducationDataLst'] as List).map<EmpEducationData>(
          (x) => EmpEducationData.fromMap(x as Map<dynamic, dynamic>),
        ),
      ),
      empDependentDataLst: List<EmpDependentData>.from(
        (map['empDependentDataLst'] as List).map<EmpDependentData>(
          (x) => EmpDependentData.fromMap(x as Map<dynamic, dynamic>),
        ),
      ),
      empWorkExperienceDataLst: List<EmpWorkExperienceData>.from(
        (map['empWorkExperienceDataLst'] as List).map<EmpWorkExperienceData>(
          (x) => EmpWorkExperienceData.fromMap(x as Map<dynamic, dynamic>),
        ),
      ),
      openRegister: map['openRegister'] != null
          ? DateTime.fromMillisecondsSinceEpoch(map['openRegister'] as int)
          : null,
      docId: map['docId'] as String,
    );
  }

  String toJson() => json.encode(toMap());

  factory EmployeeData.fromJson(String source) =>
      EmployeeData.fromMap(json.decode(source) as Map<dynamic, dynamic>);
}

class EmpBasicInfoData {
  String employeeId;

  ///active or inactive
  String employeedStatus;
  String firstName;
  String lastName;
  String? email;
  String? note;
  String username;
  String password;
  String createdDate;
  String createdBy;
  EmpBasicInfoData(
      {required this.employeeId,
      required this.employeedStatus,
      required this.firstName,
      required this.lastName,
      required this.email,
      required this.username,
      required this.password,
      required this.createdDate,
      required this.createdBy,
      required this.note});

  Map toMap() {
    return <dynamic, dynamic>{
      'employeedId': employeeId,
      'employeedStatus': employeedStatus,
      'firstName': firstName,
      'lastName': lastName,
      'email': email,
      'username': username,
      'password': password,
      'createdDate': createdDate,
      'createdBy': createdBy,
      'note': note,
    };
  }

  factory EmpBasicInfoData.fromMap(Map map) {
    return EmpBasicInfoData(
      employeeId: map['employeedId'] as String,
      employeedStatus: map['employeedStatus'] as String,
      firstName: map['firstName'] as String,
      lastName: map['lastName'] as String,
      email: map['email'] != null ? map['email'] as String : null,
      note: map['note'] != null ? map['note'] as String : null,
      username: map['username'] as String,
      password: map['password'] as String,
      createdDate: map['createdDate'] as String,
      createdBy: map['createdBy'] as String,
    );
  }

  String toJson() => json.encode(toMap());

  factory EmpBasicInfoData.fromJson(String source) =>
      EmpBasicInfoData.fromMap(json.decode(source) as Map);
}

class EmpWorkAndRolesData {
  String? assignedStoreDocId;
  String? department;
  String? position;
  String? title;
  String? discountPercentage;
  String userGroupId;
  String? dateOfJoining;
  String? employeeType;
  String? workingCity;
  String? workPhone;
  String? workMobilePhone;
  EmpWorkAndRolesData({
    required this.assignedStoreDocId,
    required this.department,
    required this.position,
    required this.title,
    required this.discountPercentage,
    required this.userGroupId,
    required this.dateOfJoining,
    required this.employeeType,
    required this.workingCity,
    required this.workPhone,
    required this.workMobilePhone,
  });

  Map toMap() {
    return <dynamic, dynamic>{
      'assignedStoreDocId': assignedStoreDocId,
      'department': department,
      'position': position,
      'title': title,
      'discountPercentage': discountPercentage,
      'userGroupId': userGroupId,
      'dateOfJoining': dateOfJoining,
      'employeeType': employeeType,
      'workingCity': workingCity,
      'workPhone': workPhone,
      'workMobilePhone': workMobilePhone,
    };
  }

  factory EmpWorkAndRolesData.fromMap(Map map) {
    return EmpWorkAndRolesData(
      assignedStoreDocId: map['assignedStoreDocId'] != null
          ? map['assignedStoreDocId'] as String
          : null,
      department:
          map['department'] != null ? map['department'] as String : null,
      position: map['position'] != null ? map['position'] as String : null,
      title: map['title'] != null ? map['title'] as String : null,
      discountPercentage: map['discountPercentage'] != null
          ? map['discountPercentage'] as String
          : null,
      userGroupId: map['userGroupId'] as String,
      dateOfJoining:
          map['dateOfJoining'] != null ? map['dateOfJoining'] as String : null,
      employeeType:
          map['employeeType'] != null ? map['employeeType'] as String : null,
      workingCity:
          map['workingCity'] != null ? map['workingCity'] as String : null,
      workPhone: map['workPhone'] != null ? map['workPhone'] as String : null,
      workMobilePhone: map['workMobilePhone'] != null
          ? map['workMobilePhone'] as String
          : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory EmpWorkAndRolesData.fromJson(String source) =>
      EmpWorkAndRolesData.fromMap(json.decode(source) as Map);
}

class EmpPersonalData {
  String? personalMobile;
  String? otherEmail;
  String? birthDate;
  String? gender;
  String? maritalStatus;
  String? citizenship;
  String? address;
  String? homeAddress;
  String? emergencyContactName;
  String? relationship;
  String? emergencyPhone;
  String? employeeImagePath;
  EmpPersonalData({
    required this.personalMobile,
    required this.otherEmail,
    required this.birthDate,
    required this.gender,
    required this.maritalStatus,
    required this.citizenship,
    required this.address,
    required this.homeAddress,
    required this.emergencyContactName,
    required this.relationship,
    required this.emergencyPhone,
    required this.employeeImagePath,
  });

  Map toMap() {
    return <dynamic, dynamic>{
      'personalMobile': personalMobile,
      'otherEmail': otherEmail,
      'birthDate': birthDate,
      'gender': gender,
      'maritalStatus': maritalStatus,
      'citizenship': citizenship,
      'address': address,
      'homeAddress': homeAddress,
      'emergencyContactName': emergencyContactName,
      'relationship': relationship,
      'emergencyPhone': emergencyPhone,
      'employeeImagePath': employeeImagePath,
    };
  }

  factory EmpPersonalData.fromMap(Map map) {
    return EmpPersonalData(
      personalMobile: map['personalMobile'] != null
          ? map['personalMobile'] as String
          : null,
      otherEmail:
          map['otherEmail'] != null ? map['otherEmail'] as String : null,
      birthDate: map['birthDate'] != null ? map['birthDate'] as String : null,
      gender: map['gender'] != null ? map['gender'] as String : null,
      maritalStatus:
          map['maritalStatus'] != null ? map['maritalStatus'] as String : null,
      citizenship:
          map['citizenship'] != null ? map['citizenship'] as String : null,
      address: map['address'] != null ? map['address'] as String : null,
      homeAddress:
          map['homeAddress'] != null ? map['homeAddress'] as String : null,
      emergencyContactName: map['emergencyContactName'] != null
          ? map['emergencyContactName'] as String
          : null,
      relationship:
          map['relationship'] != null ? map['relationship'] as String : null,
      emergencyPhone: map['emergencyPhone'] != null
          ? map['emergencyPhone'] as String
          : null,
      employeeImagePath: map['employeeImagePath'] != null
          ? map['employeeImagePath'] as String
          : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory EmpPersonalData.fromJson(String source) =>
      EmpPersonalData.fromMap(json.decode(source) as Map);
}

class EmpDocumentData {
  String docId;
  String documentName;
  String? documentNumber;
  String? documentIssueDate;
  String? documentExpiryDate;
  String? documentHijriExpiryDate;
  String? documentFilePath;
  bool saveit;
  bool donNotAllowDeleting;
  EmpDocumentData({
    required this.docId,
    required this.documentName,
    required this.documentNumber,
    required this.documentIssueDate,
    required this.documentExpiryDate,
    required this.documentHijriExpiryDate,
    required this.documentFilePath,
    this.saveit = false,
    this.donNotAllowDeleting = false,
  });

  Map<dynamic, dynamic> toMap() {
    return <dynamic, dynamic>{
      'docId': docId,
      'documentName': documentName,
      'documentNumber': documentNumber,
      'documentIssueDate': documentIssueDate,
      'documentExpiryDate': documentExpiryDate,
      'documentFilePath': documentFilePath,
      'documentHijriExpiryDate': documentHijriExpiryDate,
    };
  }

  factory EmpDocumentData.fromMap(Map<dynamic, dynamic> map) {
    return EmpDocumentData(
      docId: map['docId'] as String,
      documentName: map['documentName'] as String,
      documentNumber: map['documentNumber'] != null
          ? map['documentNumber'] as String
          : null,
      documentIssueDate: map['documentIssueDate'] != null
          ? map['documentIssueDate'] as String
          : null,
      documentExpiryDate: map['documentExpiryDate'] != null
          ? map['documentExpiryDate'] as String
          : null,
      documentHijriExpiryDate: map['documentHijriExpiryDate'] != null
          ? map['documentHijriExpiryDate'] as String
          : null,
      documentFilePath: map['documentFilePath'] != null
          ? map['documentFilePath'] as String
          : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory EmpDocumentData.fromJson(String source) =>
      EmpDocumentData.fromMap(json.decode(source) as Map<dynamic, dynamic>);
}

class EmpCertificateData {
  String certificationName;
  String docId;
  String? documentNumber;
  String? issueDate;
  String? expiryDate;
  String? documentFilePath;
  bool saveit;
  EmpCertificateData({
    required this.certificationName,
    required this.docId,
    required this.documentNumber,
    required this.issueDate,
    required this.expiryDate,
    required this.documentFilePath,
    this.saveit = false,
  });

  Map<dynamic, dynamic> toMap() {
    return <dynamic, dynamic>{
      'certificationName': certificationName,
      'docId': docId,
      'documentNumber': documentNumber,
      'issueDate': issueDate,
      'expiryDate': expiryDate,
      'documentFilePath': documentFilePath,
    };
  }

  factory EmpCertificateData.fromMap(Map<dynamic, dynamic> map) {
    return EmpCertificateData(
      certificationName: map['certificationName'] as String,
      docId: map['docId'] as String,
      documentNumber: map['documentNumber'] != null
          ? map['documentNumber'] as String
          : null,
      issueDate: map['issueDate'] != null ? map['issueDate'] as String : null,
      expiryDate:
          map['expiryDate'] != null ? map['expiryDate'] as String : null,
      documentFilePath: map['documentFilePath'] != null
          ? map['documentFilePath'] as String
          : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory EmpCertificateData.fromJson(String source) =>
      EmpCertificateData.fromMap(json.decode(source) as Map<dynamic, dynamic>);
}

class EmpEducationData {
  String docId;
  String schoolCollegeName;
  String? degreeDiplomaName;
  String? fieldsOfStudy;
  String? dateOfCompletion;
  String? documentFilePath;
  bool saveit;
  EmpEducationData({
    required this.docId,
    required this.schoolCollegeName,
    required this.degreeDiplomaName,
    required this.fieldsOfStudy,
    required this.dateOfCompletion,
    required this.documentFilePath,
    this.saveit = false,
  });

  Map<dynamic, dynamic> toMap() {
    return <dynamic, dynamic>{
      'docId': docId,
      'schoolCollegeName': schoolCollegeName,
      'degreeDiplomaName': degreeDiplomaName,
      'fieldsOfStudy': fieldsOfStudy,
      'dateOfCompletion': dateOfCompletion,
      'documentFilePath': documentFilePath,
    };
  }

  factory EmpEducationData.fromMap(Map<dynamic, dynamic> map) {
    return EmpEducationData(
      docId: map['docId'] as String,
      schoolCollegeName: map['schoolCollegeName'] as String,
      degreeDiplomaName: map['degreeDiplomaName'] != null
          ? map['degreeDiplomaName'] as String
          : null,
      fieldsOfStudy:
          map['fieldsOfStudy'] != null ? map['fieldsOfStudy'] as String : null,
      dateOfCompletion: map['dateOfCompletion'] != null
          ? map['dateOfCompletion'] as String
          : null,
      documentFilePath: map['documentFilePath'] != null
          ? map['documentFilePath'] as String
          : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory EmpEducationData.fromJson(String source) =>
      EmpEducationData.fromMap(json.decode(source) as Map<dynamic, dynamic>);
}

class EmpDependentData {
  String docId;
  String name;
  String? relationshipName;

  String? dateOfBirth;
  bool saveit;
  EmpDependentData({
    required this.docId,
    required this.name,
    required this.relationshipName,
    required this.dateOfBirth,
    this.saveit = false,
  });

  Map<dynamic, dynamic> toMap() {
    return <dynamic, dynamic>{
      'docId': docId,
      'name': name,
      'relationshipName': relationshipName,
      'dateOfBirth': dateOfBirth,
      'saveit': saveit,
    };
  }

  factory EmpDependentData.fromMap(Map<dynamic, dynamic> map) {
    return EmpDependentData(
      docId: map['docId'] as String,
      name: map['name'] as String,
      relationshipName: map['relationshipName'] != null
          ? map['relationshipName'] as String
          : null,
      dateOfBirth:
          map['dateOfBirth'] != null ? map['dateOfBirth'] as String : null,
      saveit: map['saveit'] as bool,
    );
  }

  String toJson() => json.encode(toMap());

  factory EmpDependentData.fromJson(String source) =>
      EmpDependentData.fromMap(json.decode(source) as Map<dynamic, dynamic>);
}

class EmpWorkExperienceData {
  String docId;
  String previousCompanyName;
  String? jobTitle;

  String? fromDate;
  String? toDate;
  String? documentFilePath;
  bool saveit;
  EmpWorkExperienceData({
    required this.docId,
    required this.previousCompanyName,
    required this.jobTitle,
    required this.fromDate,
    required this.toDate,
    required this.documentFilePath,
    this.saveit = false,
  });

  Map<dynamic, dynamic> toMap() {
    return <dynamic, dynamic>{
      'docId': docId,
      'previousCompanyName': previousCompanyName,
      'jobTitle': jobTitle,
      'fromDate': fromDate,
      'toDate': toDate,
      'documentFilePath': documentFilePath,
      'saveit': saveit,
    };
  }

  factory EmpWorkExperienceData.fromMap(Map<dynamic, dynamic> map) {
    return EmpWorkExperienceData(
      docId: map['docId'] as String,
      previousCompanyName: map['previousCompanyName'] as String,
      jobTitle: map['jobTitle'] != null ? map['jobTitle'] as String : null,
      fromDate: map['fromDate'] != null ? map['fromDate'] as String : null,
      toDate: map['toDate'] != null ? map['toDate'] as String : null,
      documentFilePath: map['documentFilePath'] != null
          ? map['documentFilePath'] as String
          : null,
      saveit: map['saveit'] as bool,
    );
  }

  String toJson() => json.encode(toMap());

  factory EmpWorkExperienceData.fromJson(String source) =>
      EmpWorkExperienceData.fromMap(
          json.decode(source) as Map<dynamic, dynamic>);
}
