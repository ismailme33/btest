import 'dart:convert';

import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';

String correctNumber(String val) {
  return doubleToString(double.tryParse(val) ?? 0);
}

class SpecificationData {
  String sphRight;
  String sphLeft;

  String cylRight;
  String cylLeft;
  String axisRight;
  String axisLeft;
  String ipd;
  String add;
  SpecificationData({
    required this.sphRight,
    required this.sphLeft,
    required this.cylRight,
    required this.cylLeft,
    required this.axisRight,
    required this.axisLeft,
    required this.ipd,
    required this.add,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'sphRight': sphRight,
      'sphLeft': sphLeft,
      'cylRight': cylRight,
      'cylLeft': cylLeft,
      'axisRight': axisRight,
      'axisLeft': axisLeft,
      'ipd': ipd,
      'add': add,
    };
  }

  factory SpecificationData.fromMap(Map map) {
    return SpecificationData(
      sphRight: map['sphRight'] as String,
      sphLeft: map['sphLeft'] as String,
      cylRight: map['cylRight'] as String,
      cylLeft: map['cylLeft'] as String,
      axisRight: map['axisRight'] as String,
      axisLeft: map['axisLeft'] as String,
      ipd: map['ipd'] as String,
      add: map['add'] as String,
    );
  }

  String toJson() => json.encode(toMap());

  factory SpecificationData.fromJson(String source) =>
      SpecificationData.fromMap(json.decode(source) as Map<String, dynamic>);
}
