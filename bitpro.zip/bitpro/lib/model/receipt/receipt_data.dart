// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_item_total_data.dart';
import 'package:bitpro_hive/model/specification_data.dart';

class ReceiptOrQuotationData {
  bool isQuotation;
  String docId;
  DateTime createdDate;
  String createdBy;
  List<LineItemData> lineItemsData;
  LineItemTotalData lineItemTotalData;

  // InvoiceBasicInfo? invoiceBasicInfo;
  QuotationBasicInfo? quotationBasicInfo;
  ReceiptBasicInfo? receiptBasicInfo;

  ReceiptOrQuotationData({
    required this.isQuotation,
    required this.docId,
    required this.createdDate,
    required this.createdBy,
    required this.lineItemsData,
    required this.lineItemTotalData,
    required this.quotationBasicInfo,
    required this.receiptBasicInfo,
    // required this.invoiceBasicInfo,
  });

  bool isInvoiceFinilized() =>
      isInvoiceType() && receiptBasicInfo!.invoiceData!.isFinialized;

  bool isQuotationType() => quotationBasicInfo != null;
  bool isReceiptType() => receiptBasicInfo != null;
  bool isInvoiceType() =>
      receiptBasicInfo != null && receiptBasicInfo!.invoiceData != null;

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'isQuotation': isQuotation,
      'docId': docId,
      'createdDate': createdDate.millisecondsSinceEpoch,
      'createdBy': createdBy,
      'lineItemsData': lineItemsData.map((x) => x.toMap()).toList(),
      'lineItemTotalData': lineItemTotalData.toMap(),
      'quotationBasicInfo': quotationBasicInfo?.toMap(),
      'receiptBasicInfo': receiptBasicInfo?.toMap(),
    };
  }

  factory ReceiptOrQuotationData.fromMap(Map<dynamic, dynamic> map) {
    return ReceiptOrQuotationData(
      isQuotation: map['isQuotation'] as bool,
      docId: map['docId'] as String,
      createdDate: DateTime.tryParse(map['createdDate'].toString()) ??
          DateTime.fromMillisecondsSinceEpoch(map['createdDate'] as int),
      createdBy: map['createdBy'] as String,
      lineItemsData: map['lineItemsData']
          .map<LineItemData>(
            (x) => LineItemData.fromMap(x),
          )
          .toList(),
      lineItemTotalData: LineItemTotalData.fromMap(map['lineItemTotalData']),
      quotationBasicInfo: map['quotationBasicInfo'] == null
          ? null
          : QuotationBasicInfo.fromMap(map['quotationBasicInfo']),
      receiptBasicInfo: map['receiptBasicInfo'] == null
          ? null
          : ReceiptBasicInfo.fromMap(map['receiptBasicInfo']),
    );
  }

  String toJson() => json.encode(toMap());

  factory ReceiptOrQuotationData.fromJson(String source) =>
      ReceiptOrQuotationData.fromMap(
          json.decode(source) as Map<String, dynamic>);
}

class QuotationBasicInfo {
  String quotationNo;
  String selectedCustomerID;

  String cartDiscountPercentage;
  String cartDiscountValue;

  String selectedStoreDocId;

  String receiptType;
  String referenceNo;
  String selectedCustomerBranchDocId;
  SpecificationData? specificationInfo;
  QuotationBasicInfo({
    required this.selectedCustomerBranchDocId,
    required this.quotationNo,
    required this.selectedCustomerID,
    required this.cartDiscountPercentage,
    required this.cartDiscountValue,
    required this.selectedStoreDocId,
    required this.receiptType,
    required this.referenceNo,
    required this.specificationInfo,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'quotationNo': quotationNo,
      'selectedCustomerID': selectedCustomerID,
      'cartDiscountPercentage': cartDiscountPercentage,
      'cartDiscountValue': cartDiscountValue,
      'selectedStoreDocId': selectedStoreDocId,
      'receiptType': receiptType,
      'referenceNo': referenceNo,
      'selectedCustomerBranchDocId': selectedCustomerBranchDocId,
      'specificationInfo': specificationInfo?.toMap(),
    };
  }

  factory QuotationBasicInfo.fromMap(Map<dynamic, dynamic> map) {
    return QuotationBasicInfo(
      selectedCustomerBranchDocId: map['selectedCustomerBranchDocId'] ?? '',
      quotationNo: map['quotationNo'] as String,
      selectedCustomerID: map['selectedCustomerID'] ?? '',
      cartDiscountPercentage: map['cartDiscountPercentage'] as String,
      cartDiscountValue: map['cartDiscountValue'] as String,
      selectedStoreDocId: map['selectedStoreDocId'] as String,
      receiptType: map['receiptType'] as String,
      referenceNo: map['referenceNo'] as String,
      specificationInfo: map['specificationInfo'] != null
          ? SpecificationData.fromMap(
              map['specificationInfo'] as Map<String, dynamic>)
          : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory QuotationBasicInfo.fromJson(String source) =>
      QuotationBasicInfo.fromMap(json.decode(source) as Map<String, dynamic>);
}

class ReceiptBasicInfo {
  String receiptNo;
  String selectedCustomerID;

  String selectedCustomerBranchDocId;

  String cartDiscountPercentage;
  String cartDiscountValue;

  String selectedStoreDocId;

  String receiptType;

  String referenceNo;
  SpecificationData? specificationInfo;
  bool isAdvancePaymentEnabled;

  //totals
  String receiptDue;
  String receiptBalance;

  Map<dynamic, dynamic> allPaymentMethodAmountsInfo;

  InvoiceData? invoiceData;
  ReceiptBasicInfo(
      {required this.receiptNo,
      required this.selectedCustomerID,
      required this.selectedCustomerBranchDocId,
      required this.cartDiscountPercentage,
      required this.cartDiscountValue,
      required this.selectedStoreDocId,
      required this.receiptType,
      required this.referenceNo,
      required this.specificationInfo,
      required this.isAdvancePaymentEnabled,
      required this.receiptDue,
      required this.receiptBalance,
      required this.allPaymentMethodAmountsInfo,
      this.invoiceData});

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'receiptNo': receiptNo,
      'selectedCustomerID': selectedCustomerID,
      'selectedCustomerBranchDocId': selectedCustomerBranchDocId,
      'cartDiscountPercentage': cartDiscountPercentage,
      'cartDiscountValue': cartDiscountValue,
      'selectedStoreDocId': selectedStoreDocId,
      'receiptType': receiptType,
      'referenceNo': referenceNo,
      'specificationInfo': specificationInfo?.toMap(),
      'isAdvancePaymentEnabled': isAdvancePaymentEnabled,
      'receiptDue': receiptDue,
      'receiptBalance': receiptBalance,
      'allPaymentMethodAmountsInfo': allPaymentMethodAmountsInfo,
      if (invoiceData != null) 'invoiceData': invoiceData!.toMap()
    };
  }

  factory ReceiptBasicInfo.fromMap(Map<dynamic, dynamic> map) {
    return ReceiptBasicInfo(
      receiptNo: map['receiptNo'] as String,
      selectedCustomerBranchDocId: map['selectedCustomerBranchDocId'] ?? '',
      selectedCustomerID: map['selectedCustomerID'] ?? '',
      cartDiscountPercentage: map['cartDiscountPercentage'] ?? 'Nan',
      cartDiscountValue: map['cartDiscountValue'] ?? 'Nan',
      selectedStoreDocId: map['selectedStoreDocId'] ?? '',
      receiptType: map['receiptType'] ?? '',
      referenceNo: map['referenceNo'] ?? '',
      specificationInfo: map['specificationInfo'] != null
          ? SpecificationData.fromMap(map['specificationInfo'])
          : null,
      isAdvancePaymentEnabled: map['isAdvancePaymentEnabled'] ?? false,
      receiptDue: map['receiptDue'] ?? 'NaN',
      receiptBalance: map['receiptBalance'] ?? 'NaN',
      allPaymentMethodAmountsInfo: map['allPaymentMethodAmountsInfo'] ?? {},
      invoiceData: map['invoiceData'] != null
          ? InvoiceData.fromMap(map['invoiceData'])
          : null,
    );
  }

  String toJson() => json.encode(toMap());

  factory ReceiptBasicInfo.fromJson(String source) =>
      ReceiptBasicInfo.fromMap(json.decode(source) as Map<String, dynamic>);
}

class InvoiceData {
  String selectedPaymentType;
  bool isFinialized;

  InvoiceData({
    required this.selectedPaymentType,
    required this.isFinialized,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'selectedPaymentType': selectedPaymentType,
      'isFinialized': isFinialized,
    };
  }

  factory InvoiceData.fromMap(Map<dynamic, dynamic> map) {
    return InvoiceData(
      selectedPaymentType: map['selectedPaymentType'] ?? 'Cash',
      isFinialized: map['isFinialized'] ?? true,
    );
  }

  String toJson() => json.encode(toMap());

  factory InvoiceData.fromJson(String source) =>
      InvoiceData.fromMap(json.decode(source) as Map<String, dynamic>);
}
