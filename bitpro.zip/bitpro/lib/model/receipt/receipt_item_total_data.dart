import 'dart:convert';

class LineItemTotalData {
  String totalQty;
  String totalDiscountPercentage;
  String totalDiscountValue;
  String totalBeforeTax;
  String totalTaxValue;
  String totalTaxPercentage;
  String receiptTotal;
  LineItemTotalData({
    required this.totalQty,
    required this.totalDiscountPercentage,
    required this.totalDiscountValue,
    required this.totalBeforeTax,
    required this.totalTaxValue,
    required this.totalTaxPercentage,
    required this.receiptTotal,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'totalQty': totalQty,
      'totalDiscountPercentage': totalDiscountPercentage,
      'totalDiscountValue': totalDiscountValue,
      'totalBeforeTax': totalBeforeTax,
      'totalTaxValue': totalTaxValue,
      'totalTaxPercentage': totalTaxPercentage,
      'receiptTotal': receiptTotal,
    };
  }

  factory LineItemTotalData.fromMap(Map<dynamic, dynamic> map) {
    return LineItemTotalData(
      totalQty: map['totalQty'] as String,
      totalDiscountPercentage: map['totalDiscountPercentage'] as String,
      totalDiscountValue: map['totalDiscountValue'] as String,
      totalBeforeTax: map['totalBeforeTax'] as String,
      totalTaxValue: map['totalTaxValue'] as String,
      totalTaxPercentage: map['totalTaxPercentage'] as String,
      receiptTotal: map['receiptTotal'] as String,
    );
  }

  String toJson() => json.encode(toMap());

  factory LineItemTotalData.fromJson(String source) =>
      LineItemTotalData.fromMap(json.decode(source) as Map<String, dynamic>);
}
