// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:convert';

import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';

class LineItemData {
  String productName;
  String qty;
  String orgPrice;
  String orgPriceWt;
  String discountPercentage;
  String discountPercentageWt;
  String discountValue;
  String discountValueWt;
  String price;
  String cost;
  String priceWt;
  String total;
  String totalWt;

  String barcode;
  String itemCode;
  String unitName;

  LineItemData({
    required this.productName,
    required this.qty,
    required this.orgPrice,
    required this.orgPriceWt,
    required this.discountPercentage,
    required this.discountPercentageWt,
    required this.discountValue,
    required this.discountValueWt,
    required this.price,
    required this.cost,
    required this.priceWt,
    required this.total,
    required this.totalWt,
    required this.barcode,
    required this.itemCode,
    required this.unitName,
  });

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'productName': productName,
      'qty': qty,
      'orgPrice': orgPrice,
      'orgPriceWt': orgPriceWt,
      'discountPercentage': discountPercentage,
      'discountPercentageWt': discountPercentageWt,
      'discountValue': discountValue,
      'discountValueWt': discountValueWt,
      'price': price,
      'priceWt': priceWt,
      'total': total,
      'totalWt': totalWt,
      'barcode': barcode,
      'itemCode': itemCode,
      'cost': cost,
      'unitName': unitName
    };
  }

  factory LineItemData.fromMap(Map<dynamic, dynamic> map) {
    return LineItemData(
      cost: map['cost'] ?? '0',
      unitName: map['unitName'] ?? '',
      productName: map['productName'] as String,
      qty: map['qty'] as String,
      orgPrice: map['orgPrice'] as String,
      orgPriceWt: map['orgPriceWt'] as String,
      discountPercentage: map['discountPercentage'] as String,
      discountPercentageWt: map['discountPercentageWt'] as String,
      discountValue: map['discountValue'] as String,
      discountValueWt: map['discountValueWt'] as String,
      price: map['price'] as String,
      priceWt: map['priceWt'] as String,
      total: map['total'] as String,
      totalWt: map['totalWt'] as String,
      barcode: map['barcode'] as String,
      itemCode: map['itemCode'] as String,
    );
  }

  String toJson() => json.encode(toMap());

  factory LineItemData.fromJson(String source) =>
      LineItemData.fromMap(json.decode(source) as Map<String, dynamic>);

  // Update when quantity changes
  void updateQuantity(double newQuantity, double taxPer) {
    qty = doubleToString(newQuantity);
    var res1 = calculatePriceWithTax(taxPer);
    priceWt = doubleToString(res1);
    price = calculateBeforeTaxValue(res1, taxPer);

    var res2 = calculateTotalWithTax();
    totalWt = doubleToString(res2);
    total = calculateBeforeTaxValue(res2, taxPer);
  }

  // Update when discount percentage changes
  void updateDiscountPercentage(double newDiscountPercentage, double taxPer) {
    discountPercentage = doubleToString(newDiscountPercentage);
    discountPercentageWt = doubleToString(newDiscountPercentage);

    var res1 = calculateDiscountValue();
    discountValue = doubleToString(res1);
    discountValueWt = calculateAfterTaxValue(res1, taxPer);

    var res2 = calculatePriceWithTax(taxPer);
    priceWt = doubleToString(res2);
    price = calculateBeforeTaxValue(res2, taxPer);

    var res3 = calculateTotalWithTax();
    totalWt = doubleToString(calculateTotalWithTax());
    total = calculateBeforeTaxValue(res3, taxPer);
  }

  // Update when discount value changes
  // void updateDiscountValue(
  //     {required double newDiscountValue, required double taxPer}) {
  //   discountValue = doubleToString(newDiscountValue);
  //   discountValueWt = calculateAfterTaxValue(newDiscountValue, taxPer);

  //   discountPercentage = doubleToString(calculateDiscountPercentage());
  //   discountPercentageWt = doubleToString(calculateDiscountPercentage());

  //   var res2 = calculatePriceWithTax(taxPer);
  //   priceWt = doubleToString(res2);
  //   price = calculateBeforeTaxValue(res2, taxPer);

  //   var res3 = calculateTotalWithTax();
  //   totalWt = doubleToString(calculateTotalWithTax());
  //   total = calculateBeforeTaxValue(res3, taxPer);
  // }

  void updateDiscountWtValue(
      {required double newDiscountWtValue, required double taxPer}) {
    discountValue = calculateBeforeTaxValue(newDiscountWtValue, taxPer);
    discountValueWt = doubleToString(newDiscountWtValue);

    discountPercentage = doubleToString(calculateDiscountPercentage());
    discountPercentageWt = doubleToString(calculateDiscountPercentage());

    var res2 = calculatePriceWithTax(taxPer);
    priceWt = doubleToString(res2);
    price = calculateBeforeTaxValue(res2, taxPer);

    var res3 = calculateTotalWithTax();
    totalWt = doubleToString(calculateTotalWithTax());
    total = calculateBeforeTaxValue(res3, taxPer);
  }

  // Update when price with tax changes
  void updatePriceWithTax(
      {required double newPriceWithTax, required double taxPer}) {
    priceWt = doubleToString(newPriceWithTax);
    price = calculateBeforeTaxValue(newPriceWithTax, taxPer);

    var res1 = calculateDiscountValueFromTotal(newPriceWithTax, taxPer);

    discountValue = doubleToString(res1);
    discountValueWt = doubleToString(
        calculateDiscountValueFromTotal(newPriceWithTax, taxPer));

    discountPercentage = doubleToString(calculateDiscountPercentage());

    totalWt = doubleToString(calculateTotalWithTax());
  }

  // Calculate price with tax based on current quantity and discount
  double calculatePriceWithTax(taxPer) {
    double disValueOfOneProduct = (double.tryParse(discountValue) ?? 0) /
        (double.tryParse(qty) ?? 0); //old dis value of one product

    double priceAfterDis =
        (double.tryParse(orgPrice) ?? 0) - disValueOfOneProduct;

    double taxValue = priceAfterDis * (taxPer / 100);

    return priceAfterDis + taxValue;
  }

  // Calculate total with tax based on priceWithTax and quantity
  double calculateTotalWithTax() {
    return getStringToNumber(priceWt) * getStringToNumber(qty);
  }

  // Calculate discount value based on discount percentage
  double calculateDiscountValue() {
    double disValueOfOneProduct = getStringToNumber(orgPrice) *
        (getStringToNumber(discountPercentage) / 100);

    return disValueOfOneProduct * getStringToNumber(qty);
  }

  // Calculate discount percentage based on discount value
  double calculateDiscountPercentage() {
    double disValueOfOneProduct =
        getStringToNumber(discountValue) / getStringToNumber(qty);

    double val = (disValueOfOneProduct / getStringToNumber(orgPrice)) * 100;

    return val;
  }

  // Calculate discount percentage from total with tax
  double calculateDiscountValueFromTotal(double pw, double taxPer) {
    double priceAfterDis = pw / (1 + (taxPer / 100));
    double disValueOfOneProduct = getStringToNumber(orgPrice) - priceAfterDis;
    return disValueOfOneProduct * getStringToNumber(qty);
  }

  double getStringToNumber(String val) {
    return double.tryParse(val) ?? 0;
  }
}

String calculateBeforeTaxValue(double afterTaxValue, double taxPercentage) {
  if (afterTaxValue == 0 ||
      taxPercentage == 0 ||
      afterTaxValue.isNegative ||
      taxPercentage.isNegative ||
      taxPercentage > 100) {
    return '0';
  }
  return doubleToString(afterTaxValue / (1 + (taxPercentage / 100)));
}

String calculateAfterTaxValue(double beforeTaxValue, double taxPercentage) {
  if (beforeTaxValue == 0 ||
      taxPercentage == 0 ||
      beforeTaxValue.isNegative ||
      taxPercentage.isNegative ||
      taxPercentage > 100) {
    return '0';
  }
  return doubleToString(beforeTaxValue * (1 + (taxPercentage / 100)));
}
