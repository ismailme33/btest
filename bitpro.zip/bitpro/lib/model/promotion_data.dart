import 'dart:convert';

class ExcelPromotionData {
  String percentage;
  String barcode;
  ExcelPromotionData({
    required this.percentage,
    required this.barcode,
  });

  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};

    result.addAll({'percentage': percentage});
    result.addAll({'barcode': barcode});

    return result;
  }

  factory ExcelPromotionData.fromMap(Map<dynamic, dynamic> map) {
    return ExcelPromotionData(
      percentage: map['percentage'] ?? '',
      barcode: map['barcode'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory ExcelPromotionData.fromJson(String source) =>
      ExcelPromotionData.fromMap(json.decode(source));
}
