import 'dart:convert';

class InventoryData {
  String docId;
  String itemCode;
  String? selectedVendorId;
  String productName;
  String? selectedDepartmentId;
  String cost;
  String description;
  String price;
  String margin;
  String priceWT;
  String productImg;
  String barcode;
  DateTime createdDate;
  String createdBy;

  /// it's Map<String,String>
  Map<dynamic, dynamic> ohQtyForDifferentStores;

  bool productPriceCanChange;

  DateTime? fbModifiedDate;
  DateTime? fbUploadedDate;
  String selectedStoreDocId;

  //
  bool isNewInventory;

  String unit;

  InventoryData({
    String? proImgUrl,
    required this.docId,
    required this.itemCode,
    required this.selectedVendorId,
    required this.productName,
    required this.selectedDepartmentId,
    required this.cost,
    required this.description,
    required this.price,
    required this.margin,
    required this.priceWT,
    required this.productImg,
    required this.barcode,
    required this.createdDate,
    required this.createdBy,
    required this.ohQtyForDifferentStores,
    required this.productPriceCanChange,
    this.fbModifiedDate,
    this.fbUploadedDate,
    required this.selectedStoreDocId,
    required this.isNewInventory,
    required this.unit,
  });
  Map<String, dynamic> toMap() {
    final result = <String, dynamic>{};

    result.addAll({'docId': docId});
    result.addAll({'itemCode': itemCode});
    result.addAll({'selectedVendorId': selectedVendorId});
    result.addAll({'productName': productName});
    result.addAll({'selectedDepartmentId': selectedDepartmentId});
    result.addAll({'cost': cost});
    result.addAll({'description': description});
    result.addAll({'price': price});
    result.addAll({'margin': margin});
    result.addAll({'priceWT': priceWT});
    result.addAll({'productImg': productImg});
    result.addAll({'barcode': barcode});
    result.addAll({'createdDate': createdDate.millisecondsSinceEpoch});
    result.addAll({'createdBy': createdBy});
    result.addAll({'ohQtyForDifferentStores': ohQtyForDifferentStores});
    result.addAll({'productPriceCanChange': productPriceCanChange});
    if (fbModifiedDate != null) {
      result.addAll({'fbModifiedDate': fbModifiedDate!.millisecondsSinceEpoch});
    }
    if (fbUploadedDate != null) {
      result.addAll({'fbUploadedDate': fbUploadedDate!.millisecondsSinceEpoch});
    }
    result.addAll({'selectedStoreDocId': selectedStoreDocId});
    result.addAll({'isNewInventory': isNewInventory});
    result.addAll({'unit': unit});

    return result;
  }

  factory InventoryData.fromMap(Map<dynamic, dynamic> map) {
    DateTime? fbModifiedDate;
    DateTime? fbUploadedDate;
    DateTime createdDate = DateTime.now();
    try {
      createdDate = DateTime.tryParse(map['createdDate'].toString()) ??
          DateTime.fromMillisecondsSinceEpoch(map['createdDate']);
    } catch (e) {}
    try {
      fbModifiedDate = map['fbModifiedDate'] != null
          ? DateTime.tryParse(map['fbModifiedDate'].toString()) ??
              DateTime.fromMillisecondsSinceEpoch(map['fbModifiedDate'])
          : null;
    } catch (e) {}

    try {
      fbUploadedDate = map['fbUploadedDate'] != null
          ? DateTime.tryParse(map['fbUploadedDate'].toString()) ??
              DateTime.fromMillisecondsSinceEpoch(map['fbUploadedDate'])
          : null;
    } catch (e) {}
    return InventoryData(
        docId: map['docId'] ?? '',
        itemCode: map['itemCode'] ?? '',
        selectedVendorId: map['selectedVendorId'] ?? '',
        productName: map['productName'] ?? '',
        selectedDepartmentId: map['selectedDepartmentId'] ?? '',
        cost: map['cost'] ?? '',
        description: map['description'] ?? '',
        price: map['price'] ?? '',
        margin: map['margin'] ?? '',
        priceWT: map['priceWT'] ?? '',
        productImg: map['productImg'] ?? '',
        barcode: map['barcode'] ?? '',
        createdDate: createdDate,
        createdBy: map['createdBy'] ?? '',
        ohQtyForDifferentStores:
            Map<dynamic, dynamic>.from(map['ohQtyForDifferentStores']),
        productPriceCanChange: map['productPriceCanChange'] ?? false,
        fbModifiedDate: fbModifiedDate,
        fbUploadedDate: fbUploadedDate,
        selectedStoreDocId: map['selectedStoreDocId'] ?? '',
        isNewInventory: map['isNewInventory'] ?? false,
        unit: map['unit'] ?? '');
  }

  String toJson() => json.encode(toMap());

  factory InventoryData.fromJson(String source) =>
      InventoryData.fromMap(json.decode(source));
}
