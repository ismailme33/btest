// class UserData {
//   String firstName;
//   String lastName;
//   String username;
//   String employeeId;
//   String password;
//   String userRole;
//   String maxDiscount;
//   String createdBy;
//   String docId;
//   String designation;
//   DateTime createdDate;
//   DateTime? openRegister;

//   DateTime? fbModifiedDate;
//   DateTime? fbUploadedDate;

//   UserData({

//     required this.userRole,
//     required this.maxDiscount,
//     required this.createdBy,
//     required this.docId,
//     required this.designation,
//     required this.createdDate,
//     required this.openRegister,
//     this.fbModifiedDate,
//     this.fbUploadedDate,
//   });

//   Map<String, dynamic> toMap() {
//     final result = <String, dynamic>{};
//     result.addAll({
//       'fbUploadedDate': fbUploadedDate == null ? '' : fbUploadedDate.toString()
//     });
//     result.addAll({'firstName': firstName});
//     result.addAll({'lastName': lastName});
//     result.addAll({'username': username});
//     result.addAll({'employeeId': employeeId});
//     result.addAll({'password': password});

//     result.addAll({'userRole': userRole});
//     result.addAll({'maxDiscount': maxDiscount});
//     result.addAll({'createdBy': createdBy});
//     result.addAll({'docId': docId});
//     result.addAll({'createdDate': createdDate.toString()});
//     result.addAll({'designation': designation});

//     result.addAll({
//       'fbModifiedDate': fbModifiedDate == null ? '' : fbModifiedDate.toString()
//     });

//     result.addAll({'openRegister': openRegister?.toString()});

//     return result;
//   }

//   factory UserData.fromMap(Map<dynamic, dynamic> map) {
//     return UserData(
//         fbUploadedDate: DateTime.tryParse(map['fbUploadedDate'] ?? ''),
//         fbModifiedDate: DateTime.tryParse(map['fbModifiedDate'] ?? ''),
//         firstName: map['firstName'] ?? '',
//         designation: map['designation'] ?? '',
//         lastName: map['lastName'] ?? '',
//         username: map['username'] ?? '',
//         employeeId: map['employeeId'] ?? '',
//         password: map['password'] ?? '',
//         userRole: map['userRole'] ?? '',
//         maxDiscount: map['maxDiscount'] ?? '',
//         createdBy: map['createdBy'] ?? '',
//         docId: map['docId'] ?? '',
//         createdDate: DateTime.tryParse(map['createdDate'].toString()) ??
//             DateTime.fromMillisecondsSinceEpoch(map['createdDate'] as int),
//         openRegister: DateTime.tryParse(map['openRegister'] ?? ''));
//   }
// }
