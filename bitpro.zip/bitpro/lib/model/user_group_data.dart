import 'dart:convert';

class UserGroupData {
  String docId;
  String createdBy;
  DateTime createdDate;
  String name;
  String description;
  bool employees;
  bool registers;
  bool groups;
  bool salesReceipt;
  bool vendors;
  bool reports;
  bool departments;
  bool settings;
  bool inventory;
  bool purchaseVoucher;
  bool customers;
  bool receipt;
  bool formerZout;
  bool adjustment;
  bool backupReset;
  bool promotion;
  bool dashboard;

  DateTime? fbModifiedDate;
  DateTime? fbUploadedDate;

  UserGroupData(
      {required this.docId,
      required this.dashboard,
      this.fbUploadedDate,
      required this.createdBy,
      required this.createdDate,
      required this.name,
      required this.description,
      required this.employees,
      required this.registers,
      required this.groups,
      required this.salesReceipt,
      required this.vendors,
      required this.reports,
      required this.departments,
      required this.settings,
      required this.inventory,
      required this.purchaseVoucher,
      required this.customers,
      required this.receipt,
      required this.formerZout,
      this.fbModifiedDate,
      required this.adjustment,
      required this.backupReset,
      required this.promotion});

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'fbUploadedDate': fbUploadedDate == null ? '' : fbUploadedDate.toString(),
      'docId': docId,
      'createdBy': createdBy,
      'createdDate': createdDate.millisecondsSinceEpoch,
      'name': name,
      'discription': description,
      'employees': employees,
      'registers': registers,
      'groups': groups,
      'salesReceipt': salesReceipt,
      'vendors': vendors,
      'reports': reports,
      'departments': departments,
      'settings': settings,
      'inventory': inventory,
      'purchaseVoucher': purchaseVoucher,
      'customers': customers,
      'receipt': receipt,
      'formerZout': formerZout,
      'adjustment': adjustment,
      'backupReset': backupReset,
      'fbModifiedDate': fbModifiedDate == null ? '' : fbModifiedDate.toString(),
      'promotion': promotion,
      'dashboard': dashboard,
    };
  }

  factory UserGroupData.fromMap(Map<dynamic, dynamic> map) {
    return UserGroupData(
      fbUploadedDate: DateTime.tryParse(map['fbUploadedDate'] ?? ''),
      fbModifiedDate: DateTime.tryParse(map['fbModifiedDate'] ?? ''),
      docId: map['docId'] ?? "",
      createdBy: map['createdBy'] ?? "",
      createdDate: DateTime.tryParse(map['createdDate'].toString()) ??
          DateTime.fromMillisecondsSinceEpoch(map['createdDate'] as int),
      name: map['name'] ?? "",
      description: map['discription'] ?? "",
      employees: map['employees'] ?? false,
      registers: map['registers'] ?? false,
      groups: map['groups'] ?? false,
      salesReceipt: map['salesReceipt'] ?? false,
      vendors: map['vendors'] ?? false,
      reports: map['reports'] ?? false,
      departments: map['departments'] ?? false,
      settings: map['settings'] ?? false,
      inventory: map['inventory'] ?? false,
      purchaseVoucher: map['purchaseVoucher'] ?? false,
      customers: map['customers'] ?? false,
      receipt: map['receipt'] ?? false,
      formerZout: map['formerZout'] ?? false,
      adjustment: map['adjustment'] ?? false,
      backupReset: map['backupReset'] ?? false,
      promotion: map['promotion'] ?? false,
      dashboard: map['dashboard'] ?? false,
    );
  }

  String toJson() => json.encode(toMap());

  factory UserGroupData.fromJson(String source) =>
      UserGroupData.fromMap(json.decode(source) as Map<String, dynamic>);
}
