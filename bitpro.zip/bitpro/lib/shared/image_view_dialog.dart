import 'dart:io';

import 'package:flutter/material.dart';
import 'package:photo_view/photo_view.dart';

imageViewDialog(context, String imgFile) {
  showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: Container(
              height: MediaQuery.of(context).size.height * 0.7,
              width: MediaQuery.of(context).size.height * 0.7,
              child: PhotoView(
                imageProvider: FileImage(File(imgFile)),
              )),
        );
      });
}
