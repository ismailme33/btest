//receipt payment methods name
class PaymentMethodKey {
  final String cash = 'CASH';
  final String creditCard = 'CREDITCARD';
  final String tamara = 'TAMARA';
  final String tabby = 'TABBY';
  final String credit = 'CREDIT';

  List<String> getAllPaymentMethodLst() {
    List<String> paymentMethodList = [cash, creditCard, tamara, tabby, credit];

    return paymentMethodList;
  }

  List<String> getNonCurrencyPaymentMethodLst() {
    List<String> paymentMethodList = [creditCard, tamara, tabby, credit];

    return paymentMethodList;
  }

  String getTextName(String key) {
    if (key == 'CASH') {
      return 'Cash';
    } else if (key == 'CREDITCARD') {
      return 'Credit Card';
    } else if (key == 'TAMARA') {
      return 'Tamara';
    } else if (key == 'TABBY') {
      return 'Tabby';
    } else {
      return 'Credit';
    }
  }
}

const String defaultTaxPercentge = '15';
//
const int defaultFbFetchAndUpdateTimerInMin = 15; //minutes
