// 2 to 2
// 2.0 to 2
// 2.1020 to 2.102
// 2.102344444 to 2.10235
import 'dart:math' as math;

import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';

String doubleToString(double value, {int maxDigits = 5}) {
  // Debug: Print the input value to verify
  maxDigits = digit;

  // Check if the value is effectively an integer (e.g., 2.0, 2.000)
  if (value == value.toInt()) {
    return value.toInt().toString();
  } else {
    // Truncate to maxDigits decimal places
    double multiplier = math.pow(10, maxDigits).toDouble();
    double truncated = (value * multiplier).truncateToDouble() / multiplier;

    // Format to maxDigits decimal places and remove trailing zeros/decimal point
    String formatted = truncated.toStringAsFixed(maxDigits);

    formatted = formatted.replaceAll(RegExp(r'0+$'), '');
    formatted = formatted.replaceAll(RegExp(r'\.$'), '');

    return formatted;
  }
}
