import 'package:bitpro_hive/main.dart';
// import 'package:bitpro_hive/services/mysql/get_mysql_connection.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:iconsax/iconsax.dart';

Future<void> showDbDisconnectIssueDialog(context) async {
  var box = Hive.box('bitpro_app');
  var serverData = await box.get('Server_Data');

  // await box.put('is_user_logged_in', false);
  // await box.delete('user_data');
  showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context2) {
        bool isLoading = false;
        return StatefulBuilder(builder: (context, setState2) {
          if (isLoading) {
            return AlertDialog(
                content:
                    SizedBox(height: 220, width: 320, child: showLoading()));
          }
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: BorderSide(width: 0.2, color: Colors.grey)),
            title: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(
                  Iconsax.danger,
                  size: 20,
                  color: Colors.black,
                ),
                const SizedBox(
                  width: 15,
                ),
                Text(
                  staticTextTranslate('Database Not Found'),
                  style: TextStyle(
                    fontFamily: 'assets/Inter-SemiBold.ttf',
                    color: Colors.black,
                  ),
                ),
              ],
            ),
            content: SizedBox(
              height: 110,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Server Info',
                      style: TextStyle(
                        color: Colors.black,
                      )),
                  Text(
                    """  Host : ${serverData['host']}\n  Port : ${serverData['port']}\n  User : ${serverData['user']}\n  ${serverData['password'] == null ? '' : 'Password : xxxxxxxxx'}\n  Database : """,
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                  ),
                ],
              ),
            ),
            actions: [
              SizedBox(
                height: 42,
                width: 173,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        side: BorderSide(width: 0.1, color: Colors.grey),
                        backgroundColor: Colors.red,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4))),
                    onPressed: () async {
                      setState2(() {
                        isLoading = true;
                      });
                      Box box = Hive.box('bitpro_app');
                      await box.clear();

                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(
                            builder: (context) => MyApp(
                                  setFullScreen: false,
                                )),
                        (route) => false,
                      );
                    },
                    child: Text(staticTextTranslate('Change Database'),
                        style: TextStyle(color: Colors.white))),
              ),
              SizedBox(
                height: 42,
                width: 173,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      side: BorderSide(width: 0.1, color: Colors.grey),
                      backgroundColor: Color(0xff2a77b5),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    onPressed: () async {
                      setState2(() {
                        isLoading = true;
                      });

                      // int res = await checkMySqlDBExits(
                      //     host: serverData['host'],
                      //     port: serverData['port'],
                      //     user: serverData['user'],
                      //     password: serverData['password'],
                      //     context: context);
                      // if (res == 1) {
                      //   // Navigator.pop(context);
                      //   Navigator.of(context).pushAndRemoveUntil(
                      //       MaterialPageRoute(
                      //           builder: (context) => MyApp(
                      //                 setFullScreen: false,
                      //               )),
                      //       (route) => false);
                      // }
                      setState2(() {
                        isLoading = false;
                      });
                    },
                    child: Text(
                      staticTextTranslate('Reconnect'),
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                    )),
              ),
            ],
          );
        });
      });
}
