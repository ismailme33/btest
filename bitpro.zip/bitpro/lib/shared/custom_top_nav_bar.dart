import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/shared/dialogs/exit_dialog.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitsdojo_window/bitsdojo_window.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';

class CustomNavBar extends StatefulWidget {
  final String pageName;
  final Widget child;
  const CustomNavBar({super.key, this.pageName = '', required this.child});

  @override
  State<CustomNavBar> createState() => _CustomNavBarState();
}

class _CustomNavBarState extends State<CustomNavBar> {
  String fullName = '';
  String designation = '';

  @override
  void initState() {
    initData();
    super.initState();
  }

  initData() {
    var box = Hive.box('bitpro_app');
    Map? ud = box.get('user_data');

    if (ud != null) {
      EmployeeData u = EmployeeData.fromMap(ud);

      fullName =
          '${u.empBasicInfoData.firstName} ${u.empBasicInfoData.lastName}';
      designation = u.empWorkAndRolesData.position ?? '';
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: WindowBorder(
        width: 1,
        color: Colors.black, //background color
        child: Column(
          children: [
            SizedBox(
              height: 50,
              child: WindowTitleBarBox(
                child: Container(
                  color: Color.fromARGB(255, 37, 37, 37),
                  child: Row(
                    children: [
                      Expanded(
                          child: MoveWindow(
                        child: Row(
                          children: [
                            Expanded(
                              child: SizedBox(
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        SizedBox(
                                          width: 15,
                                        ),
                                        Image.asset(
                                          'assets/icons/bitpro.png',
                                          width: 23,
                                        ),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          'BitPro',
                                          style: GoogleFonts.lato(
                                              fontSize: 22,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.white),
                                        ),
                                        const SizedBox(
                                          width: 65,
                                        ),
                                        Text(
                                          staticTextTranslate(widget.pageName),
                                          style: GoogleFonts.roboto(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w400,
                                              color: Colors.white),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                          height: 27,
                                          width: 27,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(100),
                                              color: Colors.white),
                                          child: Icon(
                                            Icons.person,
                                            size: 20,
                                            color: Colors.grey[600],
                                          ),
                                        ),
                                        const SizedBox(
                                          width: 10,
                                        ),
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              fullName,
                                              style: GoogleFonts.roboto(
                                                  fontSize:
                                                      getMediumFontSize - 1,
                                                  color: Colors.white),
                                            ),
                                            Text(
                                              designation,
                                              style: GoogleFonts.roboto(
                                                  fontSize:
                                                      getMediumFontSize - 4,
                                                  color: Colors.white),
                                            )
                                          ],
                                        ),
                                        SizedBox(
                                          width: 20,
                                        ),
                                      ],
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      )),
                      const WindowButtons()
                    ],
                  ),
                ),
              ),
            ),
            Expanded(child: widget.child),
          ],
        ),
      ),
    );
  }
}

final buttonColors = WindowButtonColors(
  iconNormal: Colors.white,
  iconMouseOver: Colors.white,
  iconMouseDown: Colors.white,
);

final closeButtonColors = WindowButtonColors(
    mouseOver: const Color(0xFFD32F2F),
    mouseDown: const Color(0xFFB71C1C),
    iconNormal: Colors.white,
    iconMouseOver: Colors.white);

class WindowButtons extends StatefulWidget {
  const WindowButtons({super.key});

  @override
  _WindowButtonsState createState() => _WindowButtonsState();
}

class _WindowButtonsState extends State<WindowButtons> {
  void maximizeOrRestore() {
    setState(() {
      appWindow.maximizeOrRestore();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 50,
      child: Row(
        children: [
          MinimizeWindowButton(
            colors: buttonColors,
          ),
          appWindow.isMaximized
              ? RestoreWindowButton(
                  colors: buttonColors,
                  onPressed: maximizeOrRestore,
                )
              : MaximizeWindowButton(
                  colors: buttonColors,
                  onPressed: maximizeOrRestore,
                ),
          CloseWindowButton(
            colors: closeButtonColors,
            onPressed: () {
              exitDialog(context);
            },
          ),
        ],
      ),
    );
  }
}
