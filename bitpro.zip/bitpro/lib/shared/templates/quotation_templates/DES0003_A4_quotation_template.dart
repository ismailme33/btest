import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../../model/customer_data.dart';

des0003A4QuotationTemplate({
  required image,
  required EmployeeData userData,
  required PrintingSetttings printingSetttings,
  required ReceiptOrQuotationData dbQuotationData,
  required englishBoldFont,
  required arabicRegularFont,
  required arabicBoldFont,
  required vatPercentage,
  required englishRegularFont,
  required StoreData selectedStoreData,
  CustomerData? selectedCustomerData,
}) {
  return pw.Container(
      width: double.maxFinite,
      child: pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.start,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.start,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.start,
                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                      children: [
                        pw.Column(
                          mainAxisAlignment: pw.MainAxisAlignment.start,
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.SizedBox(
                              height: 10,
                            ),
                            pw.Text(
                              selectedStoreData.storeName,
                              textAlign: pw.TextAlign.left,
                              textDirection: !containsExtendedArabic(
                                      selectedStoreData.storeName.toString())
                                  ? pw.TextDirection.ltr
                                  : pw.TextDirection.rtl,
                              style: pw.TextStyle(
                                  font: !containsExtendedArabic(
                                          selectedStoreData.storeName
                                              .toString())
                                      ? englishBoldFont
                                      : arabicBoldFont,
                                  fontSize: 14,
                                  fontWeight: pw.FontWeight.bold),
                            ),
                            pw.SizedBox(
                              height: 10,
                            ),
                            pw.Text(
                              selectedStoreData.address,
                              textAlign: pw.TextAlign.left,
                              textDirection: !containsExtendedArabic(
                                      selectedStoreData.address.toString())
                                  ? pw.TextDirection.ltr
                                  : pw.TextDirection.rtl,
                              style: pw.TextStyle(
                                font: !containsExtendedArabic(
                                        selectedStoreData.address.toString())
                                    ? englishRegularFont
                                    : arabicRegularFont,
                                fontSize: 10,
                              ),
                            ),
                            pw.Text(
                              'Phone : ${selectedStoreData.phone1}',
                              style: pw.TextStyle(
                                fontSize: 10,
                                font: englishRegularFont,
                              ),
                            ),
                            pw.Text(
                              'E-mail : ${selectedStoreData.email}',
                              style: pw.TextStyle(
                                fontSize: 10,
                                font: englishRegularFont,
                              ),
                            ),
                            pw.Text(
                              'VAT Number : ${selectedStoreData.vatNumber}',
                              style: pw.TextStyle(
                                fontSize: 10,
                                font: englishRegularFont,
                              ),
                            ),
                            pw.Row(children: [
                              pw.Text(
                                'Bank Name : ',
                                style: pw.TextStyle(
                                  fontSize: 10,
                                  font: englishRegularFont,
                                ),
                              ),
                              pw.Text(
                                selectedStoreData.bankName,
                                style: pw.TextStyle(
                                  fontSize: 10,
                                  font: englishRegularFont,
                                ),
                              ),
                            ]),
                            pw.Text(
                              'Account Number : ${selectedStoreData.accountNumber}',
                              style: pw.TextStyle(
                                fontSize: 10,
                                font: englishRegularFont,
                              ),
                            ),
                          ],
                        ),
                        pw.Expanded(child: pw.SizedBox(width: 20)),
                        pw.Container(
                          alignment: pw.Alignment.center,
                          margin: const pw.EdgeInsets.only(right: 20),
                          width: 170,
                          height: 90,
                          child: pw.Image(image,
                              width: 170, height: 90, fit: pw.BoxFit.contain),
                        ),
                      ]),
                  pw.SizedBox(height: 15),
                  pw.Container(
                    padding: const pw.EdgeInsets.all(2),
                    width: double.maxFinite,
                    child: pw.Row(
                        mainAxisAlignment: pw.MainAxisAlignment.center,
                        crossAxisAlignment: pw.CrossAxisAlignment.center,
                        children: [
                          pw.Text(
                            'عرض السعر',
                            textDirection: pw.TextDirection.rtl,
                            style: pw.TextStyle(
                                fontSize: 12,
                                font: arabicBoldFont,
                                fontWeight: pw.FontWeight.bold),
                          ),
                          pw.SizedBox(width: 10),
                          pw.Text(
                            'Quotation',
                            style: pw.TextStyle(
                              fontSize: 12,
                              fontBold: englishBoldFont,
                            ),
                          ),
                        ]),
                  ),
                  pw.SizedBox(
                    height: 5,
                  ),
                  pw.Container(
                    decoration: pw.BoxDecoration(
                      border: pw.Border.all(width: 0.2),
                    ),
                    child: pw.Row(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          mainAxisAlignment: pw.MainAxisAlignment.start,
                          children: [
                            pw.Container(
                                width: 350,
                                padding: const pw.EdgeInsets.all(3),
                                decoration: pw.BoxDecoration(
                                    border: pw.Border.all(width: 0.2),
                                    color: const PdfColor.fromInt(0xffeaeaea)),
                                child: pw.Text(
                                  ' Customer Details',
                                  style: pw.TextStyle(
                                      font: englishRegularFont, fontSize: 10),
                                )),
                            pw.Container(
                              width: 350,
                              decoration: pw.BoxDecoration(
                                  border: pw.Border.all(
                                width: 0.2,
                              )),
                              padding: const pw.EdgeInsets.only(
                                  left: 8, top: 10, right: 15, bottom: 15),
                              child: pw.Row(
                                  crossAxisAlignment:
                                      pw.CrossAxisAlignment.start,
                                  children: [
                                    if (selectedCustomerData != null)
                                      pw.SizedBox(
                                          width: 260,
                                          child: pw.Column(
                                              crossAxisAlignment:
                                                  pw.CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                                  pw.MainAxisAlignment.start,
                                              children: [
                                                if (selectedCustomerData
                                                    .customerName.isNotEmpty)
                                                  pw.Text(
                                                    selectedCustomerData
                                                        .customerName,
                                                    textDirection:
                                                        !containsExtendedArabic(
                                                                selectedCustomerData
                                                                    .customerName
                                                                    .toString())
                                                            ? pw.TextDirection
                                                                .ltr
                                                            : pw.TextDirection
                                                                .rtl,
                                                    style: pw.TextStyle(
                                                        font: !containsExtendedArabic(
                                                                selectedCustomerData
                                                                    .customerName
                                                                    .toString())
                                                            ? englishBoldFont
                                                            : arabicRegularFont,
                                                        fontSize: 10),
                                                  ),
                                                if (selectedCustomerData
                                                    .customerName.isNotEmpty)
                                                  pw.SizedBox(height: 3),
                                                if (selectedCustomerData
                                                    .address1.isNotEmpty)
                                                  pw.Text(
                                                    selectedCustomerData
                                                        .address1,
                                                    textDirection:
                                                        !containsExtendedArabic(
                                                                selectedCustomerData
                                                                    .address1
                                                                    .toString())
                                                            ? pw.TextDirection
                                                                .ltr
                                                            : pw.TextDirection
                                                                .rtl,
                                                    style: pw.TextStyle(
                                                        font: !containsExtendedArabic(
                                                                selectedCustomerData
                                                                    .address1
                                                                    .toString())
                                                            ? englishRegularFont
                                                            : arabicRegularFont,
                                                        fontSize: 10),
                                                  ),
                                                if (selectedCustomerData
                                                    .address1.isNotEmpty)
                                                  pw.SizedBox(height: 0),
                                                if (selectedCustomerData
                                                    .address2.isNotEmpty)
                                                  pw.Text(
                                                    selectedCustomerData
                                                        .address2,
                                                    textDirection:
                                                        !containsExtendedArabic(
                                                                selectedCustomerData
                                                                    .address2
                                                                    .toString())
                                                            ? pw.TextDirection
                                                                .ltr
                                                            : pw.TextDirection
                                                                .rtl,
                                                    style: pw.TextStyle(
                                                        font: !containsExtendedArabic(
                                                                selectedCustomerData
                                                                    .address2
                                                                    .toString())
                                                            ? englishRegularFont
                                                            : arabicRegularFont,
                                                        fontSize: 10),
                                                  ),
                                                if (selectedCustomerData
                                                    .address2.isNotEmpty)
                                                  pw.SizedBox(height: 0),
                                                if (selectedCustomerData
                                                    .phone1.isNotEmpty)
                                                  pw.Row(children: [
                                                    pw.Text(
                                                      'Phone 1 : ',
                                                      style: pw.TextStyle(
                                                        font:
                                                            englishRegularFont,
                                                        fontSize: 10,
                                                      ),
                                                    ),
                                                    pw.SizedBox(width: 10),
                                                    pw.Text(
                                                      selectedCustomerData
                                                          .phone1,
                                                      style: pw.TextStyle(
                                                        font:
                                                            englishRegularFont,
                                                        fontSize: 10,
                                                      ),
                                                    ),
                                                  ]),
                                                if (selectedCustomerData
                                                    .phone1.isNotEmpty)
                                                  pw.SizedBox(height: 0),
                                                if (selectedCustomerData
                                                    .email.isNotEmpty)
                                                  pw.Row(children: [
                                                    pw.Text(
                                                      'Email : ',
                                                      style: pw.TextStyle(
                                                        font:
                                                            englishRegularFont,
                                                        fontSize: 10,
                                                      ),
                                                    ),
                                                    pw.SizedBox(width: 10),
                                                    pw.Text(
                                                      selectedCustomerData
                                                          .email,
                                                      style: pw.TextStyle(
                                                        font:
                                                            englishRegularFont,
                                                        fontSize: 10,
                                                      ),
                                                    ),
                                                  ]),
                                                if (selectedCustomerData
                                                    .email.isNotEmpty)
                                                  pw.SizedBox(height: 5),
                                                if (selectedCustomerData
                                                    .vatNo.isNotEmpty)
                                                  pw.Row(children: [
                                                    pw.Text(
                                                      'Vat No. : ',
                                                      style: pw.TextStyle(
                                                        font:
                                                            englishRegularFont,
                                                        fontSize: 10,
                                                      ),
                                                    ),
                                                    pw.SizedBox(width: 10),
                                                    pw.Text(
                                                      selectedCustomerData
                                                          .vatNo,
                                                      style: pw.TextStyle(
                                                        font:
                                                            englishRegularFont,
                                                        fontSize: 10,
                                                      ),
                                                    ),
                                                  ])
                                              ])),
                                    pw.Expanded(
                                        child: pw.SizedBox(
                                      width: 10,
                                      height: 90,
                                    )),
                                    // pw.Align(
                                    //     alignment: pw.Alignment.topCenter,
                                    //     child: pw.SvgImage(
                                    //         svg: buildBarcode(
                                    //             height: 90,
                                    //             width: 70,
                                    //             Barcode.qrCode(),
                                    //             getQrCodeContent(
                                    //               sellerName:
                                    //                   userSettingsData == null
                                    //                       ? ''
                                    //                       : userSettingsData[
                                    //                           'companyName'],
                                    //               sellerTRN: selectedStoreData
                                    //                   .vatNumber,
                                    //               totalWithVat: dbQuotationData
                                    //                   .receiptTotal,
                                    //               vatPrice: taxValue,
                                    //             )))),
                                  ]),
                            ),
                          ],
                        ),
                        pw.Expanded(
                          child: pw.Container(
                              child: pw.Column(
                                  crossAxisAlignment:
                                      pw.CrossAxisAlignment.start,
                                  children: [
                                pw.Container(
                                    width: double.maxFinite,
                                    padding: const pw.EdgeInsets.all(3),
                                    decoration: pw.BoxDecoration(
                                        border: pw.Border.all(
                                          width: 0.2,
                                        ),
                                        color:
                                            const PdfColor.fromInt(0xffeaeaea)),
                                    child: pw.Text(
                                      '   Quotation Details',
                                      style: pw.TextStyle(
                                          font: englishRegularFont,
                                          fontSize: 10),
                                    )),
                                pw.Padding(
                                  padding: const pw.EdgeInsets.all(8),
                                  child: pw.Row(children: [
                                    pw.Column(
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.start,
                                        children: [
                                          pw.Row(children: [
                                            pw.Text(
                                              'عرض السعر',
                                              textDirection:
                                                  pw.TextDirection.rtl,
                                              style: pw.TextStyle(
                                                fontSize: 10,
                                                font: arabicBoldFont,
                                              ),
                                            ),
                                            pw.SizedBox(width: 3),
                                            pw.Text(
                                              'Quotation #',
                                              style: pw.TextStyle(
                                                fontSize: 10,
                                                font: englishRegularFont,
                                              ),
                                            ),
                                          ]),
                                          pw.SizedBox(height: 5),
                                          pw.Row(children: [
                                            pw.Text(
                                              'تاريخ ',
                                              textDirection:
                                                  pw.TextDirection.rtl,
                                              style: pw.TextStyle(
                                                fontSize: 10,
                                                font: arabicBoldFont,
                                              ),
                                            ),
                                            pw.SizedBox(width: 3),
                                            pw.Text(
                                              'Created Date : ',
                                              style: pw.TextStyle(
                                                fontSize: 10,
                                                font: englishRegularFont,
                                              ),
                                            ),
                                          ]),
                                          pw.SizedBox(height: 5),
                                          pw.Row(children: [
                                            pw.Text(
                                              'مستخدم ',
                                              textDirection:
                                                  pw.TextDirection.rtl,
                                              style: pw.TextStyle(
                                                fontSize: 10,
                                                font: arabicBoldFont,
                                              ),
                                            ),
                                            pw.SizedBox(width: 3),
                                            pw.Text(
                                              'User :',
                                              style: pw.TextStyle(
                                                fontSize: 10,
                                                font: englishRegularFont,
                                              ),
                                            ),
                                          ]),
                                          // if (dbQuotationData
                                          //     .referenceNo.isNotEmpty)
                                          //   pw.SizedBox(height: 5),
                                          // if (dbQuotationData
                                          //     .referenceNo.isNotEmpty)
                                          //   pw.Text(
                                          //     'Reference No',
                                          //     style: pw.TextStyle(
                                          //       fontSize: 10,
                                          //       font: englishRegularFont,
                                          //     ),
                                          //   ),
                                        ]),
                                    pw.SizedBox(width: 1),
                                    pw.Column(
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.start,
                                        children: [
                                          pw.Text(
                                            dbQuotationData.quotationBasicInfo!
                                                .quotationNo,
                                            style: pw.TextStyle(
                                              fontSize: 10,
                                              font: englishRegularFont,
                                            ),
                                          ),
                                          pw.SizedBox(height: 5),
                                          pw.Text(
                                            DateFormat('dd-MM-yyyy hh:mm a')
                                                .format(dbQuotationData
                                                    .createdDate),
                                            style: pw.TextStyle(
                                              fontSize: 10,
                                              font: englishRegularFont,
                                            ),
                                          ),
                                          pw.SizedBox(height: 5),
                                          pw.Text(
                                            '${userData.empBasicInfoData.username}',
                                            style: pw.TextStyle(
                                              fontSize: 10,
                                              font: englishRegularFont,
                                            ),
                                          ),
                                          // if (dbQuotationData
                                          //     .referenceNo.isNotEmpty)
                                          //   pw.SizedBox(height: 5),
                                          // if (dbQuotationData
                                          //     .referenceNo.isNotEmpty)
                                          //   pw.Text(
                                          //     dbQuotationData.referenceNo,
                                          //     style: pw.TextStyle(
                                          //       fontSize: 10,
                                          //       font: englishRegularFont,
                                          //     ),
                                          //   ),
                                        ]),
                                  ]),
                                ),
                                pw.Padding(
                                    padding: const pw.EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 4),
                                    child: pw.SvgImage(
                                        svg: buildBarcode(
                                            height: 35,
                                            width: 120,
                                            Barcode.code128(
                                                useCode128B: false,
                                                useCode128C: false),
                                            dbQuotationData
                                                .quotationBasicInfo!.quotationNo
                                                .toString(),
                                            filename: 'code-128a',
                                            fontHeight: 10))),
                                pw.SizedBox(height: 2),
                              ])),
                        )
                      ],
                    ),
                  ),
                  pw.SizedBox(
                    height: 7,
                  ),
                ]),
            pw.Container(
              width: double.maxFinite,
              alignment: pw.Alignment.centerLeft,
              child: pw.Table(
                columnWidths: {
                  0: const pw.FlexColumnWidth(1.5),
                  1: const pw.FlexColumnWidth(1.5),
                  2: const pw.FlexColumnWidth(7),
                  3: const pw.FlexColumnWidth(1),
                  4: const pw.FlexColumnWidth(2.5),
                  5: const pw.FlexColumnWidth(2.5)
                },
                children: [
                  pw.TableRow(
                      decoration: const pw.BoxDecoration(
                          border: pw.Border(
                        bottom:
                            pw.BorderSide(width: 0.2, color: PdfColors.black),
                      )),
                      children: [
                        pw.Container(
                            height: 29,
                            decoration: pw.BoxDecoration(
                                color: const PdfColor.fromInt(0xffeaeaea),
                                border: pw.Border.all(
                                  width: 0.2,
                                  color: PdfColors.black,
                                )),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'باركود',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    fontSize: 10,
                                    font: arabicBoldFont,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Barcode',
                                    style: pw.TextStyle(
                                        fontSize: 10, font: englishRegularFont))
                              ],
                            )),
                        pw.Container(
                            height: 29,
                            decoration: pw.BoxDecoration(
                                color: const PdfColor.fromInt(0xffeaeaea),
                                border: pw.Border.all(
                                    width: 0.2, color: PdfColors.black)),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'الصنف',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    fontSize: 10,
                                    font: arabicBoldFont,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Pr. code',
                                    style: pw.TextStyle(
                                        fontSize: 10, font: englishRegularFont))
                              ],
                            )),
                        pw.Container(
                            height: 29,
                            decoration: pw.BoxDecoration(
                                color: const PdfColor.fromInt(0xffeaeaea),
                                border: pw.Border.all(
                                    width: 0.2, color: PdfColors.black)),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'اسم الصنف',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicBoldFont,
                                    fontSize: 10,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Product / Service Description',
                                    style: pw.TextStyle(
                                        fontSize: 10, font: englishRegularFont))
                              ],
                            )),
                        pw.Container(
                            decoration: pw.BoxDecoration(
                                color: const PdfColor.fromInt(0xffeaeaea),
                                border: pw.Border.all(
                                    width: 0.2, color: PdfColors.black)),
                            height: 29,
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'كمية',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicBoldFont,
                                    fontSize: 10,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Qty',
                                    style: pw.TextStyle(
                                        fontSize: 10, font: englishRegularFont))
                              ],
                            )),
                        pw.Container(
                            height: 29,
                            decoration: pw.BoxDecoration(
                                color: const PdfColor.fromInt(0xffeaeaea),
                                border: pw.Border.all(
                                    width: 0.2, color: PdfColors.black)),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'السعر',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicBoldFont,
                                    fontSize: 10,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Unit Price',
                                    style: pw.TextStyle(
                                        fontSize: 10, font: englishRegularFont))
                              ],
                            )),
                        pw.Container(
                            height: 29,
                            decoration: pw.BoxDecoration(
                                color: const PdfColor.fromInt(0xffeaeaea),
                                border: pw.Border.all(
                                    width: 0.2, color: PdfColors.black)),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'اجمالي',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicBoldFont,
                                    fontSize: 10,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Total',
                                    style: pw.TextStyle(
                                        fontSize: 10, font: englishRegularFont))
                              ],
                            )),
                      ]),
                ],
              ),
            ),
            for (LineItemData localReceiptData in dbQuotationData.lineItemsData)
              productTile(
                  englishRegularFont,
                  localReceiptData,
                  arabicRegularFont,
                  vatPercentage,
                  dbQuotationData.lineItemsData.indexOf(localReceiptData) ==
                      dbQuotationData.lineItemsData.length - 1,
                  dbQuotationData),
            pw.Container(
                width: double.maxFinite,
                alignment: pw.Alignment.centerLeft,
                child: pw.Table(columnWidths: {
                  0: const pw.FlexColumnWidth(1.5),
                  1: const pw.FlexColumnWidth(1.5),
                  2: const pw.FlexColumnWidth(7),
                  3: const pw.FlexColumnWidth(1),
                  4: const pw.FlexColumnWidth(2.5),
                  5: const pw.FlexColumnWidth(2.5)
                }, children: [
                  pw.TableRow(
                      verticalAlignment: pw.TableCellVerticalAlignment.top,
                      children: [
                        pw.Container(
                          decoration: const pw.BoxDecoration(
                              border: pw.Border(
                            bottom: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            left: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            right: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            top: pw.BorderSide(
                                width: 0.2, color: PdfColors.black),
                          )),
                          height: 5,
                          alignment: pw.Alignment.center,
                        ),
                        pw.Container(
                          decoration: const pw.BoxDecoration(
                              border: pw.Border(
                            bottom: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            left: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            right: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            top: pw.BorderSide(
                                width: 0.2, color: PdfColors.black),
                          )),
                          height: 5,
                          alignment: pw.Alignment.center,
                        ),
                        pw.Container(
                          decoration: const pw.BoxDecoration(
                              border: pw.Border(
                            bottom: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            left: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            right: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            top: pw.BorderSide(
                                width: 0.2, color: PdfColors.black),
                          )),
                          height: 5,
                          alignment: pw.Alignment.center,
                        ),
                        pw.Container(
                          decoration: const pw.BoxDecoration(
                              border: pw.Border(
                            bottom: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            left: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            right: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            top: pw.BorderSide(
                                width: 0.2, color: PdfColors.black),
                          )),
                          height: 5,
                          alignment: pw.Alignment.center,
                        ),
                        pw.Container(
                          decoration: const pw.BoxDecoration(
                              border: pw.Border(
                            bottom: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            left: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            right: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            top: pw.BorderSide(
                                width: 0.2, color: PdfColors.black),
                          )),
                          height: 5,
                          alignment: pw.Alignment.center,
                        ),
                        pw.Container(
                          decoration: const pw.BoxDecoration(
                              border: pw.Border(
                            bottom: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            left: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            right: pw.BorderSide(
                                width: 0.2, color: PdfColors.white),
                            top: pw.BorderSide(
                                width: 0.2, color: PdfColors.black),
                          )),
                          height: 5,
                          alignment: pw.Alignment.center,
                        ),
                      ]),
                  tableTotalTiles(englishRegularFont, arabicRegularFont,
                      dbQuotationData.lineItemsData, 1, dbQuotationData),
                ])),
            tableTotalTiles(englishRegularFont, arabicRegularFont,
                dbQuotationData.lineItemsData, 2, dbQuotationData),
            tableTotalTiles(englishRegularFont, arabicRegularFont,
                dbQuotationData.lineItemsData, 3, dbQuotationData),
            tableTotalTiles(englishRegularFont, arabicRegularFont,
                dbQuotationData.lineItemsData, 4, dbQuotationData),
            tableTotalTiles(englishRegularFont, arabicRegularFont,
                dbQuotationData.lineItemsData, 5, dbQuotationData),
            pw.SizedBox(height: 10),
            if (printingSetttings.receiptFotterEng.isNotEmpty ||
                printingSetttings.receiptFotterArb.isNotEmpty)
              pw.Container(
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(
                  width: 0.2,
                )),
                padding: const pw.EdgeInsets.all(6),
                child: pw.Row(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  mainAxisAlignment: pw.MainAxisAlignment.start,
                  children: [
                    pw.Expanded(
                        flex: 4,
                        child: pw.Text(printingSetttings.receiptFotterEng,
                            style: pw.TextStyle(
                                fontSize: 10, font: englishRegularFont))),
                    pw.Expanded(
                        flex: 1,
                        child: pw.SizedBox(
                          width: 5,
                        )),
                    pw.Expanded(
                        flex: 4,
                        child: pw.Align(
                            alignment: pw.Alignment.bottomRight,
                            child: pw.Text(
                              printingSetttings.receiptFotterArb,
                              textDirection: pw.TextDirection.rtl,
                              style: pw.TextStyle(
                                fontSize: 10,
                                font: arabicRegularFont,
                              ),
                            ))),
                  ],
                ),
              ),
            pw.SizedBox(
              height: 25,
            ),
          ]));
}

double calculateDiscountPercentage(double t, double dist) {
  double disPer = dist / (t / 100);

  return disPer;
}

String calculateTaxValue(double t, String tax) {
  //tax
  double taxValue = 0;
  if (tax.isNotEmpty) {
    double texPer = double.tryParse(tax) ?? 0;

    double tx = 1 + (texPer / 100);

    if (tx != 0) taxValue = t - (t / tx);
  }

  return doubleToString(taxValue);
}

String calculateVatIncludedValue(double t, String tax) {
  //tax
  double taxValue = 0;
  if (tax.isNotEmpty) {
    double texPer = double.tryParse(tax) ?? 0;

    double tx = texPer / 100;

    if (tx != 0) taxValue = t * tx;
  }

  return doubleToString(taxValue);
}

tableTotalTiles(txtNormalFont, arabicLightFont, List<LineItemData> items,
    tileNo, ReceiptOrQuotationData dbQuotationData) {
  double totalQty = 0;
  double subtotal = 0;

  for (var i in items) {
    totalQty += double.tryParse(i.qty) ?? 0;
    double unitPrice = double.parse(i.orgPrice);
    subtotal += unitPrice * double.parse(i.qty);
  }

  double totalAfterDiscount = subtotal -
      (double.tryParse(dbQuotationData.lineItemTotalData.totalDiscountValue) ??
          0);

  if (tileNo == 1) {
    return pw.TableRow(
        verticalAlignment: pw.TableCellVerticalAlignment.top,
        children: [
          pw.Container(
            decoration: const pw.BoxDecoration(
                color: PdfColor.fromInt(0xffeaeaea),
                border: pw.Border(
                  bottom: pw.BorderSide(width: 0.2, color: PdfColors.black),
                  left: pw.BorderSide(width: 0.2, color: PdfColors.black),
                  top: pw.BorderSide(width: 0.2, color: PdfColors.black),
                )),
            height: 18,
            width: 100,
            alignment: pw.Alignment.centerLeft,
            padding: const pw.EdgeInsets.all(2),
          ),
          pw.Container(
            decoration: const pw.BoxDecoration(
                color: PdfColor.fromInt(0xffeaeaea),
                border: pw.Border(
                  bottom: pw.BorderSide(width: 0.2, color: PdfColors.black),
                  top: pw.BorderSide(width: 0.2, color: PdfColors.black),
                )),
            height: 18,
            alignment: pw.Alignment.center,
            padding: const pw.EdgeInsets.all(2),
          ),
          pw.Container(
            decoration: const pw.BoxDecoration(
                color: PdfColor.fromInt(0xffeaeaea),
                border: pw.Border(
                  bottom: pw.BorderSide(width: 0.2, color: PdfColors.black),
                  top: pw.BorderSide(width: 0.2, color: PdfColors.black),
                )),
            height: 18,
            width: 100,
            padding: const pw.EdgeInsets.all(2),
          ),
          pw.Container(
              decoration: pw.BoxDecoration(
                  color: const PdfColor.fromInt(0xffeaeaea),
                  border: pw.Border.all(width: 0.2, color: PdfColors.black)),
              height: 18,
              alignment: pw.Alignment.center,
              padding: const pw.EdgeInsets.all(2),
              child: pw.Text(
                doubleToString(totalQty),
                style: pw.TextStyle(font: txtNormalFont, fontSize: 10),
              )),
          pw.Container(
              decoration: pw.BoxDecoration(
                  color: const PdfColor.fromInt(0xffeaeaea),
                  border: pw.Border.all(width: 0.2, color: PdfColors.black)),
              height: 18,
              alignment: pw.Alignment.center,
              padding: const pw.EdgeInsets.all(2),
              child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.end,
                  children: [
                    pw.Text('SubTotal',
                        style: pw.TextStyle(fontSize: 10, font: txtNormalFont)),
                    pw.SizedBox(
                      width: 5,
                    ),
                    pw.Text(
                      'الاجمالي',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(
                          font: arabicLightFont,
                          fontSize: 10,
                          fontWeight: pw.FontWeight.bold),
                    ),
                    pw.SizedBox(
                      width: 5,
                    ),
                  ])),
          pw.Container(
              decoration: pw.BoxDecoration(
                  color: const PdfColor.fromInt(0xffeaeaea),
                  border: pw.Border.all(width: 0.2, color: PdfColors.black)),
              height: 18,
              alignment: pw.Alignment.center,
              padding: const pw.EdgeInsets.all(2),
              child: pw.Text(subtotal.toStringAsFixed(2),
                  style: pw.TextStyle(
                    fontSize: 10,
                    font: txtNormalFont,
                  ))),
        ]);
  } else if (tileNo == 2) {
    return pw.Row(children: [
      pw.Expanded(
        child: pw.Container(
            decoration: const pw.BoxDecoration(
                border: pw.Border(
              left: pw.BorderSide(width: 0.2, color: PdfColors.black),
              bottom: pw.BorderSide(width: 0.2, color: PdfColors.black),
              top: pw.BorderSide(width: 0.2, color: PdfColors.black),
            )),
            height: 18,
            width: double.maxFinite,
            alignment: pw.Alignment.center,
            padding: const pw.EdgeInsets.all(3),
            child:
                pw.Row(mainAxisAlignment: pw.MainAxisAlignment.end, children: [
              pw.Text(
                  'Discount(${dbQuotationData.lineItemTotalData.totalDiscountPercentage}%)',
                  style: pw.TextStyle(fontSize: 10, font: txtNormalFont)),
              pw.SizedBox(
                width: 5,
              ),
              pw.Text(
                "خصم",
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicLightFont,
                    fontSize: 10,
                    fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(
                width: 5,
              ),
            ])),
      ),
      pw.Container(
          decoration: pw.BoxDecoration(
              border: pw.Border.all(width: 0.2, color: PdfColors.black)),
          height: 18,
          width: 88.5,
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.all(3),
          child: pw.Text(dbQuotationData.lineItemTotalData.totalDiscountValue,
              style: pw.TextStyle(
                fontSize: 10,
                font: txtNormalFont,
              ))),
    ]);
  } else if (tileNo == 3) {
    return pw.Row(children: [
      pw.Expanded(
          child: pw.Container(
              decoration: const pw.BoxDecoration(
                  border: pw.Border(
                left: pw.BorderSide(width: 0.2, color: PdfColors.black),
                bottom: pw.BorderSide(width: 0.2, color: PdfColors.black),
                top: pw.BorderSide(width: 0.2, color: PdfColors.black),
              )),
              height: 18,
              alignment: pw.Alignment.center,
              padding: const pw.EdgeInsets.all(3),
              child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.end,
                  children: [
                    pw.Text('Total after Discount',
                        style: pw.TextStyle(fontSize: 10, font: txtNormalFont)),
                    pw.SizedBox(
                      width: 5,
                    ),
                    pw.Text(
                      "المجموع بعد الخصم",
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(
                          font: arabicLightFont,
                          fontSize: 10,
                          fontWeight: pw.FontWeight.bold),
                    ),
                    pw.SizedBox(
                      width: 5,
                    ),
                  ]))),
      pw.Container(
          decoration: pw.BoxDecoration(
              border: pw.Border.all(width: 0.2, color: PdfColors.black)),
          height: 18,
          width: 88.5,
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.all(3),
          child: pw.Text((totalAfterDiscount.toStringAsFixed(2)),
              style: pw.TextStyle(
                fontSize: 10,
                font: txtNormalFont,
              ))),
    ]);
  } else if (tileNo == 4) {
    return pw.Row(children: [
      pw.Expanded(
          child: pw.Container(
              decoration: const pw.BoxDecoration(
                  border: pw.Border(
                left: pw.BorderSide(width: 0.2, color: PdfColors.black),
                bottom: pw.BorderSide(width: 0.2, color: PdfColors.black),
                top: pw.BorderSide(width: 0.2, color: PdfColors.black),
              )),
              height: 18,
              alignment: pw.Alignment.center,
              padding: const pw.EdgeInsets.all(3),
              child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.end,
                  children: [
                    pw.Text(
                        'Tax (${dbQuotationData.lineItemTotalData.totalTaxPercentage}%)',
                        style: pw.TextStyle(fontSize: 10, font: txtNormalFont)),
                    pw.SizedBox(
                      width: 5,
                    ),
                    pw.Text(
                      "ضريبة٪",
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(
                          font: arabicLightFont,
                          fontSize: 10,
                          fontWeight: pw.FontWeight.bold),
                    ),
                    pw.SizedBox(
                      width: 5,
                    ),
                  ]))),
      pw.Container(
          decoration: pw.BoxDecoration(
              border: pw.Border.all(width: 0.2, color: PdfColors.black)),
          height: 18,
          width: 88.5,
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.all(3),
          child: pw.Text(dbQuotationData.lineItemTotalData.totalTaxValue,
              style: pw.TextStyle(
                fontSize: 10,
                font: txtNormalFont,
              ))),
    ]);
  } else if (tileNo == 5) {
    return pw.Row(children: [
      pw.Expanded(
          child: pw.Container(
              decoration: const pw.BoxDecoration(
                  border: pw.Border(
                left: pw.BorderSide(width: 0.2, color: PdfColors.black),
                bottom: pw.BorderSide(width: 0.2, color: PdfColors.black),
                top: pw.BorderSide(width: 0.2, color: PdfColors.black),
              )),
              height: 18,
              alignment: pw.Alignment.center,
              padding: const pw.EdgeInsets.all(3),
              child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.end,
                  children: [
                    pw.Text('Total',
                        style: pw.TextStyle(fontSize: 12, font: txtNormalFont)),
                    pw.SizedBox(
                      width: 5,
                    ),
                    pw.Text(
                      "المجموع",
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(
                          font: arabicLightFont,
                          fontSize: 10,
                          fontWeight: pw.FontWeight.bold),
                    ),
                    pw.SizedBox(
                      width: 5,
                    ),
                  ]))),
      pw.Container(
          decoration: pw.BoxDecoration(
              border: pw.Border.all(width: 0.2, color: PdfColors.black)),
          height: 18,
          width: 88.5,
          alignment: pw.Alignment.center,
          padding: const pw.EdgeInsets.all(3),
          child: pw.Text(dbQuotationData.lineItemTotalData.receiptTotal,
              style: pw.TextStyle(
                fontWeight: pw.FontWeight.bold,
                fontSize: 12,
                font: txtNormalFont,
              ))),
    ]);
  }
}

productTile(txtNormalFont, LineItemData lineItemData, arabicFont, vatPercentage,
    bool last, ReceiptOrQuotationData dbQuotationData) {
  double height = 18;
  int nol = (lineItemData.productName.toString().length / 35).ceil();

  if (nol != 1) {
    height += 15 * (nol - 1);
  }

  return pw.Row(children: [
    pw.Container(
      decoration: pw.BoxDecoration(
          border: pw.Border.all(width: 0.2, color: PdfColors.black)),
      height: height,
      width: 53,
      alignment: pw.Alignment.centerLeft,
      padding: const pw.EdgeInsets.all(3),
      child: pw.Text(
        lineItemData.barcode,
        style: pw.TextStyle(font: txtNormalFont, fontSize: 10),
      ),
    ),
    pw.Container(
      decoration: pw.BoxDecoration(
          border: pw.Border.all(width: 0.2, color: PdfColors.black)),
      height: height,
      alignment: pw.Alignment.center,
      padding: const pw.EdgeInsets.all(3),
      width: 85,
      child: pw.Text(
        lineItemData.itemCode,
        style: pw.TextStyle(
          font: txtNormalFont,
          fontSize: 10,
        ),
      ),
    ),
    pw.Container(
      decoration: pw.BoxDecoration(
          border: pw.Border.all(width: 0.2, color: PdfColors.black)),
      height: height,
      width: 224,
      padding: const pw.EdgeInsets.all(3),
      child: pw.Text(
          // '1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890',
          lineItemData.productName,
          textDirection:
              !containsExtendedArabic(lineItemData.productName.toString())
                  ? pw.TextDirection.ltr
                  : pw.TextDirection.rtl,
          softWrap: true,
          style: pw.TextStyle(
            font: !containsExtendedArabic(lineItemData.productName.toString())
                ? txtNormalFont
                : arabicFont,
            fontSize: 10,
            //
          )),
    ),
    pw.Container(
        decoration: pw.BoxDecoration(
            border: pw.Border.all(width: 0.2, color: PdfColors.black)),
        height: height,
        alignment: pw.Alignment.center,
        width: 45,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Text(
          lineItemData.qty,
          style: pw.TextStyle(font: txtNormalFont, fontSize: 10),
        )),
    pw.Container(
      decoration: pw.BoxDecoration(
        border: pw.Border.all(width: 0.2, color: PdfColors.black),
      ),
      height: height,
      alignment: pw.Alignment.center,
      width: 80,
      padding: const pw.EdgeInsets.all(3),
      child: pw.Text(
        double.parse(lineItemData.orgPrice)
            .toStringAsFixed(2), // Ensure two decimal places
        style: pw.TextStyle(fontSize: 10, font: txtNormalFont),
      ),
    ),
    pw.Container(
      decoration: pw.BoxDecoration(
        border: pw.Border.all(width: 0.2, color: PdfColors.black),
      ),
      height: height,
      alignment: pw.Alignment.center,
      width: 80,
      padding: const pw.EdgeInsets.all(3),
      child: pw.Text(
        (double.parse(lineItemData.orgPrice) * double.parse(lineItemData.qty))
            .toStringAsFixed(2), // Ensure two decimal places
        style: pw.TextStyle(
          fontSize: 10,
          font: txtNormalFont,
        ),
      ),
    )
  ]);
}
