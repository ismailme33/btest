import 'dart:io';
import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_settings_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_function.dart';
import 'package:hive/hive.dart';
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../../model/customer_data.dart';
import 'DES0003_A4_quotation_template.dart';

Future<void> printQuotation(
  context,
  ReceiptOrQuotationData dbQuotationData,
  CustomerData? selectedCustomerData,
) async {
  var box = Hive.box('bitpro_app');

  final doc = pw.Document();

  final arabicBoldFont =
      await fontFromAssetBundle('assets/Segoe.UI_.Semibold.ttf');
  final arabicRegularFont = await fontFromAssetBundle('assets/Segoe.UI.ttf');

  EmployeeData userData = EmployeeData.fromMap(box.get('user_data'));

  PrintingSetttings printingSetttings =
      await HiveSettingsDbService().getPrintingSettingsData();

  StoreData seletedStoreData =
      await HiveStoreDbService().getSelectedStoreData();

  var image;

  TaxSettingsData taxSettingsData =
      await HiveSettingsDbService().getTaxSettingsData();
  String vatPercentage = doubleToString(taxSettingsData.taxPercentage);

  try {
    if (seletedStoreData.logoPath.isNotEmpty) {
      image = pw.MemoryImage(File(seletedStoreData.logoPath).readAsBytesSync());
    }
  } catch (e) {}
  image ??= await imageFromAssetBundle('assets/bitpro_logo.png');

  if (printingSetttings.selectedQuotationTemplate == 'DES0003-A4') {
    var englishRegularFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Regular.ttf');
    var englishBoldFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Bold.ttf');
    doc.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(15),
        footer: (c) {
          return pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: [
                pw.Text('${c.pageNumber} / ${c.pagesCount}',
                    style: pw.TextStyle(
                        font: englishRegularFont,
                        color: PdfColors.grey,
                        fontSize: 9)),
              ]);
        },
        build: (pw.Context context) {
          return [
            des0003A4QuotationTemplate(
                englishRegularFont: englishRegularFont,
                englishBoldFont: englishBoldFont,
                arabicBoldFont: arabicBoldFont,
                arabicRegularFont: arabicRegularFont,
                image: image,
                selectedCustomerData: selectedCustomerData,
                dbQuotationData: dbQuotationData,
                userData: userData,
                printingSetttings: printingSetttings,
                selectedStoreData: seletedStoreData,
                vatPercentage: vatPercentage)
          ];
        }));
    await rprintFunction(
        context: context,
        doc: doc,
        selectedPrinter: printingSetttings.selectedPrinter);
  }
}

String buildBarcode(
  Barcode bc,
  String data, {
  String? filename,
  double? width,
  double? height,
  double? fontHeight,
}) {
  /// Create the Barcode
  final svg = bc.toSvg(
    data,
    width: width ?? 200,
    height: height ?? 80,
    fontHeight: fontHeight,
  );

  return svg;
}

calculateTotalPriceWt(items) {
  double t = 0;
  for (var i in items) {
    t += double.parse(i['priceWt']) * double.parse(i['qty']);
  }
  return t;
}
