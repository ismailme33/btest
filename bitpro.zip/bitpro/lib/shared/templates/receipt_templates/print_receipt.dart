import 'dart:io';
import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_settings_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_function.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/80mm_with_specification.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/DES0005_A4_receipt_template.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/ksa_001_receipt_template.dart';
import 'package:hive/hive.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/DES0002_A4_receipt_template.dart';
import 'package:printing/printing.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../../model/customer_data.dart';
import 'templates/80mm_noVat.dart';
import 'templates/80mm_receipt_template.dart';
import 'templates/DES0001_A4_receipt_template.dart';
import 'templates/DES0003_A4_receipt_template.dart';
import 'templates/DES0004_A4_receipt_template.dart';
import 'templates/ECS_POS_80mm_template.dart';

Future<void> printReceipt(
    context,
    ReceiptOrQuotationData dbReceiptData,
    String taxValue,
    CustomerData? selectedCustomerData,
    String tenderAmount,
    String changeAmount) async {
  var box = Hive.box('bitpro_app');

  final doc = pw.Document();

  final arabicBoldFont =
      await fontFromAssetBundle('assets/Segoe.UI_.Semibold.ttf');
  final arabicRegularFont = await fontFromAssetBundle('assets/Segoe.UI.ttf');

  EmployeeData userData = EmployeeData.fromMap(box.get('user_data'));

  PrintingSetttings printingSetttings =
      await HiveSettingsDbService().getPrintingSettingsData();
  List<StoreData> storeDataList =
      await HiveStoreDbService().fetchAllStoresData();

  StoreData? seletedStoreData;
  if (storeDataList.any(
      (e) => e.docId == dbReceiptData.receiptBasicInfo!.selectedStoreDocId)) {
    seletedStoreData = storeDataList
        .where((e) =>
            e.docId == dbReceiptData.receiptBasicInfo!.selectedStoreDocId)
        .first;
  }
  var image;

  TaxSettingsData taxSettingsData =
      await HiveSettingsDbService().getTaxSettingsData();
  String vatPercentage = doubleToString(taxSettingsData.taxPercentage);

  try {
    if (seletedStoreData != null && seletedStoreData.logoPath.isNotEmpty) {
      image = pw.MemoryImage(File(seletedStoreData.logoPath).readAsBytesSync());
    }
  } catch (e) {
    // image = await imageFromAssetBundle('assets/bitpro_logo.png');
  }

  if (printingSetttings.selectedReceiptTemplate == '80 mm') {
    var englishBoldFont = await fontFromAssetBundle(
        'assets/fonts/new_fonts/CourierPrime-Bold.ttf');

    doc.addPage(pw.MultiPage(
        pageFormat:
            const PdfPageFormat(70 * PdfPageFormat.mm, 297 * PdfPageFormat.mm),
        build: (context) {
          return receipt80mmTemplate(
              selectedCustomerData: selectedCustomerData,
              arabicBoldFont: arabicBoldFont,
              englishBoldFont: englishBoldFont,
              image: image,
              dbReceiptData: dbReceiptData,
              taxValue: taxValue,
              userData: userData,
              printingSetttings: printingSetttings,
              selectedStoreData: seletedStoreData,
              vatPercentage: vatPercentage);
        }));
  } else if (printingSetttings.selectedReceiptTemplate == '80mm SPCS' ||
      printingSetttings.selectedReceiptTemplate == '80mm With Specificaiton') {
    var englishBoldFont = await fontFromAssetBundle(
        'assets/fonts/new_fonts/CourierPrime-Bold.ttf');
    var englishRegularFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Regular.ttf');

    doc.addPage(pw.MultiPage(
        pageFormat:
            const PdfPageFormat(70 * PdfPageFormat.mm, 297 * PdfPageFormat.mm),
        build: (context) {
          return receipt80mmWithSpecificaitonTemplate(
              arabicBoldFont: arabicBoldFont,
              englishBoldFont: englishBoldFont,
              selectedCustomerData: selectedCustomerData,
              arabicNormalFont: arabicRegularFont,
              englishNormalFont: englishRegularFont,
              image: image,
              dbReceiptData: dbReceiptData,
              taxValue: taxValue,
              printingSetttings: printingSetttings,
              selectedStoreData: seletedStoreData,
              vatPercentage: vatPercentage);
        }));
  } else if (printingSetttings.selectedReceiptTemplate == '80 mm No Vat') {
    var englishBoldFont = await fontFromAssetBundle(
        'assets/fonts/new_fonts/CourierPrime-Bold.ttf');

    doc.addPage(pw.MultiPage(
        pageFormat:
            const PdfPageFormat(70 * PdfPageFormat.mm, 297 * PdfPageFormat.mm),
        build: (context) {
          return receipt80mmNoVatTemplate(
              arabicBoldFont: arabicBoldFont,
              englishBoldFont: englishBoldFont,
              image: image,
              dbReceiptData: dbReceiptData,
              taxValue: taxValue,
              userData: userData,
              selectedStoreData: seletedStoreData,
              printingSetttings: printingSetttings,
              vatPercentage: vatPercentage);
        }));
  } else if (printingSetttings.selectedReceiptTemplate == 'ECS-POS-80mm') {
    var englishBoldFont = await fontFromAssetBundle(
        'assets/fonts/new_fonts/CourierPrime-Bold.ttf');
    doc.addPage(pw.MultiPage(
        pageFormat:
            const PdfPageFormat(70 * PdfPageFormat.mm, 297 * PdfPageFormat.mm),
        build: (context) {
          return receiptECSPOS80mmTemplate(
              arabicBoldFont: arabicBoldFont,
              txtBoldFont: englishBoldFont,
              image: image,
              dbReceiptData: dbReceiptData,
              taxValue: taxValue,
              userData: userData,
              selectedStoreData: seletedStoreData,
              printingSetttings: printingSetttings,
              vatPercentage: vatPercentage);
        }));
  } else if (printingSetttings.selectedReceiptTemplate == 'DES0001-A4') {
    var englishRegularFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Regular.ttf');
    var englishBoldFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Bold.ttf');
    doc.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(15),
        build: (pw.Context context) {
          return [
            des0001A4ReceiptTemplate(
              englishRegularFont: englishRegularFont,
              englishBoldFont: englishBoldFont,
              arabicRegularFont: arabicRegularFont,
              arabicBoldFont: arabicBoldFont,
              image: image,
              selectedCustomerData: selectedCustomerData,
              dbReceiptData: dbReceiptData,
              taxValue: taxValue,
              userData: userData,
              printingSetttings: printingSetttings,
              selectedStoreData: seletedStoreData,
              vatPercentage: vatPercentage,
            )
          ];
        }));
  } else if (printingSetttings.selectedReceiptTemplate == 'DES0002-A4') {
    var englishRegularFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Regular.ttf');
    var englishBoldFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Bold.ttf');
    doc.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(15),
        build: (pw.Context context) {
          return [
            des0002A4ReceiptTemplate(
                englishRegularFont: englishRegularFont,
                englishBoldFont: englishBoldFont,
                arabicBoldFont: arabicBoldFont,
                arabicRegularFont: arabicRegularFont,
                image: image,
                selectedCustomerData: selectedCustomerData,
                dbReceiptData: dbReceiptData,
                taxValue: taxValue,
                userData: userData,
                selectedStoreData: seletedStoreData,
                printingSetttings: printingSetttings,
                vatPercentage: vatPercentage)
          ];
        }));
  } else if (printingSetttings.selectedReceiptTemplate == 'DES0003-A4') {
    var englishRegularFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Regular.ttf');
    var englishBoldFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Bold.ttf');
    doc.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(15),
        footer: (c) {
          return pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: [
                pw.Text('${c.pageNumber} / ${c.pagesCount}',
                    style: pw.TextStyle(
                        font: englishRegularFont,
                        color: PdfColors.grey,
                        fontSize: 9)),
              ]);
        },
        build: (pw.Context context) {
          return [
            des0003A4ReceiptTemplate(
                englishRegularFont: englishRegularFont,
                englishBoldFont: englishBoldFont,
                arabicBoldFont: arabicBoldFont,
                arabicRegularFont: arabicRegularFont,
                image: image,
                selectedCustomerData: selectedCustomerData,
                dbReceiptData: dbReceiptData,
                taxValue: taxValue,
                userData: userData,
                printingSetttings: printingSetttings,
                selectedStoreData: seletedStoreData,
                vatPercentage: vatPercentage)
          ];
        }));
  } else if (printingSetttings.selectedReceiptTemplate == 'DES0004-A4') {
    var englishRegularFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Regular.ttf');
    var englishBoldFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Bold.ttf');

    doc.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(15),
        footer: (c) {
          return pw.Row(children: [
            pw.Expanded(child: pw.SizedBox(width: 5)),
            pw.Text('Page ${c.pageNumber}',
                style: pw.TextStyle(font: englishRegularFont, fontSize: 9)),
            pw.SizedBox(width: 20)
          ]);
        },
        build: (pw.Context context) {
          return [
            des0004A4ReceiptTemplate(
                englishRegularFont: englishRegularFont,
                englishBoldFont: englishBoldFont,
                arabicBoldFont: arabicBoldFont,
                arabicRegularFont: arabicRegularFont,
                context: context,
                changeAmount: changeAmount,
                tenderAmount: tenderAmount,
                selectedCustomerData: selectedCustomerData,
                dbReceiptData: dbReceiptData,
                image: image,
                taxValue: taxValue,
                printingSetttings: printingSetttings,
                selectedStoreData: seletedStoreData,
                vatPercentage: vatPercentage)
          ];
        }));
  } else if (printingSetttings.selectedReceiptTemplate == 'DES0005-A4') {
    var englishRegularFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Regular.ttf');
    var englishBoldFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Bold.ttf');

    // String headerImgPath = await box.get('header_img_path') ?? '';
    // String fotterImgPath = await box.get('fotter_img_path') ?? '';

    var headerImg;
    var fotterImg;
    if (printingSetttings.headerImgPath.isNotEmpty &&
        File(printingSetttings.headerImgPath).existsSync() == true) {
      headerImg = await File(printingSetttings.headerImgPath).readAsBytes();
    }
    if (printingSetttings.fotterImgPath.isNotEmpty &&
        File(printingSetttings.fotterImgPath).existsSync() == true) {
      fotterImg = await File(printingSetttings.fotterImgPath).readAsBytes();
    }
    doc.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(15),
        header: headerImg == null
            ? null
            : (c) {
                return pw.Image(
                    pw.MemoryImage(
                      headerImg,
                    ),
                    fit: pw.BoxFit.fitHeight,
                    width: PdfPageFormat.a4.width,
                    height: PdfPageFormat.a4.height * 0.1347);
              },
        footer: fotterImg == null
            ? null
            : (c) {
                return pw.SizedBox(
                    width: PdfPageFormat.a4.width,
                    height: PdfPageFormat.a4.height * 0.0741,
                    child: pw.Stack(children: [
                      pw.Image(
                        pw.MemoryImage(fotterImg),
                        fit: pw.BoxFit.fitHeight,
                      ),
                      pw.Positioned(
                        bottom: 10,
                        right: 10,
                        child: pw.Text('Page ${c.pageNumber}',
                            style: pw.TextStyle(
                                font: englishRegularFont, fontSize: 9)),
                      )
                    ]));
              },
        build: (pw.Context context) {
          return [
            des0005A4ReceiptTemplate(
                englishRegularFont: englishRegularFont,
                englishBoldFont: englishBoldFont,
                arabicBoldFont: arabicBoldFont,
                arabicRegularFont: arabicRegularFont,
                context: context,
                changeAmount: changeAmount,
                tenderAmount: tenderAmount,
                selectedCustomerData: selectedCustomerData,
                dbReceiptData: dbReceiptData,
                image: image,
                taxValue: taxValue,
                printingSetttings: printingSetttings,
                selectedStoreData: seletedStoreData,
                vatPercentage: vatPercentage)
          ];
        }));
  } else if (printingSetttings.selectedReceiptTemplate == 'KSA-001') {
    var dinBold =
        await fontFromAssetBundle('assets/fonts/KSA_001_fonts/DinBold.ttf');
    var dinHeavy =
        await fontFromAssetBundle('assets/fonts/KSA_001_fonts/DinHeavy.ttf');
    var englishRegularFont =
        await fontFromAssetBundle('assets/fonts/new_fonts/Roboto-Regular.ttf');
    doc.addPage(pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        footer: (c) {
          return pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: [
                pw.Text('${c.pageNumber} / ${c.pagesCount}',
                    style: pw.TextStyle(
                        font: englishRegularFont,
                        color: PdfColors.grey,
                        fontSize: 8)),
              ]);
        },
        margin: const pw.EdgeInsets.all(15),
        build: (pw.Context context) {
          return [
            ksa001ReceiptTemplate(
              dinBold: dinBold,
              dinHeavy: dinHeavy,
              arabicRegularFont: arabicRegularFont,
              arabicBoldFont: arabicBoldFont,
              image: image,
              selectedCustomerData: selectedCustomerData,
              dbReceiptData: dbReceiptData,
              taxValue: taxValue,
              userData: userData,
              printingSetttings: printingSetttings,
              selectedStoreData: seletedStoreData,
              vatPercentage: vatPercentage,
            )
          ];
        }));
  }

  await rprintFunction(
      context: context,
      doc: doc,
      selectedPrinter: printingSetttings.selectedPrinter);
}

String buildBarcode(
  Barcode bc,
  String data, {
  String? filename,
  double? width,
  double? height,
  double? fontHeight,
}) {
  /// Create the Barcode
  final svg = bc.toSvg(
    data,
    width: width ?? 200,
    height: height ?? 80,
    fontHeight: fontHeight,
  );

  return svg;
}

calculateTotalPriceWt(items) {
  double t = 0;
  for (var i in items) {
    t += double.parse(i['priceWt']) * double.parse(i['qty']);
  }
  return t;
}
