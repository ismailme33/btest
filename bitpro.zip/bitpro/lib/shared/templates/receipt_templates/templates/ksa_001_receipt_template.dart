import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/custom_plugin/number_to_arabic/number_to_arabic.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/widget/string_related/get_payment_type.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/e_invoice_generator.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../../../model/customer_data.dart';

pw.Widget ksa001ReceiptTemplate({
  required image,
  required EmployeeData userData,
  required PrintingSetttings printingSetttings,
  required ReceiptOrQuotationData dbReceiptData,
  required dinHeavy,
  required arabicRegularFont,
  required arabicBoldFont,
  required vatPercentage,
  required taxValue,
  required dinBold,
  required StoreData? selectedStoreData,
  required CustomerData? selectedCustomerData,
}) {
  return pw.Container(
      padding: pw.EdgeInsets.all(18),
      width: double.maxFinite,
      child: pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.start,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Container(
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(width: 1),
                    borderRadius: pw.BorderRadius.circular(7)),
                width: double.maxFinite,
                // height: 200,
                padding: pw.EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                child: pw.Row(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    mainAxisAlignment: pw.MainAxisAlignment.start,
                    children: [
                      pw.Expanded(
                          child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                            pw.SizedBox(width: 5),
                            pw.Text(
                              selectedStoreData == null
                                  ? ''
                                  : selectedStoreData.storeName,
                              style: pw.TextStyle(font: dinHeavy, fontSize: 10),
                            ),
                            pw.Text(
                              selectedStoreData == null
                                  ? ''
                                  : selectedStoreData.address,
                              textDirection: !containsExtendedArabic(
                                      selectedStoreData == null
                                          ? ''
                                          : selectedStoreData.address)
                                  ? pw.TextDirection.ltr
                                  : pw.TextDirection.rtl,
                              textAlign: pw.TextAlign.left,
                              style: pw.TextStyle(font: dinHeavy, fontSize: 9),
                            ),
                          ])),
                      pw.SizedBox(width: 10),
                      if (image != null)
                        pw.ClipRRect(
                          horizontalRadius: 5,
                          verticalRadius: 5,
                          child: pw.Image(image,
                              width: 80, height: 60, fit: pw.BoxFit.contain),
                        ),
                      pw.SizedBox(width: 10),
                      pw.Expanded(
                          child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.end,
                              children: [
                            pw.SizedBox(width: 5),
                            pw.Text(
                              selectedStoreData == null
                                  ? ''
                                  : selectedStoreData.storeArabicName,
                              textDirection: pw.TextDirection.rtl,
                              textAlign: pw.TextAlign.right,
                              style: pw.TextStyle(font: dinHeavy, fontSize: 12),
                            ),
                            pw.Text(
                              selectedStoreData == null
                                  ? ''
                                  : selectedStoreData.address,
                              textDirection: !containsExtendedArabic(
                                      selectedStoreData == null
                                          ? ''
                                          : selectedStoreData.address)
                                  ? pw.TextDirection.ltr
                                  : pw.TextDirection.rtl,
                              textAlign: pw.TextAlign.right,
                              style: pw.TextStyle(font: dinHeavy, fontSize: 9),
                            ),
                          ])),
                    ])),
            pw.SizedBox(height: 5),
            pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.Text(
                    printingSetttings.receiptTitleEng,
                    style: pw.TextStyle(font: dinHeavy, fontSize: 10),
                  ),
                  pw.SizedBox(width: 5),
                  pw.Text(
                    printingSetttings.receiptTitleArb,
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                        fontSize: 10,
                        font: dinHeavy,
                        fontWeight: pw.FontWeight.bold),
                  ),
                ]),
            pw.SizedBox(height: 5),
            pw.Container(
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(width: 1),
                    borderRadius: pw.BorderRadius.circular(8)),
                width: double.maxFinite,
                // height: 200,

                child: pw.Row(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    mainAxisAlignment: pw.MainAxisAlignment.start,
                    children: [
                      //store, customer, branch info
                      storeCustomerAndBranchInfoWidget(
                          selectedStoreData: selectedStoreData,
                          selectedCustomerData: selectedCustomerData,
                          dbReceiptData: dbReceiptData,
                          font: dinBold),
                      //invoice, barcode info
                      invoiceAndBarcodeInfo(
                          dbReceiptData: dbReceiptData,
                          font: dinBold,
                          selectedStoreData: selectedStoreData,
                          taxValue: taxValue)
                    ])),
            pw.SizedBox(height: 10),
            itemTableWidget(
                font2: dinHeavy, font: dinBold, dbReceiptData: dbReceiptData),
            pw.SizedBox(height: 5),
            pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Row(children: [
                    pw.SizedBox(width: 5),
                    pw.Text(dbReceiptData.lineItemTotalData.totalQty,
                        style: pw.TextStyle(fontSize: 9, font: dinHeavy)),
                    pw.SizedBox(width: 5),
                    pw.Text('Quantity ',
                        style: pw.TextStyle(fontSize: 9, font: dinHeavy)),
                    pw.Text('كمية',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(fontSize: 9, font: dinHeavy)),
                  ]),
                  pw.Row(children: [
                    pw.Text('Totals ',
                        style: pw.TextStyle(fontSize: 10, font: dinHeavy)),
                    pw.Text('اﻹﺟﻤﺎﻟﻴﺎت',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(fontSize: 10, font: dinHeavy)),
                  ])
                ]),
            pw.SizedBox(height: 5),
            totalTableWidget(
                dbReceiptData: dbReceiptData,
                items: dbReceiptData.lineItemsData,
                font2: dinHeavy),
            pw.SizedBox(height: 5),
            // pw.Row(mainAxisAlignment: pw.MainAxisAlignment.end, children: [
            //   pw.Text(
            //       NumberToArabicWords.convert(double.tryParse(
            //               dbReceiptData.lineItemTotalData.receiptTotal) ??
            //           0),
            //       textDirection: pw.TextDirection.rtl,
            //       style: pw.TextStyle(fontSize: 8, font: dinHeavy)),
            // ]),
            pw.SizedBox(height: 5),
            if (printingSetttings.receiptFotterArb.isNotEmpty)
              pw.Row(mainAxisAlignment: pw.MainAxisAlignment.end, children: [
                pw.Text(printingSetttings.receiptFotterArb,
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(fontSize: 8, font: dinBold)),
              ]),
            pw.SizedBox(
              height: 25,
            ),
          ]));
}

pw.Widget storeCustomerAndBranchInfoWidget(
    {required StoreData? selectedStoreData,
    required CustomerData? selectedCustomerData,
    required ReceiptOrQuotationData dbReceiptData,
    required font}) {
  List<Map<String, String>> storeDataLst = [
    // {
    //   'column_1': '',
    //   'column_2_txt_a': '',
    //   'column_2_txt_b': '',
    //   'column_3': 'ﻣﺆﺳﺴﺔ ﻧﻮرا ﺳﺘﺎﻳﻞ ﻟﻠﺘﺠﺎرة',
    //   'column_4_txt_a': 'Seller ',
    //   'column_4_txt_b': 'اﺳﻢ اﻟﺒﺎﺋﻊ'
    // },
    {
      'column_1': selectedStoreData == null ? '' : selectedStoreData.crNumber,
      'column_2_txt_a': 'CR ',
      'column_2_txt_b': 'اﻟﺴﺠﻞ اﻟﺘﺠﺎري',
      'column_3': selectedStoreData == null ? '' : selectedStoreData.vatNumber,
      'column_4_txt_a': 'TIN ',
      'column_4_txt_b': 'اﻟﺮﻗﻢ اﻟﻀﺮﻳﺒﻲ'
    },
    {
      'column_1':
          selectedStoreData == null ? '' : selectedStoreData.buildingNumber,
      'column_2_txt_a': 'Building ',
      'column_2_txt_b': 'ﻣﺒﻨﻰ',
      'column_3': selectedStoreData == null ? '' : selectedStoreData.street,
      'column_4_txt_a': 'Street ',
      'column_4_txt_b': 'ﺷﺎرع'
    },
    {
      'column_1': selectedStoreData == null ? '' : selectedStoreData.postCode,
      'column_2_txt_a': 'Post code ',
      'column_2_txt_b': 'رﻣﺰ ﺑﺮﻳﺪي',
      'column_3': selectedStoreData == null ? '' : selectedStoreData.area,
      'column_4_txt_a': 'Area ',
      'column_4_txt_b': 'اﻟﺤﻲ'
    },
    {
      'column_1':
          selectedStoreData == null ? '' : selectedStoreData.additionalNumber,
      'column_2_txt_a': 'Add. No ',
      'column_2_txt_b': 'رﻗﻢ إﺿﺎﻓﻲ',
      'column_3': selectedStoreData == null ? '' : selectedStoreData.country,
      'column_4_txt_a': 'Country ',
      'column_4_txt_b': 'دوﻟﺔ'
    },
    {
      'column_1':
          selectedStoreData == null ? '' : selectedStoreData.shortAddress,
      'column_2_txt_a': 'Short Add.',
      'column_2_txt_b': 'ﻋﻨﻮان ﻣﺨﺘﺼﺮ',
      'column_3': selectedStoreData == null ? '' : selectedStoreData.city,
      'column_4_txt_a': 'City ',
      'column_4_txt_b': 'ﻣﺪﻳﻨﺔ'
    }
  ];
  List<Map<String, String>> customerDataLst = [
    // {
    //   'column_1': '',
    //   'column_2_txt_a': '',
    //   'column_2_txt_b': '',
    //   'column_3': 'ﻣﺆﺳﺴﺔ ﻧﻮرا ﺳﺘﺎﻳﻞ ﻟﻠﺘﺠﺎرة',
    //   'column_4_txt_a': 'Buyer ',
    //   'column_4_txt_b': 'اﺳﻢ اﻟﻌﻤﻴﻞ'
    // },
    {
      'column_1':
          selectedCustomerData == null ? '' : selectedCustomerData.crNumber,
      'column_2_txt_a': 'CR ',
      'column_2_txt_b': 'اﻟﺴﺠﻞ اﻟﺘﺠﺎري',
      'column_3':
          selectedCustomerData == null ? '' : selectedCustomerData.vatNo,
      'column_4_txt_a': 'TIN ',
      'column_4_txt_b': 'اﻟﺮﻗﻢ اﻟﻀﺮﻳﺒﻲ'
    },
    {
      'column_1': selectedCustomerData == null
          ? ''
          : selectedCustomerData.buildingNumber,
      'column_2_txt_a': 'Building ',
      'column_2_txt_b': 'ﻣﺒﻨﻰ',
      'column_3':
          selectedCustomerData == null ? '' : selectedCustomerData.street,
      'column_4_txt_a': 'Street ',
      'column_4_txt_b': 'ﺷﺎرع'
    },
    {
      'column_1':
          selectedCustomerData == null ? '' : selectedCustomerData.postCode,
      'column_2_txt_a': 'Post code ',
      'column_2_txt_b': 'رﻣﺰ ﺑﺮﻳﺪي',
      'column_3': selectedCustomerData == null ? '' : selectedCustomerData.area,
      'column_4_txt_a': 'Area ',
      'column_4_txt_b': 'اﻟﺤﻲ'
    },
    {
      'column_1': selectedCustomerData == null
          ? ''
          : selectedCustomerData.additionalNumber,
      'column_2_txt_a': 'Add. No ',
      'column_2_txt_b': 'رﻗﻢ إﺿﺎﻓﻲ',
      'column_3':
          selectedCustomerData == null ? '' : selectedCustomerData.country,
      'column_4_txt_a': 'Country ',
      'column_4_txt_b': 'دوﻟﺔ'
    },
    {
      'column_1':
          selectedCustomerData == null ? '' : selectedCustomerData.shortAddress,
      'column_2_txt_a': 'Short Add.',
      'column_2_txt_b': 'ﻋﻨﻮان ﻣﺨﺘﺼﺮ',
      'column_3': selectedCustomerData == null ? '' : selectedCustomerData.city,
      'column_4_txt_a': 'City ',
      'column_4_txt_b': 'ﻣﺪﻳﻨﺔ'
    }
  ];
  CustomerBranchData? selectedBranchData;

  if (dbReceiptData.receiptBasicInfo != null &&
      dbReceiptData.receiptBasicInfo!.selectedCustomerBranchDocId.isNotEmpty) {
    int index = selectedCustomerData!.customerBranchDataLst.indexWhere((e) =>
        e.docId == dbReceiptData.receiptBasicInfo!.selectedCustomerBranchDocId);
    if (index != -1) {
      selectedBranchData = selectedCustomerData.customerBranchDataLst[index];
    }
  }

  List<Map<String, String>> brachDataLst = [
    {
      'column_1':
          selectedBranchData == null ? '' : selectedBranchData.branchName,
      'column_2_txt_a': 'Branch ',
      'column_2_txt_b': 'ﻓﺮع',
      'column_3': selectedBranchData == null ? '' : selectedBranchData.phone,
      'column_4_txt_a': 'Phone ',
      'column_4_txt_b': 'ﻫﺎﺗﻒ'
    },
    {
      'column_1': selectedBranchData == null ? '' : selectedBranchData.carrier,
      'column_2_txt_a': 'Carrier ',
      'column_2_txt_b': 'ﻣﺨﺮج',
      'column_3':
          selectedBranchData == null ? '' : selectedBranchData.branchAddress,
      'column_4_txt_a': 'Address ',
      'column_4_txt_b': 'ﻋﻨﻮان'
    },
  ];

  return pw.Expanded(
      child: pw.Container(
          decoration:
              pw.BoxDecoration(border: pw.Border(right: pw.BorderSide())),
          child: pw.Column(
            children: [
              pw.SizedBox(
                height: 5,
              ),
              for (var i = 0; i < 3; i++) ...[
                if (i != 0)
                  pw.Container(
                      height: 1,
                      color: PdfColors.black,
                      width: double.infinity,
                      margin: pw.EdgeInsets.symmetric(vertical: 5)),
                if (i != 2)
                  pw.Padding(
                      padding: pw.EdgeInsets.symmetric(horizontal: 10),
                      child: pw.Table(
                          defaultVerticalAlignment:
                              pw.TableCellVerticalAlignment.full,
                          columnWidths: {
                            0: const pw.FlexColumnWidth(.2),
                            1: const pw.FlexColumnWidth(.2),
                            2: const pw.FlexColumnWidth(3.5),
                            3: const pw.FlexColumnWidth(1.32),
                          },
                          children: [
                            pw.TableRow(
                                verticalAlignment:
                                    pw.TableCellVerticalAlignment.top,
                                children: [
                                  pw.Container(
                                    alignment: pw.Alignment.centerRight,
                                  ),
                                  pw.Container(
                                    alignment: pw.Alignment.centerRight,
                                  ),
                                  pw.Container(
                                    alignment: pw.Alignment.centerRight,
                                    child: pw.Text(
                                        maxLines: 1,
                                        overflow: pw.TextOverflow.clip,
                                        i == 0
                                            ? selectedStoreData == null
                                                ? ''
                                                : selectedStoreData.storeName
                                            : selectedCustomerData == null
                                                ? ''
                                                : selectedCustomerData
                                                    .customerName,
                                        textDirection: pw.TextDirection.rtl,
                                        textAlign: pw.TextAlign.right,
                                        style: pw.TextStyle(
                                            fontSize: 9,
                                            color: PdfColors.black,
                                            font: font)),
                                  ),
                                  pw.Container(
                                      alignment: pw.Alignment.centerRight,
                                      child: pw.Row(
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.end,
                                        mainAxisAlignment:
                                            pw.MainAxisAlignment.end,
                                        children: [
                                          pw.Text(
                                            i == 0 ? 'Seller ' : 'Buyer ',
                                            textAlign: pw.TextAlign.right,
                                            style: pw.TextStyle(
                                                fontSize: 9,
                                                color: PdfColors.black,
                                                font: font),
                                          ),
                                          pw.Text(
                                            i == 0
                                                ? 'اﺳﻢ اﻟﺒﺎﺋﻊ'
                                                : 'اﺳﻢ اﻟﻌﻤﻴﻞ',
                                            textDirection: pw.TextDirection.rtl,
                                            textAlign: pw.TextAlign.right,
                                            style: pw.TextStyle(
                                                fontSize: 9,
                                                color: PdfColors.black,
                                                font: font),
                                          )
                                        ],
                                      )),
                                ])
                          ])),
                pw.Padding(
                    padding: pw.EdgeInsets.symmetric(horizontal: 10),
                    child: pw.Table(
                        defaultVerticalAlignment:
                            pw.TableCellVerticalAlignment.full,
                        columnWidths: {
                          0: const pw.FlexColumnWidth(1),
                          1: const pw.FlexColumnWidth(1),
                          2: const pw.FlexColumnWidth(1),
                          3: const pw.FlexColumnWidth(1),
                        },
                        children: [
                          for (var sd in i == 0
                              ? storeDataLst
                              : i == 1
                                  ? customerDataLst
                                  : brachDataLst)
                            pw.TableRow(
                                verticalAlignment:
                                    pw.TableCellVerticalAlignment.top,
                                children: [
                                  pw.Container(
                                    alignment: pw.Alignment.centerRight,
                                    child: pw.Text(sd['column_1']!,
                                        textDirection: !containsExtendedArabic(
                                                sd['column_1']!)
                                            ? pw.TextDirection.ltr
                                            : pw.TextDirection.rtl,
                                        textAlign: pw.TextAlign.right,
                                        style: pw.TextStyle(
                                            fontSize: 7,
                                            color: PdfColors.black,
                                            font: font)),
                                  ),
                                  pw.Container(
                                      alignment: pw.Alignment.centerRight,
                                      child: pw.Row(
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.end,
                                        mainAxisAlignment:
                                            pw.MainAxisAlignment.end,
                                        children: [
                                          pw.Text(
                                            sd['column_2_txt_a']!,
                                            textDirection:
                                                !containsExtendedArabic(
                                                        sd['column_2_txt_a']!)
                                                    ? pw.TextDirection.ltr
                                                    : pw.TextDirection.rtl,
                                            textAlign: pw.TextAlign.right,
                                            style: pw.TextStyle(
                                                fontSize: 8,
                                                color: PdfColors.black,
                                                font: font),
                                          ),
                                          pw.Text(
                                            sd['column_2_txt_b']!,
                                            textDirection:
                                                !containsExtendedArabic(
                                                        sd['column_2_txt_b']!)
                                                    ? pw.TextDirection.ltr
                                                    : pw.TextDirection.rtl,
                                            textAlign: pw.TextAlign.right,
                                            style: pw.TextStyle(
                                                fontSize: 8,
                                                color: PdfColors.black,
                                                font: font),
                                          )
                                        ],
                                      )),
                                  pw.Container(
                                    alignment: pw.Alignment.centerRight,
                                    child: pw.Text(sd['column_3']!,
                                        textDirection: !containsExtendedArabic(
                                                sd['column_3']!)
                                            ? pw.TextDirection.ltr
                                            : pw.TextDirection.rtl,
                                        textAlign: pw.TextAlign.right,
                                        style: pw.TextStyle(
                                            fontSize: 8,
                                            color: PdfColors.black,
                                            font: font)),
                                  ),
                                  pw.Container(
                                      alignment: pw.Alignment.centerRight,
                                      child: pw.Row(
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.end,
                                        mainAxisAlignment:
                                            pw.MainAxisAlignment.end,
                                        children: [
                                          pw.Text(
                                            sd['column_4_txt_a']!,
                                            textDirection:
                                                !containsExtendedArabic(
                                                        sd['column_4_txt_a']!)
                                                    ? pw.TextDirection.ltr
                                                    : pw.TextDirection.rtl,
                                            textAlign: pw.TextAlign.right,
                                            style: pw.TextStyle(
                                                fontSize: 8,
                                                color: PdfColors.black,
                                                font: font),
                                          ),
                                          pw.Text(
                                            sd['column_4_txt_b']!,
                                            textDirection:
                                                !containsExtendedArabic(
                                                        sd['column_4_txt_b']!)
                                                    ? pw.TextDirection.ltr
                                                    : pw.TextDirection.rtl,
                                            textAlign: pw.TextAlign.right,
                                            style: pw.TextStyle(
                                                fontSize: 8,
                                                color: PdfColors.black,
                                                font: font),
                                          )
                                        ],
                                      )),
                                ]),
                        ])),
              ],
              pw.SizedBox(
                height: 5,
              ),
            ],
          )));
}

pw.Widget invoiceAndBarcodeInfo(
    {required ReceiptOrQuotationData dbReceiptData,
    required StoreData? selectedStoreData,
    required font,
    required taxValue}) {
  List<Map<String, String>> invoiceDataLst = [
    {
      'column_1': dbReceiptData.receiptBasicInfo!.receiptNo,
      'column_2_txt_a': 'Inv. No ',
      'column_2_txt_b': 'رﻗﻢ اﻟﻔﺎﺗﻮرة',
    },
    {
      'column_1': DateFormat('d/MM/yyyy').format(dbReceiptData.createdDate),
      'column_2_txt_a': 'Inv. Date ',
      'column_2_txt_b': 'ﺗﺎرﻳﺦ اﻟﻔﺎﺗﻮرة',
    },
    {
      'column_1': dbReceiptData.receiptBasicInfo!.referenceNo,
      'column_2_txt_a': 'Ref. No ',
      'column_2_txt_b': 'رﻗﻢ اﻟﻤﺮﺟﻊ',
    },
    {
      'column_1': getReceiptPaymentType(dbReceiptData),
      'column_2_txt_a': '',
      'column_2_txt_b': 'ﻃﺮﻳﻘﺔ اﻟﺪﻓﻊ',
    },
  ];
  return pw.Container(
      width: 180,
      child: pw.Column(
        children: [
          pw.Container(
              padding: pw.EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration:
                  pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide())),
              child: pw.Table(
                  defaultVerticalAlignment: pw.TableCellVerticalAlignment.full,
                  columnWidths: {
                    0: const pw.FlexColumnWidth(1),
                    1: const pw.FlexColumnWidth(1.1),
                  },
                  children: [
                    for (var sd in invoiceDataLst)
                      pw.TableRow(
                          verticalAlignment: pw.TableCellVerticalAlignment.top,
                          children: [
                            pw.Container(
                              alignment: pw.Alignment.centerRight,
                              child: pw.Text(sd['column_1']!,
                                  textDirection:
                                      !containsExtendedArabic(sd['column_1']!)
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                  textAlign: pw.TextAlign.right,
                                  style: pw.TextStyle(
                                      fontSize: 8,
                                      color: PdfColors.black,
                                      font: font)),
                            ),
                            pw.Container(
                                alignment: pw.Alignment.centerRight,
                                child: pw.Row(
                                  crossAxisAlignment: pw.CrossAxisAlignment.end,
                                  mainAxisAlignment: pw.MainAxisAlignment.end,
                                  children: [
                                    pw.Text(
                                      sd['column_2_txt_a']!,
                                      textDirection: !containsExtendedArabic(
                                              sd['column_2_txt_a']!)
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                      textAlign: pw.TextAlign.right,
                                      style: pw.TextStyle(
                                          fontSize: 8,
                                          color: PdfColors.black,
                                          font: font),
                                    ),
                                    pw.Text(
                                      sd['column_2_txt_b']!,
                                      textDirection: !containsExtendedArabic(
                                              sd['column_2_txt_b']!)
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                      textAlign: pw.TextAlign.right,
                                      style: pw.TextStyle(
                                          fontSize: 8,
                                          color: PdfColors.black,
                                          font: font),
                                    )
                                  ],
                                )
                                //  pw.RichText(
                                //   textDirection: !containsExtendedArabic(
                                //           '${sd['column_2_txt_a']!} ${sd['column_2_txt_b']!}')
                                //       ? pw.TextDirection.ltr
                                //       : pw.TextDirection.rtl,
                                //   textAlign: pw.TextAlign.right,
                                //   text: pw.TextSpan(
                                //       text: sd['column_2_txt_a']!,
                                //       style: pw.TextStyle(
                                //           fontSize: 8,
                                //           color: PdfColors.black,
                                //           font: font),
                                //       children: [
                                //         pw.TextSpan(
                                //           text: sd['column_2_txt_b']!,
                                //           style: pw.TextStyle(
                                //               fontSize: 8,
                                //               color: PdfColors.black,
                                //               font: font),
                                //         )
                                //       ]),
                                // ),

                                ),
                          ])
                  ])),
          pw.Container(
              padding: pw.EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: pw.BoxDecoration(
                  border: pw.Border(
                left: pw.BorderSide(),
              )),
              child: pw.Column(children: [
                pw.Align(
                    alignment: pw.Alignment.topCenter,
                    child: pw.SvgImage(
                        svg: buildBarcode(
                            height: 85,
                            width: 85,
                            Barcode.qrCode(),
                            getQrCodeContent(
                              createdDate: dbReceiptData.createdDate,
                              sellerName: selectedStoreData == null
                                  ? ''
                                  : selectedStoreData.storeName,
                              sellerTRN: selectedStoreData == null
                                  ? ''
                                  : selectedStoreData.vatNumber,
                              totalWithVat:
                                  dbReceiptData.lineItemTotalData.receiptTotal,
                              vatPrice: taxValue,
                            )))),
                pw.SizedBox(height: 5),
                pw.Text(
                  'ﺗﻢ ﺗﺮﻣﻴﺰ رﻣﺰ اﻻﺳﺘﺠﺎﺑﺔ اﻟﺴﺮﻳﻌﺔ' +
                      '\n' +
                      'وﻓﻘً ﺎ ﻟﻤﺘﻄﻠﺒﺎت اﻟﻔﻮﺗﺮة اﻹﻟﻜﺘﺮوﻧﻴﺔ ﻟﻬﻴﺌﺔ' +
                      '\n' +
                      'اﻟﺰﻛﺎة واﻟﻀﺮﻳﺒﺔ واﻟﺠﻤﺎرك.',
                  textDirection: pw.TextDirection.rtl,
                  textAlign: pw.TextAlign.center,
                  style: pw.TextStyle(
                      fontSize: 8, color: PdfColors.black, font: font),
                )
              ]))
        ],
      ));
}

pw.Widget itemTableWidget(
    {required var font,
    required var font2,
    required ReceiptOrQuotationData dbReceiptData}) {
  List<String> arabicHeaderTxtLst = [
    'اﻹﺟﻤﺎﻟﻲ ﺷﺎﻣﻞ اﻟﻀﺮﻳﺒﺔ',
    'ﺿﺮﻳﺒﺔ %15',
    'ﺧﺼﻢ',
    'اﻟﻤﺒﻠﻎ اﻟﺨﺎﺿﻊ',
    'ﺳﻌﺮ اﻟﻮﺣﺪة',
    'ﻛﻤﻴﺔ',
    'وﺣﺪة',
    'اﺳﻢ اﻟﺼﻨﻒ',
    'رﻗﻢ اﻟﺼﻨﻒ',
    'S'
  ];
  List<String> engHeaderTxtLst = [
    'Total\nInclu. VAT',
    'VAT(${dbReceiptData.lineItemTotalData.totalTaxPercentage}%)',
    'Disc.',
    'Taxabel Amount',
    'Unit Price',
    'Qty',
    'Unit',
    'Item Name',
    'Item No.',
    'S'
  ];
  return pw.Container(
    width: double.maxFinite,
    alignment: pw.Alignment.centerLeft,
    child: pw.Table(
      defaultVerticalAlignment: pw.TableCellVerticalAlignment.full,
      columnWidths: {
        0: const pw.FlexColumnWidth(1.8),
        1: const pw.FlexColumnWidth(1.4),
        2: const pw.FlexColumnWidth(1),
        3: const pw.FlexColumnWidth(1.8),
        4: const pw.FlexColumnWidth(1.9),
        5: const pw.FlexColumnWidth(1),
        6: const pw.FlexColumnWidth(1),
        7: const pw.FlexColumnWidth(3.5),
        8: const pw.FlexColumnWidth(2),
        9: const pw.FlexColumnWidth(.5)
      },
      children: [
        for (int i = 0; i < 2; i++)
          pw.TableRow(
              decoration: pw.BoxDecoration(
                  border: pw.Border.all(
                color: PdfColors.black,
              )),
              children: [
                for (var h in i == 0 ? arabicHeaderTxtLst : engHeaderTxtLst)
                  pw.Container(
                    decoration: pw.BoxDecoration(
                        color: const PdfColor.fromInt(0xEFEFEF),
                        border: (i == 0
                                    ? arabicHeaderTxtLst.last
                                    : engHeaderTxtLst.last) ==
                                h
                            ? null
                            : pw.Border(
                                right: pw.BorderSide(width: 1.5),
                              )),
                    padding: pw.EdgeInsets.all(2),
                    alignment: pw.Alignment.center,
                    child: pw.Text(
                      h,
                      textDirection: i == 0 ? pw.TextDirection.rtl : null,
                      textAlign: pw.TextAlign.center,
                      style: pw.TextStyle(
                        fontSize: 8,
                        font: font2,
                      ),
                    ),
                  ),
              ]),

        //line items
        for (int i = 0; i < dbReceiptData.lineItemsData.length; i++)
          pw.TableRow(
              decoration: pw.BoxDecoration(
                  border: pw.Border.all(
                color: PdfColors.black,
              )),
              children: [
                for (int j = 0; j < 10; j++)
                  pw.Container(
                    decoration: pw.BoxDecoration(
                        border: j == 9
                            ? null
                            : pw.Border(
                                right: pw.BorderSide(width: 1),
                              )),
                    padding: pw.EdgeInsets.all(1),
                    alignment: pw.Alignment.center,
                    child: pw.Text(
                      j == 0
                          ? doubleToString(double.tryParse(dbReceiptData.lineItemsData[i].totalWt) ?? 0,
                              maxDigits: 2)
                          : j == 1
                              ? doubleToString(
                                  (double.tryParse(dbReceiptData.lineItemsData[i].totalWt) ?? 0) *
                                      ((double.tryParse(dbReceiptData
                                                  .lineItemTotalData
                                                  .totalTaxPercentage) ??
                                              0) /
                                          100),
                                  maxDigits: 2)
                              : j == 2
                                  ? doubleToString(double.tryParse(dbReceiptData.lineItemsData[i].discountValue) ?? 0,
                                      maxDigits: 2)
                                  : j == 3
                                      //taxable amt
                                      ? doubleToString(
                                          (double.tryParse(dbReceiptData.lineItemsData[i].orgPrice) ??
                                                  0) *
                                              (double.tryParse(dbReceiptData.lineItemsData[i].qty) ??
                                                  0),
                                          maxDigits: 2)
                                      : j == 4
                                          //unit price
                                          ? doubleToString(
                                              double.tryParse(dbReceiptData.lineItemsData[i].orgPrice) ?? 0,
                                              maxDigits: 2)
                                          : j == 5
                                              //qty
                                              ? dbReceiptData.lineItemsData[i].qty
                                              : j == 6
                                                  //unit
                                                  ? dbReceiptData.lineItemsData[i].unitName
                                                  : j == 7
                                                      //item name
                                                      ? dbReceiptData.lineItemsData[i].productName
                                                      : j == 8
                                                          //item code
                                                          ? dbReceiptData.lineItemsData[i].itemCode
                                                          : '${i + 1}',
                      textDirection: i == 0 ||
                              (j == 7 &&
                                  containsExtendedArabic(dbReceiptData
                                      .lineItemsData[i].productName))
                          ? pw.TextDirection.rtl
                          : null,
                      textAlign: pw.TextAlign.center,
                      style: pw.TextStyle(
                        fontSize: 8,
                        font: font,
                      ),
                    ),
                  ),
              ]),
      ],
    ),
  );
}

pw.Widget totalTableWidget(
    {required List<LineItemData> items,
    required ReceiptOrQuotationData dbReceiptData,
    required var font2}) {
  double subtotal = 0;

  for (var i in items) {
    double unitPrice = double.parse(i.orgPrice);
    subtotal += unitPrice * double.parse(i.qty);
  }

  double totalAfterDiscount = subtotal -
      (double.tryParse(dbReceiptData.lineItemTotalData.totalDiscountValue) ??
          0);

  List<Map<String, String>> data = [
    {
      'column_01': double.parse(doubleToString(subtotal)).toStringAsFixed(2),
      'column_02': 'Total (Excluding VAT)',
      'column_03': 'اﻹﺟﻤﺎﻟﻲ ﻏﻴﺮ ﺷﺎﻣﻞ ﺿﺮﻳﺒﺔ اﻟﻘﻴﻤﺔ اﻟﻤﻀﺎﻓﺔ',
    },
    {
      'column_01':
          double.parse(dbReceiptData.lineItemTotalData.totalDiscountValue)
              .toStringAsFixed(digit),
      'column_02':
          'Total Discounts (${(double.tryParse(dbReceiptData.lineItemTotalData.totalDiscountPercentage.toString()) ?? 0).toStringAsFixed(2)}%)',
      'column_03': 'إﺟﻤﺎﻟﻲ اﻟﺨﺼﻮﻣﺎت',
    },
    {
      'column_01': double.parse(doubleToString(totalAfterDiscount))
          .toStringAsFixed(digit),
      'column_02': 'Total Taxable Amount (Excluding VAT)',
      'column_03': 'اﻹﺟﻤﺎﻟﻲ اﻟﺨﺎﺿﻊ ﻟﻠﻀﺮﻳﺒﺔ (ﻏﻴﺮ ﺷﺎﻣﻞ اﻟﻀﺮﻳﺒﺔ)'
    },
    {
      'column_01': double.parse(dbReceiptData.lineItemTotalData.totalTaxValue)
          .toStringAsFixed(2),
      'column_02':
          'Total VAT ${dbReceiptData.lineItemTotalData.totalTaxPercentage}%',
      'column_03':
          'ﻣﺠﻤﻮع ﺿﺮﻳﺒﺔ اﻟﻘﻴﻤﺔ اﻟﻤﻀﺎﻓﺔ ${dbReceiptData.lineItemTotalData.totalTaxPercentage}%'
    },
    {
      'column_01': double.parse(dbReceiptData.lineItemTotalData.receiptTotal)
          .toStringAsFixed(digit),
      'column_02': 'Total Amount Including VAT',
      'column_03': 'اﻹﺟﻤﺎﻟﻲ اﻟﻨﻬﺎﺋﻲ ﺷﺎﻣﻞ ﺿﺮﻳﺒﺔ اﻟﻘﻴﻤﺔ اﻟﻤﻀﺎﻓﺔ'
    }
  ];

  return pw.Container(
      width: double.maxFinite,
      alignment: pw.Alignment.centerLeft,
      child: pw.Table(
          defaultVerticalAlignment: pw.TableCellVerticalAlignment.full,
          columnWidths: {
            0: const pw.FlexColumnWidth(.5),
            1: const pw.FlexColumnWidth(1),
            2: const pw.FlexColumnWidth(1),
          },
          children: [
            for (var h in data)
              pw.TableRow(
                  decoration: pw.BoxDecoration(
                      border: pw.Border.all(
                    color: PdfColors.black,
                  )),
                  children: [
                    for (int i = 0; i < 3; i++)
                      pw.Container(
                        decoration: pw.BoxDecoration(
                            border: i == 2
                                ? null
                                : pw.Border(
                                    right: pw.BorderSide(width: 2),
                                  )),
                        padding: pw.EdgeInsets.symmetric(
                            horizontal: 5, vertical: 2.5),
                        alignment: pw.Alignment.centerRight,
                        child: pw.Text(
                          i == 0
                              ? h['column_01']!
                              : i == 1
                                  ? h['column_02']!
                                  : h['column_03']!,
                          textDirection: i == 2 ? pw.TextDirection.rtl : null,
                          textAlign: pw.TextAlign.right,
                          style: pw.TextStyle(
                            fontSize: 8,
                            font: font2,
                          ),
                        ),
                      ),
                  ]),
          ]));
}
