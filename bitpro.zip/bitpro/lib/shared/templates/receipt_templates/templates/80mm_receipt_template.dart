import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/customer_data.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/e_invoice_generator.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

List<pw.Widget> receipt80mmTemplate(
    {required image,
    required EmployeeData userData,
    required PrintingSetttings printingSetttings,
    required StoreData? selectedStoreData,
    required ReceiptOrQuotationData dbReceiptData,
    required englishBoldFont,
    required arabicBoldFont,
    required vatPercentage,
    required CustomerData? selectedCustomerData,
    required taxValue}) {
  return [
    pw.Container(
        width: double.maxFinite,
        child: pw.Column(children: [
          pw.SizedBox(
            height: 15,
          ),
          if (image != null)
            pw.Align(
              alignment: pw.Alignment.center,
              child: pw.Image(image, height: 60),
            ),
          pw.SizedBox(
            height: 1,
          ),
          if (selectedStoreData != null)
            pw.Text(
              selectedStoreData.storeName,
              textDirection: !containsExtendedArabic(
                      selectedStoreData.storeName.toString())
                  ? pw.TextDirection.ltr
                  : pw.TextDirection.rtl,
              style: pw.TextStyle(
                font: !containsExtendedArabic(
                        selectedStoreData.storeName.toString())
                    ? englishBoldFont
                    : arabicBoldFont,
                fontSize: 9,
              ),
            ),
          if (selectedStoreData != null)
            pw.Text(
              selectedStoreData.address,
              textAlign: pw.TextAlign.center,
              textDirection:
                  !containsExtendedArabic(selectedStoreData.address.toString())
                      ? pw.TextDirection.ltr
                      : pw.TextDirection.rtl,
              style: pw.TextStyle(
                font: !containsExtendedArabic(
                        selectedStoreData.address.toString())
                    ? englishBoldFont
                    : arabicBoldFont,
                fontSize: 7,
              ),
            ),
          if (selectedStoreData != null)
            pw.Text(
              selectedStoreData.phone1,
              style: pw.TextStyle(
                fontSize: 9,
                font: englishBoldFont,
              ),
            ),
          pw.SizedBox(
            height: 7,
          ),
          if ((printingSetttings.receiptTitleArb.isNotEmpty ||
                  printingSetttings.receiptTitleEng.isNotEmpty) &&
              dbReceiptData.receiptBasicInfo!.receiptType != 'Return')
            pw.Padding(
              padding: pw.EdgeInsets.symmetric(vertical: 7),
              child: pw.Column(children: [
                pw.Text(
                  printingSetttings.receiptFotterEng,
                  style: pw.TextStyle(
                      fontSize: 8,
                      font: englishBoldFont,
                      fontWeight: pw.FontWeight.bold),
                ),
                pw.Text(
                  printingSetttings.receiptTitleArb,
                  textDirection: pw.TextDirection.rtl,
                  style: pw.TextStyle(
                    fontSize: 8,
                    font: arabicBoldFont,
                  ),
                ),
              ]),
            ),
          if (dbReceiptData.receiptBasicInfo!.receiptType != 'Regular')
            pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.end,
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Padding(
                    padding: pw.EdgeInsets.symmetric(
                      vertical: 7,
                    ),
                    child: pw.Row(
                        mainAxisAlignment: pw.MainAxisAlignment.center,
                        crossAxisAlignment: pw.CrossAxisAlignment.center,
                        children: [
                          pw.Text(
                            'CREDIT NOTE إشعار الائتمان ',
                            textDirection: pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              fontSize: 10,
                              fontWeight: pw.FontWeight.bold,
                              font: arabicBoldFont,
                            ),
                          ),
                        ]),
                  )
                ]),
          pw.SizedBox(
            height: 7,
          ),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceAround,
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                mainAxisAlignment: pw.MainAxisAlignment.start,
                children: [
                  pw.Text(
                    'RECEIPT #',
                    style: pw.TextStyle(
                        fontSize: 8,
                        font: englishBoldFont,
                        fontWeight: pw.FontWeight.bold),
                  ),
                  pw.SizedBox(height: 3),
                  pw.Text(
                    'DATE :',
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.SizedBox(height: 3),
                  pw.Text(
                    'CASHIER :',
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.SizedBox(height: 3),
                  if (selectedStoreData != null)
                    if (selectedStoreData.vatNumber.isNotEmpty)
                      pw.Text(
                        'VAT No :',
                        style: pw.TextStyle(
                          fontSize: 8,
                          font: englishBoldFont,
                        ),
                      ),
                  // pw.Text(
                  //   'Reference No :',
                  //   style: pw.TextStyle(
                  //     fontSize: 7,
                  //     font: txtBoldFont,
                  //   ),
                  //  ),
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.Text(
                    dbReceiptData.receiptBasicInfo!.receiptNo.toString(),
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.SizedBox(height: 3),
                  pw.Text(
                    DateFormat('dd-MM-yyyy hh:mm a')
                        .format(dbReceiptData.createdDate),
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.SizedBox(height: 3),
                  pw.Text(
                    userData.empBasicInfoData.username,
                    textDirection: !containsExtendedArabic(
                            userData.empBasicInfoData.username.toString())
                        ? pw.TextDirection.ltr
                        : pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      font: !containsExtendedArabic(
                              userData.empBasicInfoData.username.toString())
                          ? englishBoldFont
                          : arabicBoldFont,
                      fontSize: 8,
                    ),
                  ),
                  pw.SizedBox(height: 3),
                  if (selectedStoreData != null)
                    if (selectedStoreData.vatNumber.isNotEmpty)
                      pw.Text(
                        selectedStoreData.vatNumber,
                        style: pw.TextStyle(
                          fontSize: 8,
                          font: englishBoldFont,
                        ),
                      ),
                  //if (dbReceiptData.referenceNo.isNotEmpty)
                  // pw.Text(
                  //  dbReceiptData.referenceNo,
                  //  style: pw.TextStyle(
                  //     fontSize: 7,
                  //     font: txtBoldFont,
                  //    ),
                  //   ),
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text(
                    '# فاتورة',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: arabicBoldFont,
                    ),
                  ),
                  pw.Text(
                    'تاريخ',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: arabicBoldFont,
                    ),
                  ),
                  pw.Text(
                    'كاشير',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: arabicBoldFont,
                    ),
                  ),
                  if (selectedStoreData != null)
                    if (selectedStoreData.vatNumber.isNotEmpty)
                      pw.Text(
                        'رقم الضريبة',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(
                          fontSize: 8,
                          font: arabicBoldFont,
                        ),
                      ),
                ],
              )
            ],
          ),
          if (selectedCustomerData != null)
            pw.Padding(
              padding: pw.EdgeInsets.symmetric(horizontal: 5),
              child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        if (selectedCustomerData.customerName.isNotEmpty)
                          pw.Text(
                            'CUSTOMER',
                            textDirection: pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              fontSize: 8,
                              font: englishBoldFont,
                            ),
                          ),
                        if (selectedCustomerData.address1.isNotEmpty)
                          pw.Text(
                            "ADDRESS",
                            textDirection: pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              fontSize: 8,
                              font: englishBoldFont,
                            ),
                          ),
                        if (selectedCustomerData.vatNo.isNotEmpty)
                          pw.Text(
                            'VAT NO. ',
                            textDirection: pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              fontSize: 8,
                              font: englishBoldFont,
                            ),
                          ),
                      ],
                    ),
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.center,
                      children: [
                        if (selectedCustomerData.customerName.isNotEmpty)
                          pw.Text(
                            selectedCustomerData.customerName,
                            maxLines: 1,
                            textDirection: !containsExtendedArabic(
                                    selectedCustomerData.customerName)
                                ? pw.TextDirection.ltr
                                : pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              font: !containsExtendedArabic(
                                      selectedCustomerData.customerName)
                                  ? englishBoldFont
                                  : arabicBoldFont,
                              fontSize: 8,
                            ),
                          ),
                        if (selectedCustomerData.address1.isNotEmpty)
                          pw.Text(
                            selectedCustomerData.address1,
                            maxLines: 1,
                            textDirection: !containsExtendedArabic(
                                    selectedCustomerData.address1)
                                ? pw.TextDirection.ltr
                                : pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              font: !containsExtendedArabic(
                                      selectedCustomerData.address1)
                                  ? englishBoldFont
                                  : arabicBoldFont,
                              fontSize: 8,
                            ),
                          ),
                        if (selectedCustomerData.vatNo.isNotEmpty)
                          pw.Text(
                            selectedCustomerData.vatNo,
                            maxLines: 1,
                            style: pw.TextStyle(
                              fontSize: 8,
                              font: englishBoldFont,
                            ),
                          ),
                      ],
                    ),
                    pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                      children: [
                        if (selectedCustomerData.customerName.isNotEmpty)
                          pw.Text(
                            'اسم العميل',
                            textDirection: pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              fontSize: 8,
                              font: arabicBoldFont,
                            ),
                          ),
                        if (selectedCustomerData.address1.isNotEmpty)
                          pw.Text(
                            "عنوان العميل",
                            textDirection: pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              fontSize: 8,
                              font: arabicBoldFont,
                            ),
                          ),
                        if (selectedCustomerData.vatNo.isNotEmpty)
                          pw.Text(
                            'رقم الضريبي',
                            textDirection: pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              fontSize: 8,
                              font: arabicBoldFont,
                            ),
                          ),
                      ],
                    )
                  ]),
            ),
          pw.SizedBox(
            height: 4,
          ),
          pw.Align(
              alignment: pw.Alignment.center,
              child: pw.SvgImage(
                  svg: buildBarcode(
                height: 30,
                width: 80,
                Barcode.code128(useCode128B: false, useCode128C: false),
                dbReceiptData.receiptBasicInfo!.receiptNo.toString(),
                filename: 'code-128a',
              ))),
          pw.Text(
              '---------------------------------------------------------------------------------',
              style: pw.TextStyle(font: englishBoldFont, fontSize: 4)),
        ])),
    pw.Column(mainAxisSize: pw.MainAxisSize.min, children: [
      pw.Row(children: [
        pw.Container(
            width: 100,
            padding: const pw.EdgeInsets.only(left: 10),
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'باركود',
                  textDirection: pw.TextDirection.rtl,
                  style: pw.TextStyle(
                      fontSize: 8,
                      font: arabicBoldFont,
                      fontWeight: pw.FontWeight.bold),
                ),
                pw.Text('BARCODE',
                    style: pw.TextStyle(fontSize: 8, font: englishBoldFont))
              ],
            )),
        pw.Container(
            width: 30,
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'سعر',
                  textDirection: pw.TextDirection.rtl,
                  style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 8,
                      fontWeight: pw.FontWeight.bold),
                ),
                pw.Text('PRICE',
                    style: pw.TextStyle(fontSize: 8, font: englishBoldFont))
              ],
            )),
        pw.Container(
            width: 30,
            alignment: pw.Alignment.center,
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              children: [
                pw.Text(
                  'كمية',
                  textDirection: pw.TextDirection.rtl,
                  style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 8,
                      fontWeight: pw.FontWeight.bold),
                ),
                pw.Text('QTY',
                    style: pw.TextStyle(fontSize: 8, font: englishBoldFont))
              ],
            )),
        pw.Container(
            width: 40,
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'اجمالي',
                  textDirection: pw.TextDirection.rtl,
                  style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 8,
                      fontWeight: pw.FontWeight.bold),
                ),
                pw.Text('TOTAL',
                    style: pw.TextStyle(fontSize: 8, font: englishBoldFont))
              ],
            )),
      ]),
      pw.SizedBox(height: 3),
      for (LineItemData lineItemData in dbReceiptData.lineItemsData)
        ...productTile(englishBoldFont, lineItemData, arabicBoldFont),
    ]),
    pw.Container(
      padding: const pw.EdgeInsets.symmetric(vertical: 2, horizontal: 10),
      decoration: const pw.BoxDecoration(),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('TOTAL QTY',
                  style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              pw.SizedBox(
                height: 5,
              ),
              pw.Text('TOTAL W/T',
                  style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              pw.SizedBox(
                height: 3,
              ),
              pw.Text(
                  'Dis (${doubleToString(double.tryParse(dbReceiptData.lineItemTotalData.totalDiscountPercentage) ?? 0)}%)',
                  style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              pw.SizedBox(
                height: 3,
              ),
              pw.Text('BEFORE VAT',
                  style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              pw.SizedBox(
                height: 3,
              ),
              pw.Text('${'VAT (' + vatPercentage}%)',
                  style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              pw.SizedBox(
                height: 8,
              ),
              pw.Text(
                'TOTAL',
                style: pw.TextStyle(
                    font: englishBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
            ],
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.SizedBox(
                height: -1,
              ),
              pw.Text(dbReceiptData.lineItemTotalData.totalQty,
                  style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              pw.SizedBox(
                height: 5,
              ),
              pw.Text(
                ((double.tryParse(
                                dbReceiptData.lineItemTotalData.receiptTotal) ??
                            0) +
                        (double.tryParse(dbReceiptData
                                .lineItemTotalData.totalDiscountValue) ??
                            0))
                    .toInt()
                    .toString(),
                style: pw.TextStyle(fontSize: 8, font: englishBoldFont),
              ),
              pw.SizedBox(
                height: 3,
              ),
              pw.Text(dbReceiptData.lineItemTotalData.totalDiscountValue,
                  style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              pw.SizedBox(
                height: 3,
              ),
              pw.Text(
                  doubleToString(double.parse(
                          dbReceiptData.lineItemTotalData.receiptTotal) -
                      double.parse(taxValue)),
                  style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              pw.SizedBox(
                height: 3,
              ),
              pw.Text(taxValue,
                  style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              pw.SizedBox(
                height: 8,
              ),
              pw.Text(
                dbReceiptData.lineItemTotalData.receiptTotal,
                style: pw.TextStyle(
                    font: englishBoldFont,
                    fontSize: 9,
                    fontWeight: pw.FontWeight.bold),
              ),
            ],
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.SizedBox(height: -6),
              pw.Text(
                'الكمية',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(
                height: 0,
              ),
              pw.Text(
                'الاجملي قبل الخصم',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(
                height: 0,
              ),
              pw.Text(
                'خصم ',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(
                height: 0,
              ),
              pw.Text(
                'اجمالي قبل الضريبة',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(
                height: 0,
              ),
              pw.Text(
                '(15%) الضريبة ',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(
                height: 5,
              ),
              pw.Text(
                'الاجمالي',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
            ],
          ),
        ],
      ),
    ),
    pw.Text(
        '---------------------------------------------------------------------------------',
        style: pw.TextStyle(font: englishBoldFont, fontSize: 4)),
    pw.Container(
        padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 1),
        decoration: const pw.BoxDecoration(),
        child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('CASH',
                      style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text('CREDIT CARD',
                      style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text('CHANGE',
                      style: pw.TextStyle(fontSize: 8, font: englishBoldFont))
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                      dbReceiptData.receiptBasicInfo!
                                  .allPaymentMethodAmountsInfo[
                              PaymentMethodKey().cash] ??
                          '0',
                      style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
                  pw.SizedBox(
                    height: 4,
                  ),
                  pw.Text(
                      dbReceiptData.receiptBasicInfo!
                                  .allPaymentMethodAmountsInfo[
                              PaymentMethodKey().creditCard] ??
                          '0',
                      style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
                  pw.SizedBox(
                    height: 4,
                  ),
                  pw.Text(dbReceiptData.receiptBasicInfo!.receiptBalance,
                      style: pw.TextStyle(fontSize: 8, font: englishBoldFont))
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text('كاش',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(fontSize: 7, font: arabicBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text('شبكة',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(fontSize: 7, font: arabicBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text('المتبقي',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(fontSize: 7, font: arabicBoldFont)),
                ],
              ),
            ])),
    pw.SizedBox(
      height: 0,
    ),
    if (printingSetttings.receiptFotterEng.isNotEmpty)
      pw.Padding(
          padding: const pw.EdgeInsets.symmetric(horizontal: 10),
          child: pw.Text(printingSetttings.receiptFotterEng,
              style: pw.TextStyle(fontSize: 8, font: englishBoldFont))),
    pw.SizedBox(
      height: 1,
    ),
    if (printingSetttings.receiptFotterArb.isNotEmpty)
      pw.Padding(
          padding: const pw.EdgeInsets.symmetric(horizontal: 10),
          child: pw.Align(
              alignment: pw.Alignment.bottomRight,
              child: pw.Text(
                printingSetttings.receiptFotterArb,
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                  fontSize: 8,
                  font: arabicBoldFont,
                ),
              ))),
    pw.SizedBox(
      height: 1,
    ),
    pw.Text(
        '---------------------------------------------------------------------------------',
        style: pw.TextStyle(font: englishBoldFont, fontSize: 4)),
    pw.SizedBox(height: 2),
    pw.Align(
        alignment: pw.Alignment.center,
        child: pw.SvgImage(
            svg: buildBarcode(
                height: 70,
                width: 70,
                Barcode.qrCode(),
                getQrCodeContent(
                  createdDate: dbReceiptData.createdDate,
                  sellerName: selectedStoreData == null
                      ? ""
                      : selectedStoreData.storeName,
                  sellerTRN: selectedStoreData == null
                      ? ""
                      : selectedStoreData.vatNumber,
                  totalWithVat: dbReceiptData.lineItemTotalData.receiptTotal,
                  vatPrice: taxValue,
                ))))
  ];
}

List<pw.Widget> productTile(
    txtBoldFont, LineItemData lineItemData, arabicFont) {
  // double height = 24;

  // int nol = (localReceiptData['productName'].toString().length / 15).ceil();

  // if (nol != 1) {
  //   height += 2 * (nol);
  // }

  return [
    pw.Row(children: [
      pw.Container(
        width: 100,
        padding: const pw.EdgeInsets.only(left: 10),
        child: pw.Text(
          lineItemData.barcode,
          style: pw.TextStyle(
              font: txtBoldFont, fontSize: 7, fontWeight: pw.FontWeight.bold),
        ),
      ),
      pw.Container(
        width: 30,
        child: pw.Text(
          '${lineItemData.priceWt}',
          style: pw.TextStyle(
              font: txtBoldFont, fontSize: 7, fontWeight: pw.FontWeight.bold),
        ),
      ),
      pw.Container(
        width: 30,
        child: pw.Center(
          child: pw.Text(
            lineItemData.qty,
            style: pw.TextStyle(
                font: txtBoldFont, fontSize: 7, fontWeight: pw.FontWeight.bold),
          ),
        ),
      ),
      pw.Container(
        width: 40,
        child: pw.Text(
          lineItemData.totalWt,
          style: pw.TextStyle(
              //
              fontSize: 7,
              font: txtBoldFont,
              fontWeight: pw.FontWeight.bold),
        ),
      ),
    ]),
    pw.SizedBox(
      height: 2,
    ),
    pw.Padding(
        padding: pw.EdgeInsets.symmetric(horizontal: 10),
        child: pw.SizedBox(
            width: double.maxFinite,
            child: pw.Text(lineItemData.productName,
                textDirection: !containsExtendedArabic(lineItemData.productName)
                    ? pw.TextDirection.ltr
                    : pw.TextDirection.rtl,
                style: pw.TextStyle(
                  font: !containsExtendedArabic(
                          lineItemData.productName.toString())
                      ? txtBoldFont
                      : arabicFont,
                  fontSize: 7,
                  //
                )))),
    pw.Divider(
      color: PdfColors.grey,
    ),
  ];
}
