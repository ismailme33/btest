import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/e_invoice_generator.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../../../model/customer_data.dart';

pw.Widget des0002A4ReceiptTemplate({
  required image,
  required EmployeeData userData,
  required PrintingSetttings printingSetttings,
  required ReceiptOrQuotationData dbReceiptData,
  required englishBoldFont,
  required arabicRegularFont,
  required arabicBoldFont,
  required vatPercentage,
  required taxValue,
  required englishRegularFont,
  required StoreData? selectedStoreData,
  CustomerData? selectedCustomerData,
}) {
  return pw.Container(
      width: double.maxFinite,
      child: pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.start,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.start,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.start,
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Column(
                          mainAxisAlignment: pw.MainAxisAlignment.start,
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            if (printingSetttings.receiptTitleEng.isNotEmpty ||
                                printingSetttings.receiptTitleArb.isNotEmpty)
                              pw.Row(
                                  mainAxisAlignment:
                                      pw.MainAxisAlignment.center,
                                  crossAxisAlignment:
                                      pw.CrossAxisAlignment.center,
                                  children: [
                                    pw.Text(
                                      printingSetttings.receiptTitleEng,
                                      style: pw.TextStyle(
                                          fontSize: 8,
                                          fontBold: englishBoldFont,
                                          fontWeight: pw.FontWeight.bold),
                                    ),
                                    pw.Text(
                                      ' / ',
                                      style: pw.TextStyle(
                                          fontSize: 8,
                                          fontBold: englishBoldFont,
                                          fontWeight: pw.FontWeight.bold),
                                    ),
                                    pw.Text(
                                      printingSetttings.receiptTitleArb,
                                      textDirection: pw.TextDirection.rtl,
                                      style: pw.TextStyle(
                                          fontSize: 8,
                                          font: arabicBoldFont,
                                          fontWeight: pw.FontWeight.bold),
                                    ),
                                  ]),
                            pw.SizedBox(
                              height: 10,
                            ),
                            if (selectedStoreData != null)
                              pw.Text(
                                selectedStoreData.storeName,
                                textAlign: pw.TextAlign.left,
                                textDirection: !containsExtendedArabic(
                                        selectedStoreData.storeName.toString())
                                    ? pw.TextDirection.ltr
                                    : pw.TextDirection.rtl,
                                style: pw.TextStyle(
                                    font: !containsExtendedArabic(
                                            selectedStoreData.storeName
                                                .toString())
                                        ? englishBoldFont
                                        : arabicBoldFont,
                                    fontSize: 8,
                                    fontWeight: pw.FontWeight.bold),
                              ),
                            pw.SizedBox(
                              height: 10,
                            ),
                            if (selectedStoreData != null)
                              pw.Text(
                                selectedStoreData.address,
                                textAlign: pw.TextAlign.left,
                                textDirection: !containsExtendedArabic(
                                        selectedStoreData.address.toString())
                                    ? pw.TextDirection.ltr
                                    : pw.TextDirection.rtl,
                                style: pw.TextStyle(
                                  font: !containsExtendedArabic(
                                          selectedStoreData.address.toString())
                                      ? englishRegularFont
                                      : arabicRegularFont,
                                  fontSize: 8,
                                ),
                              ),
                            pw.SizedBox(
                              height: 10,
                            ),
                            pw.Row(children: [
                              pw.Column(
                                  crossAxisAlignment:
                                      pw.CrossAxisAlignment.start,
                                  children: [
                                    pw.Text(
                                      'VAT No. : ',
                                      style: pw.TextStyle(
                                        fontSize: 8,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                    pw.SizedBox(height: 5),
                                    pw.Text(
                                      'Phone : ',
                                      style: pw.TextStyle(
                                        fontSize: 8,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                    pw.SizedBox(height: 5),
                                    pw.Text(
                                      'Email : ',
                                      style: pw.TextStyle(
                                        fontSize: 8,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                  ]),
                              pw.SizedBox(width: 15),
                              pw.Column(
                                  crossAxisAlignment:
                                      pw.CrossAxisAlignment.start,
                                  children: [
                                    if (selectedStoreData != null)
                                      pw.Text(
                                        selectedStoreData.vatNumber,
                                        style: pw.TextStyle(
                                          fontSize: 8,
                                          font: englishRegularFont,
                                        ),
                                      ),
                                    pw.SizedBox(height: 5),
                                    if (selectedStoreData != null)
                                      pw.Text(
                                        selectedStoreData.phone1,
                                        style: pw.TextStyle(
                                          fontSize: 8,
                                          font: englishRegularFont,
                                        ),
                                      ),
                                    pw.SizedBox(height: 5),
                                    if (selectedStoreData != null)
                                      pw.Text(
                                        selectedStoreData.email,
                                        style: pw.TextStyle(
                                          fontSize: 8,
                                          font: englishRegularFont,
                                        ),
                                      ),
                                  ])
                            ]),
                            pw.SizedBox(width: 10),
                          ],
                        ),
                        pw.Expanded(child: pw.SizedBox(width: 20)),
                        if (image != null)
                          pw.Container(
                            margin: const pw.EdgeInsets.only(right: 20),
                            width: 170,
                            height: 90,
                            child: pw.Image(image,
                                width: 170, height: 90, fit: pw.BoxFit.contain),
                          ),
                        pw.SizedBox(width: 20),
                      ]),
                  pw.SizedBox(
                    height: 10,
                  ),
                  pw.Container(
                      color: PdfColors.grey400,
                      width: double.maxFinite,
                      height: .5),
                  pw.SizedBox(
                    height: 10,
                  ),
                  pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      if (selectedCustomerData != null)
                        pw.Column(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Text(
                              'Bill to',
                              style: pw.TextStyle(
                                  font: englishBoldFont, fontSize: 8),
                            ),
                            pw.SizedBox(height: 5),
                            pw.Text(
                              selectedCustomerData.customerName,
                              textDirection: !containsExtendedArabic(
                                      selectedCustomerData.customerName
                                          .toString())
                                  ? pw.TextDirection.ltr
                                  : pw.TextDirection.rtl,
                              style: pw.TextStyle(
                                  font: !containsExtendedArabic(
                                          selectedCustomerData.customerName
                                              .toString())
                                      ? englishRegularFont
                                      : arabicRegularFont,
                                  fontSize: 8),
                            ),
                            pw.SizedBox(height: 5),
                            pw.Text(
                              selectedCustomerData.address1,
                              textDirection: !containsExtendedArabic(
                                      selectedCustomerData.address1.toString())
                                  ? pw.TextDirection.ltr
                                  : pw.TextDirection.rtl,
                              style: pw.TextStyle(
                                  font: !containsExtendedArabic(
                                          selectedCustomerData.address1
                                              .toString())
                                      ? englishRegularFont
                                      : arabicRegularFont,
                                  fontSize: 8),
                            ),
                            pw.SizedBox(height: 5),
                            pw.Row(children: [
                              pw.Text(
                                'Vat No. : ',
                                style: pw.TextStyle(
                                  font: englishRegularFont,
                                  fontSize: 8,
                                ),
                              ),
                              pw.SizedBox(width: 15),
                              pw.Text(
                                selectedCustomerData.vatNo,
                                textDirection: !containsExtendedArabic(
                                        selectedCustomerData.vatNo.toString())
                                    ? pw.TextDirection.ltr
                                    : pw.TextDirection.rtl,
                                style: pw.TextStyle(
                                  font: !containsExtendedArabic(
                                          selectedCustomerData.vatNo.toString())
                                      ? englishRegularFont
                                      : arabicRegularFont,
                                  fontSize: 8,
                                ),
                              ),
                            ])
                          ],
                        ),
                      pw.Expanded(
                          child: pw.SizedBox(
                        width: 10,
                      )),
                      pw.Row(
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Column(
                                crossAxisAlignment: pw.CrossAxisAlignment.start,
                                children: [
                                  pw.Text(
                                    'Invoice No. : ',
                                    style: pw.TextStyle(
                                      fontSize: 8,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.SizedBox(height: 5),
                                  pw.Text(
                                    'Date : ',
                                    style: pw.TextStyle(
                                      fontSize: 8,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.SizedBox(height: 5),
                                  pw.Text(
                                    'Created : ',
                                    style: pw.TextStyle(
                                      fontSize: 8,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  if (dbReceiptData
                                      .receiptBasicInfo!.referenceNo.isNotEmpty)
                                    pw.SizedBox(height: 5),
                                  if (dbReceiptData
                                      .receiptBasicInfo!.referenceNo.isNotEmpty)
                                    pw.Text(
                                      'Reference no : ',
                                      style: pw.TextStyle(
                                        fontSize: 8,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                  pw.SizedBox(height: 5),
                                  pw.Text(
                                    'Bank acc. number : ',
                                    style: pw.TextStyle(
                                      fontSize: 8,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.SizedBox(height: 5),
                                  pw.Text(
                                    'Bank name : ',
                                    style: pw.TextStyle(
                                      fontSize: 8,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                ]),
                            pw.SizedBox(width: 10),
                            pw.Column(
                                crossAxisAlignment: pw.CrossAxisAlignment.start,
                                children: [
                                  pw.Text(
                                    dbReceiptData.receiptBasicInfo!.receiptNo,
                                    style: pw.TextStyle(
                                      fontSize: 8,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.SizedBox(height: 5),
                                  pw.Text(
                                    DateFormat('dd-MM-yyyy hh:mm a')
                                        .format(dbReceiptData.createdDate),
                                    style: pw.TextStyle(
                                      fontSize: 8,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.SizedBox(height: 5),
                                  pw.Text(
                                    '${userData.empBasicInfoData.username}',
                                    textDirection: !containsExtendedArabic(
                                            userData.empBasicInfoData.username
                                                .toString())
                                        ? pw.TextDirection.ltr
                                        : pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                      font: !containsExtendedArabic(userData
                                              .empBasicInfoData.username
                                              .toString())
                                          ? englishRegularFont
                                          : arabicRegularFont,
                                      fontSize: 8,
                                    ),
                                  ),
                                  if (dbReceiptData
                                      .receiptBasicInfo!.referenceNo.isNotEmpty)
                                    pw.SizedBox(height: 5),
                                  if (dbReceiptData
                                      .receiptBasicInfo!.referenceNo.isNotEmpty)
                                    pw.Text(
                                      dbReceiptData
                                          .receiptBasicInfo!.referenceNo,
                                      style: pw.TextStyle(
                                        fontSize: 8,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                  pw.SizedBox(height: 5),
                                  if (selectedStoreData != null)
                                    pw.Text(
                                      selectedStoreData.accountNumber,
                                      style: pw.TextStyle(
                                        fontSize: 8,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                  pw.SizedBox(height: 5),
                                  if (selectedStoreData != null)
                                    pw.Text(
                                      selectedStoreData.bankName,
                                      textDirection: !containsExtendedArabic(
                                              selectedStoreData.bankName
                                                  .toString())
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                      style: pw.TextStyle(
                                        font: !containsExtendedArabic(
                                                selectedStoreData.bankName
                                                    .toString())
                                            ? englishRegularFont
                                            : arabicRegularFont,
                                        fontSize: 8,
                                      ),
                                    ),
                                ]),
                          ]),
                      pw.SizedBox(
                        width: 50,
                      )
                    ],
                  ),
                  if (dbReceiptData.receiptBasicInfo!.receiptType != 'Regular')
                    pw.Center(
                        child: pw.Container(
                            decoration:
                                pw.BoxDecoration(border: pw.Border.all()),
                            padding: const pw.EdgeInsets.symmetric(
                                vertical: 5, horizontal: 10),
                            child: pw.Column(children: [
                              pw.Text(
                                'Return Invoice',
                                textDirection: pw.TextDirection.rtl,
                                style: pw.TextStyle(
                                  fontSize: 8,
                                  font: englishBoldFont,
                                ),
                              ),
                              pw.SizedBox(height: 3),
                              pw.Text(
                                'فاتورة الاسترجاع',
                                textDirection: pw.TextDirection.rtl,
                                style: pw.TextStyle(
                                  fontSize: 8,
                                  font: arabicBoldFont,
                                ),
                              ),
                            ]))),
                  pw.SizedBox(
                    height: 15,
                  ),
                ]),
            pw.Container(
              width: double.maxFinite,
              alignment: pw.Alignment.centerLeft,
              child: pw.Table(
                columnWidths: {
                  0: const pw.FlexColumnWidth(2),
                  1: const pw.FlexColumnWidth(6.5),
                  2: const pw.FlexColumnWidth(1.5),
                  3: const pw.FlexColumnWidth(2),
                  4: const pw.FlexColumnWidth(2),
                  5: const pw.FlexColumnWidth(2)
                },
                children: [
                  pw.TableRow(
                      decoration: const pw.BoxDecoration(
                          border: pw.Border(
                        bottom:
                            pw.BorderSide(color: PdfColors.grey500, width: 2),
                      )),
                      children: [
                        pw.Container(
                            height: 30,
                            decoration: pw.BoxDecoration(
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'باركود',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    fontSize: 8,
                                    font: arabicBoldFont,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Barcode',
                                    style: pw.TextStyle(
                                        fontSize: 8, font: englishBoldFont))
                              ],
                            )),
                        pw.Container(
                            height: 30,
                            decoration: pw.BoxDecoration(
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'الصنف',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    fontSize: 8,
                                    font: arabicBoldFont,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Item',
                                    style: pw.TextStyle(
                                        fontSize: 8, font: englishBoldFont))
                              ],
                            )),
                        pw.Container(
                            height: 30,
                            decoration: pw.BoxDecoration(
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'كمية',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicBoldFont,
                                    fontSize: 8,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Qty',
                                    style: pw.TextStyle(
                                        fontSize: 8, font: englishBoldFont))
                              ],
                            )),
                        pw.Container(
                            decoration: pw.BoxDecoration(
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            height: 30,
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'سعر',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicBoldFont,
                                    fontSize: 8,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Price',
                                    style: pw.TextStyle(
                                        fontSize: 8, font: englishBoldFont))
                              ],
                            )),
                        pw.Container(
                            height: 30,
                            decoration: pw.BoxDecoration(
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'الضريبية',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicBoldFont,
                                    fontSize: 8,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Tax',
                                    style: pw.TextStyle(
                                        fontSize: 8, font: englishBoldFont))
                              ],
                            )),
                        pw.Container(
                            height: 30,
                            decoration: pw.BoxDecoration(
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              children: [
                                pw.Text(
                                  'اجمالي',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicBoldFont,
                                    fontSize: 8,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 2,
                                ),
                                pw.Text('Total',
                                    style: pw.TextStyle(
                                        fontSize: 8, font: englishBoldFont))
                              ],
                            )),
                      ]),
                ],
              ),
            ),
            for (LineItemData localReceiptData in dbReceiptData.lineItemsData)
              productTile(
                  englishRegularFont,
                  localReceiptData,
                  arabicRegularFont,
                  vatPercentage,
                  dbReceiptData.lineItemsData.indexOf(localReceiptData) ==
                      dbReceiptData.lineItemsData.length - 1),
            pw.SizedBox(height: 10),
            pw.Container(
              child: pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                mainAxisAlignment: pw.MainAxisAlignment.start,
                children: [
                  if (printingSetttings.receiptFotterArb.isNotEmpty ||
                      printingSetttings.receiptFotterEng.isNotEmpty)
                    pw.SizedBox(
                        width: 200,
                        child: pw.Column(
                            crossAxisAlignment: pw.CrossAxisAlignment.start,
                            mainAxisAlignment: pw.MainAxisAlignment.start,
                            children: [
                              pw.Padding(
                                  padding: const pw.EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: pw.Text(
                                      printingSetttings.receiptFotterEng,
                                      style: pw.TextStyle(
                                          fontSize: 8,
                                          font: englishRegularFont))),
                              pw.SizedBox(
                                height: 5,
                              ),
                              pw.Padding(
                                  padding: const pw.EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: pw.Align(
                                      alignment: pw.Alignment.bottomRight,
                                      child: pw.Text(
                                        printingSetttings.receiptFotterArb,
                                        textDirection: pw.TextDirection.rtl,
                                        style: pw.TextStyle(
                                          fontSize: 8,
                                          font: arabicRegularFont,
                                        ),
                                      ))),
                            ])),
                  pw.Expanded(
                      child: pw.SizedBox(
                    width: 10,
                  )),
                  pw.Column(
                    children: [
                      pw.Row(children: [
                        pw.Container(
                            height: 20,
                            width: 90,
                            decoration: pw.BoxDecoration(
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            padding: const pw.EdgeInsets.all(4),
                            child: pw.Text('Subtotal',
                                style: pw.TextStyle(
                                    fontSize: 8, font: englishBoldFont))),
                        pw.Container(
                          height: 20,
                          width: 90,
                          decoration: pw.BoxDecoration(
                              border: pw.Border.all(
                                  color: PdfColors.grey400, width: .6)),
                          padding: const pw.EdgeInsets.all(4),
                          alignment: pw.Alignment.centerRight,
                          child: pw.Text(
                            doubleToString(double.parse(dbReceiptData
                                    .lineItemTotalData.receiptTotal) -
                                double.parse(taxValue)),
                            style: pw.TextStyle(
                                font: englishBoldFont,
                                fontSize: 8,
                                fontWeight: pw.FontWeight.bold),
                          ),
                        )
                      ]),
                      pw.Row(children: [
                        pw.Container(
                            height: 20,
                            width: 90,
                            decoration: pw.BoxDecoration(
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            padding: const pw.EdgeInsets.all(4),
                            child: pw.Text('VAT',
                                style: pw.TextStyle(
                                    fontSize: 8, font: englishBoldFont))),
                        pw.Container(
                            height: 20,
                            width: 90,
                            decoration: pw.BoxDecoration(
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            padding: const pw.EdgeInsets.all(4),
                            alignment: pw.Alignment.centerRight,
                            child: pw.Text(taxValue,
                                style: pw.TextStyle(
                                    fontSize: 8, font: englishBoldFont))),
                      ]),
                      pw.Row(children: [
                        pw.Container(
                            height: 20,
                            width: 90,
                            decoration: pw.BoxDecoration(
                                color: const PdfColor.fromInt(0xfff5f5f5),
                                border: pw.Border.all(
                                    color: PdfColors.grey400, width: .6)),
                            padding: const pw.EdgeInsets.all(4),
                            child: pw.Text('Total',
                                style: pw.TextStyle(
                                    fontSize: 8, font: englishBoldFont))),
                        pw.Container(
                          height: 20,
                          width: 90,
                          decoration: pw.BoxDecoration(
                              color: const PdfColor.fromInt(0xfff5f5f5),
                              border: pw.Border.all(
                                  color: PdfColors.grey400, width: .6)),
                          alignment: pw.Alignment.centerRight,
                          padding: const pw.EdgeInsets.all(4),
                          child: pw.Text(
                              dbReceiptData.lineItemTotalData.receiptTotal,
                              style: pw.TextStyle(
                                  font: englishBoldFont,
                                  fontSize: 8,
                                  fontWeight: pw.FontWeight.bold)),
                        ),
                      ])
                    ],
                  ),
                ],
              ),
            ),
            pw.SizedBox(
              height: 25,
            ),
            pw.Align(
                alignment: pw.Alignment.topCenter,
                child: pw.SvgImage(
                    svg: buildBarcode(
                        height: 70,
                        width: 70,
                        Barcode.qrCode(),
                        getQrCodeContent(
                          createdDate: dbReceiptData.createdDate,
                          sellerName: selectedStoreData == null
                              ? ''
                              : selectedStoreData.storeName,
                          sellerTRN: selectedStoreData == null
                              ? ''
                              : selectedStoreData.vatNumber,
                          totalWithVat:
                              dbReceiptData.lineItemTotalData.receiptTotal,
                          vatPrice: taxValue,
                        )))),
            pw.SizedBox(
              height: 25,
            ),
          ]));
}

productTile(
    txtNormalFont, localReceiptData, arabicFont, vatPercentage, bool last) {
  double height = 30;
  int nol = (localReceiptData['productName'].toString().length / 50).ceil();

  if (nol != 1) {
    height += 10 * (nol - 1);
  }

  return pw.Row(children: [
    pw.Container(
        decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey400, width: .6)),
        height: height,
        width: 71,
        alignment: pw.Alignment.centerLeft,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                localReceiptData['barcode'],
                style: pw.TextStyle(font: txtNormalFont, fontSize: 8),
              ),
              pw.SizedBox(
                height: 2,
              ),
              pw.Text(
                localReceiptData['itemCode'],
                style: pw.TextStyle(font: txtNormalFont, fontSize: 8),
              ),
            ])),
    pw.Container(
      decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey400, width: .6)),
      height: height,
      width: 230,
      padding: const pw.EdgeInsets.all(3),
      child: pw.Text(
          // '1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890',
          localReceiptData['productName'],
          textDirection:
              !containsExtendedArabic(localReceiptData['productName'])
                  ? pw.TextDirection.ltr
                  : pw.TextDirection.rtl,
          softWrap: true,
          style: pw.TextStyle(
            font: !containsExtendedArabic(
                    localReceiptData['productName'].toString())
                ? txtNormalFont
                : arabicFont,
            fontSize: 8,
            //
          )),
    ),
    pw.Container(
        decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey400, width: .6)),
        height: height,
        width: 54,
        alignment: pw.Alignment.centerRight,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Text(
          localReceiptData['qty'],
          style: pw.TextStyle(font: txtNormalFont, fontSize: 8),
        )),
    pw.Container(
      decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey400, width: .6)),
      height: height,
      width: 70,
      alignment: pw.Alignment.centerRight,
      padding: const pw.EdgeInsets.all(3),
      child: pw.Text(
        '${localReceiptData['priceWt']}',
        style: pw.TextStyle(
          font: txtNormalFont,
          fontSize: 8,
        ),
      ),
    ),
    pw.Container(
        decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey400, width: .6)),
        height: height,
        width: 71,
        alignment: pw.Alignment.centerRight,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Text('$vatPercentage%',
            style: pw.TextStyle(fontSize: 8, font: txtNormalFont))),
    pw.Container(
        decoration: pw.BoxDecoration(
            border: pw.Border.all(color: PdfColors.grey400, width: .6)),
        height: height,
        width: 71,
        alignment: pw.Alignment.centerRight,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Text(localReceiptData['total'],
            style: pw.TextStyle(
              fontSize: 8,
              font: txtNormalFont,
            ))),
  ]);
}
