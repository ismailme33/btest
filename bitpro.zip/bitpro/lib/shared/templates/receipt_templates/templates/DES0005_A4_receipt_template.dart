import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/e_invoice_generator.dart';
import 'package:bitpro_hive/widget/string_related/get_payment_type.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:spelling_number/spelling_number.dart';
import '../../../../model/customer_data.dart';

pw.Widget des0005A4ReceiptTemplate(
    {required image,
    required PrintingSetttings printingSetttings,
    required ReceiptOrQuotationData dbReceiptData,
    required englishBoldFont,
    required arabicRegularFont,
    required arabicBoldFont,
    required vatPercentage,
    required taxValue,
    required englishRegularFont,
    required String tenderAmount,
    required String changeAmount,
    required StoreData? selectedStoreData,
    CustomerData? selectedCustomerData,
    context}) {
  return pw.Container(
      width: double.maxFinite,
      child: pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.start,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.start,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Container(
                    padding: pw.EdgeInsets.all(5),
                    decoration: pw.BoxDecoration(
                      border: pw.Border.all(width: 0.4),
                      borderRadius: pw.BorderRadius.circular(5),
                    ),
                    child: pw.Row(
                        mainAxisAlignment: pw.MainAxisAlignment.start,
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Expanded(
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.start,
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                if (selectedStoreData != null)
                                  pw.SizedBox(
                                    height: 5,
                                  ),
                                if (selectedStoreData != null)
                                  pw.SizedBox(
                                    width: 260,
                                    child: pw.Text(
                                      selectedStoreData.address,
                                      textAlign: pw.TextAlign.left,
                                      textDirection: !containsExtendedArabic(
                                              selectedStoreData.address
                                                  .toString())
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                      style: pw.TextStyle(
                                        font: !containsExtendedArabic(
                                                selectedStoreData.address
                                                    .toString())
                                            ? englishRegularFont
                                            : arabicRegularFont,
                                        fontSize: 10,
                                      ),
                                    ),
                                  ),
                                if (selectedStoreData != null)
                                  pw.SizedBox(
                                    height: 5,
                                  ),
                                if (selectedStoreData != null)
                                  pw.Text(
                                    'VAT number:  ${selectedStoreData.vatNumber}',
                                    style: pw.TextStyle(
                                      fontSize: 10,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                if (selectedStoreData != null)
                                  pw.SizedBox(height: 3),
                                pw.Padding(
                                  padding: const pw.EdgeInsets.symmetric(
                                      horizontal: 0, vertical: 0),
                                  child: pw.SvgImage(
                                    svg: buildBarcode(
                                        height: 25,
                                        width: 65,
                                        Barcode.code128(
                                            useCode128B: false,
                                            useCode128C: false),
                                        dbReceiptData
                                            .receiptBasicInfo!.receiptNo
                                            .toString(),
                                        filename: 'code-128a',
                                        fontHeight: 10),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          pw.Expanded(
                              child: pw.Align(
                            alignment: pw.Alignment.centerRight,
                            child: pw.Container(
                              width: 300,
                              child: pw.Column(
                                crossAxisAlignment: pw.CrossAxisAlignment.start,
                                children: [
                                  pw.Align(
                                      alignment: pw.Alignment.centerLeft,
                                      child: pw.Container(
                                          width: 200,
                                          child: pw.Column(children: [
                                            pw.Row(
                                                crossAxisAlignment:
                                                    pw.CrossAxisAlignment.start,
                                                children: [
                                                  pw.Text(
                                                    'Date',
                                                    style: pw.TextStyle(
                                                      fontSize: 10,
                                                      font: englishRegularFont,
                                                    ),
                                                  ),
                                                  pw.SizedBox(
                                                    width: 43,
                                                  ),
                                                  pw.Text(
                                                    'التاريخ',
                                                    textDirection:
                                                        pw.TextDirection.rtl,
                                                    style: pw.TextStyle(
                                                      fontSize: 9,
                                                      font: arabicRegularFont,
                                                    ),
                                                  ),
                                                  pw.SizedBox(
                                                    width: 35,
                                                  ),
                                                  pw.Text(
                                                    DateFormat(
                                                            'dd/MM/yyyy hh:mm a')
                                                        .format(dbReceiptData
                                                            .createdDate),
                                                    style: pw.TextStyle(
                                                      fontSize: 10,
                                                      font: englishRegularFont,
                                                    ),
                                                  ),
                                                ]),
                                            pw.Row(
                                                crossAxisAlignment:
                                                    pw.CrossAxisAlignment.start,
                                                children: [
                                                  pw.Text(
                                                    'Invoice No',
                                                    style: pw.TextStyle(
                                                      fontSize: 10,
                                                      font: englishRegularFont,
                                                    ),
                                                  ),
                                                  pw.SizedBox(
                                                    width: 10,
                                                  ),
                                                  pw.Text(
                                                    'الرقم الفاتورة',
                                                    textDirection:
                                                        pw.TextDirection.rtl,
                                                    style: pw.TextStyle(
                                                      fontSize: 10,
                                                      font: arabicRegularFont,
                                                    ),
                                                  ),
                                                  pw.SizedBox(
                                                    width: 10,
                                                  ),
                                                  pw.Text(
                                                    dbReceiptData
                                                        .receiptBasicInfo!
                                                        .receiptNo,
                                                    style: pw.TextStyle(
                                                      fontSize: 10,
                                                      font: englishRegularFont,
                                                    ),
                                                  ),
                                                ]),
                                          ]))),
                                  pw.SizedBox(height: 10),
                                  if (selectedCustomerData != null &&
                                      selectedCustomerData
                                          .customerName.isNotEmpty)
                                    pw.Align(
                                      alignment: pw.Alignment.centerRight,
                                      child: pw.Padding(
                                          padding:
                                              pw.EdgeInsets.only(right: 20),
                                          child: pw.Column(children: [
                                            pw.Row(children: [
                                              pw.Text(
                                                'Bill to',
                                                style: pw.TextStyle(
                                                    font: englishRegularFont,
                                                    fontSize: 10),
                                              ),
                                              pw.SizedBox(
                                                width: 10,
                                              ),
                                              pw.SizedBox(
                                                width: 240,
                                                child: pw.Text(
                                                  selectedCustomerData
                                                      .customerName,
                                                  textDirection:
                                                      !containsExtendedArabic(
                                                              selectedCustomerData
                                                                  .customerName
                                                                  .toString())
                                                          ? pw.TextDirection.ltr
                                                          : pw.TextDirection
                                                              .rtl,
                                                  style: pw.TextStyle(
                                                      font: !containsExtendedArabic(
                                                              selectedCustomerData
                                                                  .customerName
                                                                  .toString())
                                                          ? englishRegularFont
                                                          : arabicRegularFont,
                                                      fontSize: 10),
                                                ),
                                              )
                                            ]),
                                            pw.Row(children: [
                                              pw.Text(
                                                'Bill to',
                                                style: pw.TextStyle(
                                                    color: PdfColors.white,
                                                    font: englishBoldFont,
                                                    fontSize: 10),
                                              ),
                                              pw.SizedBox(
                                                width: 10,
                                              ),
                                              pw.SizedBox(
                                                width: 240,
                                                child: pw.Text(
                                                  selectedCustomerData.address1,
                                                  textDirection:
                                                      !containsExtendedArabic(
                                                              selectedCustomerData
                                                                  .address1
                                                                  .toString())
                                                          ? pw.TextDirection.ltr
                                                          : pw.TextDirection
                                                              .rtl,
                                                  style: pw.TextStyle(
                                                      font: !containsExtendedArabic(
                                                              selectedCustomerData
                                                                  .address1
                                                                  .toString())
                                                          ? englishRegularFont
                                                          : arabicRegularFont,
                                                      fontSize: 10),
                                                ),
                                              ),
                                            ]),
                                            if (selectedCustomerData
                                                .vatNo.isNotEmpty)
                                              pw.Row(children: [
                                                pw.Text(
                                                  'VAT ID',
                                                  style: pw.TextStyle(
                                                      font: englishRegularFont,
                                                      fontSize: 10),
                                                ),
                                                pw.SizedBox(
                                                  width: 10,
                                                ),
                                                pw.Text(
                                                  selectedCustomerData.vatNo,
                                                  style: pw.TextStyle(
                                                      font: englishRegularFont,
                                                      fontSize: 10),
                                                ),
                                              ])
                                          ])),
                                    )
                                ],
                              ),
                            ),
                          ))
                        ]),
                  ),
                ]),
            pw.SizedBox(height: 15),
            pw.SizedBox(
              height: 3,
            ),
            pw.SizedBox(
              height: 3,
            ),
            pw.Container(
              width: double.maxFinite,
              alignment: pw.Alignment.centerLeft,
              child: pw.Table(
                columnWidths: {
                  0: const pw.FlexColumnWidth(1),
                  1: const pw.FlexColumnWidth(1),
                  2: const pw.FlexColumnWidth(1),
                  3: const pw.FlexColumnWidth(1),
                },
                children: [
                  pw.TableRow(children: [
                    pw.Container(
                        height: 18,
                        alignment: pw.Alignment.center,
                        padding: pw.EdgeInsets.symmetric(horizontal: 5),
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Text('Sales Person',
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                              pw.SizedBox(width: 10),
                              pw.Text('مندوب مبيعات',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 9, font: arabicRegularFont))
                            ])),
                    pw.Container(
                        height: 18,
                        alignment: pw.Alignment.center,
                        padding: pw.EdgeInsets.symmetric(horizontal: 5),
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Text('Ref.No',
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                              pw.SizedBox(width: 10),
                              pw.Text('رقم المرجع',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 9, font: arabicRegularFont))
                            ])),
                    pw.Container(
                        height: 18,
                        alignment: pw.Alignment.center,
                        padding: pw.EdgeInsets.symmetric(horizontal: 5),
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Text('Payment Terms',
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                              pw.SizedBox(width: 10),
                              pw.Text('شروط الدفع',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 9, font: arabicRegularFont))
                            ])),
                    pw.Container(
                        height: 18,
                        alignment: pw.Alignment.center,
                        padding: pw.EdgeInsets.symmetric(horizontal: 5),
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Text('Due Date',
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                              pw.SizedBox(width: 10),
                              pw.Text('تاريخ الاستحقاق',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 9, font: arabicRegularFont))
                            ])),
                  ]),
                ],
              ),
            ),
            pw.SizedBox(
              height: 0,
            ),
            pw.Container(
              width: double.maxFinite,
              alignment: pw.Alignment.centerLeft,
              child: pw.Table(
                columnWidths: {
                  0: const pw.FlexColumnWidth(1),
                  1: const pw.FlexColumnWidth(1),
                  2: const pw.FlexColumnWidth(1),
                  3: const pw.FlexColumnWidth(1),
                },
                children: [
                  pw.TableRow(children: [
                    pw.Container(
                      height: 18,
                      decoration: const pw.BoxDecoration(
                          border: pw.Border(
                        top: pw.BorderSide(color: PdfColors.black, width: .3),
                        left: pw.BorderSide(color: PdfColors.black, width: .3),
                        right: pw.BorderSide(color: PdfColors.black, width: .3),
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: .3),
                      )),
                      padding: pw.EdgeInsets.symmetric(horizontal: 2),
                      alignment: pw.Alignment.centerLeft,
                      child: pw.Text(dbReceiptData.createdBy,
                          style: pw.TextStyle(
                              fontSize: 10, font: englishRegularFont)),
                    ),
                    pw.Container(
                      height: 18,
                      decoration: const pw.BoxDecoration(
                          border: pw.Border(
                        top: pw.BorderSide(color: PdfColors.black, width: .3),
                        left: pw.BorderSide(color: PdfColors.black, width: .3),
                        right: pw.BorderSide(color: PdfColors.black, width: .3),
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: .3),
                      )),
                      alignment: pw.Alignment.center,
                      padding: pw.EdgeInsets.symmetric(horizontal: 5),
                      child: pw.Text(
                          dbReceiptData.receiptBasicInfo!.referenceNo,
                          style: pw.TextStyle(
                              fontSize: 9, font: englishRegularFont)),
                    ),
                    pw.Container(
                      height: 18,
                      decoration: const pw.BoxDecoration(
                          border: pw.Border(
                        top: pw.BorderSide(color: PdfColors.black, width: .3),
                        left: pw.BorderSide(color: PdfColors.black, width: .3),
                        right: pw.BorderSide(color: PdfColors.black, width: .3),
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: .3),
                      )),
                      alignment: pw.Alignment.center,
                      padding: pw.EdgeInsets.symmetric(horizontal: 5),
                      child: pw.Text(getReceiptPaymentType(dbReceiptData),
                          style: pw.TextStyle(
                              fontSize: 10, font: englishRegularFont)),
                    ),
                    pw.Container(
                      decoration: const pw.BoxDecoration(
                          border: pw.Border(
                        top: pw.BorderSide(color: PdfColors.black, width: .3),
                        left: pw.BorderSide(color: PdfColors.black, width: .3),
                        right: pw.BorderSide(color: PdfColors.black, width: .3),
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: .3),
                      )),
                      height: 18,
                      alignment: pw.Alignment.center,
                      padding: pw.EdgeInsets.symmetric(horizontal: 5),
                      child: pw.Text(
                          DateFormat('dd/MM/yyyy')
                              .format(dbReceiptData.createdDate),
                          style: pw.TextStyle(
                              fontSize: 10, font: englishRegularFont)),
                    ),
                  ]),
                ],
              ),
            ),
            if (dbReceiptData.receiptBasicInfo!.receiptType != 'Regular')
              pw.Center(
                child: pw.Padding(
                  padding: pw.EdgeInsets.symmetric(vertical: 10),
                  child: pw.Text(
                    'CREDIT NOTE إشعار الائتمان ',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 12,
                      fontWeight: pw.FontWeight.bold,
                      font: arabicRegularFont,
                    ),
                  ),
                ),
              ),
            pw.SizedBox(
              height: 5,
            ),
            if (dbReceiptData.receiptBasicInfo!.receiptType != 'Return')
              if (printingSetttings.receiptTitleEng.isNotEmpty ||
                  printingSetttings.receiptTitleEng.isNotEmpty)
                pw.Center(
                  child: pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.center,
                      crossAxisAlignment: pw.CrossAxisAlignment.center,
                      children: [
                        pw.Text(
                          printingSetttings.receiptTitleArb,
                          textDirection: pw.TextDirection.rtl,
                          style: pw.TextStyle(
                              fontSize: 10,
                              font: arabicBoldFont,
                              fontWeight: pw.FontWeight.bold),
                        ),
                        pw.SizedBox(width: 10),
                        pw.Text(
                          printingSetttings.receiptTitleEng,
                          style: pw.TextStyle(
                            font: englishBoldFont,
                            fontSize: 10,
                          ),
                        ),
                      ]),
                ),
            pw.SizedBox(
              height: 5,
            ),
            pw.Container(
              width: double.maxFinite,
              alignment: pw.Alignment.centerLeft,
              child: pw.Table(
                columnWidths: {
                  0: const pw.FlexColumnWidth(0.8),
                  1: const pw.FlexColumnWidth(5),
                  2: const pw.FlexColumnWidth(1.5),
                  3: const pw.FlexColumnWidth(1.5),
                },
                children: [
                  pw.TableRow(children: [
                    pw.Container(
                        height: 18,
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          left:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          right:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          bottom:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                        )),
                        alignment: pw.Alignment.center,
                        padding: pw.EdgeInsets.symmetric(horizontal: 5),
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Text('Qty',
                                  style: pw.TextStyle(
                                      fontSize: 9, font: englishRegularFont)),
                              pw.Text('الكمية',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 10, font: arabicRegularFont))
                            ])),
                    pw.Container(
                        height: 18,
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          left:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          right:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          bottom:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                        )),
                        alignment: pw.Alignment.center,
                        padding: pw.EdgeInsets.symmetric(horizontal: 5),
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Text('PRODUCT',
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                              pw.Text('الوصف',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 9, font: arabicRegularFont))
                            ])),
                    pw.Container(
                        height: 18,
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          left:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          right:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          bottom:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                        )),
                        alignment: pw.Alignment.center,
                        padding: pw.EdgeInsets.symmetric(horizontal: 5),
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Text('Unit Price',
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                              pw.Text('السعر',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 9, font: arabicRegularFont))
                            ])),
                    pw.Container(
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          left:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          right:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                          bottom:
                              pw.BorderSide(color: PdfColors.black, width: 0.3),
                        )),
                        height: 18,
                        alignment: pw.Alignment.center,
                        padding: pw.EdgeInsets.symmetric(horizontal: 5),
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Text('Line Total',
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                              pw.Text("المجموع",
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 9, font: arabicRegularFont))
                            ])),
                  ]),
                ],
              ),
            ),
            for (LineItemData localReceiptData in dbReceiptData.lineItemsData)
              productTile(
                  englishRegularFont,
                  localReceiptData,
                  arabicRegularFont,
                  vatPercentage,
                  dbReceiptData.lineItemsData.indexOf(localReceiptData) ==
                      dbReceiptData.lineItemsData.length - 1,
                  dbReceiptData,
                  dbReceiptData.lineItemsData.indexOf(localReceiptData)),
            pw.SizedBox(height: 10),
            getBottomTotalCalucations(
                englishBoldFont,
                englishRegularFont,
                arabicBoldFont,
                arabicRegularFont,
                dbReceiptData,
                tenderAmount,
                changeAmount,
                selectedStoreData,
                taxValue,
                printingSetttings),
            pw.SizedBox(height: 10),
          ]));
}

getBottomTotalCalucations(
    txtBoldFont,
    englishRegularFont,
    arabicBoldFont,
    arabicNormalFont,
    ReceiptOrQuotationData dbReceiptData,
    tendorAmount,
    changeAmount,
    selectedStoreData,
    taxValue,
    PrintingSetttings printingSetttings) {
  double subTotal = 0;
  double vatTotal = double.parse(dbReceiptData.lineItemTotalData.totalTaxValue);
  double total = double.parse(dbReceiptData.lineItemTotalData.receiptTotal);

  subTotal = total - vatTotal;

  return pw.Row(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      mainAxisAlignment: pw.MainAxisAlignment.start,
      children: [
        pw.Padding(
          padding: pw.EdgeInsets.only(right: 5),
          child: pw.Container(
              padding: pw.EdgeInsets.all(8),
              decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.black, width: 0.3)),
              alignment: pw.Alignment.center,
              child: pw.SvgImage(
                  svg: buildBarcode(
                      height: 65,
                      width: 65,
                      Barcode.qrCode(),
                      getQrCodeContent(
                        createdDate: dbReceiptData.createdDate,
                        sellerName: selectedStoreData.storeName,
                        sellerTRN: selectedStoreData.vatNumber,
                        totalWithVat:
                            dbReceiptData.lineItemTotalData.receiptTotal,
                        vatPrice: taxValue,
                      )))),
        ),
        pw.Column(children: [
          pw.Row(children: [
            pw.SizedBox(
                width: 300,
                child: pw.Column(children: [
                  pw.Container(
                      decoration: pw.BoxDecoration(
                          border: pw.Border(
                        right:
                            pw.BorderSide(color: PdfColors.black, width: 0.3),
                        left: pw.BorderSide(color: PdfColors.black, width: 0.3),
                        top: pw.BorderSide(color: PdfColors.black, width: 0.3),
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: 0.3),
                      )),
                      height: 22,
                      width: 350,
                      alignment: pw.Alignment.centerLeft,
                      padding: pw.EdgeInsets.symmetric(horizontal: 10),
                      child: pw.Text(
                          double.parse(doubleToString(total)) >
                                  double.parse(doubleToString(total))
                              ? SpellingNumber(
                                      lang: "en",
                                      wholesUnit: "Riyals",
                                      fractionUnit: "Halala",
                                      digitsLengthW2F: 2,
                                      decimalSeperator: "and")
                                  .convert(double.parse(doubleToString(total)))
                              : SpellingNumber(
                                  lang: "en",
                                  wholesUnit: "Riyals",
                                ).convert(double.parse(doubleToString(total))),
                          style: pw.TextStyle(
                              fontSize: 10, font: englishRegularFont))),
                  pw.SizedBox(
                    height: 10,
                  ),
                  pw.Text(printingSetttings.receiptFotterEng,
                      style:
                          pw.TextStyle(fontSize: 9, font: englishRegularFont)),
                  pw.Text(printingSetttings.receiptFotterArb,
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(
                        fontSize: 9,
                        font: arabicNormalFont,
                      ))
                ])),
            pw.SizedBox(
                child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                    children: [
                  if (double.tryParse(dbReceiptData
                          .lineItemTotalData.totalDiscountPercentage)! >
                      0)
                    pw.Container(
                        height: 10,
                        width: 190,
                        // color: PdfColors.red,
                        padding: const pw.EdgeInsets.only(
                            left: 5, right: 10, top: 5, bottom: 5),
                        alignment: pw.Alignment.centerLeft,
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Row(children: [
                                pw.SizedBox(width: 10),
                                pw.Text('SubTotal',
                                    style: pw.TextStyle(
                                        fontSize: 10,
                                        font: englishRegularFont)),
                                pw.SizedBox(width: 10),
                                pw.Text('المجموع',
                                    textDirection: pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                        fontSize: 9, font: arabicNormalFont)),
                              ]),
                              pw.Text(
                                ((double.tryParse(dbReceiptData
                                                .lineItemTotalData
                                                .receiptTotal) ??
                                            0) +
                                        (double.tryParse(dbReceiptData
                                                .lineItemTotalData
                                                .totalDiscountValue) ??
                                            0))
                                    .toInt()
                                    .toString(),
                                style: pw.TextStyle(
                                    fontSize: 10, font: englishRegularFont),
                              ),
                            ])),
                  if (double.tryParse(dbReceiptData
                          .lineItemTotalData.totalDiscountPercentage)! >
                      0)
                    pw.SizedBox(
                      height: 3,
                    ),
                  if (double.tryParse(dbReceiptData
                          .lineItemTotalData.totalDiscountPercentage)! >
                      0)
                    pw.Container(
                        height: 10,
                        width: 190,
                        // color: PdfColors.red,
                        // decoration: pw.BoxDecoration(
                        //     border: pw.Border.all(
                        //   color: PdfColors.grey500,
                        //   width: .3,
                        // )),
                        padding: const pw.EdgeInsets.only(
                            left: 5, right: 10, top: 5, bottom: 5),
                        alignment: pw.Alignment.centerLeft,
                        child: pw.Row(
                            mainAxisAlignment:
                                pw.MainAxisAlignment.spaceBetween,
                            children: [
                              pw.Row(children: [
                                pw.SizedBox(width: 10),
                                pw.Text(
                                    'Dis (${doubleToString(double.tryParse(dbReceiptData.lineItemTotalData.totalDiscountPercentage) ?? 0)}%)',
                                    style: pw.TextStyle(
                                        fontSize: 10,
                                        font: englishRegularFont)),
                                pw.SizedBox(width: 10),
                                pw.Text('خصم',
                                    textDirection: pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                        fontSize: 9, font: arabicNormalFont)),
                              ]),
                              pw.Text(
                                  dbReceiptData
                                      .lineItemTotalData.totalDiscountValue,
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                            ])),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Container(
                      height: 10,
                      width: 190,
                      // color: PdfColors.red,
                      padding: const pw.EdgeInsets.only(
                          left: 5, right: 10, top: 5, bottom: 5),
                      alignment: pw.Alignment.centerLeft,
                      child: pw.Row(
                          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                          children: [
                            pw.Row(children: [
                              pw.SizedBox(width: 10),
                              pw.Text('Tot. bef.Tax',
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                              pw.SizedBox(width: 10),
                              pw.Text('المجموع',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 9, font: arabicNormalFont)),
                            ]),
                            pw.Text(
                              doubleToString(subTotal),
                              style: pw.TextStyle(
                                  fontSize: 10, font: englishRegularFont),
                            ),
                          ])),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Container(
                      height: 10,
                      width: 190,
                      padding: const pw.EdgeInsets.only(
                          left: 5, right: 10, top: 5, bottom: 5),
                      alignment: pw.Alignment.centerLeft,
                      child: pw.Row(
                          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                          children: [
                            pw.Row(children: [
                              pw.SizedBox(width: 10),
                              pw.Text(
                                  'Tax (${dbReceiptData.lineItemTotalData.totalTaxPercentage}%)',
                                  style: pw.TextStyle(
                                      fontSize: 10, font: englishRegularFont)),
                              pw.SizedBox(width: 10),
                              pw.Text('الضريبة',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 9, font: arabicNormalFont)),
                            ]),
                            pw.Text(doubleToString(vatTotal),
                                style: pw.TextStyle(
                                    fontSize: 10, font: englishRegularFont)),
                          ])),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Container(
                      height: 10,
                      width: 190,
                      padding: const pw.EdgeInsets.only(
                          left: 5, right: 10, top: 5, bottom: 5),
                      alignment: pw.Alignment.centerLeft,
                      child: pw.Row(
                          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                          children: [
                            pw.Row(children: [
                              pw.SizedBox(width: 10),
                              pw.Text('Total',
                                  style: pw.TextStyle(
                                      fontSize: 11, font: txtBoldFont)),
                              pw.SizedBox(width: 10),
                              pw.Text('الصافي',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                      fontSize: 10, font: arabicBoldFont)),
                            ]),
                            pw.Text(doubleToString(total),
                                style: pw.TextStyle(
                                    fontSize: 11, font: txtBoldFont)),
                          ])),
                  pw.SizedBox(height: 10),
                  // pw.Container(
                  //   width: 190,
                  //   height: 20,
                  //   child: pw.Row(
                  //       crossAxisAlignment: pw.CrossAxisAlignment.end,
                  //       mainAxisAlignment: pw.MainAxisAlignment.end,
                  //       children: [
                  //         if (dbReceiptData.receiptBasicInfo!.receiptType ==
                  //                 'Regular' &&
                  //             getReceiptPaymentType(dbReceiptData) == "CREDIT")
                  //           pw.Text('Payment Status : Unpaid',
                  //               style: pw.TextStyle(
                  //                   color: PdfColors.red, fontSize: 10)),
                  //         if (dbReceiptData.receiptBasicInfo!.receiptType ==
                  //                 'Regular' &&
                  //             getReceiptPaymentType(dbReceiptData) != "CREDIT")
                  //           pw.Text('Payment Status : Paid',
                  //               style: pw.TextStyle(
                  //                   color: PdfColors.green, fontSize: 10)),
                  //         pw.SizedBox(width: 15),
                  //         // pw.Text(getReceiptPaymentType(dbReceiptData)),
                  //       ]),
                  // )
                ])),
          ])
        ]),
      ]);
}

String calculateTaxValue(double t, String tax) {
  //tax
  double taxValue = 0;
  if (tax.isNotEmpty) {
    double texPer = double.tryParse(tax) ?? 0;

    double tx = 1 + (texPer / 100);

    if (tx != 0) taxValue = t - (t / tx);
  }

  return doubleToString(taxValue);
}

String calculateVatIncludedValue(double t, String tax) {
  //tax
  double taxValue = 0;
  if (tax.isNotEmpty) {
    double texPer = double.tryParse(tax) ?? 0;

    double tx = texPer / 100;

    if (tx != 0) taxValue = t * tx;
  }

  return doubleToString(taxValue);
}

productTile(txtNormalFont, LineItemData localReceiptData, arabicFont,
    vatPercentage, bool last, dbReceiptData, int i) {
  double height = 20;
  int nol = (localReceiptData.productName.toString().length / 50).ceil();

  if (nol != 1) {
    height += 15 * (nol - 1);
  }

  return pw.Row(children: [
    pw.Container(
      decoration: pw.BoxDecoration(
          // color: i.isOdd ? const PdfColor.fromInt(0xfff5f5f5) : null,
          border: pw.Border.all(width: 0.3, color: PdfColors.black)),
      height: height,
      width: 52,
      alignment: pw.Alignment.centerLeft,
      margin: pw.EdgeInsets.symmetric(vertical: 0),
      padding: const pw.EdgeInsets.all(4),
      child: pw.Text(
        localReceiptData.qty,
        style: pw.TextStyle(font: txtNormalFont, fontSize: 10),
      ),
    ),
    pw.Container(
      decoration: pw.BoxDecoration(
          // color: i.isOdd ? const PdfColor.fromInt(0xfff5f5f5) : null,
          border: pw.Border.all(width: 0.3, color: PdfColors.black)),
      height: height,
      width: 322,
      margin: pw.EdgeInsets.symmetric(vertical: 0),
      padding: const pw.EdgeInsets.all(4),
      child: pw.Text(localReceiptData.productName,
          textDirection: !containsExtendedArabic(localReceiptData.productName)
              ? pw.TextDirection.ltr
              : pw.TextDirection.rtl,
          softWrap: true,
          style: pw.TextStyle(
            font:
                !containsExtendedArabic(localReceiptData.productName.toString())
                    ? txtNormalFont
                    : arabicFont,
            fontSize: 10,
            //
          )),
    ),
    pw.Container(
      decoration: pw.BoxDecoration(
        border: pw.Border.all(width: 0.3, color: PdfColors.black),
      ),
      height: height,
      alignment: pw.Alignment.centerRight,
      width: 96,
      margin: pw.EdgeInsets.symmetric(vertical: 0),
      padding: const pw.EdgeInsets.all(4),
      child: pw.Text(
        double.parse(localReceiptData.orgPrice)
            .toStringAsFixed(2), // Ensure two decimal places
        style: pw.TextStyle(fontSize: 10, font: txtNormalFont),
      ),
    ),
    pw.Container(
      decoration: pw.BoxDecoration(
        border: pw.Border.all(width: 0.3, color: PdfColors.black),
      ),
      height: height,
      alignment: pw.Alignment.centerRight,
      width: 96,
      margin: pw.EdgeInsets.symmetric(vertical: 0),
      padding: const pw.EdgeInsets.all(4),
      child: pw.Text(
        (double.parse(localReceiptData.orgPrice) *
                (double.tryParse(localReceiptData.qty) ?? 0))
            .toStringAsFixed(2), // Ensure two decimal places
        style: pw.TextStyle(
          fontSize: 10,
          font: txtNormalFont,
        ),
      ),
    )
  ]);
}
