import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/e_invoice_generator.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../../../model/customer_data.dart';

pw.Widget des0001A4ReceiptTemplate({
  required image,
  required EmployeeData userData,
  required PrintingSetttings printingSetttings,
  required ReceiptOrQuotationData dbReceiptData,
  required englishBoldFont,
  required arabicRegularFont,
  required arabicBoldFont,
  required vatPercentage,
  required taxValue,
  required englishRegularFont,
  required StoreData? selectedStoreData,
  CustomerData? selectedCustomerData,
}) {
  return pw.Container(
      width: double.maxFinite,
      decoration: pw.BoxDecoration(border: pw.Border.all(width: 1.5)),
      child: pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.start,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Container(
                padding: const pw.EdgeInsets.all(15),
                width: double.maxFinite,
                child: pw.Column(
                    mainAxisAlignment: pw.MainAxisAlignment.start,
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Row(
                          mainAxisAlignment: pw.MainAxisAlignment.start,
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.start,
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                if (image != null) pw.Image(image, height: 35),
                                pw.SizedBox(
                                  height: 10,
                                ),
                                if (selectedStoreData != null)
                                  pw.Text(
                                    selectedStoreData.storeName,
                                    textAlign: pw.TextAlign.left,
                                    textDirection: !containsExtendedArabic(
                                            selectedStoreData.storeName
                                                .toString())
                                        ? pw.TextDirection.ltr
                                        : pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                        font: !containsExtendedArabic(
                                                selectedStoreData.storeName
                                                    .toString())
                                            ? englishBoldFont
                                            : arabicBoldFont,
                                        fontSize: 7,
                                        fontWeight: pw.FontWeight.bold),
                                  ),
                                if (selectedStoreData != null)
                                  pw.Text(
                                    selectedStoreData.address,
                                    textAlign: pw.TextAlign.left,
                                    textDirection: !containsExtendedArabic(
                                            selectedStoreData.address
                                                .toString())
                                        ? pw.TextDirection.ltr
                                        : pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                      font: !containsExtendedArabic(
                                              selectedStoreData.address
                                                  .toString())
                                          ? englishRegularFont
                                          : arabicRegularFont,
                                      fontSize: 7,
                                    ),
                                  ),
                                pw.SizedBox(
                                  height: 10,
                                ),
                                pw.Row(children: [
                                  pw.Text(
                                    'VAT No / ',
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.Text(
                                    'رقم الضريبة',
                                    textDirection: pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: arabicRegularFont,
                                    ),
                                  ),
                                  pw.Text(
                                    ' : ',
                                    textDirection: pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: arabicRegularFont,
                                    ),
                                  ),
                                  pw.SizedBox(width: 10),
                                  if (selectedStoreData != null)
                                    pw.Text(
                                      selectedStoreData.vatNumber,
                                      style: pw.TextStyle(
                                        fontSize: 7,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                ]),
                                pw.Row(children: [
                                  pw.Text(
                                    'Phone / ',
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.Text(
                                    "هاتف",
                                    textDirection: pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: arabicRegularFont,
                                    ),
                                  ),
                                  pw.Text(
                                    ' : ',
                                    textDirection: pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: arabicRegularFont,
                                    ),
                                  ),
                                  pw.SizedBox(width: 30),
                                  if (selectedStoreData != null)
                                    pw.Text(
                                      selectedStoreData.phone1,
                                      style: pw.TextStyle(
                                        fontSize: 7,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                ]),
                                pw.Row(children: [
                                  pw.Text(
                                    'A/C Number :',
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.SizedBox(width: 30),
                                  if (selectedStoreData != null)
                                    pw.Text(
                                      selectedStoreData.accountNumber,
                                      style: pw.TextStyle(
                                        fontSize: 7,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                ]),
                              ],
                            ),
                            pw.SizedBox(width: 20),
                            pw.SizedBox(width: 20),
                            pw.Align(
                                alignment: pw.Alignment.topCenter,
                                child: pw.SvgImage(
                                    svg: buildBarcode(
                                        height: 70,
                                        width: 70,
                                        Barcode.qrCode(),
                                        getQrCodeContent(
                                          createdDate:
                                              dbReceiptData.createdDate,
                                          sellerName: selectedStoreData == null
                                              ? 'testsellername'
                                              : selectedStoreData.storeName,
                                          sellerTRN: selectedStoreData == null
                                              ? '0'
                                              : selectedStoreData.vatNumber,
                                          totalWithVat: dbReceiptData
                                              .lineItemTotalData.receiptTotal,
                                          vatPrice: taxValue,
                                        )))),
                            pw.SizedBox(width: 10),
                            pw.Flexible(
                                child: pw.Column(
                                    mainAxisAlignment: pw.MainAxisAlignment.end,
                                    crossAxisAlignment:
                                        pw.CrossAxisAlignment.start,
                                    children: [
                                  pw.Row(children: [
                                    pw.Text(
                                      'Customer Info / ',
                                      style: pw.TextStyle(
                                          fontSize: 8,
                                          fontBold: englishBoldFont,
                                          fontWeight: pw.FontWeight.bold),
                                    ),
                                    pw.Text(
                                      'معلومات العميل',
                                      textDirection: pw.TextDirection.rtl,
                                      style: pw.TextStyle(
                                          fontSize: 8,
                                          fontBold: arabicBoldFont,
                                          fontWeight: pw.FontWeight.bold),
                                    ),
                                  ]),
                                  pw.SizedBox(height: 10),
                                  if (selectedCustomerData != null)
                                    pw.Text(
                                      selectedCustomerData.customerName,
                                      textDirection: !containsExtendedArabic(
                                              selectedCustomerData.customerName
                                                  .toString())
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                      style: pw.TextStyle(
                                          font: !containsExtendedArabic(
                                                  selectedCustomerData
                                                      .customerName
                                                      .toString())
                                              ? englishRegularFont
                                              : arabicRegularFont,
                                          fontSize: 7),
                                    ),
                                  //address 1
                                  if (selectedCustomerData != null &&
                                      selectedCustomerData.address1.isNotEmpty)
                                    pw.Text(
                                      selectedCustomerData.address1,
                                      textDirection: !containsExtendedArabic(
                                              selectedCustomerData.address1
                                                  .toString())
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                      style: pw.TextStyle(
                                        font: !containsExtendedArabic(
                                                selectedCustomerData.address1
                                                    .toString())
                                            ? englishRegularFont
                                            : arabicRegularFont,
                                        fontSize: 7,
                                      ),
                                    ),
                                  //address 2
                                  if (selectedCustomerData != null &&
                                      selectedCustomerData.address1.isEmpty &&
                                      selectedCustomerData.address2.isNotEmpty)
                                    pw.Text(
                                      selectedCustomerData.address2,
                                      textDirection: !containsExtendedArabic(
                                              selectedCustomerData.address2
                                                  .toString())
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                      style: pw.TextStyle(
                                        font: !containsExtendedArabic(
                                                selectedCustomerData.address2
                                                    .toString())
                                            ? englishRegularFont
                                            : arabicRegularFont,
                                        fontSize: 7,
                                      ),
                                    ),
                                  pw.SizedBox(height: 10),
                                  pw.Text(
                                    'Invoice# ${dbReceiptData.receiptBasicInfo!.receiptNo}',
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.Text(
                                    'Date : ${DateFormat('dd-MM-yyyy hh:mm a').format(dbReceiptData.createdDate)}',
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: englishRegularFont,
                                    ),
                                  ),
                                  pw.Row(children: [
                                    pw.Text(
                                      'Created :# ',
                                      style: pw.TextStyle(
                                        fontSize: 7,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                    pw.Text(
                                      userData.empBasicInfoData.username,
                                      textDirection: !containsExtendedArabic(
                                              userData.empBasicInfoData.username
                                                  .toString())
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                      style: pw.TextStyle(
                                        font: !containsExtendedArabic(userData
                                                .empBasicInfoData.username
                                                .toString())
                                            ? englishRegularFont
                                            : arabicRegularFont,
                                        fontSize: 7,
                                      ),
                                    ),
                                  ]),
                                  if (dbReceiptData
                                      .receiptBasicInfo!.referenceNo.isNotEmpty)
                                    pw.Text(
                                      'Reference no : ${dbReceiptData.receiptBasicInfo!.referenceNo}',
                                      style: pw.TextStyle(
                                        fontSize: 7,
                                        font: englishRegularFont,
                                      ),
                                    ),
                                  pw.SizedBox(height: 10),
                                  pw.SvgImage(
                                      svg: buildBarcode(
                                    height: 30,
                                    width: 80,
                                    Barcode.code128(
                                        useCode128B: false, useCode128C: false),
                                    dbReceiptData.receiptBasicInfo!.receiptNo
                                        .toString(),
                                    filename: 'code-128a',
                                  ))
                                ])),
                            pw.SizedBox(width: 10),
                          ]),
                      pw.SizedBox(
                        height: 20,
                      ),
                      if (dbReceiptData.receiptBasicInfo!.receiptType !=
                          'Regular')
                        pw.Center(
                            child: pw.Container(
                                decoration:
                                    pw.BoxDecoration(border: pw.Border.all()),
                                padding: const pw.EdgeInsets.symmetric(
                                    vertical: 5, horizontal: 10),
                                child: pw.Column(children: [
                                  pw.Text(
                                    'Return Invoice',
                                    textDirection: pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: englishBoldFont,
                                    ),
                                  ),
                                  pw.SizedBox(height: 3),
                                  pw.Text(
                                    'فاتورة الاسترجاع',
                                    textDirection: pw.TextDirection.rtl,
                                    style: pw.TextStyle(
                                      fontSize: 7,
                                      font: arabicBoldFont,
                                    ),
                                  ),
                                ]))),
                      pw.SizedBox(
                        height: 15,
                      ),
                    ])),
            if (printingSetttings.receiptTitleArb.isNotEmpty ||
                printingSetttings.receiptTitleEng.isNotEmpty)
              pw.Container(
                width: double.maxFinite,
                decoration: pw.BoxDecoration(border: pw.Border.all(width: 1.5)),
                padding: const pw.EdgeInsets.symmetric(vertical: 5),
                child: pw.Row(
                    mainAxisAlignment: pw.MainAxisAlignment.center,
                    crossAxisAlignment: pw.CrossAxisAlignment.center,
                    children: [
                      pw.Text(
                        printingSetttings.receiptTitleArb,
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(
                            fontSize: 9,
                            font: arabicBoldFont,
                            fontWeight: pw.FontWeight.bold),
                      ),
                      pw.SizedBox(width: 10),
                      pw.Text(
                        printingSetttings.receiptTitleEng,
                        style: pw.TextStyle(
                            fontSize: 9,
                            fontBold: englishBoldFont,
                            fontWeight: pw.FontWeight.bold),
                      ),
                    ]),
              ),
            pw.Container(
              width: double.maxFinite,
              alignment: pw.Alignment.centerLeft,
              child: pw.Table(
                columnWidths: {
                  0: const pw.FlexColumnWidth(4),
                  1: const pw.FlexColumnWidth(4),
                  2: const pw.FlexColumnWidth(3),
                  3: const pw.FlexColumnWidth(2),
                  4: const pw.FlexColumnWidth(2)
                },
                children: [
                  pw.TableRow(
                      decoration: const pw.BoxDecoration(
                          border: pw.Border(
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: 1.5),
                      )),
                      children: [
                        pw.Container(
                            height: 40,
                            alignment: pw.Alignment.centerLeft,
                            padding: const pw.EdgeInsets.only(left: 20),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text(
                                  'باركود',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    fontSize: 7,
                                    font: arabicRegularFont,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 4,
                                ),
                                pw.Text('Barcode',
                                    style: pw.TextStyle(
                                        fontSize: 7, font: englishRegularFont))
                              ],
                            )),
                        pw.Container(
                            height: 40,
                            alignment: pw.Alignment.centerLeft,
                            padding: const pw.EdgeInsets.only(left: 20),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text(
                                  'رقم صنف',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    fontSize: 7,
                                    font: arabicRegularFont,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 4,
                                ),
                                pw.Text('Product ID',
                                    style: pw.TextStyle(
                                        fontSize: 7, font: englishRegularFont))
                              ],
                            )),
                        pw.Container(
                            height: 40,
                            alignment: pw.Alignment.centerLeft,
                            padding: const pw.EdgeInsets.only(left: 20),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text(
                                  'سعر',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicRegularFont,
                                    fontSize: 7,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 4,
                                ),
                                pw.Text('Price',
                                    style: pw.TextStyle(
                                        fontSize: 7, font: englishRegularFont))
                              ],
                            )),
                        pw.Container(
                            height: 40,
                            alignment: pw.Alignment.centerLeft,
                            padding: const pw.EdgeInsets.only(left: 20),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text(
                                  'كمية',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicRegularFont,
                                    fontSize: 7,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 4,
                                ),
                                pw.Text('Qty',
                                    style: pw.TextStyle(
                                        fontSize: 7, font: englishRegularFont))
                              ],
                            )),
                        pw.Container(
                            height: 40,
                            alignment: pw.Alignment.centerLeft,
                            padding: const pw.EdgeInsets.only(left: 20),
                            child: pw.Column(
                              mainAxisAlignment: pw.MainAxisAlignment.center,
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text(
                                  'اجمالي',
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicRegularFont,
                                    fontSize: 7,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 4,
                                ),
                                pw.Text('Total',
                                    style: pw.TextStyle(
                                        fontSize: 7, font: englishRegularFont))
                              ],
                            )),
                      ]),
                ],
              ),
            ),
            for (LineItemData lineItemData in dbReceiptData.lineItemsData)
              productTile(
                  englishRegularFont,
                  lineItemData,
                  arabicRegularFont,
                  dbReceiptData.lineItemsData.indexOf(lineItemData) ==
                      dbReceiptData.lineItemsData.length - 1),
            pw.SizedBox(height: 80),
            pw.Container(
              padding:
                  const pw.EdgeInsets.symmetric(vertical: 10, horizontal: 10),
              decoration: const pw.BoxDecoration(
                  border: pw.Border(
                top: pw.BorderSide(color: PdfColors.black, width: 1.5),
              )),
              child: pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                mainAxisAlignment: pw.MainAxisAlignment.start,
                children: [
                  if (printingSetttings.receiptFotterEng.isNotEmpty ||
                      printingSetttings.receiptFotterArb.isNotEmpty)
                    pw.SizedBox(
                        width: 200,
                        child: pw.Column(
                            crossAxisAlignment: pw.CrossAxisAlignment.start,
                            mainAxisAlignment: pw.MainAxisAlignment.start,
                            children: [
                              pw.Padding(
                                  padding: const pw.EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: pw.Text(
                                      printingSetttings.receiptFotterEng,
                                      style: pw.TextStyle(
                                          fontSize: 7,
                                          font: englishRegularFont))),
                              pw.SizedBox(
                                height: 5,
                              ),
                              pw.Padding(
                                  padding: const pw.EdgeInsets.symmetric(
                                      horizontal: 10),
                                  child: pw.Align(
                                      alignment: pw.Alignment.bottomRight,
                                      child: pw.Text(
                                        printingSetttings.receiptFotterArb,
                                        textDirection: pw.TextDirection.rtl,
                                        style: pw.TextStyle(
                                          fontSize: 7,
                                          font: arabicRegularFont,
                                        ),
                                      ))),
                            ])),
                  pw.Expanded(
                      child: pw.SizedBox(
                    width: 10,
                  )),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text('Total Quantity',
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text('Total Price W/T',
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text('Discount %',
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text('Discount \$',
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text('Before VAT',
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text('VAT ($vatPercentage%)',
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 20,
                      ),
                      pw.Text(
                        'Subtotal',
                        style: pw.TextStyle(
                            font: englishBoldFont,
                            fontSize: 8,
                            fontWeight: pw.FontWeight.bold),
                      ),
                    ],
                  ),
                  pw.SizedBox(width: 30),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text(dbReceiptData.lineItemTotalData.totalQty,
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text(dbReceiptData.lineItemTotalData.receiptTotal,
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text(
                          dbReceiptData
                              .lineItemTotalData.totalDiscountPercentage,
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text(
                          dbReceiptData.lineItemTotalData.totalDiscountValue,
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text(
                          doubleToString(double.parse(dbReceiptData
                                  .lineItemTotalData.receiptTotal) -
                              double.parse(taxValue)),
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 4,
                      ),
                      pw.Text(taxValue,
                          style: pw.TextStyle(
                              fontSize: 7, font: englishRegularFont)),
                      pw.SizedBox(
                        height: 20,
                      ),
                      pw.Text(
                        dbReceiptData.lineItemTotalData.receiptTotal,
                        style: pw.TextStyle(
                            font: englishBoldFont,
                            fontSize: 8,
                            fontWeight: pw.FontWeight.bold),
                      ),
                    ],
                  ),
                  pw.SizedBox(width: 30),
                  pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.end,
                    children: [
                      pw.Text(
                        'الكمية',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(font: arabicBoldFont, fontSize: 7),
                      ),
                      pw.SizedBox(
                        height: 3,
                      ),
                      pw.Text(
                        'الاجملي قبل الخصم',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(font: arabicBoldFont, fontSize: 7),
                      ),
                      pw.SizedBox(
                        height: 3,
                      ),
                      pw.Text(
                        'خصم %',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(font: arabicBoldFont, fontSize: 7),
                      ),
                      pw.SizedBox(
                        height: 3,
                      ),
                      pw.Text(
                        'خصم \$',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(font: arabicBoldFont, fontSize: 7),
                      ),
                      pw.SizedBox(
                        height: 3,
                      ),
                      pw.Text(
                        'اجمالي قبل الضريبة',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(font: arabicBoldFont, fontSize: 7),
                      ),
                      pw.SizedBox(
                        height: 3,
                      ),
                      pw.Text(
                        'الضريبة ($vatPercentage%)',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(font: arabicBoldFont, fontSize: 7),
                      ),
                      pw.SizedBox(
                        height: 20,
                      ),
                      pw.Text(
                        'الاجمالي',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(
                            font: arabicBoldFont,
                            fontSize: 8,
                            fontWeight: pw.FontWeight.bold),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            pw.SizedBox(
              height: 15,
            ),
          ]));
}

productTile(txtNormalFont, LineItemData lineItemData, arabicFont, bool last) {
  double height = 35;

  int nol = (lineItemData.productName.toString().length / 30).ceil();

  if (nol != 1) {
    height += 10 * (nol - 1);
  }

  return pw.Row(
      // verticalAlignment: pw.TableCellVerticalAlignment.top,
      children: [
        pw.Container(
            decoration: pw.BoxDecoration(
                border: last
                    ? null
                    : const pw.Border(
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: 1.5),
                      )),
            height: height,
            width: 150,
            alignment: pw.Alignment.centerLeft,
            padding: const pw.EdgeInsets.only(left: 20),
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(
                  height: 4,
                ),
                pw.Text(
                  lineItemData.barcode,
                  style: pw.TextStyle(font: txtNormalFont, fontSize: 7),
                ),
                pw.SizedBox(
                  height: 4,
                ),
                pw.Flexible(
                    child: pw.Text(lineItemData.productName,
                        textDirection: !containsExtendedArabic(
                                lineItemData.productName.toString())
                            ? pw.TextDirection.ltr
                            : pw.TextDirection.rtl,
                        softWrap: true,
                        style: pw.TextStyle(
                          font: !containsExtendedArabic(
                                  lineItemData.productName.toString())
                              ? txtNormalFont
                              : arabicFont,
                          fontSize: 7,
                        ))),
                pw.SizedBox(
                  height: 4,
                ),
              ],
            )),
        pw.Container(
            decoration: pw.BoxDecoration(
                border: last
                    ? null
                    : const pw.Border(
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: 1.5),
                      )),
            height: height,
            width: 150,
            alignment: pw.Alignment.centerLeft,
            padding: const pw.EdgeInsets.only(left: 20),
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(
                  height: 4,
                ),
                pw.Text(
                  lineItemData.itemCode,
                  style: pw.TextStyle(font: txtNormalFont, fontSize: 7),
                ),
                pw.SizedBox(
                  height: 4,
                ),
                pw.Text(
                    'Discount %: ${doubleToString((double.parse(lineItemData.discountValue) * 100) / double.parse(lineItemData.totalWt))}',
                    style: pw.TextStyle(fontSize: 7, font: txtNormalFont))
              ],
            )),
        pw.Container(
            decoration: pw.BoxDecoration(
                border: last
                    ? null
                    : const pw.Border(
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: 1.5),
                      )),
            height: height,
            width: 120,
            alignment: pw.Alignment.centerLeft,
            padding: const pw.EdgeInsets.only(left: 20),
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(
                  height: 4,
                ),
                pw.Text(
                  '${lineItemData.priceWt}',
                  style: pw.TextStyle(
                    font: txtNormalFont,
                    fontSize: 7,
                  ),
                ),
                pw.SizedBox(
                  height: 4,
                ),
                pw.Text('Dicount\$: ${lineItemData.discountValue}',
                    style: pw.TextStyle(
                      fontSize: 7,
                      font: txtNormalFont,
                    ))
              ],
            )),
        pw.Container(
            decoration: pw.BoxDecoration(
                border: last
                    ? null
                    : const pw.Border(
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: 1.5),
                      )),
            height: height,
            width: 70,
            alignment: pw.Alignment.centerLeft,
            padding: const pw.EdgeInsets.only(left: 20),
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(
                  height: 4,
                ),
                pw.Text(
                  lineItemData.qty,
                  style: pw.TextStyle(font: txtNormalFont, fontSize: 7),
                ),
              ],
            )),
        pw.Container(
            decoration: pw.BoxDecoration(
                border: last
                    ? null
                    : const pw.Border(
                        bottom:
                            pw.BorderSide(color: PdfColors.black, width: 1.5),
                      )),
            height: height,
            width: 75,
            alignment: pw.Alignment.centerLeft,
            padding: const pw.EdgeInsets.only(left: 20),
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(
                  height: 4,
                ),
                pw.Text(
                  lineItemData.totalWt,
                  style: pw.TextStyle(
                    fontSize: 7,
                    font: txtNormalFont,
                  ),
                ),
              ],
            )),
      ]);
}
