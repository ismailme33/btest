import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/e_invoice_generator.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../../../../model/customer_data.dart';

pw.Widget des0004A4ReceiptTemplate(
    {required image,
    required PrintingSetttings printingSetttings,
    required ReceiptOrQuotationData dbReceiptData,
    required englishBoldFont,
    required arabicRegularFont,
    required arabicBoldFont,
    required vatPercentage,
    required taxValue,
    required englishRegularFont,
    required String tenderAmount,
    required String changeAmount,
    required StoreData? selectedStoreData,
    CustomerData? selectedCustomerData,
    context}) {
  return pw.Container(
      width: double.maxFinite,
      child: pw.Column(
          mainAxisAlignment: pw.MainAxisAlignment.start,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.start,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Row(
                      mainAxisAlignment: pw.MainAxisAlignment.start,
                      crossAxisAlignment: pw.CrossAxisAlignment.end,
                      children: [
                        pw.Column(
                          mainAxisAlignment: pw.MainAxisAlignment.start,
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.SizedBox(
                              height: 10,
                            ),
                            pw.Row(
                              children: [
                                pw.Text(
                                  printingSetttings.receiptTitleEng,
                                  textAlign: pw.TextAlign.left,
                                  style: pw.TextStyle(
                                      font: englishBoldFont,
                                      fontSize: 8,
                                      fontWeight: pw.FontWeight.bold),
                                ),
                                pw.SizedBox(
                                  width: 3,
                                ),
                                pw.Text(
                                  printingSetttings.receiptTitleArb,
                                  textAlign: pw.TextAlign.left,
                                  textDirection: pw.TextDirection.rtl,
                                  style: pw.TextStyle(
                                    font: arabicBoldFont,
                                    fontSize: 8,
                                  ),
                                ),
                              ],
                            ),
                            pw.SizedBox(
                              height: 10,
                            ),
                            if (selectedStoreData != null)
                              pw.Text(
                                selectedStoreData.storeName,
                                textAlign: pw.TextAlign.left,
                                textDirection: !containsExtendedArabic(
                                        selectedStoreData.storeName.toString())
                                    ? pw.TextDirection.ltr
                                    : pw.TextDirection.rtl,
                                style: pw.TextStyle(
                                    font: !containsExtendedArabic(
                                            selectedStoreData.storeName
                                                .toString())
                                        ? englishBoldFont
                                        : arabicBoldFont,
                                    fontSize: 12,
                                    fontWeight: pw.FontWeight.bold),
                              ),
                            pw.SizedBox(
                              height: 5,
                            ),
                            if (selectedStoreData != null)
                              pw.Text(
                                selectedStoreData.address,
                                textAlign: pw.TextAlign.left,
                                textDirection: !containsExtendedArabic(
                                        selectedStoreData.address.toString())
                                    ? pw.TextDirection.ltr
                                    : pw.TextDirection.rtl,
                                style: pw.TextStyle(
                                  font: !containsExtendedArabic(
                                          selectedStoreData.address.toString())
                                      ? englishRegularFont
                                      : arabicRegularFont,
                                  fontSize: 8,
                                ),
                              ),
                            pw.SizedBox(
                              height: 5,
                            ),
                            if (selectedStoreData != null)
                              pw.Text(
                                'Tax No.:          ${selectedStoreData.vatNumber}',
                                style: pw.TextStyle(
                                  fontSize: 8,
                                  font: englishRegularFont,
                                ),
                              ),
                            if (selectedStoreData != null)
                              pw.Row(children: [
                                pw.Text(
                                  'Bank Name : ',
                                  style: pw.TextStyle(
                                    fontSize: 8,
                                    font: englishRegularFont,
                                  ),
                                ),
                                pw.Text(
                                  selectedStoreData.bankName,
                                  style: pw.TextStyle(
                                    fontSize: 8,
                                    font: englishRegularFont,
                                  ),
                                ),
                              ]),
                            if (selectedStoreData != null)
                              pw.Text(
                                'Account Number : ${selectedStoreData.accountNumber}',
                                style: pw.TextStyle(
                                  fontSize: 8,
                                  font: englishRegularFont,
                                ),
                              ),
                          ],
                        ),
                        pw.Expanded(child: pw.SizedBox(width: 20)),
                        if (image != null)
                          pw.Align(
                            alignment: pw.Alignment.centerRight,
                            child: pw.Image(image, height: 60),
                          ),
                      ]),
                  pw.SizedBox(height: 15),
                  pw.Container(
                      width: double.maxFinite,
                      height: .1,
                      color: PdfColors.grey),
                  pw.SizedBox(
                    height: 5,
                  ),
                  pw.Row(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.SizedBox(
                        width: 200,
                        child: selectedCustomerData == null ||
                                selectedCustomerData.customerName.isEmpty
                            ? pw.SizedBox()
                            : pw.Column(
                                crossAxisAlignment: pw.CrossAxisAlignment.start,
                                mainAxisAlignment: pw.MainAxisAlignment.start,
                                children: [
                                    pw.Text(
                                      'Bill to',
                                      style: pw.TextStyle(
                                          font: englishBoldFont, fontSize: 8),
                                    ),
                                    pw.SizedBox(
                                      height: 5,
                                    ),
                                    pw.Text(
                                      selectedCustomerData.customerName,
                                      textDirection: !containsExtendedArabic(
                                              selectedCustomerData.customerName
                                                  .toString())
                                          ? pw.TextDirection.ltr
                                          : pw.TextDirection.rtl,
                                      style: pw.TextStyle(
                                          font: !containsExtendedArabic(
                                                  selectedCustomerData
                                                      .customerName
                                                      .toString())
                                              ? englishRegularFont
                                              : arabicRegularFont,
                                          fontSize: 7),
                                    ),
                                  ]),
                      ),
                      pw.Expanded(
                          child: pw.Container(
                              child: pw.Column(
                        children: [
                          pw.Align(
                              alignment: pw.Alignment.center,
                              child: pw.SvgImage(
                                  svg: buildBarcode(
                                      height: 55,
                                      width: 55,
                                      Barcode.qrCode(),
                                      getQrCodeContent(
                                        createdDate: dbReceiptData.createdDate,
                                        sellerName: selectedStoreData == null
                                            ? ''
                                            : selectedStoreData.storeName,
                                        sellerTRN: selectedStoreData == null
                                            ? ''
                                            : selectedStoreData.vatNumber,
                                        totalWithVat: dbReceiptData
                                            .lineItemTotalData.receiptTotal,
                                        vatPrice: taxValue,
                                      ))))
                        ],
                      ))),
                      pw.Expanded(
                        child: pw.Container(
                            child: pw.Column(
                                crossAxisAlignment: pw.CrossAxisAlignment.start,
                                children: [
                              pw.Padding(
                                padding: const pw.EdgeInsets.all(8),
                                child: pw.Row(children: [
                                  pw.Column(
                                      crossAxisAlignment:
                                          pw.CrossAxisAlignment.start,
                                      children: [
                                        pw.Text(
                                          'Invoice No.:',
                                          style: pw.TextStyle(
                                            fontSize: 8,
                                            font: englishRegularFont,
                                          ),
                                        ),
                                        pw.SizedBox(height: 5),
                                        pw.Text(
                                          'Date:',
                                          style: pw.TextStyle(
                                            fontSize: 8,
                                            font: englishRegularFont,
                                          ),
                                        ),
                                        pw.SizedBox(height: 5),
                                        pw.Text(
                                          'Payment status:',
                                          style: pw.TextStyle(
                                            fontSize: 8,
                                            font: englishRegularFont,
                                          ),
                                        ),
                                      ]),
                                  pw.SizedBox(width: 10),
                                  pw.Column(
                                      crossAxisAlignment:
                                          pw.CrossAxisAlignment.start,
                                      children: [
                                        pw.Text(
                                          dbReceiptData
                                              .receiptBasicInfo!.receiptNo,
                                          style: pw.TextStyle(
                                            fontSize: 8,
                                            font: englishRegularFont,
                                          ),
                                        ),
                                        pw.SizedBox(height: 5),
                                        pw.Text(
                                          DateFormat('dd/MM/yyyy').format(
                                              dbReceiptData.createdDate),
                                          style: pw.TextStyle(
                                            fontSize: 8,
                                            font: englishRegularFont,
                                          ),
                                        ),
                                        pw.SizedBox(height: 5),
                                        pw.Text(
                                          double.tryParse(dbReceiptData
                                                          .receiptBasicInfo!
                                                          .allPaymentMethodAmountsInfo[
                                                              PaymentMethodKey()
                                                                  .cash]
                                                          .toString()) !=
                                                      null &&
                                                  double.parse(dbReceiptData
                                                              .receiptBasicInfo!
                                                              .allPaymentMethodAmountsInfo[
                                                          PaymentMethodKey()
                                                              .cash]) !=
                                                      0
                                              ? 'Credit'
                                              : 'Paid',
                                          style: pw.TextStyle(
                                            fontSize: 8,
                                            font: englishRegularFont,
                                          ),
                                        ),
                                      ]),
                                ]),
                              ),
                            ])),
                      )
                    ],
                  ),
                ]),
            pw.SizedBox(
              height: 10,
            ),
            pw.Container(
              width: double.maxFinite,
              alignment: pw.Alignment.centerLeft,
              child: pw.Table(
                columnWidths: {
                  0: const pw.FlexColumnWidth(1),
                  1: const pw.FlexColumnWidth(6.5),
                  2: const pw.FlexColumnWidth(1.5),
                  3: const pw.FlexColumnWidth(1.5),
                  4: const pw.FlexColumnWidth(1.5),
                  5: const pw.FlexColumnWidth(1.5),
                  6: const pw.FlexColumnWidth(2.5)
                },
                children: [
                  pw.TableRow(children: [
                    pw.Container(
                        height: 18,
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          left: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          right: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          bottom: pw.BorderSide(
                              color: PdfColors.grey500, width: 3.5),
                        )),
                        alignment: pw.Alignment.center,
                        child: pw.Text('#',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))),
                    pw.Container(
                        height: 18,
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          left: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          right: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          bottom: pw.BorderSide(
                              color: PdfColors.grey500, width: 3.5),
                        )),
                        alignment: pw.Alignment.center,
                        child: pw.Text('Item',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))),
                    pw.Container(
                        height: 18,
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          left: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          right: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          bottom: pw.BorderSide(
                              color: PdfColors.grey500, width: 3.5),
                        )),
                        alignment: pw.Alignment.center,
                        child: pw.Text('Quantity',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))),
                    pw.Container(
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          left: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          right: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          bottom: pw.BorderSide(
                              color: PdfColors.grey500, width: 3.5),
                        )),
                        height: 18,
                        alignment: pw.Alignment.center,
                        child: pw.Text('Unit Price',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))),
                    pw.Container(
                        height: 18,
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          left: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          right: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          bottom: pw.BorderSide(
                              color: PdfColors.grey500, width: 3.5),
                        )),
                        alignment: pw.Alignment.center,
                        child: pw.Text('Tax',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))),
                    pw.Container(
                        height: 18,
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          left: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          right: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          bottom: pw.BorderSide(
                              color: PdfColors.grey500, width: 3.5),
                        )),
                        alignment: pw.Alignment.center,
                        child: pw.Text('Discount',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))),
                    pw.Container(
                        height: 18,
                        decoration: const pw.BoxDecoration(
                            border: pw.Border(
                          top: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          left: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          right: pw.BorderSide(
                              color: PdfColors.grey500, width: .3),
                          bottom: pw.BorderSide(
                              color: PdfColors.grey500, width: 3.5),
                        )),
                        alignment: pw.Alignment.center,
                        child: pw.Text('Total',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))),
                  ]),
                ],
              ),
            ),
            for (LineItemData lineItemData in dbReceiptData.lineItemsData)
              productTile(
                  englishRegularFont,
                  lineItemData,
                  arabicRegularFont,
                  vatPercentage,
                  dbReceiptData.lineItemsData.indexOf(lineItemData) ==
                      dbReceiptData.lineItemsData.length - 1,
                  dbReceiptData,
                  dbReceiptData.lineItemsData.indexOf(lineItemData)),
            pw.SizedBox(height: 10),
            getBottomTotalCalucations(englishBoldFont, arabicBoldFont,
                dbReceiptData, tenderAmount, changeAmount),
            pw.SizedBox(height: 10),
          ]));
}

getBottomTotalCalucations(txtBoldFont, arabicNormalFont,
    ReceiptOrQuotationData dbReceiptData, tendorAmount, changeAmount) {
  double subTotal = 0;
  double vatTotal = double.parse(dbReceiptData.lineItemTotalData.totalTaxValue);
  double total = double.parse(dbReceiptData.lineItemTotalData.receiptTotal);

  subTotal = total - vatTotal;

  return pw.Column(children: [
    pw.Row(mainAxisAlignment: pw.MainAxisAlignment.end, children: [
      pw.Column(children: [
        pw.Container(
            height: 20,
            width: 88,
            decoration: pw.BoxDecoration(
                border: pw.Border.all(
              color: PdfColors.grey500,
              width: .3,
            )),
            padding: const pw.EdgeInsets.all(5),
            alignment: pw.Alignment.centerLeft,
            child: pw.Text('Subtotal',
                style: pw.TextStyle(fontSize: 8, font: txtBoldFont))),
        pw.Container(
            height: 20,
            width: 88,
            decoration: pw.BoxDecoration(
                border: pw.Border.all(
              color: PdfColors.grey500,
              width: .3,
            )),
            padding: const pw.EdgeInsets.all(5),
            alignment: pw.Alignment.centerLeft,
            child: pw.Text('VAT',
                style: pw.TextStyle(fontSize: 8, font: txtBoldFont))),
        pw.Container(
            height: 20,
            width: 88,
            decoration: pw.BoxDecoration(
                color: const PdfColor.fromInt(0xfff5f5f5),
                border: pw.Border.all(
                  color: PdfColors.grey500,
                  width: .3,
                )),
            padding: const pw.EdgeInsets.all(5),
            alignment: pw.Alignment.centerLeft,
            child: pw.Text('Total',
                style: pw.TextStyle(fontSize: 8, font: txtBoldFont))),
      ]),
      pw.Column(children: [
        pw.Container(
            height: 20,
            width: 88,
            decoration: pw.BoxDecoration(
                border: pw.Border.all(
              color: PdfColors.grey500,
              width: .3,
            )),
            padding: const pw.EdgeInsets.all(5),
            alignment: pw.Alignment.centerRight,
            child: pw.Text('SR ${doubleToString(subTotal)}',
                style: pw.TextStyle(fontSize: 8, font: txtBoldFont))),
        pw.Container(
            height: 20,
            width: 88,
            decoration: pw.BoxDecoration(
                border: pw.Border.all(
              color: PdfColors.grey500,
              width: .3,
            )),
            padding: const pw.EdgeInsets.all(5),
            alignment: pw.Alignment.centerRight,
            child: pw.Text('SR ${doubleToString(vatTotal)}',
                style: pw.TextStyle(fontSize: 8, font: txtBoldFont))),
        pw.Container(
            height: 20,
            width: 88,
            decoration: pw.BoxDecoration(
                color: const PdfColor.fromInt(0xfff5f5f5),
                border: pw.Border.all(
                  color: PdfColors.grey500,
                  width: .3,
                )),
            padding: const pw.EdgeInsets.all(5),
            alignment: pw.Alignment.centerRight,
            child: pw.Text('SR ${total}',
                style: pw.TextStyle(fontSize: 8, font: txtBoldFont))),
      ]),
    ]),
    pw.SizedBox(height: 10),
    pw.Align(
      alignment: pw.Alignment.centerRight,
      child: pw.SizedBox(
        width: 88 * 2,
        child: pw.Column(children: [
          pw.Row(
            children: List.generate(
                1000 ~/ 10,
                (index) => pw.Expanded(
                      child: pw.Container(
                        color: index % 2 == 0 ? null : PdfColors.grey,
                        height: .5,
                      ),
                    )),
          ),
          pw.SizedBox(height: 4),
          pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Payment method:',
                    style: pw.TextStyle(fontSize: 8, font: txtBoldFont)),
                pw.Text(
                    // dbReceiptData.tendor.credit != '0' &&
                    //         dbReceiptData.tendor.credit != '0.0'
                    //     ? 'Credit'
                    //     : dbReceiptData.tendor.cash != '0' &&
                    //             dbReceiptData.tendor.creditCard == '0'
                    //         ? 'Cash'
                    //         : dbReceiptData.tendor.cash == '0' &&
                    //                 dbReceiptData.tendor.creditCard != '0'
                    //             ? 'Credit Card'
                    //             : 'Split',
                    'payment method',
                    style: pw.TextStyle(fontSize: 8, font: txtBoldFont))
              ]),
          pw.SizedBox(height: 4),
          pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Paid amount:',
                    style: pw.TextStyle(fontSize: 8, font: txtBoldFont)),
                pw.Text(
                    // dbReceiptData.tendor.credit != '0' &&
                    //         dbReceiptData.tendor.credit != '0.0'
                    //     ? 'SR 0'
                    //     :
                    'SR ' + tendorAmount,
                    style: pw.TextStyle(fontSize: 8, font: txtBoldFont))
              ]),
          pw.SizedBox(height: 4),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('Change:',
                  style: pw.TextStyle(fontSize: 8, font: txtBoldFont)),
              pw.Text(dbReceiptData.receiptBasicInfo!.receiptBalance,
                  style: pw.TextStyle(fontSize: 8, font: txtBoldFont))
            ],
          ),
          pw.SizedBox(height: 4),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('Amount due:',
                  style: pw.TextStyle(fontSize: 8, font: txtBoldFont)),
              pw.Text('SR 0',
                  style: pw.TextStyle(fontSize: 8, font: txtBoldFont))
            ],
          ),
        ]),
      ),
    ),
  ]);
}

String calculateTaxValue(double t, String tax) {
  //tax
  double taxValue = 0;
  if (tax.isNotEmpty) {
    double texPer = double.tryParse(tax) ?? 0;

    double tx = 1 + (texPer / 100);

    if (tx != 0) taxValue = t - (t / tx);
  }

  return doubleToString(taxValue);
}

String calculateVatIncludedValue(double t, String tax) {
  //tax
  double taxValue = 0;
  if (tax.isNotEmpty) {
    double texPer = double.tryParse(tax) ?? 0;

    double tx = texPer / 100;

    if (tx != 0) taxValue = t * tx;
  }

  return doubleToString(taxValue);
}

productTile(txtNormalFont, LineItemData localReceiptData, arabicFont,
    vatPercentage, bool last, ReceiptOrQuotationData dbReceiptData, int i) {
  double height = 15;
  int nol = (localReceiptData.productName.toString().length / 50).ceil();

  if (nol != 1) {
    height += 10 * (nol - 1);
  }

  return pw.Row(children: [
    pw.Container(
      decoration: pw.BoxDecoration(
          color: i.isOdd ? const PdfColor.fromInt(0xfff5f5f5) : null,
          border: pw.Border.all(width: 0.2, color: PdfColors.grey)),
      height: height,
      width: 35,
      alignment: pw.Alignment.centerLeft,
      padding: const pw.EdgeInsets.all(3),
      child: pw.Text(
        '${i + 1}',
        style: pw.TextStyle(font: txtNormalFont, fontSize: 8),
      ),
    ),
    pw.Container(
      decoration: pw.BoxDecoration(
          color: i.isOdd ? const PdfColor.fromInt(0xfff5f5f5) : null,
          border: pw.Border.all(width: 0.2, color: PdfColors.grey)),
      height: height,
      width: 230,
      padding: const pw.EdgeInsets.all(3),
      child: pw.Text(localReceiptData.productName,
          textDirection: !containsExtendedArabic(localReceiptData.productName)
              ? pw.TextDirection.ltr
              : pw.TextDirection.rtl,
          softWrap: true,
          style: pw.TextStyle(
            font:
                !containsExtendedArabic(localReceiptData.productName.toString())
                    ? txtNormalFont
                    : arabicFont,
            fontSize: 8,
            //
          )),
    ),
    pw.Container(
        decoration: pw.BoxDecoration(
            color: i.isOdd ? const PdfColor.fromInt(0xfff5f5f5) : null,
            border: pw.Border.all(width: 0.2, color: PdfColors.grey)),
        height: height,
        alignment: pw.Alignment.centerRight,
        width: 53,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Text(
          localReceiptData.qty,
          style: pw.TextStyle(font: txtNormalFont, fontSize: 8),
        )),
    pw.Container(
        decoration: pw.BoxDecoration(
            color: i.isOdd ? const PdfColor.fromInt(0xfff5f5f5) : null,
            border: pw.Border.all(width: 0.2, color: PdfColors.grey)),
        height: height,
        alignment: pw.Alignment.centerRight,
        width: 53,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Text(doubleToString(double.parse(localReceiptData.orgPrice)),
            style: pw.TextStyle(fontSize: 8, font: txtNormalFont))),
    pw.Container(
        decoration: pw.BoxDecoration(
            color: i.isOdd ? const PdfColor.fromInt(0xfff5f5f5) : null,
            border: pw.Border.all(width: 0.2, color: PdfColors.grey)),
        height: height,
        alignment: pw.Alignment.centerRight,
        width: 53,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Text('${dbReceiptData.lineItemTotalData.totalTaxPercentage}%',
            style: pw.TextStyle(
              fontSize: 8,
              font: txtNormalFont,
            ))),
    pw.Container(
        decoration: pw.BoxDecoration(
            color: i.isOdd ? const PdfColor.fromInt(0xfff5f5f5) : null,
            border: pw.Border.all(width: 0.2, color: PdfColors.grey)),
        height: height,
        alignment: pw.Alignment.centerRight,
        width: 53,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Text(localReceiptData.discountPercentage + '%',
            style: pw.TextStyle(
              fontSize: 8,
              font: txtNormalFont,
            ))),
    pw.Container(
        decoration: pw.BoxDecoration(
            color: i.isOdd ? const PdfColor.fromInt(0xfff5f5f5) : null,
            border: pw.Border.all(width: 0.2, color: PdfColors.grey)),
        height: height,
        alignment: pw.Alignment.centerRight,
        width: 88,
        padding: const pw.EdgeInsets.all(3),
        child: pw.Text(doubleToString(double.parse(localReceiptData.totalWt)),
            style: pw.TextStyle(
              fontSize: 8,
              font: txtNormalFont,
            ))),
  ]);
}
