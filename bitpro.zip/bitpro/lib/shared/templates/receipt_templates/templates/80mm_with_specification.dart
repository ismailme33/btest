import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/customer_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/e_invoice_generator.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';

List<pw.Widget> receipt80mmWithSpecificaitonTemplate({
  required image,
  required PrintingSetttings printingSetttings,
  required StoreData? selectedStoreData,
  required ReceiptOrQuotationData dbReceiptData,
  required englishNormalFont,
  required arabicNormalFont,
  required englishBoldFont,
  required arabicBoldFont,
  required vatPercentage,
  required taxValue,
  CustomerData? selectedCustomerData,
}) {
  return [
    pw.Container(
        width: double.maxFinite,
        child: pw.Column(children: [
          pw.SizedBox(
            height: 15,
          ),
          if (image != null)
            pw.Align(
              alignment: pw.Alignment.center,
              child: pw.Image(image, height: 80),
            ),
          pw.SizedBox(
            height: 5,
          ),
          if (selectedStoreData != null)
            pw.Text(
              selectedStoreData.storeName,
              textDirection: !containsExtendedArabic(
                      selectedStoreData.storeName.toString())
                  ? pw.TextDirection.ltr
                  : pw.TextDirection.rtl,
              style: pw.TextStyle(
                font: !containsExtendedArabic(
                        selectedStoreData.storeName.toString())
                    ? englishBoldFont
                    : arabicBoldFont,
                fontSize: 10,
              ),
            ),
          if (selectedStoreData != null)
            pw.Text(
              selectedStoreData.address,
              textAlign: pw.TextAlign.center,
              textDirection:
                  !containsExtendedArabic(selectedStoreData.address.toString())
                      ? pw.TextDirection.ltr
                      : pw.TextDirection.rtl,
              style: pw.TextStyle(
                font: !containsExtendedArabic(
                        selectedStoreData.address.toString())
                    ? englishBoldFont
                    : arabicBoldFont,
                fontSize: 8,
              ),
            ),
          pw.SizedBox(
            height: 7,
          ),
          if (dbReceiptData.receiptBasicInfo!.receiptType != 'Regular')
            pw.Container(
                margin: const pw.EdgeInsets.symmetric(horizontal: 42),
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(), color: PdfColors.black),
                padding:
                    const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 3),
                child: pw.Center(
                  child: pw.Row(children: [
                    pw.Text(
                      'Return Invoice',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(
                        color: PdfColors.white,
                        fontSize: 7,
                        font: englishBoldFont,
                      ),
                    ),
                    pw.SizedBox(width: 3),
                    pw.Text(
                      'فاتورة الاسترجاع',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(
                        color: PdfColors.white,
                        fontSize: 7,
                        font: arabicBoldFont,
                      ),
                    ),
                  ]),
                )),
          pw.SizedBox(
            height: 7,
          ),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceAround,
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                mainAxisAlignment: pw.MainAxisAlignment.start,
                children: [
                  if (selectedStoreData != null)
                    if (selectedStoreData.vatNumber.isNotEmpty)
                      pw.Text(
                        'VAT No.',
                        style: pw.TextStyle(
                          fontSize: 8,
                          font: englishBoldFont,
                        ),
                      ),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text(
                    'Invoice No.',
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text(
                    'Date/Time',
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.SizedBox(
                    height: 3,
                  ),
                  if (selectedStoreData != null)
                    if (selectedStoreData.phone1.isNotEmpty)
                      pw.Text(
                        'Phone',
                        style: pw.TextStyle(
                          fontSize: 8,
                          font: englishBoldFont,
                        ),
                      ),
                ],
              ),
              pw.Column(
                children: [
                  if (selectedStoreData != null)
                    if (selectedStoreData.vatNumber.isNotEmpty)
                      pw.Text(
                        selectedStoreData.vatNumber,
                        style: pw.TextStyle(
                          fontSize: 10,
                          font: englishBoldFont,
                        ),
                      ),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text(
                    dbReceiptData.receiptBasicInfo!.receiptNo.toString(),
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text(
                    DateFormat('dd-MM-yyyy hh:mm a')
                        .format(dbReceiptData.createdDate),
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.SizedBox(
                    height: 3,
                  ),
                  if (selectedStoreData != null)
                    if (selectedStoreData.phone1.isNotEmpty)
                      pw.Text(
                        selectedStoreData.phone1,
                        style: pw.TextStyle(
                          fontSize: 8,
                          font: englishBoldFont,
                        ),
                      ),
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  if (selectedStoreData != null)
                    if (selectedStoreData.vatNumber.isNotEmpty)
                      pw.Text(
                        'رقم الضريبة',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(
                          fontSize: 8,
                          font: arabicBoldFont,
                        ),
                      ),
                  pw.Text(
                    'رقم الفاتورة',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: arabicBoldFont,
                    ),
                  ),
                  pw.Text(
                    'تاريخ',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: arabicBoldFont,
                    ),
                  ),
                  if (selectedStoreData != null)
                    if (selectedStoreData.phone1.isNotEmpty)
                      pw.Text(
                        'تاريخ',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(
                          fontSize: 8,
                          font: arabicBoldFont,
                        ),
                      ),
                ],
              )
            ],
          ),
          pw.SizedBox(
            height: 5,
          ),
          if (printingSetttings.receiptTitleEng.isNotEmpty ||
              printingSetttings.receiptTitleArb.isNotEmpty)
            pw.Container(
                width: double.maxFinite,
                color: PdfColor.fromInt(0xffe4e4de),
                padding: pw.EdgeInsets.symmetric(vertical: 4),
                margin: pw.EdgeInsets.symmetric(horizontal: 5),
                child: pw.Column(children: [
                  pw.Text(
                    printingSetttings.receiptTitleArb,
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: arabicBoldFont,
                    ),
                  ),
                  pw.Text(
                    printingSetttings.receiptTitleEng,
                    style: pw.TextStyle(
                      fontWeight: pw.FontWeight.bold,
                      fontSize: 8,
                      font: englishBoldFont,
                    ),
                  ),
                ])),
          pw.SizedBox(
            height: 7,
          ),
          if (selectedCustomerData != null)
            pw.Container(
                width: double.maxFinite,
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(width: .6),
                    borderRadius: pw.BorderRadius.circular(4)),
                padding: pw.EdgeInsets.all(5),
                margin: pw.EdgeInsets.symmetric(horizontal: 5),
                child: pw.Row(
                    crossAxisAlignment: pw.CrossAxisAlignment.end,
                    children: [
                      pw.Spacer(),
                      pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.end,
                        children: [
                          pw.Text(
                            selectedCustomerData.customerName,
                            maxLines: 1,
                            textDirection: !containsExtendedArabic(
                                    selectedCustomerData.customerName)
                                ? pw.TextDirection.ltr
                                : pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              font: !containsExtendedArabic(
                                      selectedCustomerData.customerName)
                                  ? englishBoldFont
                                  : arabicBoldFont,
                              fontSize: 8,
                            ),
                          ),
                          pw.Text(
                            selectedCustomerData.address1,
                            maxLines: 1,
                            textDirection: !containsExtendedArabic(
                                    selectedCustomerData.address1)
                                ? pw.TextDirection.ltr
                                : pw.TextDirection.rtl,
                            style: pw.TextStyle(
                              font: !containsExtendedArabic(
                                      selectedCustomerData.address1)
                                  ? englishBoldFont
                                  : arabicBoldFont,
                              fontSize: 8,
                            ),
                          ),
                          pw.Text(
                            selectedCustomerData.phone1,
                            maxLines: 1,
                            style: pw.TextStyle(
                              fontSize: 8,
                              font: englishBoldFont,
                            ),
                          ),
                        ],
                      ),
                      pw.SizedBox(width: 10),
                      pw.Column(
                        crossAxisAlignment: pw.CrossAxisAlignment.end,
                        children: [
                          if (selectedCustomerData.customerName.isNotEmpty)
                            pw.Text(
                              'اسم العميل',
                              textDirection: pw.TextDirection.rtl,
                              style: pw.TextStyle(
                                fontSize: 8,
                                font: arabicBoldFont,
                              ),
                            ),
                          if (selectedCustomerData.address1.isNotEmpty)
                            pw.Text(
                              "عنوان العميل",
                              textDirection: pw.TextDirection.rtl,
                              style: pw.TextStyle(
                                fontSize: 8,
                                font: arabicBoldFont,
                              ),
                            ),
                          if (selectedCustomerData.phone1.isNotEmpty)
                            pw.Text(
                              'هاتف العميل',
                              textDirection: pw.TextDirection.rtl,
                              style: pw.TextStyle(
                                fontSize: 8,
                                font: arabicBoldFont,
                              ),
                            ),
                        ],
                      )
                    ]))
        ])),
    pw.Container(
      // width: double.maxFinite,
      alignment: pw.Alignment.centerLeft,
      margin: pw.EdgeInsets.symmetric(horizontal: 5),
      child: pw.Table(
        columnWidths: {
          0: const pw.FlexColumnWidth(3),
          1: const pw.FlexColumnWidth(3),
          2: const pw.FlexColumnWidth(3),
          3: const pw.FlexColumnWidth(5)
        },
        children: [
          pw.TableRow(
              decoration: const pw.BoxDecoration(
                  border: pw.Border(
                bottom: pw.BorderSide(color: PdfColors.black, width: 1),
              )),
              children: [
                pw.Container(
                  height: 20,
                  alignment: pw.Alignment.centerLeft,
                  child: pw.Text(
                    'الاجمالي',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 8,
                      font: arabicBoldFont,
                    ),
                  ),
                ),
                pw.Container(
                  height: 20,
                  alignment: pw.Alignment.centerLeft,
                  child: pw.Text(
                    'السعر',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 8,
                    ),
                  ),
                ),
                pw.Container(
                  height: 20,
                  alignment: pw.Alignment.centerLeft,
                  child: pw.Text(
                    'العدد',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 8,
                    ),
                  ),
                ),
                pw.Container(
                  height: 20,
                  alignment: pw.Alignment.centerRight,
                  child: pw.Text(
                    'الصنف',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 8,
                    ),
                  ),
                ),
              ]),
          for (LineItemData lineItemData in dbReceiptData.lineItemsData)
            ...productTile(englishBoldFont, lineItemData, arabicNormalFont),
        ],
      ),
    ),
    pw.SizedBox(height: 5),
    pw.Container(
      padding: const pw.EdgeInsets.symmetric(vertical: 2, horizontal: 5),
      child: pw.Row(
        children: [
          pw.Expanded(
              child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Container(
                width: double.maxFinite,
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(width: .5),
                    borderRadius:
                        pw.BorderRadius.only(topLeft: pw.Radius.circular(5))),
                padding: pw.EdgeInsets.symmetric(vertical: 4, horizontal: 5),
                child: pw.Text('Vat',
                    style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              ),
              pw.Container(
                width: double.maxFinite,
                decoration: pw.BoxDecoration(border: pw.Border.all(width: .5)),
                padding: pw.EdgeInsets.symmetric(vertical: 4, horizontal: 5),
                child: pw.Text('Inv. Total',
                    style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              ),
              pw.Container(
                width: double.maxFinite,
                decoration: pw.BoxDecoration(border: pw.Border.all(width: .5)),
                padding: pw.EdgeInsets.symmetric(vertical: 4, horizontal: 5),
                child: pw.Text('Paid Amount',
                    style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              ),
              pw.Container(
                width: double.maxFinite,
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(width: .5),
                    borderRadius: pw.BorderRadius.only(
                        bottomLeft: pw.Radius.circular(8))),
                padding: pw.EdgeInsets.symmetric(vertical: 4, horizontal: 5),
                child: pw.Text('Due Amount',
                    style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              ),
            ],
          )),
          pw.Expanded(
              child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Container(
                width: double.maxFinite,
                decoration: pw.BoxDecoration(border: pw.Border.all(width: .5)),
                padding: pw.EdgeInsets.symmetric(vertical: 4, horizontal: 5),
                alignment: pw.Alignment.center,
                child: pw.Text(taxValue.toString(),
                    style: pw.TextStyle(fontSize: 8, font: englishBoldFont)),
              ),
              pw.Container(
                  width: double.maxFinite,
                  decoration:
                      pw.BoxDecoration(border: pw.Border.all(width: .5)),
                  alignment: pw.Alignment.center,
                  padding: pw.EdgeInsets.symmetric(vertical: 4, horizontal: 5),
                  child: pw.Text(dbReceiptData.lineItemTotalData.receiptTotal,
                      style: pw.TextStyle(fontSize: 8, font: englishBoldFont))),
              pw.Container(
                  width: double.maxFinite,
                  decoration:
                      pw.BoxDecoration(border: pw.Border.all(width: .5)),
                  padding: pw.EdgeInsets.symmetric(vertical: 4, horizontal: 5),
                  alignment: pw.Alignment.center,
                  child: pw.Text(
                      doubleToString(double.parse(
                              dbReceiptData.lineItemTotalData.receiptTotal) -
                          double.parse(
                              dbReceiptData.receiptBasicInfo!.receiptDue)),
                      style: pw.TextStyle(fontSize: 8, font: englishBoldFont))),
              pw.Container(
                  width: double.maxFinite,
                  decoration:
                      pw.BoxDecoration(border: pw.Border.all(width: .5)),
                  padding: pw.EdgeInsets.symmetric(vertical: 4, horizontal: 5),
                  alignment: pw.Alignment.center,
                  child: pw.Text(
                      doubleToString(double.parse(
                          dbReceiptData.receiptBasicInfo!.receiptDue)),
                      style: pw.TextStyle(fontSize: 8, font: englishBoldFont))),
            ],
          )),
          pw.Expanded(
              child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Container(
                  width: double.maxFinite,
                  decoration: pw.BoxDecoration(
                      border: pw.Border.all(width: .5),
                      borderRadius: pw.BorderRadius.only(
                          topRight: pw.Radius.circular(8))),
                  padding: pw.EdgeInsets.symmetric(horizontal: 5),
                  alignment: pw.Alignment.centerRight,
                  height: 17.2,
                  child: pw.Text(
                    'ضريبة',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 9,
                    ),
                  )),
              pw.Container(
                  width: double.maxFinite,
                  decoration:
                      pw.BoxDecoration(border: pw.Border.all(width: .5)),
                  height: 17.2,
                  padding: pw.EdgeInsets.symmetric(horizontal: 5),
                  alignment: pw.Alignment.centerRight,
                  child: pw.Text(
                    'الاجمالي',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 9,
                    ),
                  )),
              pw.Container(
                  width: double.maxFinite,
                  decoration:
                      pw.BoxDecoration(border: pw.Border.all(width: .5)),
                  height: 17.2,
                  padding: pw.EdgeInsets.symmetric(horizontal: 5),
                  alignment: pw.Alignment.centerRight,
                  child: pw.Text(
                    'المدفوع',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 8,
                    ),
                  )),
              pw.Container(
                  width: double.maxFinite,
                  decoration: pw.BoxDecoration(
                      border: pw.Border.all(width: .5),
                      borderRadius: pw.BorderRadius.only(
                          bottomRight: pw.Radius.circular(8))),
                  height: 17.2,
                  padding: pw.EdgeInsets.symmetric(horizontal: 5),
                  alignment: pw.Alignment.centerRight,
                  child: pw.Text(
                    'المبلغ المستحق',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      font: arabicBoldFont,
                      fontSize: 8,
                    ),
                  )),
            ],
          )),
        ],
      ),
    ),
    pw.SizedBox(height: 5),
    pw.Align(
        alignment: pw.Alignment.center,
        child: pw.Text(
          'شكرا لزيارتكم',
          textDirection: pw.TextDirection.rtl,
          style: pw.TextStyle(
            font: arabicBoldFont,
            fontSize: 8,
          ),
        )),
    pw.SizedBox(height: 8),
    if (dbReceiptData.receiptBasicInfo!.specificationInfo != null)
      specificaitonTableWidget(
        dbReceiptData,
        englishBoldFont,
        arabicNormalFont,
        englishBoldFont,
        arabicBoldFont,
      ),
    if (dbReceiptData.receiptBasicInfo!.specificationInfo != null)
      pw.SizedBox(height: 8),
    if (printingSetttings.receiptFotterEng.isNotEmpty)
      pw.Padding(
          padding: const pw.EdgeInsets.symmetric(horizontal: 10),
          child: pw.Text(printingSetttings.receiptFotterEng,
              textAlign: pw.TextAlign.center,
              style: pw.TextStyle(fontSize: 8, font: englishBoldFont))),
    pw.SizedBox(
      height: 1,
    ),
    if (printingSetttings.receiptFotterArb.isNotEmpty)
      pw.Padding(
          padding: const pw.EdgeInsets.symmetric(horizontal: 10),
          child: pw.Align(
              alignment: pw.Alignment.bottomRight,
              child: pw.Text(
                printingSetttings.receiptFotterArb,
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                  fontSize: 8,
                  font: arabicBoldFont,
                ),
              ))),
    pw.SizedBox(
      height: 10,
    ),
    pw.Align(
        alignment: pw.Alignment.center,
        child: pw.SvgImage(
            svg: buildBarcode(
                height: 110,
                width: 110,
                Barcode.qrCode(),
                getQrCodeContent(
                  createdDate: dbReceiptData.createdDate,
                  sellerName: selectedStoreData == null
                      ? ''
                      : selectedStoreData.storeName,
                  sellerTRN: selectedStoreData == null
                      ? ''
                      : selectedStoreData.vatNumber,
                  totalWithVat: dbReceiptData.lineItemTotalData.receiptTotal,
                  vatPrice: taxValue,
                )))),
    pw.SizedBox(
      height: 15,
    ),
  ];
}

specificaitonTableWidget(
  ReceiptOrQuotationData dbReceiptData,
  englishNormalFont,
  arabicNormalFont,
  englishBoldFont,
  arabicBoldFont,
) {
  return pw.Container(
      padding: pw.EdgeInsets.symmetric(horizontal: 5),
      child: pw.Column(
        children: [
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Container(
                  decoration: pw.BoxDecoration(
                      border: pw.Border.all(width: .5),
                      borderRadius:
                          pw.BorderRadius.only(topLeft: pw.Radius.circular(8))),
                  height: 16,
                  width: 40),
              pw.Expanded(
                  child: pw.Container(
                      decoration: pw.BoxDecoration(
                        border: pw.Border.all(width: .5),
                      ),
                      height: 16,
                      alignment: pw.Alignment.center,
                      child: pw.Text(
                        'Right',
                        style: pw.TextStyle(
                          font: englishBoldFont,
                          fontSize: 8,
                        ),
                      ))),
              pw.Expanded(
                  child: pw.Container(
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(width: .5),
                    borderRadius:
                        pw.BorderRadius.only(topRight: pw.Radius.circular(8))),
                height: 16,
                alignment: pw.Alignment.center,
                child: pw.Text('Left',
                    style: pw.TextStyle(
                      font: englishBoldFont,
                      fontSize: 8,
                    )),
              )),
            ],
          ),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Container(
                  decoration: pw.BoxDecoration(
                    border: pw.Border.all(width: .5),
                  ),
                  height: 16,
                  width: 40,
                  alignment: pw.Alignment.center,
                  child: pw.Text(
                    'SPH',
                    style: pw.TextStyle(
                      font: englishBoldFont,
                      fontSize: 8,
                    ),
                  )),
              pw.Expanded(
                  child: pw.Container(
                      decoration:
                          pw.BoxDecoration(border: pw.Border.all(width: .5)),
                      height: 16,
                      alignment: pw.Alignment.center,
                      child: pw.Text(
                        dbReceiptData
                            .receiptBasicInfo!.specificationInfo!.sphRight,
                        maxLines: 1,
                        style: pw.TextStyle(
                          font: englishBoldFont,
                          fontSize: 9,
                        ),
                      ))),
              pw.Expanded(
                  child: pw.Container(
                      decoration:
                          pw.BoxDecoration(border: pw.Border.all(width: .5)),
                      height: 16,
                      alignment: pw.Alignment.center,
                      child: pw.Text(
                        dbReceiptData
                            .receiptBasicInfo!.specificationInfo!.sphLeft,
                        maxLines: 1,
                        style: pw.TextStyle(
                          font: englishBoldFont,
                          fontSize: 9,
                        ),
                      ))),
            ],
          ),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Container(
                  decoration:
                      pw.BoxDecoration(border: pw.Border.all(width: .5)),
                  height: 16,
                  width: 40,
                  alignment: pw.Alignment.center,
                  child: pw.Text(
                    'CYL',
                    style: pw.TextStyle(
                      font: englishBoldFont,
                      fontSize: 8,
                    ),
                  )),
              pw.Expanded(
                  child: pw.Container(
                      decoration:
                          pw.BoxDecoration(border: pw.Border.all(width: .5)),
                      height: 16,
                      alignment: pw.Alignment.center,
                      child: pw.Text(
                        dbReceiptData
                            .receiptBasicInfo!.specificationInfo!.cylRight,
                        maxLines: 1,
                        style: pw.TextStyle(
                          font: englishBoldFont,
                          fontSize: 9,
                        ),
                      ))),
              pw.Expanded(
                  child: pw.Container(
                decoration: pw.BoxDecoration(border: pw.Border.all(width: .5)),
                height: 16,
                alignment: pw.Alignment.center,
                child: pw.Text(
                    dbReceiptData.receiptBasicInfo!.specificationInfo!.cylLeft,
                    maxLines: 1,
                    style: pw.TextStyle(
                      font: englishBoldFont,
                      fontSize: 9,
                    )),
              )),
            ],
          ),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Container(
                  decoration:
                      pw.BoxDecoration(border: pw.Border.all(width: .5)),
                  height: 16,
                  width: 40,
                  alignment: pw.Alignment.center,
                  child: pw.Text(
                    'AXIS',
                    style: pw.TextStyle(
                      font: englishBoldFont,
                      fontSize: 8,
                    ),
                  )),
              pw.Expanded(
                  child: pw.Container(
                      decoration:
                          pw.BoxDecoration(border: pw.Border.all(width: .5)),
                      height: 16,
                      alignment: pw.Alignment.center,
                      child: pw.Text(
                        dbReceiptData
                            .receiptBasicInfo!.specificationInfo!.axisRight,
                        maxLines: 1,
                        style: pw.TextStyle(
                          font: englishBoldFont,
                          fontSize: 9,
                        ),
                      ))),
              pw.Expanded(
                  child: pw.Container(
                      decoration:
                          pw.BoxDecoration(border: pw.Border.all(width: .5)),
                      height: 16,
                      alignment: pw.Alignment.center,
                      child: pw.Text(
                        dbReceiptData
                            .receiptBasicInfo!.specificationInfo!.axisLeft,
                        maxLines: 1,
                        style: pw.TextStyle(
                          font: englishBoldFont,
                          fontSize: 9,
                        ),
                      ))),
            ],
          ),
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Container(
                  decoration: pw.BoxDecoration(
                      border: pw.Border.all(width: .5),
                      borderRadius: pw.BorderRadius.only(
                          bottomLeft: pw.Radius.circular(8))),
                  height: 16,
                  width: 40,
                  alignment: pw.Alignment.center,
                  child: pw.Text(
                    'IPD',
                    style: pw.TextStyle(
                      font: englishBoldFont,
                      fontSize: 8,
                    ),
                  )),
              pw.Expanded(
                  child: pw.Container(
                      decoration: pw.BoxDecoration(
                        border: pw.Border.all(width: .5),
                      ),
                      height: 16,
                      alignment: pw.Alignment.center,
                      child: pw.Text(
                        dbReceiptData.receiptBasicInfo!.specificationInfo!.ipd,
                        maxLines: 1,
                        style: pw.TextStyle(
                          font: englishBoldFont,
                          fontSize: 9,
                        ),
                      ))),
              pw.Container(
                  decoration:
                      pw.BoxDecoration(border: pw.Border.all(width: .5)),
                  height: 16,
                  width: 40,
                  alignment: pw.Alignment.center,
                  child: pw.Text(
                    'ADD',
                    style: pw.TextStyle(
                      font: englishBoldFont,
                      fontSize: 8,
                    ),
                  )),
              pw.Expanded(
                  child: pw.Container(
                      decoration: pw.BoxDecoration(
                          border: pw.Border.all(width: .5),
                          borderRadius: pw.BorderRadius.only(
                              bottomRight: pw.Radius.circular(8))),
                      height: 16,
                      alignment: pw.Alignment.center,
                      child: pw.Text(
                        dbReceiptData.receiptBasicInfo!.specificationInfo!.add,
                        maxLines: 1,
                        style: pw.TextStyle(
                          font: englishBoldFont,
                          fontSize: 9,
                        ),
                      ))),
            ],
          )
        ],
      ));
}

List<pw.TableRow> productTile(
    txtBoldFont, LineItemData lineItemData, arabicFont) {
  return [
    pw.TableRow(
        verticalAlignment: pw.TableCellVerticalAlignment.top,
        children: [
          pw.Container(
              alignment: pw.Alignment.topLeft,
              padding: pw.EdgeInsets.symmetric(vertical: 4),
              child: pw.Text(
                lineItemData.totalWt,
                style: pw.TextStyle(
                  //
                  fontSize: 8,
                  font: txtBoldFont,
                ),
              )),
          pw.Container(
              alignment: pw.Alignment.topLeft,
              padding: pw.EdgeInsets.symmetric(vertical: 4),
              child: pw.Text(
                '${lineItemData.priceWt}',
                style: pw.TextStyle(
                  font: txtBoldFont,
                  fontSize: 8,
                ),
              )),
          pw.Container(
              alignment: pw.Alignment.topLeft,
              padding: pw.EdgeInsets.symmetric(vertical: 4),
              child: pw.Text(
                lineItemData.qty,
                style: pw.TextStyle(
                  font: txtBoldFont,
                  fontSize: 8,
                ),
              )),
          pw.Container(
              alignment: pw.Alignment.topRight,
              padding: pw.EdgeInsets.symmetric(vertical: 4),
              child: pw.Text(lineItemData.productName,
                  textDirection: !containsExtendedArabic(
                          lineItemData.productName.toString())
                      ? pw.TextDirection.ltr
                      : pw.TextDirection.rtl,
                  style: pw.TextStyle(
                    font: !containsExtendedArabic(
                            lineItemData.productName.toString())
                        ? txtBoldFont
                        : arabicFont,
                    fontSize: 8,
                    //
                  ))),
        ]),
    pw.TableRow(
        verticalAlignment: pw.TableCellVerticalAlignment.top,
        children: [
          pw.Container(
              decoration: const pw.BoxDecoration(
                  border: pw.Border(
                bottom: pw.BorderSide(color: PdfColors.black, width: 1),
              )),
              margin: pw.EdgeInsets.only(left: 5)),
          pw.Container(
            decoration: const pw.BoxDecoration(
                border: pw.Border(
              bottom: pw.BorderSide(color: PdfColors.black),
            )),
          ),
          pw.Container(
            decoration: const pw.BoxDecoration(
                border: pw.Border(
              bottom: pw.BorderSide(color: PdfColors.black),
            )),
            // height: height,
          ),
          pw.Container(
            margin: pw.EdgeInsets.only(right: 5),
            decoration: const pw.BoxDecoration(
                border: pw.Border(
              bottom: pw.BorderSide(color: PdfColors.black),
            )),
          ),
        ])
  ];
}
