import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:bitpro_hive/shared/templates/receipt_templates/templates/e_invoice_generator.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';

List<pw.Widget> receipt80mmNoVatTemplate(
    {required image,
    required EmployeeData userData,
    required PrintingSetttings printingSetttings,
    required StoreData? selectedStoreData,
    required ReceiptOrQuotationData dbReceiptData,
    required englishBoldFont,
    required arabicBoldFont,
    required vatPercentage,
    required taxValue}) {
  return [
    pw.Container(
        width: double.maxFinite,
        child: pw.Column(children: [
          pw.SizedBox(
            height: 15,
          ),
          if (image != null)
            pw.Align(
              alignment: pw.Alignment.center,
              child: pw.Image(image, height: 80),
            ),
          pw.SizedBox(
            height: 5,
          ),
          if (selectedStoreData != null)
            pw.Text(
              selectedStoreData.storeName,
              textDirection: !containsExtendedArabic(
                      selectedStoreData.storeName.toString())
                  ? pw.TextDirection.ltr
                  : pw.TextDirection.rtl,
              style: pw.TextStyle(
                font: !containsExtendedArabic(
                        selectedStoreData.storeName.toString())
                    ? englishBoldFont
                    : arabicBoldFont,
                fontSize: 8,
              ),
            ),
          if (selectedStoreData != null)
            pw.Text(
              selectedStoreData.address,
              textAlign: pw.TextAlign.center,
              textDirection:
                  !containsExtendedArabic(selectedStoreData.address.toString())
                      ? pw.TextDirection.ltr
                      : pw.TextDirection.rtl,
              style: pw.TextStyle(
                font: !containsExtendedArabic(
                        selectedStoreData.address.toString())
                    ? englishBoldFont
                    : arabicBoldFont,
                fontSize: 7,
              ),
            ),
          if (selectedStoreData != null)
            pw.Text(
              selectedStoreData.phone1,
              style: pw.TextStyle(
                fontSize: 7,
                font: englishBoldFont,
              ),
            ),
          pw.SizedBox(
            height: 7,
          ),
          pw.Text(
            printingSetttings.receiptTitleEng,
            style: pw.TextStyle(
              fontSize: 8,
              font: englishBoldFont,
            ),
          ),
          pw.Text(
            printingSetttings.receiptTitleArb,
            textDirection: pw.TextDirection.rtl,
            style: pw.TextStyle(
              fontSize: 7,
              font: arabicBoldFont,
            ),
          ),
          pw.SizedBox(
            height: 7,
          ),
          if (dbReceiptData.receiptBasicInfo!.receiptType != 'Regular')
            pw.Container(
                margin: const pw.EdgeInsets.symmetric(horizontal: 42),
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(), color: PdfColors.black),
                padding:
                    const pw.EdgeInsets.symmetric(vertical: 3, horizontal: 3),
                child: pw.Center(
                  child: pw.Row(children: [
                    pw.Text(
                      'Return Invoice',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(
                        color: PdfColors.white,
                        fontSize: 7,
                        font: englishBoldFont,
                      ),
                    ),
                    pw.SizedBox(width: 3),
                    pw.Text(
                      'فاتورة الاسترجاع',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(
                        color: PdfColors.white,
                        fontSize: 7,
                        font: arabicBoldFont,
                      ),
                    ),
                  ]),
                )),
          pw.SizedBox(
            height: 7,
          ),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceAround,
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                mainAxisAlignment: pw.MainAxisAlignment.start,
                children: [
                  pw.Text(
                    'Receipt #',
                    style: pw.TextStyle(
                      fontSize: 7,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.Text(
                    'Date :',
                    style: pw.TextStyle(
                      fontSize: 7,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.Text(
                    'Cashier :',
                    style: pw.TextStyle(
                      fontSize: 7,
                      font: englishBoldFont,
                    ),
                  ),
                  if (selectedStoreData != null)
                    if (selectedStoreData.vatNumber.isNotEmpty)
                      pw.Text(
                        'VAT No :',
                        style: pw.TextStyle(
                          fontSize: 7,
                          font: englishBoldFont,
                        ),
                      ),
                  // pw.Text(
                  //   'Reference No :',
                  //   style: pw.TextStyle(
                  //     fontSize: 7,
                  //     font: txtBoldFont,
                  //   ),
                  //  ),
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text(
                    dbReceiptData.receiptBasicInfo!.receiptNo.toString(),
                    style: pw.TextStyle(
                      fontSize: 7,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.Text(
                    DateFormat('dd-MM-yyyy hh:mm a')
                        .format(dbReceiptData.createdDate),
                    style: pw.TextStyle(
                      fontSize: 7,
                      font: englishBoldFont,
                    ),
                  ),
                  pw.Text(
                    userData.empBasicInfoData.username,
                    textDirection: !containsExtendedArabic(
                            userData.empBasicInfoData.username.toString())
                        ? pw.TextDirection.ltr
                        : pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      font: !containsExtendedArabic(
                              userData.empBasicInfoData.username.toString())
                          ? englishBoldFont
                          : arabicBoldFont,
                      fontSize: 7,
                    ),
                  ),
                  if (selectedStoreData != null)
                    if (selectedStoreData.vatNumber.isNotEmpty)
                      pw.Text(
                        selectedStoreData.vatNumber,
                        style: pw.TextStyle(
                          fontSize: 7,
                          font: englishBoldFont,
                        ),
                      ),
                  //if (dbReceiptData.referenceNo.isNotEmpty)
                  // pw.Text(
                  //  dbReceiptData.referenceNo,
                  //  style: pw.TextStyle(
                  //     fontSize: 7,
                  //     font: txtBoldFont,
                  //    ),
                  //   ),
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                    '# فاتورة',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 7,
                      font: arabicBoldFont,
                    ),
                  ),
                  pw.Text(
                    'تاريخ',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 7,
                      font: arabicBoldFont,
                    ),
                  ),
                  pw.Text(
                    'كاشير',
                    textDirection: pw.TextDirection.rtl,
                    style: pw.TextStyle(
                      fontSize: 7,
                      font: arabicBoldFont,
                    ),
                  ),
                  if (selectedStoreData != null)
                    if (selectedStoreData.vatNumber.isNotEmpty)
                      pw.Text(
                        'رقم الضريبة',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(
                          fontSize: 7,
                          font: arabicBoldFont,
                        ),
                      ),
                ],
              )
            ],
          ),
          pw.SizedBox(
            height: 5,
          ),
          pw.Align(
              alignment: pw.Alignment.center,
              child: pw.SvgImage(
                  svg: buildBarcode(
                height: 30,
                width: 80,
                Barcode.code128(useCode128B: false, useCode128C: false),
                dbReceiptData.receiptBasicInfo!.receiptNo.toString(),
                filename: 'code-128a',
              )))
        ])),
    pw.Container(
      width: double.maxFinite,
      alignment: pw.Alignment.centerLeft,
      child: pw.Table(
        columnWidths: {
          0: const pw.FlexColumnWidth(5),
          2: const pw.FlexColumnWidth(3),
          3: const pw.FlexColumnWidth(3),
          4: const pw.FlexColumnWidth(5)
        },
        children: [
          pw.TableRow(
              decoration: const pw.BoxDecoration(
                  border: pw.Border(
                bottom: pw.BorderSide(color: PdfColors.black, width: 0.3),
              )),
              children: [
                pw.Container(
                    height: 25,
                    padding: const pw.EdgeInsets.only(left: 10),
                    child: pw.Column(
                      mainAxisAlignment: pw.MainAxisAlignment.center,
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          'باركود',
                          textDirection: pw.TextDirection.rtl,
                          style: pw.TextStyle(
                              fontSize: 7,
                              font: arabicBoldFont,
                              fontWeight: pw.FontWeight.bold),
                        ),
                        pw.Text('Barcode',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))
                      ],
                    )),
                pw.Container(
                    height: 25,
                    child: pw.Column(
                      mainAxisAlignment: pw.MainAxisAlignment.center,
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          'سعر',
                          textDirection: pw.TextDirection.rtl,
                          style: pw.TextStyle(
                              font: arabicBoldFont,
                              fontSize: 7,
                              fontWeight: pw.FontWeight.bold),
                        ),
                        pw.Text('Price',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))
                      ],
                    )),
                pw.Container(
                    height: 25,
                    alignment: pw.Alignment.center,
                    child: pw.Column(
                      mainAxisAlignment: pw.MainAxisAlignment.center,
                      children: [
                        pw.Text(
                          'كمية',
                          textDirection: pw.TextDirection.rtl,
                          style: pw.TextStyle(
                              font: arabicBoldFont,
                              fontSize: 7,
                              fontWeight: pw.FontWeight.bold),
                        ),
                        pw.Text('Qty',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))
                      ],
                    )),
                pw.Container(
                    height: 25,
                    child: pw.Column(
                      mainAxisAlignment: pw.MainAxisAlignment.center,
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          'اجمالي',
                          textDirection: pw.TextDirection.rtl,
                          style: pw.TextStyle(
                              font: arabicBoldFont,
                              fontSize: 7,
                              fontWeight: pw.FontWeight.bold),
                        ),
                        pw.Text('Total',
                            style: pw.TextStyle(
                                fontSize: 8, font: englishBoldFont))
                      ],
                    )),
              ]),
          for (LineItemData lineItemData in dbReceiptData.lineItemsData)
            productTile(englishBoldFont, lineItemData, arabicBoldFont),
        ],
      ),
    ),
    pw.Container(
      padding: const pw.EdgeInsets.symmetric(vertical: 2, horizontal: 10),
      decoration: const pw.BoxDecoration(
          border: pw.Border(
              bottom: pw.BorderSide(color: PdfColors.black, width: 0.3),
              top: pw.BorderSide(color: PdfColors.black, width: 0.3))),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Total Quantity',
                  style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
              pw.SizedBox(
                height: 4,
              ),
              pw.Text('Total Price W/T',
                  style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
              pw.SizedBox(
                height: 4,
              ),
              pw.Text(
                  'Dis (${dbReceiptData.lineItemTotalData.totalDiscountPercentage}%)',
                  style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
              pw.SizedBox(
                height: 4,
              ),
              // pw.Text('Before VAT',
              //     style: pw.TextStyle(fontSize: 7, font: txtBoldFont)),
              // pw.SizedBox(
              //   height: 4,
              // ),
              // pw.Text('VAT (' + vatPersentage + '%)',
              //     style: pw.TextStyle(fontSize: 7, font: txtBoldFont)),
              pw.SizedBox(
                height: 10,
              ),
              pw.Text(
                'Total',
                style: pw.TextStyle(
                    font: englishBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
            ],
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.SizedBox(
                height: -4,
              ),
              pw.Text(dbReceiptData.lineItemTotalData.totalQty,
                  style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
              pw.SizedBox(
                height: 4,
              ),
              pw.Text(dbReceiptData.lineItemTotalData.receiptTotal,
                  style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
              pw.SizedBox(
                height: 4,
              ),
              pw.Text(dbReceiptData.lineItemTotalData.totalDiscountValue,
                  style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
              pw.SizedBox(
                height: 4,
              ),
              pw.SizedBox(
                height: 10,
              ),
              pw.Text(
                dbReceiptData.lineItemTotalData.receiptTotal,
                style: pw.TextStyle(
                    font: englishBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
            ],
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Text(
                'الكمية',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 7,
                    fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(
                height: 4,
              ),
              pw.Text(
                'الاجملي قبل الخصم',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 7,
                    fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(
                height: 4,
              ),
              pw.Text(
                'خصم ',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 7,
                    fontWeight: pw.FontWeight.bold),
              ),
              pw.SizedBox(
                height: 4,
              ),
              // pw.Text(
              //   'اجمالي قبل الضريبة',
              //   textDirection: pw.TextDirection.rtl,
              //   style: pw.TextStyle(
              //       font: arabicNormalFont,
              //       fontSize: 7,
              //       fontWeight: pw.FontWeight.bold),
              // ),
              // pw.SizedBox(
              //   height: 4,
              // ),
              // pw.Text(vatPersentage + '%' +'الضريبة ',
              //   textDirection: pw.TextDirection.rtl,
              //   style: pw.TextStyle(
              //       font: arabicNormalFont,
              //       fontSize: 7,
              //       fontWeight: pw.FontWeight.bold),
              // ),
              pw.SizedBox(
                height: 10,
              ),
              pw.Text(
                'الاجمالي',
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                    font: arabicBoldFont,
                    fontSize: 8,
                    fontWeight: pw.FontWeight.bold),
              ),
            ],
          ),
        ],
      ),
    ),
    pw.Container(
        padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 2),
        decoration: const pw.BoxDecoration(
            border: pw.Border(
                bottom: pw.BorderSide(
                  color: PdfColors.black,
                  width: 0.4,
                ),
                top: pw.BorderSide(color: PdfColors.black, width: 0.4))),
        child: pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('Cash',
                      style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text('Credit Card',
                      style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text('Change',
                      style: pw.TextStyle(fontSize: 7, font: englishBoldFont))
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                      dbReceiptData.receiptBasicInfo!
                                  .allPaymentMethodAmountsInfo[
                              PaymentMethodKey().cash] ??
                          '0',
                      style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text(
                      dbReceiptData.receiptBasicInfo!
                                  .allPaymentMethodAmountsInfo[
                              PaymentMethodKey().creditCard] ??
                          '0',
                      style: pw.TextStyle(fontSize: 7, font: englishBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text(dbReceiptData.receiptBasicInfo!.receiptBalance,
                      style: pw.TextStyle(fontSize: 7, font: englishBoldFont))
                ],
              ),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Text('كاش',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(fontSize: 7, font: arabicBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text('شبكة',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(fontSize: 7, font: arabicBoldFont)),
                  pw.SizedBox(
                    height: 3,
                  ),
                  pw.Text('المتبقي',
                      textDirection: pw.TextDirection.rtl,
                      style: pw.TextStyle(fontSize: 7, font: arabicBoldFont))
                ],
              )
            ])),
    // pw.SizedBox(
    //   height: 2,
    // ),
    // pw.Align(
    //     alignment: pw.Alignment.center,
    //     child: pw.Text(
    //       'شكرا للتسوق معنا',
    //       textDirection: pw.TextDirection.rtl,
    //       style: pw.TextStyle(
    //         fontSize: 7,
    //         font: arabicNormalFont,
    //       ),
    //     )),
    // pw.SizedBox(
    //   height: 1,
    // ),
    // pw.Align(
    //     alignment: pw.Alignment.center,
    //     child: pw.Text('Thank you for shopping with us',
    //         style: pw.TextStyle(fontSize: 7, font: txtBoldFont))),
    // pw.SizedBox(
    //   height: 0,
    // ),
    if (printingSetttings.receiptFotterEng.isNotEmpty)
      pw.Padding(
          padding: const pw.EdgeInsets.symmetric(horizontal: 10),
          child: pw.Text(printingSetttings.receiptFotterEng,
              style: pw.TextStyle(fontSize: 8, font: englishBoldFont))),
    pw.SizedBox(
      height: 1,
    ),
    if (printingSetttings.receiptFotterArb.isNotEmpty)
      pw.Padding(
          padding: const pw.EdgeInsets.symmetric(horizontal: 10),
          child: pw.Align(
              alignment: pw.Alignment.bottomRight,
              child: pw.Text(
                printingSetttings.receiptFotterArb,
                textDirection: pw.TextDirection.rtl,
                style: pw.TextStyle(
                  fontSize: 7,
                  font: arabicBoldFont,
                ),
              ))),
    pw.SizedBox(
      height: 1,
    ),
    pw.Divider(color: PdfColors.black, height: 0.0),
    pw.SizedBox(height: 5),
    pw.Align(
        alignment: pw.Alignment.center,
        child: pw.SvgImage(
            svg: buildBarcode(
                height: 70,
                width: 70,
                Barcode.qrCode(),
                getQrCodeContent(
                  createdDate: dbReceiptData.createdDate,
                  sellerName: selectedStoreData == null
                      ? ''
                      : selectedStoreData.storeName,
                  sellerTRN: selectedStoreData == null
                      ? ''
                      : selectedStoreData.vatNumber,
                  totalWithVat: dbReceiptData.lineItemTotalData.receiptTotal,
                  vatPrice: taxValue,
                ))))
  ];
}

productTile(txtBoldFont, LineItemData lineItemData, arabicFont) {
  double height = 24;

  int nol = (lineItemData.productName.toString().length / 13).ceil();

  if (nol != 1) {
    height += 10 * (nol);
  }

  return pw.TableRow(
      verticalAlignment: pw.TableCellVerticalAlignment.top,
      children: [
        pw.Container(
            decoration: const pw.BoxDecoration(
                border: pw.Border(
              bottom: pw.BorderSide(color: PdfColors.grey),
            )),
            height: height,
            width: 40,
            padding: const pw.EdgeInsets.only(left: 10),
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(
                  height: 2,
                ),
                pw.Text(
                  lineItemData.barcode,
                  style: pw.TextStyle(
                      font: txtBoldFont,
                      fontSize: 7,
                      fontWeight: pw.FontWeight.bold),
                ),
                pw.SizedBox(
                  height: 2,
                ),
                pw.Flexible(
                    child: pw.Text(lineItemData.productName,
                        textDirection: !containsExtendedArabic(
                                lineItemData.productName.toString())
                            ? pw.TextDirection.ltr
                            : pw.TextDirection.rtl,
                        style: pw.TextStyle(
                          font: !containsExtendedArabic(
                                  lineItemData.productName.toString())
                              ? txtBoldFont
                              : arabicFont,
                          fontSize: 7,
                          //
                        )))
              ],
            )),
        pw.Container(
            decoration: const pw.BoxDecoration(
                border: pw.Border(
              bottom: pw.BorderSide(color: PdfColors.grey),
            )),
            height: height,
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(
                  height: 2,
                ),
                pw.Text(
                  '${lineItemData.priceWt}',
                  style: pw.TextStyle(
                      font: txtBoldFont,
                      fontSize: 7,
                      fontWeight: pw.FontWeight.bold),
                ),
              ],
            )),
        pw.Container(
            decoration: const pw.BoxDecoration(
                border: pw.Border(
              bottom: pw.BorderSide(color: PdfColors.grey),
            )),
            height: height,
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              children: [
                pw.SizedBox(
                  height: 2,
                ),
                pw.Text(
                  lineItemData.qty,
                  style: pw.TextStyle(
                      font: txtBoldFont,
                      fontSize: 7,
                      fontWeight: pw.FontWeight.bold),
                ),
              ],
            )),
        pw.Container(
            decoration: const pw.BoxDecoration(
                border: pw.Border(
              bottom: pw.BorderSide(color: PdfColors.grey),
            )),
            height: height,
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.start,
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.SizedBox(
                  height: 2,
                ),
                pw.Text(
                  lineItemData.totalWt,
                  style: pw.TextStyle(
                      //
                      fontSize: 7,
                      font: txtBoldFont,
                      fontWeight: pw.FontWeight.bold),
                ),
              ],
            )),
      ]);
}
