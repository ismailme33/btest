import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:flutter/cupertino.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart';
import 'package:printing/printing.dart';

Future<void> rprintFunction(
    {required BuildContext context,
    required Document doc,
    bool isLandscape = false,
    required Printer? selectedPrinter}) async {
  List<Printer> p = await Printing.listPrinters();

  if (selectedPrinter != null) {
    if (selectedPrinter.name == 'Select Printer While Printing') {
      selectedPrinter = const Printer(
          url: 'Select Printer While Printing',
          name: 'Select Printer While Printing');
    } else {
      for (var t in p) {
        if (t.name == selectedPrinter!.name) {
          selectedPrinter = t;
        }
      }
    }
  }
  if (selectedPrinter == null) {
    showToast(staticTextTranslate('Select a printer from printing settings'),
        context);
    return;
  }

  //printing logic

  if (selectedPrinter.url == 'Select Printer While Printing') {
    if (isLandscape) {
      await Printing.layoutPdf(
          format: PdfPageFormat.a4.landscape,
          onLayout: (PdfPageFormat format) async => doc.save());
    } else {
      var data = await doc.save();
      await Printing.layoutPdf(onLayout: (v) => data);
    }
  } else {
    if (isLandscape) {
      await Printing.directPrintPdf(
          format: PdfPageFormat.a4.landscape,
          printer: selectedPrinter,
          onLayout: (PdfPageFormat format) async => doc.save());
    } else {
      await Printing.directPrintPdf(
          printer: selectedPrinter,
          onLayout: (PdfPageFormat format) async => doc.save());
    }
  }
}
