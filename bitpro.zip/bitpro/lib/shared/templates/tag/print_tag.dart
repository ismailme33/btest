import 'package:barcode_image/barcode_image.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/check_contain_arabic_letters.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/bottom_panel_for_dialog.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:iconsax/iconsax.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/toast.dart';
import '../../global_variables/font_sizes.dart';

class PrintTagData {
  String productName;
  String storeName;
  String itemCode;
  String barcodeValue;
  String priceWt;
  int onHandQty;
  double docQty;
  PrintTagData({
    required this.productName,
    required this.storeName,
    required this.itemCode,
    required this.barcodeValue,
    required this.priceWt,
    required this.onHandQty,
    required this.docQty,
  });
}

void buildTagPrint({
  required List<PrintTagData> allPrintTagDataLst,
  required PrintTagData selectedPrintTagData,
  required BuildContext context,
}) async {
  List<Printer> p = await Printing.listPrinters();
  int printSelectedRecode = 1;
  String copyType = 'normal_copy';
  int copies = 1;
  Printer? selectedPrinter;
  GlobalKey dropdownButtonKey = GlobalKey();
  // ignore: use_build_context_synchronously
  showDialog(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setState2) {
            return Dialog(
              backgroundColor: homeBgColor,
              child: SizedBox(
                  height: 450,
                  width: 600,
                  child: Column(children: [
                    Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          BlackTopPanelForDialogWindow(label: 'Print Tag'),
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 18,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(
                                  height: 15,
                                ),
                                Text(
                                  staticTextTranslate(
                                      'Selected record to print selected items tag. All listed record to print tag of all listed items here'),
                                  style: GoogleFonts.roboto(
                                    fontSize: getMediumFontSize + 1,
                                  ),
                                ),
                                const SizedBox(
                                  height: 17,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Radio(
                                        value: 1,
                                        splashRadius: 15,
                                        activeColor: darkBlueColor,
                                        groupValue: printSelectedRecode,
                                        onChanged: (value) {
                                          printSelectedRecode = value as int;
                                          setState2(() {});
                                          // setState(() {});
                                        }),
                                    Text(
                                      staticTextTranslate('Selected Record'),
                                      style: GoogleFonts.roboto(
                                        fontSize: getMediumFontSize + 1,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 20,
                                    ),
                                    Radio(
                                        value: 2,
                                        groupValue: printSelectedRecode,
                                        splashRadius: 15,
                                        onChanged: (value) {
                                          printSelectedRecode = value as int;
                                          setState2(() {});
                                          // setState(() {});
                                        }),
                                    Text(
                                      staticTextTranslate('All Listed Record'),
                                      style: GoogleFonts.roboto(
                                        fontSize: getMediumFontSize + 1,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  children: [
                                    Container(
                                      height: 37,
                                      padding: const EdgeInsets.only(left: 0),
                                      decoration: BoxDecoration(
                                          borderRadius: const BorderRadius.only(
                                            topLeft: Radius.circular(4),
                                            bottomLeft: Radius.circular(4),
                                          ),
                                          border: Border.all(
                                            width: 0.5,
                                            color: const Color.fromARGB(
                                                255, 43, 43, 43),
                                          )),
                                      child: DropdownButtonHideUnderline(
                                        child: DropdownButton<String>(
                                          key: dropdownButtonKey,
                                          hint: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Text(
                                              staticTextTranslate(
                                                  'Select Printer'),
                                              style: GoogleFonts.roboto(
                                                fontSize: getMediumFontSize + 2,
                                              ),
                                            ),
                                          ),
                                          items: p.map((Printer value) {
                                            return DropdownMenuItem<String>(
                                              value: value.name,
                                              child: Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Text(
                                                  value.name,
                                                  style: GoogleFonts.roboto(
                                                    fontSize:
                                                        getMediumFontSize + 2,
                                                  ),
                                                ),
                                              ),
                                            );
                                          }).toList(),
                                          padding: EdgeInsets.zero,
                                          icon: const SizedBox(),
                                          borderRadius: const BorderRadius.only(
                                              topLeft: Radius.circular(4),
                                              bottomLeft: Radius.circular(4)),
                                          value: selectedPrinter?.name,
                                          onChanged: (value) {
                                            selectedPrinter = p.firstWhere(
                                                (element) =>
                                                    element.name == value);
                                            setState2(() {});
                                          },
                                        ),
                                      ),
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        if (p.isNotEmpty) {
                                          dropdownButtonKey.currentContext
                                              ?.visitChildElements((element) {
                                            if (element.widget is Semantics) {
                                              element.visitChildElements(
                                                  (element) {
                                                if (element.widget is Actions) {
                                                  element.visitChildElements(
                                                      (element) {
                                                    Actions.invoke(element,
                                                        const ActivateIntent());
                                                  });
                                                }
                                              });
                                            }
                                          });
                                        }
                                      },
                                      child: Container(
                                          height: 37,
                                          width: 37,
                                          decoration: const BoxDecoration(
                                            color:
                                                Color.fromARGB(255, 43, 43, 43),
                                            borderRadius: BorderRadius.only(
                                                topRight: Radius.circular(4),
                                                bottomRight:
                                                    Radius.circular(4)),
                                          ),
                                          alignment: Alignment.center,
                                          child: const Icon(
                                              Icons.arrow_drop_down_rounded,
                                              color: Colors.white)),
                                    )
                                  ],
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Row(children: [
                                  Radio(
                                      activeColor: darkBlueColor,
                                      value: "onHandQuantity",
                                      groupValue: copyType,
                                      onChanged: (String? value) {
                                        if (value != null) {
                                          copyType = value;

                                          setState2(() {});
                                        }
                                      }),
                                  Text(staticTextTranslate('On Hand Quantity'),
                                      style: TextStyle(
                                          fontSize: getMediumFontSize)),
                                ]),
                                if (selectedPrintTagData.docQty != -1)
                                  Row(children: [
                                    Radio(
                                        activeColor: darkBlueColor,
                                        value: "doc_quantity",
                                        groupValue: copyType,
                                        onChanged: (String? value) {
                                          if (value != null) {
                                            copyType = value;
                                            setState2(() {});
                                          }
                                        }),
                                    Text(staticTextTranslate(
                                        'Document Quantity')),
                                  ]),
                                Row(children: [
                                  Radio(
                                      activeColor: darkBlueColor,
                                      value: "normal_copy",
                                      groupValue: copyType,
                                      onChanged: (String? value) {
                                        if (value != null) {
                                          copyType = value;

                                          setState2(() {});
                                        }
                                      }),
                                  Text(
                                    staticTextTranslate('Copy'),
                                    style:
                                        TextStyle(fontSize: getMediumFontSize),
                                  ),
                                ]),
                                const SizedBox(
                                  height: 5,
                                ),
                                if (copyType == 'normal_copy')
                                  Row(children: [
                                    const SizedBox(
                                      width: 8,
                                    ),
                                    SizedBox(
                                        width: 80,
                                        child: TextFormField(
                                            scrollPadding:
                                                const EdgeInsets.all(8),
                                            initialValue: copies.toString(),
                                            autovalidateMode: AutovalidateMode
                                                .onUserInteraction,
                                            validator: (value) {
                                              if (int.tryParse(value!) ==
                                                  null) {
                                                return staticTextTranslate(
                                                    'Enter a valid number');
                                              }
                                              return null;
                                            },
                                            style:
                                                const TextStyle(fontSize: 16),
                                            decoration: const InputDecoration(
                                                errorStyle:
                                                    TextStyle(fontSize: 12),
                                                isDense: true,
                                                contentPadding:
                                                    EdgeInsets.all(10),
                                                border: OutlineInputBorder()),
                                            onChanged: (val) {
                                              setState2(() {
                                                copies = int.parse(val);
                                              });
                                              setState2(() {});
                                            })),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Text(
                                      staticTextTranslate('Copies'),
                                      style: GoogleFonts.roboto(
                                        fontSize: getMediumFontSize + 1,
                                      ),
                                    ),
                                  ]),
                              ],
                            ),
                          ),
                        ])),
                    Align(
                        alignment: Alignment.bottomCenter,
                        child: BottomPanelForDialog(buttons: [
                          OnPageGreyButton(
                            label: 'Cancel',
                            onPressed: () {
                              Navigator.pop(context);
                            },
                          ),
                          const SizedBox(width: 10),
                          OnPageButton(
                              label: 'Print',
                              onPressed: () async {
                                if (selectedPrinter != null) {
                                  if (printSelectedRecode == 1) {
                                    await printTag(
                                        selectedPrinter,
                                        copies,
                                        copyType,
                                        [selectedPrintTagData],
                                        context);
                                  } else {
                                    await printTag(selectedPrinter, copies,
                                        copyType, allPrintTagDataLst, context);
                                  }
                                } else {
                                  showToast(
                                      staticTextTranslate('Select a printer'),
                                      context);
                                }
                              },
                              icon: Iconsax.printer5),
                        ]))
                  ])),
            );
          }));
}

Future<void> printTag(Printer? printer, int copies, String copyType,
    List<PrintTagData> printTagDataLst, BuildContext constext) async {
  final doc = pw.Document();
  var box = Hive.box('bitpro_app');

  final arabicNormalFont =
      await fontFromAssetBundle('assets/Segoe.UI_.Semibold.ttf');

  final sarFont = await fontFromAssetBundle('assets/saudi_riyal.ttf');

  double headerFontSize = 10;
  double productIdFontSize = 8;
  double productNameFontSize = 8;
  double priceFontSize = 8;
  double barcodeHeight = 30;
  double barcodeWidth = 50;

  double pageWidth = 2;
  double pageHeight = 1;
  double marginTop = 4;
  double marginBottom = 4;
  double marginLeft = 4;
  double marginRight = 4;
  //

  bool enablePrice = true;
  bool enableProdId = true;
  String customHeader = 'Store Name';
  double spaceAfterProdName = 7;
  double spaceAfterProdId = 16;
  double sizeAfterPrice = 21;
  String priceAnnotation = "\u{E900}";

  Map? inventoryTagSize;

  if (printer == null) {
    inventoryTagSize = await box.get('test_inventory_tag_size');
  } else {
    inventoryTagSize = await box.get('inventory_tag_size');
  }

  if (inventoryTagSize != null) {
    headerFontSize = inventoryTagSize['headerFontSize'];
    productIdFontSize = inventoryTagSize['productIdFontSize'];
    productNameFontSize = inventoryTagSize['productNameFontSize'];
    priceFontSize = inventoryTagSize['priceFontSize'];
    barcodeWidth = inventoryTagSize['barcodeWidth'];
    barcodeHeight = inventoryTagSize['barcodeHeight'];

    // sizedboxHeight = inventoryTagSize['sizedboxHeight'];
    pageWidth = inventoryTagSize['pageWidth'];
    pageHeight = inventoryTagSize['pageHeight'];
    marginTop = inventoryTagSize['marginTop'];
    marginBottom = inventoryTagSize['marginBottom'];
    marginLeft = inventoryTagSize['marginLeft'];
    marginRight = inventoryTagSize['marginRight'];

    enablePrice = inventoryTagSize['enablePrice'];
    enableProdId = inventoryTagSize['enableProdId'];
    customHeader = inventoryTagSize['customHeader'];
    spaceAfterProdId = inventoryTagSize['spaceAfterProdId'];
    spaceAfterProdName = inventoryTagSize['spaceAfterProdName'];
    priceAnnotation = inventoryTagSize['priceAnnotation'];
    sizeAfterPrice = inventoryTagSize['sizeAfterPrice'];
  }

  for (int j = 0; j < printTagDataLst.length; j++) {
    int noOfCopies = 1;
    if (copyType == 'normal_copy') {
      noOfCopies = copies;
    } else if (copyType == 'onHandQuantity') {
      noOfCopies = printTagDataLst.elementAt(j).onHandQty;
    } else if (copyType == 'doc_quantity') {
      noOfCopies = printTagDataLst.elementAt(j).docQty.toInt();
    }
    for (int i = 0; i < noOfCopies; i++) {
      doc.addPage(pw.Page(
          pageFormat: PdfPageFormat(
              pageWidth * PdfPageFormat.inch, pageHeight * PdfPageFormat.inch),
          build: (pw.Context context) {
            return pw.Container(
                width: double.maxFinite,
                height: double.maxFinite,
                decoration: pw.BoxDecoration(
                    border: pw.Border.all(color: PdfColors.black)),
                alignment: pw.Alignment.centerLeft,
                padding: pw.EdgeInsets.fromLTRB(
                    marginLeft, marginTop, marginRight, marginBottom),
                child: pw.Expanded(
                    child: pw.Stack(
                  children: [
                    pw.Row(
                        mainAxisAlignment: pw.MainAxisAlignment.center,
                        children: [
                          pw.Text(customHeader,
                              textDirection:
                                  !containsExtendedArabic(customHeader)
                                      ? pw.TextDirection.ltr
                                      : pw.TextDirection.rtl,
                              style: pw.TextStyle(
                                  fontSize: headerFontSize,
                                  font: !containsExtendedArabic(customHeader)
                                      ? null
                                      : arabicNormalFont,
                                  fontWeight: pw.FontWeight.bold)),
                        ]),
                    pw.Positioned(
                      top: spaceAfterProdName,
                      child: pw.Text(printTagDataLst.elementAt(j).productName,
                          textDirection: !containsExtendedArabic(
                                  printTagDataLst.elementAt(j).productName)
                              ? pw.TextDirection.ltr
                              : pw.TextDirection.rtl,
                          textAlign: pw.TextAlign.right,
                          style: pw.TextStyle(
                              font: !containsExtendedArabic(
                                      printTagDataLst.elementAt(j).productName)
                                  ? null
                                  : arabicNormalFont,
                              fontSize: productNameFontSize,
                              fontWeight: pw.FontWeight.bold)),
                    ),
                    if (enableProdId)
                      pw.Positioned(
                        top: spaceAfterProdId,
                        child: pw.Text(printTagDataLst.elementAt(j).itemCode,
                            style: pw.TextStyle(
                                fontSize: productIdFontSize,
                                fontWeight: pw.FontWeight.bold)),
                      ),
                    if (enablePrice)
                      pw.Positioned(
                          top: sizeAfterPrice,
                          child: pw.Row(children: [
                            pw.Text(
                                printer == null
                                    ? priceAnnotation
                                    : priceAnnotation,
                                textDirection:
                                    !containsExtendedArabic(priceAnnotation)
                                        ? pw.TextDirection.ltr
                                        : pw.TextDirection.rtl,
                                style: pw.TextStyle(
                                    font: sarFont,
                                    fontSize: priceFontSize,
                                    fontWeight: pw.FontWeight.bold)),
                            pw.Text(
                                printer == null
                                    ? '10.00'
                                    : double.tryParse(printTagDataLst
                                                .elementAt(j)
                                                .priceWt) ==
                                            null
                                        ? '0'
                                        : doubleToString(double.parse(
                                            printTagDataLst
                                                .elementAt(j)
                                                .priceWt)),
                                textDirection:
                                    !containsExtendedArabic(priceAnnotation)
                                        ? pw.TextDirection.ltr
                                        : pw.TextDirection.rtl,
                                style: pw.TextStyle(
                                    fontSize: priceFontSize,
                                    fontWeight: pw.FontWeight.bold)),
                          ])),
                    pw.Align(
                        alignment: pw.Alignment.bottomCenter,
                        child: pw.Row(
                            mainAxisAlignment: pw.MainAxisAlignment.center,
                            children: [
                              pw.SvgImage(
                                  svg: buildBarcode(
                                      Barcode.code128(
                                          useCode128B: false,
                                          useCode128C: false),
                                      printTagDataLst.elementAt(j).barcodeValue,
                                      filename: 'code-128a',
                                      fontHeight: priceFontSize,
                                      height: barcodeHeight,
                                      width: barcodeWidth))
                            ]))
                  ],
                )));
          }));
    }
  }

  if (printer != null) {
    var d = await doc.save();

    await Printing.directPrintPdf(
        usePrinterSettings: true,
        printer: printer,
        onLayout: (PdfPageFormat format) => d);
  } else {
    await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => doc.save());
  }
}

String buildBarcode(
  Barcode bc,
  String data, {
  String? filename,
  double? width,
  double? height,
  double? fontHeight,
}) {
  /// Create the Barcode
  final svg = bc.toSvg(
    data,
    width: width ?? 200,
    height: height ?? 80,
    fontHeight: fontHeight,
  );

  return svg;
}
