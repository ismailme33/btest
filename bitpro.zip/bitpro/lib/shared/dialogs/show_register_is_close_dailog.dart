import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

showRegisterClosedDialog(context) {
  showDialog(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setState2) {
            return Dialog(
                backgroundColor: homeBgColor,
                child: Container(
                  height: 160,
                  width: 400,
                  padding: const EdgeInsets.only(
                      top: 25, left: 10, right: 10, bottom: 10),
                  child: Column(children: [
                    Row(
                      children: [
                        const Icon(
                          CupertinoIcons.exclamationmark_circle,
                          color: Color.fromARGB(255, 227, 87, 87),
                          size: 30,
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              staticTextTranslate('Register is Closed'),
                              style: TextStyle(fontSize: getMediumFontSize + 5),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(
                              staticTextTranslate(
                                  'Please open the register to start selling'),
                              style: TextStyle(
                                fontSize: getMediumFontSize - 1,
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                    const Expanded(
                        child: SizedBox(
                      height: 10,
                    )),
                    SizedBox(
                      height: 45,
                      width: 380,
                      child: Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(4),
                            gradient: const LinearGradient(
                                end: Alignment.bottomCenter,
                                colors: [
                                  Color(0xff092F53),
                                  Color(0xff284F70),
                                ],
                                begin: Alignment.topCenter)),
                        height: 42,
                        width: 173,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                shape: RoundedRectangleBorder(
                                    side: const BorderSide(
                                        width: 0.5, color: Colors.grey),
                                    borderRadius: BorderRadius.circular(4))),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.cancel_outlined,
                                    color: Color.fromARGB(255, 233, 233, 233),
                                    size: 19),
                                const SizedBox(
                                  width: 10,
                                ),
                                Text(staticTextTranslate('Close'),
                                    style: TextStyle(
                                        fontSize: getMediumFontSize,
                                        color: Colors.white)),
                              ],
                            )),
                      ),
                    )
                  ]),
                ));
          }));
}
