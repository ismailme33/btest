import 'package:bitpro_hive/model/settings/receipt_details_data.dart';
import 'package:flutter/material.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';

import '../global_variables/font_sizes.dart';

Future showProductPriceEnterDialog(
    {context,
    required String productPriceWt,
    required String productPrice,
    required ReceiptSettingData receiptSettingData}) async {
  String price = productPrice;
  final controller = TextEditingController(text: price);

  String priceWT = productPriceWt;
  final controller2 = TextEditingController(text: priceWT);

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  // var box = Hive.box('bitpro_app');
  int selectedTabIndex = receiptSettingData.priceCanChangeSelectTabIndex;
  if (selectedTabIndex == 0) {
    controller.selection = TextSelection(
      baseOffset: 0,
      extentOffset: price.length,
    );
  } else {
    controller2.selection = TextSelection(
      baseOffset: 0,
      extentOffset: priceWT.length,
    );
  }

  return showDialog(
      context: context,
      builder: (context2) {
        return StatefulBuilder(builder: (context, setState) {
          return Dialog(
            child: SizedBox(
              width: 400,
              height: 250,
              child: Form(
                key: formKey,
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              selectedTabIndex = 0;

                              setState(() {});
                            },
                            child: Container(
                              height: 50,
                              width: double.maxFinite,
                              alignment: Alignment.center,
                              child: Text("Price"),
                              decoration: BoxDecoration(
                                  border: Border(
                                      bottom: BorderSide(
                                          color: selectedTabIndex == 0
                                              ? Colors.blue
                                              : Colors.white))),
                            ),
                          ),
                        ),
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              selectedTabIndex = 1;

                              setState(() {});
                            },
                            child: Container(
                              height: 50,
                              width: double.maxFinite,
                              alignment: Alignment.center,
                              child: Text("Price W/T"),
                              decoration: BoxDecoration(
                                  border: Border(
                                      bottom: BorderSide(
                                          color: selectedTabIndex == 1
                                              ? Colors.blue
                                              : Colors.white))),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Spacer(),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: Text(
                          staticTextTranslate('Please enter a price'),
                          style: TextStyle(fontSize: getMediumFontSize),
                        ),
                      ),
                    ),
                    Spacer(),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: selectedTabIndex == 0
                          ? TextFormField(
                              autofocus: true,
                              // initialValue: price,
                              controller: controller,
                              style: const TextStyle(),
                              onChanged: (val) {
                                price = val;
                                setState(() {});
                              },
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (value) => value == null ||
                                      double.tryParse(value) == null
                                  ? 'Please enter a valid number'
                                  : value.isEmpty
                                      ? 'Please enter the price'
                                      : null,
                              onFieldSubmitted: (val) {
                                Navigator.pop(context2, {
                                  'selectedTabIndex': selectedTabIndex,
                                  'price': price,
                                  'priceWt': priceWT
                                });
                              },
                            )
                          : TextFormField(
                              autofocus: true,
                              // initialValue: priceWT,
                              controller: controller2,
                              style: const TextStyle(),
                              onChanged: (val) {
                                priceWT = val;
                                setState(() {});
                              },
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (value) => value == null ||
                                      double.tryParse(value) == null
                                  ? 'Please enter a valid number'
                                  : value.isEmpty
                                      ? 'Please enter the price'
                                      : null,
                              onFieldSubmitted: (val) {
                                Navigator.pop(context2, {
                                  'selectedTabIndex': selectedTabIndex,
                                  'price': price,
                                  'priceWt': priceWT
                                });
                              },
                            ),
                    ),
                    Spacer(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        SizedBox(
                          height: 42,
                          width: 173,
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  side: const BorderSide(
                                      width: 0.1, color: Colors.grey),
                                  backgroundColor: Colors.grey[100],
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(4))),
                              onPressed: () {
                                Navigator.pop(context2);
                              },
                              child: Text(staticTextTranslate('Cancel'),
                                  style: TextStyle(
                                      fontSize: getMediumFontSize,
                                      color: Colors.black))),
                        ),
                        SizedBox(
                          height: 42,
                          width: 173,
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                side: const BorderSide(
                                    width: 0.1, color: Colors.grey),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                              onPressed: () {
                                if (formKey.currentState!.validate()) {
                                  Navigator.pop(context2, {
                                    'selectedTabIndex': selectedTabIndex,
                                    'price': price,
                                    'priceWt': priceWT
                                  });
                                }
                              },
                              child: Text(
                                staticTextTranslate('Submit'),
                                style: TextStyle(
                                  fontSize: getMediumFontSize,
                                  color: Colors.white,
                                ),
                              )),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
          );
        });
      });
}
