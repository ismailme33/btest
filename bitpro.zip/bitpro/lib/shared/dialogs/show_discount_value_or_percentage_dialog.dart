import 'package:flutter/material.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';

import '../global_variables/font_sizes.dart';

Future showDiscountValueOrPercentageEnterDialog(
    {context,
    required String discountPer,
    required String discountValue,
    required bool viewOnly,
    required bool showOverallDiscountPerTabInReceiptCreate}) async {
  String disVal = discountValue;
  final controller = TextEditingController(text: disVal);

  String disPer = discountPer;
  final controller2 = TextEditingController(text: disPer);

  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  int selectedTabIndex = 0;
  if (showOverallDiscountPerTabInReceiptCreate) {
    selectedTabIndex = 1;
  }

  if (selectedTabIndex == 0) {
    controller.selection = TextSelection(
      baseOffset: 0,
      extentOffset: disVal.length,
    );
  } else {
    controller2.selection = TextSelection(
      baseOffset: 0,
      extentOffset: disPer.length,
    );
  }

  return showDialog(
      context: context,
      builder: (context2) {
        return StatefulBuilder(builder: (context, setState) {
          return Dialog(
            child: SizedBox(
              width: 400,
              height: 250,
              child: Form(
                key: formKey,
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              selectedTabIndex = 0;

                              setState(() {});
                            },
                            child: Container(
                              height: 50,
                              width: double.maxFinite,
                              alignment: Alignment.center,
                              child: Text("Dicount Wt Value"),
                              decoration: BoxDecoration(
                                  border: Border(
                                      bottom: BorderSide(
                                          color: selectedTabIndex == 0
                                              ? Colors.blue
                                              : Colors.white))),
                            ),
                          ),
                        ),
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              selectedTabIndex = 1;

                              setState(() {});
                            },
                            child: Container(
                              height: 50,
                              width: double.maxFinite,
                              alignment: Alignment.center,
                              child: Text("Discount Wt Percentage"),
                              decoration: BoxDecoration(
                                  border: Border(
                                      bottom: BorderSide(
                                          color: selectedTabIndex == 1
                                              ? Colors.blue
                                              : Colors.white))),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Spacer(),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 20),
                        child: Text(
                          staticTextTranslate('Please enter a discount'),
                          style: TextStyle(fontSize: getMediumFontSize),
                        ),
                      ),
                    ),
                    Spacer(),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: selectedTabIndex == 0
                          ? TextFormField(
                              autofocus: true,
                              readOnly: viewOnly,
                              // initialValue: price,
                              controller: controller,
                              style: const TextStyle(),
                              onChanged: (val) {
                                disVal = val;
                                setState(() {});
                              },
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (value) => value == null ||
                                      double.tryParse(value) == null
                                  ? 'Please enter a valid number'
                                  : value.isEmpty
                                      ? 'Please enter the discount value'
                                      : null,
                              onFieldSubmitted: (val) {
                                Navigator.pop(context2, {
                                  'selectedTabIndex': selectedTabIndex,
                                  'disVal': disVal,
                                  'disPer': disPer
                                });
                              },
                            )
                          : TextFormField(
                              readOnly: viewOnly,
                              autofocus: true,
                              // initialValue: priceWT,
                              controller: controller2,
                              style: const TextStyle(),
                              onChanged: (val) {
                                disPer = val;
                                setState(() {});
                              },
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                              validator: (value) => value == null ||
                                      double.tryParse(value) == null ||
                                      double.parse(value).isNegative ||
                                      double.parse(value) > 100
                                  ? 'Please enter a valid number'
                                  : value.isEmpty
                                      ? 'Please enter the discout percentage'
                                      : null,
                              onFieldSubmitted: (val) {
                                Navigator.pop(context2, {
                                  'selectedTabIndex': selectedTabIndex,
                                  'disVal': disVal,
                                  'disPer': disPer
                                });
                              },
                            ),
                    ),
                    Spacer(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        SizedBox(
                          height: 42,
                          width: 173,
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  side: const BorderSide(
                                      width: 0.1, color: Colors.grey),
                                  backgroundColor: Colors.grey[100],
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(4))),
                              onPressed: () {
                                Navigator.pop(context2);
                              },
                              child: Text(staticTextTranslate('Cancel'),
                                  style: TextStyle(
                                      fontSize: getMediumFontSize,
                                      color: Colors.black))),
                        ),
                        SizedBox(
                          height: 42,
                          width: 173,
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                side: const BorderSide(
                                    width: 0.1, color: Colors.grey),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                              onPressed: viewOnly
                                  ? null
                                  : () {
                                      if (formKey.currentState!.validate()) {
                                        Navigator.pop(context2, {
                                          'selectedTabIndex': selectedTabIndex,
                                          'disVal': disVal,
                                          'disPer': disPer
                                        });
                                      }
                                    },
                              child: Text(
                                staticTextTranslate('Submit'),
                                style: TextStyle(
                                  fontSize: getMediumFontSize,
                                  color: Colors.white,
                                ),
                              )),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            ),
          );
        });
      });
}
