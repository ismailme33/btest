import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

Future<dynamic> showDbIsEmptyDialog(context, msg,
    {bool showOkButton = false}) async {
  return await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: const BorderSide(width: 0.2, color: Colors.grey)),
          title: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Icon(
                Iconsax.data,
                size: 20,
                color: Color.fromARGB(255, 143, 42, 35),
              ),
              const SizedBox(
                width: 15,
              ),
              Text(
                staticTextTranslate('Database is empty!'),
                style: TextStyle(fontSize: getMediumFontSize + 5),
              ),
            ],
          ),
          content: Text(staticTextTranslate(msg),
              style: TextStyle(fontSize: getMediumFontSize)),
          actions: [
            if (showOkButton == false)
              SizedBox(
                height: 42,
                width: 173,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        side: const BorderSide(width: 0.1, color: Colors.grey),
                        backgroundColor: Colors.grey[100],
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4))),
                    onPressed: () {
                      Navigator.pop(context, false);
                    },
                    child: Text(staticTextTranslate('No'),
                        style: TextStyle(
                            color: Colors.black, fontSize: getMediumFontSize))),
              ),
            if (showOkButton == false)
              SizedBox(
                height: 42,
                width: 173,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      side: const BorderSide(width: 0.1, color: Colors.grey),
                      // backgroundColor: Colors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    onPressed: () {
                      Navigator.pop(context, true);
                    },
                    child: Text(
                      staticTextTranslate('Yes'),
                      style: TextStyle(
                          color: Colors.white, fontSize: getMediumFontSize),
                    )),
              ),
            if (showOkButton)
              SizedBox(
                height: 42,
                width: 173,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      side: const BorderSide(width: 0.1, color: Colors.grey),
                      // backgroundColor: Colors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text(
                      staticTextTranslate('Ok'),
                      style: TextStyle(
                          color: Colors.white, fontSize: getMediumFontSize),
                    )),
              ),
          ],
        );
      });
}
