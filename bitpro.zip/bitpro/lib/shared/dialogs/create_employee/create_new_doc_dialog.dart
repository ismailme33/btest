// import 'dart:io';

// import 'package:bitpro_hive/model/employee_data.dart';
// import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
// import 'package:bitpro_hive/shared/toast.dart';
// import 'package:bitpro_hive/widget/bTextField.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/material.dart';
// import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:hive/hive.dart';
// import 'package:intl/intl.dart';

// Future<EmpDocumentData?> showCreateDocumentDialog({
//   context,
// }) async {
//   String documentName = '';
//   String documentNumber = '';
//   String documentIssueDate = '';
//   String documentExpiryDate = '';
//   File? documentFile;

//   // var box = Hive.box('bitpro_app');
//   // int selectedTabIndex = await box.get('priceCanChangeSelectTabIndex') ?? 0;

//   TextEditingController docIssueDateController =
//       TextEditingController(text: 'Select Date');
//   TextEditingController docExpiryDateController =
//       TextEditingController(text: 'Select Date');
//   return await showDialog(
//       context: context,
//       builder: (context2) {
//         return StatefulBuilder(builder: (context, setState) {
//           return Dialog(
//             child: SizedBox(
//               width: 440,
//               height: 380,
//               child: Padding(
//                 padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                 child: Column(
//                   children: [
//                     Container(
//                       height: 50,
//                       width: double.maxFinite,
//                       alignment: Alignment.center,
//                       child: Text("Create Document"),
//                     ),
//                     BTextField(
//                       textFieldReadOnly: false,
//                       label: 'Document Name',
//                       // initialValue: userName,
//                       // validator: ((value) {}),
//                       onChanged: (val) => setState(() {
//                         documentName = val;
//                       }),
//                       autovalidateMode: AutovalidateMode.onUserInteraction,
//                     ),
//                     SizedBox(
//                       height: 10,
//                     ),
//                     BTextField(
//                       textFieldReadOnly: false,
//                       label: 'Document Number',
//                       // initialValue: userName,
//                       // validator: ((value) {}),
//                       onChanged: (val) => setState(() {
//                         documentNumber = val;
//                       }),
//                       autovalidateMode: AutovalidateMode.onUserInteraction,
//                     ),
//                     SizedBox(
//                       height: 10,
//                     ),
//                     BTextField(
//                       textFieldReadOnly: true,
//                       controller: docIssueDateController,
//                       label: 'Document Issue Date',
//                       onTap: () async {
//                         DateTime? dateTime = await showDatePicker(
//                           context: context,
//                           currentDate: DateTime.tryParse(documentIssueDate),
//                           firstDate: DateTime(2000),
//                           lastDate: DateTime(3000),
//                         );
//                         if (dateTime != null) {
//                           documentIssueDate = dateTime.toString();
//                           docIssueDateController.text =
//                               DateFormat('MMM d, yyyy').format(dateTime);
//                           setState(() {});
//                         }
//                       },
//                       onChanged: (v) {},
//                       autovalidateMode: AutovalidateMode.onUserInteraction,
//                     ),
//                     SizedBox(
//                       height: 10,
//                     ),
//                     BTextField(
//                       textFieldReadOnly: true,
//                       controller: docExpiryDateController,
//                       label: 'Document Expiry Date',
//                       onTap: () async {
//                         DateTime? dateTime = await showDatePicker(
//                           context: context,
//                           currentDate: DateTime.tryParse(documentExpiryDate),
//                           firstDate: DateTime(2000),
//                           lastDate: DateTime(3000),
//                         );
//                         if (dateTime != null) {
//                           documentExpiryDate = dateTime.toString();
//                           docExpiryDateController.text =
//                               DateFormat('MMM d, yyyy').format(dateTime);
//                           setState(() {});
//                         }
//                       },
//                       onChanged: (v) {},
//                       autovalidateMode: AutovalidateMode.onUserInteraction,
//                     ),
//                     SizedBox(
//                       height: 10,
//                     ),
//                     Row(
//                       children: [
//                         Text(
//                           'Document File',
//                           style: GoogleFonts.roboto(
//                             fontSize: 16,
//                           ),
//                         ),
//                         Spacer(),
//                         SizedBox(
//                           height: 80,
//                           width: 80,
//                           child: documentFile != null
//                               ? Image.file(
//                                   documentFile!,
//                                   width: 200,
//                                   height: 50,
//                                 )
//                               : null,
//                         ),
//                         SizedBox(
//                           width: 10,
//                         ),
//                         // documentFile
//                         OutlinedButton.icon(
//                             icon: const Icon(Icons.upload),
//                             style: ElevatedButton.styleFrom(
//                                 backgroundColor: Colors.transparent,
//                                 shape: RoundedRectangleBorder(
//                                     borderRadius: BorderRadius.circular(4))),
//                             onPressed: () async {
//                               FilePickerResult? result =
//                                   await FilePicker.platform.pickFiles(
//                                       allowMultiple: false,
//                                       dialogTitle:
//                                           staticTextTranslate('Header Image'),
//                                       type: FileType.image);

//                               if (result != null &&
//                                   result.files.first.path != null) {
//                                 // var box = Hive.box('bitpro_app');
//                                 // await box.put(
//                                 //     'header_img_path', result.files.first.path);
//                                 // headerImgPath = result.files.first.path!;
//                                 documentFile = File(result.files.first.path!);
//                                 setState(() {});
//                               }
//                             },
//                             label: Text(staticTextTranslate('Choose Image'),
//                                 style: GoogleFonts.roboto(fontSize: 14))),
//                       ],
//                     ),
//                     Spacer(),
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       children: [
//                         SizedBox(
//                           height: 42,
//                           width: 173,
//                           child: ElevatedButton(
//                               style: ElevatedButton.styleFrom(
//                                   side: const BorderSide(
//                                       width: 0.1, color: Colors.grey),
//                                   backgroundColor: Colors.grey[100],
//                                   shape: RoundedRectangleBorder(
//                                       borderRadius: BorderRadius.circular(4))),
//                               onPressed: () {
//                                 Navigator.pop(context2);
//                               },
//                               child: Text(staticTextTranslate('Cancel'),
//                                   style: TextStyle(
//                                       fontSize: getMediumFontSize,
//                                       color: Colors.black))),
//                         ),
//                         SizedBox(
//                           height: 42,
//                           width: 173,
//                           child: ElevatedButton(
//                               style: ElevatedButton.styleFrom(
//                                 side: const BorderSide(
//                                     width: 0.1, color: Colors.grey),
//                                 shape: RoundedRectangleBorder(
//                                   borderRadius: BorderRadius.circular(4),
//                                 ),
//                               ),
//                               onPressed: () {
//                                 if (documentName.isNotEmpty &&
//                                     documentNumber.isNotEmpty &&
//                                     documentIssueDate.isNotEmpty &&
//                                     documentExpiryDate.isNotEmpty &&
//                                     documentFile != null) {
//                                   Navigator.pop(
//                                       context,
//                                       EmpDocumentData(
//                                           documentName: documentName,
//                                           documentNumber: documentNumber,
//                                           documentIssueDate: documentIssueDate,
//                                           documentExpiryDate:
//                                               documentExpiryDate,
//                                           documentFilePath:
//                                               documentFile!.path));
//                                 } else {
//                                   showToast('Please fill the form', context);
//                                 }
//                               },
//                               child: Text(
//                                 staticTextTranslate('Submit'),
//                                 style: TextStyle(
//                                   fontSize: getMediumFontSize,
//                                   color: Colors.white,
//                                 ),
//                               )),
//                         ),
//                       ],
//                     ),
//                     Spacer(),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         });
//       });
//   // return EmpDocumentData(
//   //     documentName: documentName,
//   //     documentNumber: documentNumber,
//   //     documentIssueDate: DateTime.parse(documentIssueDate),
//   //     documentExpiryDate: DateTime.parse(documentExpiryDate),
//   //     documentFile: documentFile!);
// }
