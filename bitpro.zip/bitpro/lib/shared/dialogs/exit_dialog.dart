import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitsdojo_window/bitsdojo_window.dart';
import 'package:flutter/material.dart';

exitDialog(context) {
  showDialog(
      context: context,
      builder: (context) => AlertDialog(
            elevation: 5,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: const BorderSide(width: 0.2, color: Colors.grey)),
            title: Text(
              staticTextTranslate('Exit'),
              style: TextStyle(fontSize: getMediumFontSize + 5),
            ),
            content: Text(
              staticTextTranslate('Do you really want to exit?'),
              style: TextStyle(fontSize: getMediumFontSize - 1),
            ),
            actions: [
              SizedBox(
                height: 42,
                width: 173,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        side: const BorderSide(width: 0.1, color: Colors.grey),
                        backgroundColor: Colors.grey[100],
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4))),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text(staticTextTranslate('Cancel'),
                        style: TextStyle(
                            fontSize: getMediumFontSize, color: Colors.black))),
              ),
              SizedBox(
                height: 42,
                width: 173,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      side: const BorderSide(width: 0.1, color: Colors.grey),
                      backgroundColor: Colors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    onPressed: () {
                      appWindow.close();
                    },
                    child: Text(
                      staticTextTranslate('Exit'),
                      style: TextStyle(
                          color: Colors.white, fontSize: getMediumFontSize),
                    )),
              ),
            ],
          ));
}
