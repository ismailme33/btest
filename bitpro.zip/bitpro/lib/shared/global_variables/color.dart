import 'package:flutter/material.dart';

Color loginBgColor = const Color(0xffe2e2e2);
Color homeBgColor = const Color(0xfff7f8f9);
Color activeBtnColor = const Color(0xffe9eaf3);
Color darkBlueColor = const Color(0xff2a77b5);
Color getBitproLogoColor = const Color.fromARGB(255, 6, 91, 160);
