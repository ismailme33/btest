import 'dart:io';

import 'package:path_provider/path_provider.dart';

Future<String> uploadImageInSystem(
    {required File file, required String fileName}) async {
  var p =
      await getApplicationSupportDirectory(); // C:\Users\team\AppData\Roaming\com.example\bitpro_hive

  File imgDirectory =
      File('${p.path}/images/merchandise_inventory/$fileName.png');

  try {
    await imgDirectory.create(recursive: true);
  } catch (e) {}

  await file.copy(imgDirectory.path);

  return imgDirectory.path;
}
