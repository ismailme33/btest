import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class SaveImageFileService {
  Future<File?> saveImageFile(File orgFile) async {
    try {
      final Directory documentsDirectory =
          await getApplicationDocumentsDirectory();
      final customPath = Directory('${documentsDirectory.path}/Images');

      if (!await customPath.exists()) {
        await customPath.create(recursive: true);
      }

      // Get the original file name
      final String fileName = p.basename(orgFile.path);

      // Create the new file path
      final String newPath = p.join(customPath.path, fileName);

      // Copy the file to the new path
      final File newFile = await orgFile.copy(newPath);

      return newFile;
    } catch (e) {
      print('Error saving file: $e');
      return null;
    }
  }
}
