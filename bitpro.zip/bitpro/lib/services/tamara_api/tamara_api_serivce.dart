// import 'dart:convert';

// import 'package:bitpro_hive/model/receipt/db_receipt_data.dart';
// import 'package:bitpro_hive/model/receipt/local_receipt_data.dart';
// import 'package:http/http.dart' as http;
// import 'package:uuid/uuid.dart';

// class TamaraApiService {
//   final sandboxBaseUrl = 'https://api-sandbox.tamara.co';
//   final productionBaseUrl = 'https://api.tamara.co';
//   final currency = 'AED';
//   var uuid = Uuid();

//   Future<Map<String, dynamic>?> tamaraCheckout(
//       {required ReceiptOrQuotationData dbReceiptData,
//       required String phoneNumber,
//       required String? email}) async {
//     Uri url = Uri.dataFromString('$sandboxBaseUrl/checkout/in-store-session');
//     String barrierToken = '';

//     var payloadBody = jsonEncode({
//       "total_amount": {
//         "amount": double.parse(dbReceiptData.receiptTotal),
//         "currency": currency
//       },
//       "phone_number": phoneNumber,
//       "email": email,
//       "order_reference_id": uuid.v4(),
//       "order_number": null, //"A1231234123",
//       "items": [
//         for (LocalReceiptData i in dbReceiptData.selectedItems)
//           {
//             "name": i.productName,
//             "type": "Consumer Products",
//             "reference_id": i.barcode,
//             "sku": i.itemCode,
//             "quantity": int.parse(i.qty),
//             "discount_amount": {
//               "amount": double.parse(i.discountValue),
//               "currency": currency
//             },
//             "tax_amount": {
//               "amount": double.parse(i.priceWt),
//               "currency": currency
//             },
//             "unit_price": {
//               "amount": double.parse(i.orgPrice),
//               "currency": currency
//             },
//             "total_amount": {
//               "amount": double.parse(i.total),
//               "currency": currency
//             }
//           }
//       ],
//       "locale": "ar_SA",
//       "payment_type": "PAY_NOW",
//       // "additional_data": {"store_code": "Branch A"}
//     });

//     var res = await http.post(url, body: payloadBody, headers: {
//       'Content-Type': 'application/json',
//       'Accept': 'application/json',
//       'Authorization': 'Bearer $barrierToken'
//     });

//     var body = jsonDecode(res.body);
//     // print(body);
//     if (res.statusCode == 200) {
//       //success
//       return body;
//     } else {
//       //error
//     }
//     return null;
//   }

//   checkOrderStatus(String orderId) async {
//     Uri url = Uri.dataFromString('$sandboxBaseUrl/orders/$orderId');
//     // String barrierToken = '';

//     var res = await http.get(url);

//     // var body = jsonDecode(res.body);
//     // print(body);

//     if (res.statusCode == 200) {
//       //success
//     } else {
//       //error
//     }
//   }
// }
