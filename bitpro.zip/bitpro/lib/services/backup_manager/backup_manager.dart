import 'dart:io';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';
// import 'package:permission_handler/permission_handler.dart';
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:path/path.dart' as p;

class BackupManager {
  static const String _backupBoxKey = 'backup_settings';
  static const String _lastBackupKey = 'last_backup';
  static const String _backupPathKey = 'backup_path';
  static const int _maxBackups = 15;

  // Initialize backup system
  Future<void> init() async {
    // if (Platform.isWindows) {
    //   await _requestStoragePermission();
    // }
    await _checkAndPerformBackup();
  }

  // Request storage permission
  // Future<bool> _requestStoragePermission() async {
  //   var status = await Permission.storage.status;
  //   if (!status.isGranted) {
  //     status = await Permission.storage.request();
  //   }
  //   return status.isGranted;
  // }

  // Check and perform backup if needed
  Future<void> _checkAndPerformBackup() async {
    final box = await Hive.openBox(_backupBoxKey);
    final lastBackup = box.get(_lastBackupKey) as DateTime?;
    final now = DateTime.now();
    print('yo1 $lastBackup');
    if (lastBackup == null ||
        !lastBackup.isSameDate(now) && now.isAfter(lastBackup)) {
      print('yo2');
      await _createBackup();
      await box.put(_lastBackupKey, now);
    }
  }

  // Create backup file
  Future<void> _createBackup() async {
    try {
      final directory = await _getBackupDirectory();
      final backupName = DateFormat('ddMMyyyyHHmmss').format(DateTime.now());
      final backupFile = File('${directory.path}/$backupName.hive');

      // Copy current Hive data to backup
      final Directory documentsDirectory =
          await getApplicationDocumentsDirectory();
      final customPath = Directory('${documentsDirectory.path}/BitproDatabase');
      File hiveFile = File('${customPath.path}/bitpro_app.hive');
      if (await hiveFile.exists()) {
        await hiveFile.copy(backupFile.path);
      }
      // Manage backup count
      await _manageBackupFiles(directory);
      print('yo3');
      print("backup is done ");
    } catch (e) {
      print('Backup error: $e');
    }
  }

  // Manage backup files (keep only latest 15)
  Future<void> _manageBackupFiles(Directory directory) async {
    final files = directory
        .listSync()
        .where((file) => file.path.endsWith('.hive'))
        .toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));

    if (files.length > _maxBackups) {
      for (var i = _maxBackups; i < files.length; i++) {
        await File(files[i].path).delete();
      }
    }
  }

  // Get backup directory
  Future<Directory> _getBackupDirectory() async {
    final box = await Hive.openBox(_backupBoxKey);
    String? path = box.get(_backupPathKey);

    if (path == null) {
      final documentsDirectory = await getApplicationDocumentsDirectory();
      path = '${documentsDirectory.path}/BitproDatabase';
      final customPath = Directory(path);
      if (!await customPath.exists()) {
        await customPath.create(recursive: true);
      }
      await box.put(_backupPathKey, path);
    }

    return Directory(path);
  }

  // Change backup directory
  Future<void> changeBackupDirectory() async {
    final result = await FilePicker.platform.getDirectoryPath();
    if (result != null) {
      final box = await Hive.openBox(_backupBoxKey);
      await box.put(_backupPathKey, result);
    }
  }

  // Get current backup path
  Future<String> getCurrentBackupPath() async {
    final box = await Hive.openBox(_backupBoxKey);
    return box.get(_backupPathKey) ??
        (await getApplicationDocumentsDirectory()).path + '/BitproDatabase';
  }

  // Open current backup folder
  Future<void> openBackupFolder() async {
    final directory = await _getBackupDirectory();
    if (await directory.exists()) {
      launchUrl(directory.uri);
    } else {
      print('Backup directory does not exist: ${directory.path}');
    }
  }

  Future<void> saveHiveBackupToTheDirPath(
      {required String selectedDirectory,
      required BuildContext context}) async {
    final Directory documentsDirectory =
        await getApplicationDocumentsDirectory();
    final customPath = Directory('${documentsDirectory.path}/BitproDatabase');

    if (!await customPath.exists()) {
      await customPath.create(recursive: true);
    } // C:\Users\team\AppData\Roaming\com.example\bitpro_hive
    //saving hive file
    File hiveFile = File('$selectedDirectory/Bitpro Backup/bitpro_app.hive');

    try {
      await hiveFile.create(recursive: true);
    } catch (e) {}
    File file = File('${customPath.path}/bitpro_app.hive');

    await file.copy(hiveFile.path);
    //saving image

    await copyFolder(
        '${customPath.path}/images', '$selectedDirectory/Bitpro Backup/images');

    showToast(staticTextTranslate("Saved"), context);
  }

  Future<void> copyFolder(String from, String to) async {
    if (Directory(from).existsSync()) {
      try {
        await Directory(to).create(recursive: true);
      } catch (e) {}

      await for (final file in Directory(from).list(recursive: true)) {
        final copyTo = p.join(to, p.relative(file.path, from: from));
        if (file is Directory) {
          try {
            await Directory(copyTo).create(recursive: true);
          } catch (e) {}
        } else if (file is File) {
          await File(file.path).copy(copyTo);
        } else if (file is Link) {
          await Link(copyTo).create(await file.target(), recursive: true);
        }
      }
    }
  }
}

// Extension to check if dates are same
extension DateTimeExtension on DateTime {
  bool isSameDate(DateTime other) {
    return year == other.year && month == other.month && day == other.day;
  }
}
