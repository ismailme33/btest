import 'dart:math';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/widget/string_related/get_employee_data.dart';
import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/user_group_data.dart';
import 'package:bitpro_hive/services/hive/hive_user_group_db_service.dart';

class HiveUserDbService {
  addEditUser(EmployeeData employeeData, {bool updateWatingList = true}) async {
    var box = Hive.box('bitpro_app');
    Map users = box.get('Users') ?? {};

    users[employeeData.docId] = employeeData.toMap();

    await box.put('Users', users);

    if (updateWatingList) {
      //adding docId in fb waiting list
      List userDataFbWaitingLst = await box.get('userDataFbWaitingLst') ?? [];
      userDataFbWaitingLst.add(employeeData.docId);

      await box.put('userDataFbWaitingLst', userDataFbWaitingLst);
    }
    //if it's loggedin user data
    Map? ud = box.get('user_data');
    if (ud != null) {
      EmployeeData loggedInUser = EmployeeData.fromMap(ud);
      if (loggedInUser.docId == employeeData.docId) {
        await box.put('user_data', employeeData.toMap());
      }
    }
  }

  Future<EmployeeData?> login(String username, String password) async {
    var box = Hive.box('bitpro_app');

    //login for other users
    Map users = box.get('Users') ?? {};
    List<EmployeeData> userDataLst =
        users.values.map((e) => EmployeeData.fromMap(e)).toList();
    int i = userDataLst.indexWhere((element) =>
        element.empBasicInfoData.username == username &&
        element.empBasicInfoData.password == password);
    if (i != -1) {
      await box.put('user_data', userDataLst.elementAt(i).toMap());
      return userDataLst.elementAt(i);
    }

    //if user is admin
    if (users.isEmpty && username == 'admin' && password == 'admin') {
      Map? ud = box.get('user_data');
      if (ud == null) {
        String docId = getRandomString(20);
        EmployeeData ud = getAdminEmployeeData(docId);

        await box.put('user_data', ud.toMap());
        Map users = box.get('Users') ?? {};

        users[docId] = ud.toMap();
        await box.put('Users', users);

        // creating first group
        await HiveUserGroupDbService().addEditUserGroup(UserGroupData(
            dashboard: true,
            backupReset: true,
            adjustment: true,
            createdBy: 'system',
            createdDate: DateTime.now(),
            customers: true,
            departments: true,
            description: 'full access',
            docId: docId,
            employees: true,
            formerZout: true,
            groups: true,
            inventory: true,
            name: 'Admin',
            purchaseVoucher: true,
            receipt: true,
            registers: true,
            reports: true,
            salesReceipt: true,
            settings: true,
            vendors: true,
            promotion: true));

        //creating first store
        String storeDocId = getRandomString(20);
        await HiveStoreDbService().addEditStoreData(StoreData(
          docId: storeDocId,
          storeCode: '1',
          storeName: 'Store 1',
          note: '',
          address: '',
          phone1: '',
          phone2: '',
          vatNumber: '',
          logoPath: '',
          bankName: '',
          email: '',
          accountNumber: '',
          priceLevel: '',
          crNumber: '',
          isEnabled: true,
          storeDocumentData: [],
          subName: '',
          additionalNumber: '',
          area: '',
          buildingNumber: '',
          city: '',
          country: '',
          postCode: '',
          shortAddress: '',
          storeArabicName: '',
          street: '',
        ));

        await box.put('user_settings_data', {
          'companyName': '',
          'selectedStoreCode': 1,
          'workstationNumber': 1
        });

        return ud;
      } else {
        return EmployeeData.fromMap(ud);
      }
    }
    return null;
  }

  Future<List<EmployeeData>> fetchAllUserData() async {
    var box = Hive.box('bitpro_app');
    Map? users = box.get('Users');
    if (users == null) return [];
    return users.keys.map((k) {
      var ud = users[k];

      return EmployeeData.fromMap(ud);
    }).toList();
  }

  logoutUser(String username) async {
    Box box = Hive.box('bitpro_app');
    await box.put('is_user_logged_in', false);
    await box.put('last_user_username', username);
    await box.delete('user_data');
  }
}

const _chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
Random _rnd = Random();

String getRandomString(int length) => String.fromCharCodes(Iterable.generate(
    length, (_) => _chars.codeUnitAt(_rnd.nextInt(_chars.length))));
