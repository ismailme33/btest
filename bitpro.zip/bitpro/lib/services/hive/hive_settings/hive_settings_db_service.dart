import 'dart:convert';
import 'dart:io';
import 'package:bitpro_hive/model/settings/company_details_settings.dart';
import 'package:bitpro_hive/model/settings/default_settings_data.dart';
import 'package:bitpro_hive/model/settings/license_setting_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/settings/receipt_details_data.dart';
import 'package:bitpro_hive/model/settings/smpt_server_settings.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:bitpro_hive/wrapper.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:device_info_plus/device_info_plus.dart';

class HiveSettingsDbService {
  //company settings
  Future<void> addUpdateCompanySettingsData(
      {required CompanyDetailsSettings companyDetailsSettings}) async {
    var box = Hive.box('bitpro_app');

    await box.put('user_settings_data', companyDetailsSettings.toMap());
  }

  Future<CompanyDetailsSettings> getCompanySettingsData() async {
    var box = Hive.box('bitpro_app');
    var res = await box.get('user_settings_data');
    if (res != null) {
      return CompanyDetailsSettings.fromMap(res);
    } else {
      return CompanyDetailsSettings(
          companyName: '', selectedStoreCode: null, workstationNumber: null);
    }
  }

  //printing settings
  Future<void> addUpdatePrintingSmtpSettings(
      {required PrintingSetttings printingSetttings,
      required SmptServerSettings smptServerSettings}) async {
    var box = Hive.box('bitpro_app');

    await box.put('user_printing_settings', printingSetttings.toMap());
    await box.put('user_smtp_server_settings', smptServerSettings.toMap());
  }

  Future<PrintingSetttings> getPrintingSettingsData() async {
    var box = Hive.box('bitpro_app');

    var printingSettings = await box.get('user_printing_settings');
    if (printingSettings != null) {
      List<Printer> allPrinterLst = await Printing.listPrinters();
      return PrintingSetttings.fromMap(printingSettings,
          allPrinterLst: allPrinterLst);
    } else {
      return PrintingSetttings(
          selectedReceiptTemplate: '80 mm',
          selectedQuotationTemplate: 'DES0003-A4',
          receiptTitleEng: '',
          receiptTitleArb: '',
          receiptFotterEng: '',
          receiptFotterArb: '',
          headerImgPath: '',
          fotterImgPath: '');
    }
  }

  Future<String> uploadImage({required File file}) async {
    //Add Device Image Url
    var p =
        await getApplicationSupportDirectory(); // C:\Users\team\AppData\Roaming\com.example\bitpro_hive

    File imgDirectory = File('${p.path}/images/settings/companyLogo.png');

    try {
      await imgDirectory.create(recursive: true);
    } catch (e) {}

    await file.copy(imgDirectory.path);

    return imgDirectory.path;
  }

  //smtp server
  Future<SmptServerSettings> getSmtpServerSettingsData() async {
    var box = Hive.box('bitpro_app');

    var smtpServerSettings = await box.get('user_smtp_server_settings');
    if (smtpServerSettings != null) {
      return SmptServerSettings.fromMap(smtpServerSettings);
    } else {
      return SmptServerSettings(
          server: '',
          username: '',
          password: '',
          port: '',
          isSSLEnabled: false,
          senderEmailName: '',
          enableSaveAndSendEmailButton: false,
          sendToEmailWhilePrintAndUpdate: false);
    }
  }

  //tax percentage
  Future<void> addUpdateTab3SettingsData({
    required TaxSettingsData taxSettingsData,
  }) async {
    var box = Hive.box('bitpro_app');

    await box.put('user_taxes_settings', taxSettingsData.toMap());

    //adding docId in fb waiting list
    await box.put('settingFbNeedToUpdate', true);
  }

  Future<TaxSettingsData> getTaxSettingsData() async {
    var box = Hive.box('bitpro_app');

    var res = await box.get('user_taxes_settings');
    if (res != null) {
      return TaxSettingsData.fromMap(res);
    } else {
      return TaxSettingsData(taxPercentage: double.parse(defaultTaxPercentge));
    }
  }

  //License settting
  Future<void> addUpdateLicenseSettingsData({
    required LicenseSettingData licenseSettingData,
  }) async {
    var box = Hive.box('bitpro_app');

    await box.put('license_data', licenseSettingData.toMap());
  }

  Future<LicenseSettingData?> getLicesnseSettingsData(
      {bool resetIfLicenseIsNull = false,
      required BuildContext context}) async {
    if (Platform.isWindows == false) {
      return LicenseSettingData(
          key: 'test_key_macos',
          auth: 'test_auth_for_macos',
          expiry_date: DateTime.now().add(const Duration(days: 20)),
          showLicenseAuthError: false,
          windownsProductId: '12345',
          showLicenseKeyError: false);
    }

    var box = Hive.box('bitpro_app');

    var res = await box.get('license_data');
    if (res != null) {
      return LicenseSettingData.fromMap(res);
    } else {
      if (resetIfLicenseIsNull) {
        Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (BuildContext context) => Wrapper()),
            (Route<dynamic> route) => false);
      }
      return null;
    }
  }

  /// null = empty string, -1 = key invalid, -2 = auth invalid, -3 = key & auth invalid
  Future<int?> checkLicenseKeyAuthIsValid(
      {required String key, required String auth}) async {
    if (key.isEmpty || auth.isEmpty) {
      return null;
    }

    Codec<String, String> stringToBase64 = utf8.fuse(base64);

    int? noOfDays;

    bool showLicenseKeyError = false;
    bool showLicenseAuthError = false;

    //key
    try {
      DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
      WindowsDeviceInfo win = await deviceInfo.windowsInfo;

      String keysDecoded = stringToBase64.decode(key); //MzY1

      if (win.productId != keysDecoded) {
        showLicenseKeyError = true;
      }
    } catch (e) {
      showLicenseKeyError = true;
    }

    //auth
    try {
      String decoded = stringToBase64.decode(auth);

      noOfDays = int.tryParse(decoded);

      if (noOfDays == null) {
        showLicenseAuthError = true;
      }
    } catch (e) {
      showLicenseAuthError = true;
    }

    if (showLicenseAuthError && showLicenseKeyError) {
      return -3;
    } else if (showLicenseAuthError) {
      return -2;
    } else if (showLicenseKeyError) {
      return -1;
    }
    return noOfDays;
  }

  //receipt settting
  Future<void> addUpdateReceiptSettingsData({
    required ReceiptSettingData receiptSettingData,
  }) async {
    var box = Hive.box('bitpro_app');

    await box.put('receipt_setting_data', receiptSettingData.toMap());
  }

  Future<ReceiptSettingData> getReceiptSettingsData() async {
    var box = Hive.box('bitpro_app');

    var res = await box.get('receipt_setting_data');
    if (res == null) {
      return ReceiptSettingData(
          paymentTypeList: {
            for (var k in PaymentMethodKey().getAllPaymentMethodLst()) k: 1
          },
          inTenderUseAdvancePayment: false,
          priceCanChangeSelectTabIndex: 0,
          isVendorMandatory: true,
          isDepartmentMandatory: true,
          showCustomCrateDate: false);
    } else {
      return ReceiptSettingData.fromMap(res);
    }
  }

  //general setting
  Future<void> addUpdateGenearalSettingsData({
    required GeneralSettingsData generalSettingsData,
  }) async {
    var box = Hive.box('bitpro_app');

    await box.put('general_setting_data', generalSettingsData.toMap());
  }

  Future<GeneralSettingsData> getGeneralSettingsData() async {
    var box = Hive.box('bitpro_app');

    var res = await box.get('general_setting_data');
    if (res == null) {
      return GeneralSettingsData(
          expiryNotificationDays: 30,
          isHijriDateEnable: true,
          showBarcodeInReceiptCreate: true,
          showItemCodeInReceiptCreate: true,
          showOriginalPriceInReceiptCreate: true,
          showOverallDiscountInReceiptCreate: false,
          showOverallDiscountPerTabInReceiptCreate: false);
    } else {
      return GeneralSettingsData.fromMap(res);
    }
  }
}
