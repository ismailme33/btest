import 'dart:io';

import 'package:path_provider/path_provider.dart';

Future<String> uploadImageService(
    {required File file, required folderFilePath}) async {
  //Add Device Image Url

  var p =
      await getApplicationSupportDirectory(); // C:\Users\team\AppData\Roaming\com.example\bitpro_hive

  File imgDirectory = File('${p.path}/$folderFilePath');

  try {
    await imgDirectory.create(recursive: true);
  } catch (e) {}

  await file.copy(imgDirectory.path);

  return imgDirectory.path;
}
