import 'package:bitpro_hive/services/hive/hive_merchandise_db_service/inventory_db_service.dart';
import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/voucher/db_voucher_data.dart';
import 'package:bitpro_hive/model/inventory_data.dart';

class HiveVoucherDbService {
  addVoucher(
      {required DbVoucherData voucherData,
      required List<InventoryData> allInventoryDataLst,
      bool updateWatingList = true}) async {
    var box = Hive.box('bitpro_app');

    if (updateWatingList == true) {
      for (var v in voucherData.selectedItems) {
        int i =
            allInventoryDataLst.indexWhere((e) => e.barcode == v['barcode']);
        if (i != -1) {
          //getting baseline ohInfo and adding docId in fb waiting list
          // Map ohStoreInfoOfInventory =
          //     await box.get('ohStoreInfoOfInventoryFbWaitingLst') ?? {};

          // if (ohStoreInfoOfInventory.keys
          //         .contains(allInventoryDataLst.elementAt(i).docId) ==
          //     false) {
          //   ohStoreInfoOfInventory[allInventoryDataLst.elementAt(i).docId] = {
          //     for (var k in allInventoryDataLst
          //         .elementAt(i)
          //         .ohQtyForDifferentStores
          //         .keys)
          //       k: allInventoryDataLst.elementAt(i).ohQtyForDifferentStores[k]
          //   };

          //   await box.put(
          //       'ohStoreInfoOfInventoryFbWaitingLst', ohStoreInfoOfInventory);
          // }
          //old ohQty of selected store
          InventoryData inventoryData = allInventoryDataLst.elementAt(i);

          double oldOhQty = double.tryParse(inventoryData
                  .ohQtyForDifferentStores[voucherData.selectedStoreDocId]
                  .toString()) ??
              0;

          double newOhQty = voucherData.voucherType == 'Regular'
              ? oldOhQty + double.parse(v['qty'])
              : oldOhQty - double.parse(v['qty']);

          //updating oh quantity
          Map storeOhInfo = inventoryData.ohQtyForDifferentStores;
          storeOhInfo[voucherData.selectedStoreDocId] = newOhQty.toString();

          inventoryData.ohQtyForDifferentStores = storeOhInfo;

          inventoryData.cost = v['cost'].toString();
          inventoryData.price = v['price'].toString();
          inventoryData.priceWT = v['priceWt'].toString();

          //updating inventory
          await HiveInventoryDbService()
              .addEditInventoryData(inventoryData: inventoryData);
        }
      }
    }

    String dId = voucherData.docId;
    Map purchaseVoucher = box.get('Purchase Voucher') ?? {};
    purchaseVoucher[dId] = voucherData.toMap();

    await box.put('Purchase Voucher', purchaseVoucher);

    if (updateWatingList) {
      //adding docId in fb waiting list
      List voucherDataFbWaitingLst =
          await box.get('voucherDataFbWaitingLst') ?? [];

      if (voucherDataFbWaitingLst.contains(voucherData.docId) == false) {
        voucherDataFbWaitingLst.add(voucherData.docId);

        await box.put('voucherDataFbWaitingLst', voucherDataFbWaitingLst);
      }
    }
  }

  Future<List<DbVoucherData>> fetchAllVoucherData() async {
    var box = Hive.box('bitpro_app');

    Map? purchaseVoucher = box.get('Purchase Voucher');
    if (purchaseVoucher == null) return [];

    return purchaseVoucher.values.map((v) {
      return DbVoucherData.fromMap(v);
    }).toList();
  }
}
