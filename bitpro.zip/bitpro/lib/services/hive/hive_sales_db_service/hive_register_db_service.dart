import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_receipt_db_service.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class HiveRegisterDbService {
  final BuildContext context;
  HiveRegisterDbService({
    required this.context,
  });

  openRegister(EmployeeData userData) async {
    var box = Hive.box('bitpro_app');
    Map users = box.get('Users') ?? {};

    userData.openRegister = DateTime.now();

    users[userData.docId] = userData.toMap();
    await box.put('Users', users);

    await box.put('user_data', userData.toMap());

    //adding docId in fb waiting list
    List userDataFbWaitingLst = await box.get('userDataFbWaitingLst') ?? [];
    if (userDataFbWaitingLst.contains(userData.docId) == false) {
      userDataFbWaitingLst.add(userData.docId);

      await box.put('userDataFbWaitingLst', userDataFbWaitingLst);
    }
  }

  closeRegister(EmployeeData userData) async {
    var box = Hive.box('bitpro_app');
    Map users = box.get('Users') ?? {};
    userData.openRegister = null;

    users[userData.docId] = userData.toMap();
    await box.put('Users', users);

    await box.put('user_data', userData.toMap());

    //adding docId in fb waiting list
    List userDataFbWaitingLst = await box.get('userDataFbWaitingLst') ?? [];
    if (userDataFbWaitingLst.contains(userData.docId) == false) {
      userDataFbWaitingLst.add(userData.docId);

      await box.put('userDataFbWaitingLst', userDataFbWaitingLst);
    }
  }

  Future<List<ReceiptOrQuotationData>> closeRegisterData(
      String username, DateTime openRegisterDate) async {
    List<ReceiptOrQuotationData> receiptLst =
        await HiveReceiptDbService().fetchAllReceiptData();

    List<ReceiptOrQuotationData> dbReceiptData =
        receiptLst.where((element) => element.createdBy == username).toList();

    return dbReceiptData
        .where(
            (element) => openRegisterDate.compareTo(element.createdDate) == -1)
        .toList();
  }
}
