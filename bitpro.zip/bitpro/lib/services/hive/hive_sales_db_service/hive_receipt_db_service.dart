import 'package:bitpro_hive/model/customer_payment_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_item_total_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_merchandise_db_service/inventory_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_customer_payment_db_service.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/inventory_data.dart';
import 'package:bitpro_hive/model/specification_data.dart';

class HiveReceiptDbService {
  Future<void> updateCustomerPaymentTransaction(
      {required ReceiptOrQuotationData dbReceiptData}) async {
    List<CustomerPaymentData> allCustomerPaymentdata =
        await HiveCustomerPaymentDbService().fetchAllCustomerPaymentData();
    List<CustomerPaymentData> selectedCustomerPaymentLstData =
        allCustomerPaymentdata
            .where((element) =>
                element.customerId ==
                dbReceiptData.receiptBasicInfo!.selectedCustomerID)
            .toList();
    for (var k
        in dbReceiptData.receiptBasicInfo!.allPaymentMethodAmountsInfo.keys) {
      if (k.toString().toLowerCase() != 'credit') {
        String docNo;

        if (selectedCustomerPaymentLstData.isEmpty) {
          docNo = '100001';
        } else {
          docNo = (int.parse(selectedCustomerPaymentLstData.last.documentNo) +
                  1 +
                  dbReceiptData
                      .receiptBasicInfo!.allPaymentMethodAmountsInfo.keys
                      .toList()
                      .indexOf(k))
              .toString();
        }

        await HiveCustomerPaymentDbService().addCustomerPaymentData(
            CustomerPaymentData(
                selectedStoreDocId:
                    dbReceiptData.receiptBasicInfo!.selectedStoreDocId,
                docId: getRandomString(20),
                customerId: dbReceiptData.receiptBasicInfo!.selectedCustomerID,
                paymentType: k,
                amount: double.tryParse(dbReceiptData
                        .receiptBasicInfo!.allPaymentMethodAmountsInfo[k]) ??
                    0,
                createdDate: DateTime.now(),
                comment: 'Paid on ${dbReceiptData.receiptBasicInfo!.receiptNo}',
                documentNo: docNo));
      }
    }
  }

  addEditReceipt(
      {required ReceiptOrQuotationData dbReceiptData,
      required List<InventoryData> allInventoryDataLst,
      bool updateInventoryQty = true}) async {
    var box = Hive.box('bitpro_app');

    if (updateInventoryQty && dbReceiptData.isQuotation == false) {
      //updating inventory on hand quantity
      for (var v in dbReceiptData.lineItemsData) {
        int i = allInventoryDataLst.indexWhere((e) => e.barcode == v.barcode);

        if (i != -1) {
          //old ohQty of selected store
          InventoryData inventoryData = allInventoryDataLst.elementAt(i);

          double oldOhQty = double.tryParse(inventoryData
                  .ohQtyForDifferentStores[
                      dbReceiptData.receiptBasicInfo!.selectedStoreDocId]
                  .toString()) ??
              0;

          double newOhQty =
              dbReceiptData.receiptBasicInfo!.receiptType == 'Regular'
                  ? oldOhQty - double.parse(v.qty)
                  : oldOhQty + double.parse(v.qty);

          //updating oh quantity
          Map storeOhInfo = inventoryData.ohQtyForDifferentStores;
          storeOhInfo[dbReceiptData.receiptBasicInfo!.selectedStoreDocId] =
              newOhQty.toString();

          inventoryData.ohQtyForDifferentStores = storeOhInfo;
          //updating inventory
          await HiveInventoryDbService()
              .addEditInventoryData(inventoryData: inventoryData);
        }
      }
    }
    String dId = dbReceiptData.docId;
    Map salesReceipts = box.get('Sale Receipts') ?? {};
    salesReceipts[dId] = dbReceiptData.toMap();

    await box.put('Sale Receipts', salesReceipts);
    if (dbReceiptData.receiptBasicInfo != null &&
        dbReceiptData.receiptBasicInfo!.receiptType != 'Return') {
      await updateCustomerPaymentTransaction(dbReceiptData: dbReceiptData);
    }
  }

  partialPaymentReceipt(
      {required ReceiptOrQuotationData dbReceiptData,
      required List<InventoryData> allInventoryDataLst}) async {
    var box = Hive.box('bitpro_app');

    String dId = dbReceiptData.docId;
    Map salesReceipts = box.get('Sale Receipts') ?? {};
    salesReceipts[dId] = dbReceiptData.toMap();

    await box.put('Sale Receipts', salesReceipts);
  }

  Future<List<ReceiptOrQuotationData>> fetchAllReceiptData(
      {bool isQuotationData = false}) async {
    var box = Hive.box('bitpro_app');
    Map? salesReceipts = box.get('Sale Receipts');

    if (salesReceipts == null) return [];

    List<ReceiptOrQuotationData> receiptLst = [];
    // await box.delete('Sale Receipts');
    for (var map in salesReceipts.values) {
      try {
        var d = ReceiptOrQuotationData.fromMap(map);
        if (d.quotationBasicInfo != null || d.receiptBasicInfo != null) {
          receiptLst.add(d);
        }
        continue;
      } catch (e) {
        //
      }
      receiptLst.add(getOldReceiptDataInNew(map));
    }

    receiptLst.sort((b, a) => a.createdDate.compareTo(b.createdDate));
    return receiptLst
        .where((e) =>
            (isQuotationData && e.isQuotation) ||
            (isQuotationData == false && e.isQuotation == false))
        .toList();
  }

  ReceiptOrQuotationData getOldReceiptDataInNew(var map) {
    List<LineItemData> lineItemsData = [];

    for (var s in map['selectedItems']) {
      lineItemsData.add(LineItemData(
        unitName: s['unitName'] ?? '',
        cost: s['cost'] ?? '0',
        productName: s['productName'],
        qty: s['qty'],
        orgPrice: s['orgPrice'],
        orgPriceWt: '0',
        discountPercentage: s['discountPercentage'],
        discountPercentageWt: '0',
        discountValue: s['discountValue'],
        discountValueWt: '0',
        price: '0',
        priceWt: s['priceWt'],
        total: '0',
        totalWt: s['total'],
        barcode: s['barcode'],
        itemCode: s['itemCode'],
      ));
    }

    LineItemTotalData lineItemTotalData = LineItemTotalData(
      totalQty: correctNumber(map['totalQty'] ?? ''),
      totalDiscountPercentage: correctNumber(map['discountPercentage'] ?? ''),
      totalDiscountValue: correctNumber(map['discountValue'] ?? ''),
      totalTaxValue: correctNumber(map['taxValue'] ?? ''),
      totalTaxPercentage: correctNumber(map['taxPer'] ?? ''),
      receiptTotal: correctNumber(map['receiptTotal'] ?? ''),
      totalBeforeTax: '0',
    );

    ReceiptBasicInfo receiptBasicInfo = ReceiptBasicInfo(
        receiptNo: map['receiptNo'] ?? '',
        selectedCustomerBranchDocId: map['selectedCustomerBranchDocId'] ?? '',
        selectedCustomerID: map['selectedCustomerID'] ?? '',
        cartDiscountPercentage: map['cartDiscountPercentage'] ?? '0',
        cartDiscountValue: map['cartDiscountValue'] ?? '0',
        selectedStoreDocId: map['selectedStoreDocId'],
        receiptType: map['receiptType'] ?? 'Regular',
        referenceNo: map['referenceNo'] ?? '',
        specificationInfo: map['specificationInfo'] == null
            ? null
            : SpecificationData.fromMap(map['specificationInfo']),
        isAdvancePaymentEnabled: map['isAdvancePaymentEnabled'] ?? false,
        receiptDue: correctNumber(map['receiptDue'] ?? ''),
        receiptBalance: correctNumber(map['receiptBalance'] ?? ''),
        allPaymentMethodAmountsInfo: map['allPaymentMethodAmountsInfo'] ?? {});
    return ReceiptOrQuotationData(
        isQuotation: false,
        docId: map['docId'] ?? '',
        createdDate: DateTime.tryParse(map['createdDate'].toString()) ??
            DateTime.fromMillisecondsSinceEpoch(map['createdDate'] as int),
        createdBy: map['createdBy'] ?? '',
        lineItemsData: lineItemsData,
        lineItemTotalData: lineItemTotalData,
        quotationBasicInfo: null,
        receiptBasicInfo: receiptBasicInfo);
  }
}
