import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/former_z_out_data.dart';

class HiveFormerZOutDbService {
  addFormerZOutReceipt(FormerZOutData formerZOutData,
      {bool updateWatingList = true}) async {
    var box = Hive.box('bitpro_app');
    Map lst = box.get('Former Z Out') ?? {};
    lst[formerZOutData.docId] = formerZOutData.toMap();
    await box.put('Former Z Out', lst);

    if (updateWatingList) {
      //adding docId in fb waiting list
      List formerZOutFbWaitingLst =
          await box.get('formerZOutDataFbWaitingLst') ?? [];

      if (formerZOutFbWaitingLst.contains(formerZOutData.docId) == false) {
        formerZOutFbWaitingLst.add(formerZOutData.docId);

        await box.put('formerZOutDataFbWaitingLst', formerZOutFbWaitingLst);
      }
    }
  }

  Future<List<FormerZOutData>> fetchAllFormerZoutData() async {
    var box = Hive.box('bitpro_app');
    Map? lst = box.get('Former Z Out');

    if (lst == null) return [];
    return lst.values.map((v) {
      return FormerZOutData.fromMap(v);
    }).toList();
  }
}
