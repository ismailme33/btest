// import 'package:bitpro_hive/model/quotation/db_quotation_data.dart';
// import 'package:hive/hive.dart';
// import 'package:bitpro_hive/model/inventory_data.dart';

// class HiveQuoatationDbService {
//   addQuoatation(
//       {required DbQuotationData dbQuotationData,
//       required List<InventoryData> allInventoryDataLst,
//       bool updateWatingList = true}) async {
//     var box = Hive.box('bitpro_app');

//     String dId = dbQuotationData.docId;
//     Map salesQuoatation = box.get('Sale Quotation') ?? {};
//     salesQuoatation[dId] = dbQuotationData.toMap();

//     await box.put('Sale Quotation', salesQuoatation);

//     if (updateWatingList) {
//       //adding docId in fb waiting list
//       List salesQuotationFbWaitingLst =
//           await box.get('salesQuotationFbWaitingLst') ?? [];

//       if (salesQuotationFbWaitingLst.contains(dbQuotationData.docId) == false) {
//         salesQuotationFbWaitingLst.add(dbQuotationData.docId);

//         await box.put('salesQuotationFbWaitingLst', salesQuotationFbWaitingLst);
//       }
//     }
//   }

//   Future<List<DbQuotationData>> fetchAllQuotationData() async {
//     var box = Hive.box('bitpro_app');
//     Map? salesQuotations = box.get('Sale Quotation');

//     if (salesQuotations == null) return [];

//     return salesQuotations.values.map((v) {
//       return DbQuotationData.fromMap(v);
//     }).toList();
//   }
// }
