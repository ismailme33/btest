import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/customer_data.dart';

class HiveCustomerDbService {
  Future addEditCustomerData(CustomerData customerData,
      {bool updateWatingList = true}) async {
    var box = Hive.box('bitpro_app');

    Map salesCustomerData = box.get('Sales Customer Data') ?? {};

    String dId = customerData.docId;
    salesCustomerData[dId] = customerData.toMap();
    await box.put('Sales Customer Data', salesCustomerData);

    if (updateWatingList) {
      //adding docId in fb waiting list
      List customerDataFbWaitingLst =
          await box.get('customerDataFbWaitingLst') ?? [];

      if (customerDataFbWaitingLst.contains(customerData.docId) == false) {
        customerDataFbWaitingLst.add(customerData.docId);

        await box.put('customerDataFbWaitingLst', customerDataFbWaitingLst);
      }
    }
  }

  Future<List<CustomerData>> fetchAllCustomersData() async {
    var box = Hive.box('bitpro_app');
    Map? customers = box.get('Sales Customer Data');
    if (customers == null) return [];
    return customers.keys.map((k) {
      var ud = customers[k];

      return CustomerData.fromMap(ud);
    }).toList();
  }
}
