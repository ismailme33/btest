import 'package:bitpro_hive/model/department_data.dart';
import 'package:bitpro_hive/model/vendor_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:excel/excel.dart';
import '../../../model/inventory_data.dart';

//inventory update quantity

Map<String, dynamic> inventoryUpdateQuantityFromExcel(
    Excel excel, List<InventoryData> oldInventorylst) {
  int? barcodeIndex;
  int? ohQtyIndex;

  // List<InventoryData> inventoryDataLst = [];
  int itemsfound = 0;
  int itemsNotFound = 0;

  Map<String, int> udpatedQuantityData = {};

  for (var table in excel.tables.keys) {
    for (int j = 0; j < excel.tables[table]!.rows.length; j++) {
      var row = excel.tables[table]!.rows.elementAt(j);
      if (j == 0) {
        for (int i = 0; i < row.length; i++) {
          if (row.elementAt(i) != null) {
            var d = row.elementAt(i)!.value.toString().toLowerCase();

            switch (d) {
              case 'barcode':
                barcodeIndex = i;
                break;
              case 'quantity':
                ohQtyIndex = i;
                break;
            }
          }
        }
      } else if (barcodeIndex != null &&
          row.elementAt(barcodeIndex) != null &&
          ohQtyIndex != null &&
          row.elementAt(ohQtyIndex) != null) {
        String excelBarcode = row.elementAt(barcodeIndex)!.value.toString();
        int excelQuantity =
            int.tryParse(row.elementAt(ohQtyIndex)!.value.toString()) ?? 0;
        if (oldInventorylst.indexWhere((ele) => ele.barcode == excelBarcode) ==
            -1) {
          itemsNotFound++;
        } else {
          itemsfound++;

          String docId = oldInventorylst
              .elementAt(oldInventorylst
                  .indexWhere((ele) => ele.barcode == excelBarcode))
              .docId;
          udpatedQuantityData[docId] = excelQuantity;
        }
      }
    }
  }
  return {
    'itemsFound': itemsfound,
    'itemsNotFound': itemsNotFound,
    'udpatedQuantityData': udpatedQuantityData
  };
}

//inventory import
Map<String, dynamic> inventoryDataFromExcel(
    String selectedStoreDocId,
    Excel excel,
    String createdBy,
    List<InventoryData> oldInventorylst,
    List<VendorData> allVendorDataLst,
    List<DepartmentData> allDepartmentDataLst,
    double taxPer) {
  int? barcodeIndex;
  int? productNameIndex;
  int? costIndex;
  int? priceIndex;
  int? priceWtIndex;
  int? marginIndex;
  int? descriptionIndex;
  int? productImgIndex;
  int? departmentIdIndex;
  int? vendorIdIndex;
  int? unitIndex;
  int? priceCanChangeIndex;

  List<InventoryData> inventoryDataLst = [];
  int wrongVendorIdOrDepartmentId = 0;
  for (var table in excel.tables.keys) {
    for (int j = 0; j < excel.tables[table]!.rows.length; j++) {
      var row = excel.tables[table]!.rows.elementAt(j);
      if (j == 0) {
        for (int i = 0; i < row.length; i++) {
          if (row.elementAt(i) != null) {
            var d = row.elementAt(i)!.value.toString().toLowerCase();

            switch (d) {
              case 'barcode':
                barcodeIndex = i;
                break;
              case 'productname':
                productNameIndex = i;
                break;
              case 'cost':
                costIndex = i;
                break;
              case 'price':
                priceIndex = i;
                break;
              case 'pricewt':
                priceWtIndex = i;
                break;
              case 'margin':
                marginIndex = i;
                break;
              case 'description':
                descriptionIndex = i;
                break;
              case 'productimgurl':
                productImgIndex = i;
                break;
              case 'vendorid':
                vendorIdIndex = i;
                break;
              case 'departmentid':
                departmentIdIndex = i;
                break;
              case 'unit':
                unitIndex = i;
                break;
              case 'pricecanchange':
                priceCanChangeIndex = i;
                break;
            }
          }
        }
      } else if (barcodeIndex != null &&
          row.elementAt(barcodeIndex) != null &&
          productNameIndex != null &&
          row.elementAt(productNameIndex) != null &&
          vendorIdIndex != null &&
          departmentIdIndex != null) {
        if ((row.elementAt(vendorIdIndex) != null &&
                allVendorDataLst.indexWhere((element) =>
                        element.vendorId ==
                        row.elementAt(vendorIdIndex!)!.value.toString()) ==
                    -1) ||
            (row.elementAt(departmentIdIndex) != null &&
                allDepartmentDataLst.indexWhere((element) =>
                        element.departmentId ==
                        row.elementAt(departmentIdIndex!)!.value.toString()) ==
                    -1)) {
          wrongVendorIdOrDepartmentId++;
          continue;
        }

        String? barcode = row.elementAt(barcodeIndex)!.value.toString();
        String? productName = row.elementAt(productNameIndex)?.value.toString();
        String? cost;
        String? price;
        String? priceWt;
        String? margin =
            marginIndex == null || row.elementAt(marginIndex) == null
                ? null
                : row.elementAt(marginIndex)!.value.toString();
        String? description =
            descriptionIndex == null || row.elementAt(descriptionIndex) == null
                ? null
                : row.elementAt(descriptionIndex)!.value.toString();
        String? productImg =
            productImgIndex == null || row.elementAt(productImgIndex) == null
                ? null
                : row.elementAt(productImgIndex)!.value.toString();
        String? departmentId =
            row.elementAt(departmentIdIndex)?.value.toString();
        String? vendorId = row.elementAt(vendorIdIndex)?.value.toString();
        String? unit;
        bool? priceCanChange;

        if (priceWtIndex != null &&
            row.elementAt(priceWtIndex) != null &&
            row.elementAt(priceWtIndex)!.value.toString().isNotEmpty) {
          try {
            priceWt = row.elementAt(priceWtIndex)!.value.toString();
            price = calculatePrice(priceWt, taxPer);
          } catch (e) {}
        } else if (priceIndex != null &&
            row.elementAt(priceIndex) != null &&
            row.elementAt(priceIndex)!.value.toString().isNotEmpty) {
          try {
            price = row.elementAt(priceIndex)!.value.toString();
            priceWt = calculatePriceWt(price, taxPer);
          } catch (e) {}
        }
        try {
          unit = unitIndex == null ||
                  row.elementAt(unitIndex) == null ||
                  row.elementAt(unitIndex)!.value.toString().isEmpty
              ? null
              : row.elementAt(unitIndex)!.value.toString();
        } catch (e) {}
        try {
          var val = row.elementAt(priceCanChangeIndex!)!.value.toString();
          if (val == '1') {
            priceCanChange = true;
          }
        } catch (e) {}

        cost = costIndex == null || row.elementAt(costIndex) == null
            ? null
            : row.elementAt(costIndex)!.value.toString().isEmpty
                ? null
                : row.elementAt(costIndex)!.value.toString();
        margin = (double.parse(price ?? '0') - double.parse(cost ?? '0'))
            .toStringAsFixed(digit);

        int index = oldInventorylst.indexWhere((e) => e.barcode == barcode);

        InventoryData inventoryData;

        if (index != -1) {
          //updating
          inventoryData = oldInventorylst[index];
          if (unit != null) {
            inventoryData.unit = unit;
          }
          if (productName != null) {
            inventoryData.productName = productName;
          }
          if (vendorId != null) {
            inventoryData.selectedVendorId = vendorId;
          }
          if (departmentId != null) {
            inventoryData.selectedDepartmentId = departmentId;
          }
          if (productImg != null) {
            inventoryData.productImg = productImg;
          }
          if (description != null) {
            inventoryData.description = description;
          }
          if (margin != '0') {
            inventoryData.margin = margin;
          }
          if (cost != null && cost != '0') {
            inventoryData.cost = cost;
          }
          if (price != null && price != '0') {
            inventoryData.price = price;
          }
          if (priceWt != null && priceWt != '0') {
            inventoryData.priceWT = priceWt;
          }
          if (priceCanChange != null) {
            inventoryData.productPriceCanChange = priceCanChange;
          }
        } else {
          //adding
          inventoryData = InventoryData(
              docId: '',
              isNewInventory: true,
              unit: unit ?? '',
              selectedStoreDocId: selectedStoreDocId,
              barcode: barcode,
              itemCode: '',
              productName: productName ?? '',
              selectedVendorId: vendorId,
              selectedDepartmentId: departmentId,
              productImg: productImg ?? '',
              description: description ?? '',
              margin: margin,
              createdBy: createdBy,
              createdDate: DateTime.now(),
              cost: cost ?? '0',
              price: price ?? '0',
              priceWT: priceWt ?? '0',
              ohQtyForDifferentStores: {},
              productPriceCanChange: priceCanChange ?? false);
        }

        inventoryDataLst.add(inventoryData);
      }
    }
  }

  return {
    'wrongVendorIdOrDepartmentId': wrongVendorIdOrDepartmentId,
    'inventoryDataLst': inventoryDataLst
  };
}

String calculatePriceWt(String pr, double taxPer) {
  double p = double.parse(pr);

  return doubleToString((p * (1 + (taxPer / 100))));
}

String calculatePrice(String prWt, double taxPer) {
  double p = double.parse(prWt);

  return doubleToString(p - (p / (1 + (100 / taxPer))));
}
