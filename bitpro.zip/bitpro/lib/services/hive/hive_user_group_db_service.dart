import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/user_group_data.dart';

class HiveUserGroupDbService {
  Future<void> addEditUserGroup(UserGroupData userGroupData,
      {bool updateWatingList = true}) async {
    var box = Hive.box('bitpro_app');

    Map userGroups = box.get('UserGroups') ?? {};

    String dId = userGroupData.docId;

    userGroups[dId] = userGroupData.toMap();

    await box.put('UserGroups', userGroups);

    if (updateWatingList) {
      //adding docId in fb waiting list
      List userGroupFbWaitingLst =
          await box.get('userGroupDataFbWaitingLst') ?? [];
      if (userGroupFbWaitingLst.contains(userGroupData.docId) == false) {
        userGroupFbWaitingLst.add(userGroupData.docId);

        await box.put('userGroupDataFbWaitingLst', userGroupFbWaitingLst);
      }
    }
  }

  Future<List<UserGroupData>> fetchAllUserGroups() async {
    var box = Hive.box('bitpro_app');

    Map userGroups = box.get('UserGroups') ?? {};

    return userGroups.values.map((v) {
      return UserGroupData.fromMap(v);
    }).toList();
  }
}
