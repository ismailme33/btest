import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/vendor_data.dart';

class HiveVendorDbService {
  Future addEditVendorData(VendorData vendorData,
      {bool updateWatingList = true}) async {
    var box = Hive.box('bitpro_app');

    Map vendors = box.get('Merchandise Vendors') ?? {};

    String dId = vendorData.docId;

    vendors[dId] = vendorData.toMap();
    await box.put('Merchandise Vendors', vendors);

    if (updateWatingList) {
      //adding docId in fb waiting list
      List vendorDataFbWaitingLst =
          await box.get('vendorDataFbWaitingLst') ?? [];

      if (vendorDataFbWaitingLst.contains(vendorData.docId) == false) {
        vendorDataFbWaitingLst.add(vendorData.docId);
        await box.put('vendorDataFbWaitingLst', vendorDataFbWaitingLst);
      }
    }
  }

  Future<List<VendorData>> fetchAllVendorsData() async {
    var box = Hive.box('bitpro_app');
    Map? vendors = box.get('Merchandise Vendors');
    if (vendors == null) return [];

    return vendors.keys.map((k) {
      var ud = vendors[k];

      return VendorData.fromMap(ud);
    }).toList();
  }
}
