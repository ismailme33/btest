import 'dart:io';
import 'package:bitpro_hive/services/providers/upload_image_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/inventory_data.dart';
import 'package:bitpro_hive/shared/toast.dart';

class HiveInventoryDbService {
  var box = Hive.box('bitpro_app');

  Future addEditInventoryData(
      {File? productImgFile,
      required InventoryData inventoryData,
      bool updateWatingList = true}) async {
    Map merchandiseInventory = box.get('Merchandise Inventory') ?? {};

    String newProductImgUrl = productImgFile != null
        ? await uploadImageInSystem(
            file: productImgFile, fileName: inventoryData.docId)
        : '';

    if (newProductImgUrl.isNotEmpty) {
      inventoryData.productImg = newProductImgUrl;
    }

    String dId = inventoryData.docId;
    merchandiseInventory[dId] = inventoryData.toMap();
    await box.put('Merchandise Inventory', merchandiseInventory);

    //add if unit doesn't exits

    List<String> lst = await fetchAllInventoryUnitData();

    if (lst.contains(inventoryData.unit) == false) {
      lst.add(inventoryData.unit);
      await box.put('inventoryUnitLst', lst);
    }
  }

  updateInventoryOhQuantity(
      Map<String, int> excelData, BuildContext context) async {
    Map merchandiseInventory = box.get('Merchandise Inventory') ?? {};

    for (var d in excelData.keys) {
      merchandiseInventory[d]['ohQty'] = excelData[d].toString();
      //adding docId in fb waiting list
      List inventoryFbWaitingLst = await box.get('inventoryFbWaitingLst') ?? [];

      if (inventoryFbWaitingLst.contains(d) == false) {
        inventoryFbWaitingLst.add(d);
        await box.put('inventoryFbWaitingLst', inventoryFbWaitingLst);
      }
    }

    await box.put('Merchandise Inventory', merchandiseInventory);
    showToast('Data updated successfully', context);
  }

  Future<List<InventoryData>> fetchAllInventoryData() async {
    Map? merchandiseInventory = box.get('Merchandise Inventory');
    // box.delete('Merchandise Inventory');
    if (merchandiseInventory == null) return [];

    return merchandiseInventory.keys.map((k) {
      var ud = merchandiseInventory[k];

      return InventoryData.fromMap(ud);
    }).toList();
  }

  Future<List<String>> fetchAllInventoryUnitData() async {
    var inventoryUnitLst = box.get('inventoryUnitLst');

    if (inventoryUnitLst != null) {
      return inventoryUnitLst is List
          ? List<String>.from(inventoryUnitLst)
          : [];
    }
    return [];
  }

  Future<List<String>> addUnitData() async {
    var inventoryUnitLst = box.get('inventoryUnitLst');

    if (inventoryUnitLst != null) {
      return inventoryUnitLst is List
          ? List<String>.from(inventoryUnitLst)
          : [];
    }
    return [];
  }
}
