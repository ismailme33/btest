import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/department_data.dart';

class HiveDepartmentDbService {
  Future addEditDepartmentData(DepartmentData departmentData,
      {bool updateWatingList = true}) async {
    var box = Hive.box('bitpro_app');

    Map merchandiseDepartment = box.get('Merchandise Departments') ?? {};

    String dId = departmentData.docId;

    merchandiseDepartment[dId] = departmentData.toMap();
    await box.put('Merchandise Departments', merchandiseDepartment);

    if (updateWatingList) {
      //adding docId in fb waiting list
      List departmentFbWaitingLst =
          await box.get('departmentFbWaitingLst') ?? [];
      if (departmentFbWaitingLst.contains(departmentData.docId) == false) {
        departmentFbWaitingLst.add(departmentData.docId);

        await box.put('departmentFbWaitingLst', departmentFbWaitingLst);
      }
    }
  }

  Future<List<DepartmentData>> fetchAllDepartmentsData() async {
    var box = Hive.box('bitpro_app');
    Map? departments = box.get('Merchandise Departments');
    if (departments == null) return [];
    return departments.keys.map((k) {
      var ud = departments[k];

      return DepartmentData.fromMap(ud);
    }).toList();
  }
}
