import 'package:hive/hive.dart';
import 'package:bitpro_hive/model/vendor_payment_data.dart';

class HiveVendorPaymentDbService {
  Future addVendorPaymentData(VendorPaymentData vendorPaymentData,
      {bool updateWatingList = true}) async {
    var box = Hive.box('bitpro_app');

    Map vendors = box.get('Merchandise Vendors Payments') ?? {};

    String dId = vendorPaymentData.docId;

    vendors[dId] = vendorPaymentData.toMap();
    await box.put('Merchandise Vendors Payments', vendors);

    if (updateWatingList) {
      //adding docId in fb waiting list
      List vendorPaymentDataFbWaitingLst =
          await box.get('vendorPaymentDataFbWaitingLst') ?? [];

      if (vendorPaymentDataFbWaitingLst.contains(vendorPaymentData.docId) ==
          false) {
        vendorPaymentDataFbWaitingLst.add(vendorPaymentData.docId);

        await box.put(
            'vendorPaymentDataFbWaitingLst', vendorPaymentDataFbWaitingLst);
      }
    }
  }

  Future<List<VendorPaymentData>> fetchAllVendorsPaymentData() async {
    var box = Hive.box('bitpro_app');
    Map? vendorPaymentData = box.get('Merchandise Vendors Payments');
    if (vendorPaymentData == null) return [];
    return vendorPaymentData.keys.map((k) {
      var ud = vendorPaymentData[k];

      return VendorPaymentData.fromMap(ud);
    }).toList();
  }
}
