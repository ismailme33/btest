import 'package:bitpro_hive/accounting/accounting_page.dart';
import 'package:bitpro_hive/home/01_dashboard/dashboard_page.dart';
import 'package:bitpro_hive/hrms/hrms_page.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/services/backup_manager/backup_manager.dart';
import 'package:bitpro_hive/services/hive/hive_user_db_service.dart';

import 'package:bitpro_hive/services/hive/hive_user_group_db_service.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:bitpro_hive/home/03_purchase/purchase_page.dart';
import 'package:bitpro_hive/home/06_employess/employess/employees_page.dart';
import 'package:bitpro_hive/home/05_reports/reports_page.dart';
import 'package:bitpro_hive/home/02_sales/sales_page.dart';
import 'package:bitpro_hive/home/08_preferences/setting_page.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/loading.dart';
import '../model/user_group_data.dart';
import '../shared/dialogs/language_select_dialog.dart';
import '../shared/global_variables/font_sizes.dart';
import '../shared/global_variables/static_text_translate.dart';
import '09_backup_and_restore/backup_and_restore_page.dart';
import '04_merchandise/merchandise_page.dart';

class HomePage extends StatefulWidget {
  final EmployeeData userData;
  const HomePage({super.key, required this.userData});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int selectedTabIndex = 1;
  UserGroupData? currentUserRole;
  var box = Hive.box('bitpro_app');

  bool isLoading = true;
  List<UserGroupData> userGroupsDataLst = [];

  //for fb uploading and fetching status
  double progressIndicatorValue = 0;
  bool showFbDataFetchingDialog = false;
  bool showFbDataUploadingDialog = false;
  @override
  void initState() {
    super.initState();
    initData();
  }

  updateProgressValue(double v) {
    setState(() {
      progressIndicatorValue = v;
    });
  }

  initData() async {
    //Fetching & Updating userGroup data if userRole not found
    if (userGroupsDataLst.indexWhere(
            (e) => e.name == widget.userData.empWorkAndRolesData.userGroupId) ==
        -1) {
      userGroupsDataLst = await HiveUserGroupDbService().fetchAllUserGroups();
    }
    //updating loggedIn UserRole info
    int index = userGroupsDataLst.indexWhere(
        (e) => e.name == widget.userData.empWorkAndRolesData.userGroupId);
    if (index != -1) {
      currentUserRole = userGroupsDataLst.elementAt(index);
    } else {}

    //checking and backing up data
    await BackupManager().init();

    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (currentUserRole != null &&
        currentUserRole!.dashboard == false &&
        selectedTabIndex == 1) {
      selectedTabIndex = 2;
    }
    if (isLoading || showFbDataFetchingDialog || showFbDataUploadingDialog) {
      return Scaffold(
        body: showFbDataFetchingDialog
            ? Container(
                width: double.maxFinite,
                height: double.maxFinite,
                color: Colors.black54,
                child: AlertDialog(
                  title: Column(
                    children: [
                      const Text('Fetching Data, Please wait...'),
                      const SizedBox(
                        height: 15,
                      ),
                      LinearProgressIndicator(
                        value: progressIndicatorValue,
                      )
                    ],
                  ),
                ),
              )
            : showFbDataUploadingDialog
                ? Container(
                    width: double.maxFinite,
                    height: double.maxFinite,
                    color: Colors.black54,
                    child: AlertDialog(
                      title: Column(
                        children: [
                          const Text('Uploading Data, Please wait...'),
                          const SizedBox(
                            height: 10,
                          ),
                          LinearProgressIndicator(value: progressIndicatorValue)
                        ],
                      ),
                    ),
                  )
                : Center(child: showLoading()),
      );
    }

    return Scaffold(
        backgroundColor: homeBgColor,
        body: currentUserRole == null
            ? const Center(
                child: Text(
                  "User Role not found",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                ),
              )
            : SafeArea(
                child: Container(
                  color: Colors.grey,
                  child: Row(
                    children: [
                      Align(
                        alignment: Alignment.topCenter,
                        child: SizedBox(
                          height: MediaQuery.of(context).size.height / 1.05,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Container(
                                  color: const Color.fromARGB(255, 43, 43, 43),
                                  child: Column(
                                    children: [
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      if (currentUserRole == null ||
                                          !(!currentUserRole!.dashboard))
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedTabIndex = 1;
                                            });
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: selectedTabIndex == 1
                                                    ? const Color.fromARGB(
                                                        255, 17, 17, 17)
                                                    : Colors.transparent,
                                                borderRadius:
                                                    BorderRadius.circular(0)),
                                            height: 40,
                                            width: 170,
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Image.asset(
                                                  'assets/icons/dashboard.png',
                                                  width: 20,
                                                ),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Text(
                                                  staticTextTranslate(
                                                      'Dashboard'),
                                                  style: TextStyle(
                                                      color:
                                                          selectedTabIndex == 1
                                                              ? darkBlueColor
                                                              : Colors.white,
                                                      fontSize:
                                                          getMediumFontSize),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      if (currentUserRole == null ||
                                          !(!currentUserRole!.receipt &&
                                              !currentUserRole!.customers &&
                                              !currentUserRole!.registers &&
                                              !currentUserRole!.formerZout))
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedTabIndex = 2;
                                            });
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: selectedTabIndex == 2
                                                    ? const Color.fromARGB(
                                                        255, 17, 17, 17)
                                                    : Colors.transparent,
                                                borderRadius:
                                                    BorderRadius.circular(0)),
                                            height: 40,
                                            width: 170,
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Image.asset(
                                                  'assets/icons/sales.png',
                                                  width: 23,
                                                ),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Text(
                                                  staticTextTranslate('Sales'),
                                                  style: TextStyle(
                                                      color:
                                                          selectedTabIndex == 2
                                                              ? darkBlueColor
                                                              : Colors.white,
                                                      fontSize:
                                                          getMediumFontSize),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      if (currentUserRole == null ||
                                          currentUserRole!.purchaseVoucher)
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedTabIndex = 3;
                                            });
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: selectedTabIndex == 3
                                                    ? const Color.fromARGB(
                                                        255, 17, 17, 17)
                                                    : Colors.transparent,
                                                borderRadius:
                                                    BorderRadius.circular(0)),
                                            height: 40,
                                            width: 170,
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Image.asset(
                                                  'assets/icons/purchase.png',
                                                  width: 23,
                                                ),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Text(
                                                  staticTextTranslate(
                                                      'Purchase'),
                                                  style: TextStyle(
                                                      color:
                                                          selectedTabIndex == 3
                                                              ? darkBlueColor
                                                              : Colors.white,
                                                      fontSize:
                                                          getMediumFontSize),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      if (currentUserRole == null ||
                                          !(!currentUserRole!.inventory &&
                                              !currentUserRole!.vendors &&
                                              !currentUserRole!.departments &&
                                              !currentUserRole!.adjustment))
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedTabIndex = 4;
                                            });
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: selectedTabIndex == 4
                                                    ? const Color.fromARGB(
                                                        255, 17, 17, 17)
                                                    : Colors.transparent,
                                                borderRadius:
                                                    BorderRadius.circular(0)),
                                            height: 40,
                                            width: 170,
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Image.asset(
                                                  'assets/icons/merchandise.png',
                                                  width: 23,
                                                ),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Text(
                                                  staticTextTranslate(
                                                      'Merchandise'),
                                                  style: TextStyle(
                                                      color:
                                                          selectedTabIndex == 4
                                                              ? darkBlueColor
                                                              : Colors.white,
                                                      fontSize:
                                                          getMediumFontSize),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      // const SizedBox(
                                      //   height: 20,
                                      // ),
                                      // GestureDetector(
                                      //   onTap: () {
                                      //     setState(() {
                                      //       selectedTabIndex = 9;
                                      //     });
                                      //   },
                                      //   child: Container(
                                      //     decoration: BoxDecoration(
                                      //         color: selectedTabIndex == 9
                                      //             ? const Color.fromARGB(
                                      //                 255, 17, 17, 17)
                                      //             : Colors.transparent,
                                      //         borderRadius:
                                      //             BorderRadius.circular(
                                      //                 0)),
                                      //     height: 40,
                                      //     width: 170,
                                      //     child: Row(
                                      //       crossAxisAlignment:
                                      //           CrossAxisAlignment.center,
                                      //       children: [
                                      //         const SizedBox(
                                      //           width: 10,
                                      //         ),
                                      //         Image.asset(
                                      //           'assets/icons/accounting.png',
                                      //           width: 23,
                                      //         ),
                                      //         const SizedBox(
                                      //           width: 10,
                                      //         ),
                                      //         Text(
                                      //           staticTextTranslate(
                                      //               'Accounting'),
                                      //           style: TextStyle(
                                      //               color:
                                      //                   selectedTabIndex ==
                                      //                           11
                                      //                       ? darkBlueColor
                                      //                       : Colors
                                      //                           .white,
                                      //               fontSize:
                                      //                   getMediumFontSize),
                                      //         )
                                      //       ],
                                      //     ),
                                      //   ),
                                      // ),
                                      // GestureDetector(
                                      //   onTap: () {
                                      //     setState(() {
                                      //       selectedTabIndex = 10;
                                      //     });
                                      //   },
                                      //   child: Container(
                                      //     decoration: BoxDecoration(
                                      //         color: selectedTabIndex ==
                                      //                 10
                                      //             ? const Color.fromARGB(
                                      //                 255, 17, 17, 17)
                                      //             : Colors.transparent,
                                      //         borderRadius:
                                      //             BorderRadius.circular(
                                      //                 0)),
                                      //     height: 40,
                                      //     width: 170,
                                      //     child: Row(
                                      //       crossAxisAlignment:
                                      //           CrossAxisAlignment.center,
                                      //       children: [
                                      //         const SizedBox(
                                      //           width: 10,
                                      //         ),
                                      //         Image.asset(
                                      //           'assets/icons/hr.png',
                                      //           width: 23,
                                      //         ),
                                      //         const SizedBox(
                                      //           width: 10,
                                      //         ),
                                      //         Text(
                                      //           staticTextTranslate(
                                      //               'HR Management'),
                                      //           style: TextStyle(
                                      //               color:
                                      //                   selectedTabIndex ==
                                      //                           11
                                      //                       ? darkBlueColor
                                      //                       : Colors
                                      //                           .white,
                                      //               fontSize:
                                      //                   getMediumFontSize),
                                      //         )
                                      //       ],
                                      //     ),
                                      //   ),
                                      // ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      if (currentUserRole == null ||
                                          currentUserRole!.reports)
                                        GestureDetector(
                                          onTap: () {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                    builder: (context) =>
                                                        ReportsPage(
                                                          userData:
                                                              widget.userData,
                                                        )));
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: selectedTabIndex == 5
                                                    ? const Color.fromARGB(
                                                        255, 17, 17, 17)
                                                    : Colors.transparent,
                                                borderRadius:
                                                    BorderRadius.circular(0)),
                                            height: 40,
                                            width: 170,
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Image.asset(
                                                  'assets/icons/report.png',
                                                  width: 23,
                                                ),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Text(
                                                  staticTextTranslate(
                                                      'Reports'),
                                                  style: TextStyle(
                                                      color: selectedTabIndex ==
                                                              5
                                                          ? const Color
                                                              .fromARGB(
                                                              255, 17, 17, 17)
                                                          : Colors.white,
                                                      fontSize:
                                                          getMediumFontSize),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      if (currentUserRole == null ||
                                          !(!currentUserRole!.employees &&
                                              !currentUserRole!.groups))
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedTabIndex = 6;
                                            });
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: selectedTabIndex == 6
                                                    ? const Color.fromARGB(
                                                        255, 17, 17, 17)
                                                    : Colors.transparent,
                                                borderRadius:
                                                    BorderRadius.circular(0)),
                                            height: 40,
                                            width: 170,
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Image.asset(
                                                  'assets/icons/employees.png',
                                                  width: 23,
                                                ),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Text(
                                                  staticTextTranslate(
                                                      'Employees'),
                                                  style: TextStyle(
                                                      color:
                                                          selectedTabIndex == 6
                                                              ? darkBlueColor
                                                              : Colors.white,
                                                      fontSize:
                                                          getMediumFontSize),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      GestureDetector(
                                        onTap: () {
                                          showLanguageSelectDialog(context);
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                              color: Colors.transparent,
                                              borderRadius:
                                                  BorderRadius.circular(0)),
                                          height: 40,
                                          width: 170,
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Image.asset(
                                                'assets/icons/language.png',
                                                width: 23,
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Text(
                                                staticTextTranslate('Language'),
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize:
                                                        getMediumFontSize),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                      if (currentUserRole == null ||
                                          currentUserRole!.settings)
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedTabIndex = 7;
                                            });
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: selectedTabIndex == 7
                                                    ? const Color.fromARGB(
                                                        255, 17, 17, 17)
                                                    : Colors.transparent,
                                                borderRadius:
                                                    BorderRadius.circular(0)),
                                            height: 40,
                                            width: 170,
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Image.asset(
                                                  'assets/icons/settings.png',
                                                  width: 23,
                                                ),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Text(
                                                  staticTextTranslate(
                                                      'Preferences'),
                                                  style: TextStyle(
                                                      color:
                                                          selectedTabIndex == 7
                                                              ? darkBlueColor
                                                              : Colors.white,
                                                      fontSize:
                                                          getMediumFontSize),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      if (currentUserRole == null ||
                                          currentUserRole!.backupReset)
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedTabIndex = 8;
                                            });
                                          },
                                          child: Container(
                                            decoration: BoxDecoration(
                                                color: selectedTabIndex == 8
                                                    ? const Color.fromARGB(
                                                        255, 75, 75, 75)
                                                    : Colors.transparent,
                                                borderRadius:
                                                    BorderRadius.circular(0)),
                                            height: 40,
                                            width: 170,
                                            child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Image.asset(
                                                  'assets/icons/backup.png',
                                                  width: 23,
                                                ),
                                                const SizedBox(
                                                  width: 10,
                                                ),
                                                Text(
                                                  staticTextTranslate(
                                                      'Backup & Restore'),
                                                  style: GoogleFonts.roboto(
                                                      fontSize:
                                                          getMediumFontSize + 1,
                                                      color: Colors.white),
                                                )
                                              ],
                                            ),
                                          ),
                                        ),
                                      GestureDetector(
                                        onTap: () async {
                                          // Box box =
                                          //     Hive.box('bitpro_app');
                                          // await box.put(
                                          //     'is_user_logged_in', false);
                                          // await box.put(
                                          //     'last_user_username',
                                          //     widget
                                          //         .userData
                                          //         .empBasicInfoData
                                          //         .username);
                                          // await box.delete('user_data');
                                          await HiveUserDbService().logoutUser(
                                              widget.userData.empBasicInfoData
                                                  .username);
                                          setState(() {});
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(0)),
                                          height: 40,
                                          width: 170,
                                          child: Row(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Image.asset(
                                                'assets/icons/logout.png',
                                                width: 23,
                                              ),
                                              const SizedBox(width: 10),
                                              Text(
                                                staticTextTranslate('Logout'),
                                                style: GoogleFonts.roboto(
                                                    fontSize:
                                                        getMediumFontSize + 1,
                                                    color: Colors.white),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Expanded(
                        child: Container(
                          color: Colors.grey[300],
                          width: double.maxFinite,
                          height: double.maxFinite,
                          child: Card(
                              shape: RoundedRectangleBorder(
                                  side: const BorderSide(
                                      width: 0.5, color: Colors.grey),
                                  borderRadius: BorderRadius.circular(0)),
                              elevation: 0,
                              child: Container(
                                color: Colors.grey[300],
                                child: Padding(
                                    padding:
                                        //setting tab index
                                        selectedTabIndex == 7
                                            ? const EdgeInsets.all(0)
                                            : const EdgeInsets.all(10.0),
                                    child: getCurrentPage()),
                              )),
                        ),
                      )
                    ],
                  ),
                ),
              ));
  }

  getCurrentPage() {
    switch (selectedTabIndex) {
      case 1:
        return DashboardPage();
      case 2:
        return SalesPage(
          userData: widget.userData,
          currentUserRole: currentUserRole!,
        );
      case 3:
        return PurchasePage(
          userData: widget.userData,
          currentUserRole: currentUserRole!,
        );
      case 4:
        return MerchandisePage(
          userData: widget.userData,
          currentUserRole: currentUserRole!,
        );
      case 9:
        return AccountingPage();
      case 10:
        return HrmsPage();
      case 6:
        return EmployeesPage(
          userData: widget.userData,
          currentUserRole: currentUserRole!,
        );
      case 7:
        return SettingsPage(
          userData: widget.userData,
        );
      case 8:
        return const BackupAndRestore();
    }
  }
}
