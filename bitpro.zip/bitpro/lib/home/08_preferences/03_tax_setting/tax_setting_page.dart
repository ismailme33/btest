import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class TaxSettingPage extends StatefulWidget {
  final TaxSettingsData taxSettingsData;
  const TaxSettingPage({super.key, required this.taxSettingsData});

  @override
  State<TaxSettingPage> createState() => _TaxSettingPageState();
}

class _TaxSettingPageState extends State<TaxSettingPage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          staticTextTranslate('Tax Percentage'),
          style: GoogleFonts.roboto(fontSize: 14),
        ),
        const SizedBox(
          height: 5,
        ),
        SizedBox(
          width: 250,
          height: 28,
          child: TextFormField(
            initialValue: widget.taxSettingsData.taxPercentage.toString(),
            autovalidateMode: AutovalidateMode.onUserInteraction,
            validator: (value) {
              if (double.tryParse(value ?? '') == null) {
                return staticTextTranslate('Enter a valid number');
              }
              return null;
            },
            style: GoogleFonts.roboto(fontSize: 14),
            decoration: const InputDecoration(
                enabledBorder:
                    OutlineInputBorder(borderSide: BorderSide(width: 0.3)),
                fillColor: Colors.white,
                filled: true,
                isDense: true,
                contentPadding:
                    EdgeInsets.symmetric(vertical: 15, horizontal: 5),
                border: OutlineInputBorder()),
            onChanged: (val) => setState(() {
              if (double.tryParse(val) != null) {
                widget.taxSettingsData.taxPercentage = double.parse(val);
              }
            }),
          ),
        ),
      ],
    ));
  }
}
