import 'package:bitpro_hive/model/settings/receipt_details_data.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';

class ResceiptSettingView extends StatefulWidget {
  final ReceiptSettingData receiptSettingData;
  const ResceiptSettingView({super.key, required this.receiptSettingData});

  @override
  State<ResceiptSettingView> createState() => _ResceiptSettingViewState();
}

class _ResceiptSettingViewState extends State<ResceiptSettingView> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(15),
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                border: Border.all(width: 0.3),
                color: Colors.white),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text('Receipt General Settings'),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      children: [
                        Checkbox(
                            activeColor: darkBlueColor,
                            side: const BorderSide(width: 0.7),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4)),
                            value: widget
                                .receiptSettingData.inTenderUseAdvancePayment,
                            onChanged: (val) {
                              setState(() {
                                widget.receiptSettingData
                                    .inTenderUseAdvancePayment = val!;
                              });
                            }),
                        InkWell(
                          onTap: () {
                            setState(() {
                              widget.receiptSettingData
                                      .inTenderUseAdvancePayment =
                                  !widget.receiptSettingData
                                      .inTenderUseAdvancePayment;
                            });
                          },
                          child: Text(
                              staticTextTranslate(
                                  'In tender use advance payment'),
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Align(
                        alignment: Alignment.centerLeft,
                        child: Text(' Default pricing Tab for new Invoices')),
                    Row(
                      children: [
                        Checkbox(
                            activeColor: darkBlueColor,
                            side: const BorderSide(width: 0.7),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4)),
                            value: widget.receiptSettingData
                                    .priceCanChangeSelectTabIndex ==
                                0,
                            onChanged: (val) async {
                              widget.receiptSettingData
                                  .priceCanChangeSelectTabIndex = 0;

                              setState(() {});
                            }),
                        InkWell(
                          onTap: () async {
                            widget.receiptSettingData
                                .priceCanChangeSelectTabIndex = 0;

                            setState(() {});
                          },
                          child: Text(staticTextTranslate('Price'),
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        ),
                        SizedBox(
                          width: 20,
                        ),
                        Checkbox(
                            activeColor: darkBlueColor,
                            side: const BorderSide(width: 0.7),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4)),
                            value: widget.receiptSettingData
                                    .priceCanChangeSelectTabIndex ==
                                1,
                            onChanged: (val) async {
                              widget.receiptSettingData
                                  .priceCanChangeSelectTabIndex = 1;

                              setState(() {});
                            }),
                        InkWell(
                          onTap: () async {
                            widget.receiptSettingData
                                .priceCanChangeSelectTabIndex = 1;

                            setState(() {});
                          },
                          child: Text(staticTextTranslate('Price w/t'),
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        ),
                        SizedBox(
                          width: 20,
                        )
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                          staticTextTranslate(
                              ' Is vendor and department mandatory, while creating inventory'),
                          style: TextStyle(
                            fontSize: getMediumFontSize,
                          )),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Row(
                      children: [
                        Checkbox(
                            activeColor: darkBlueColor,
                            side: const BorderSide(width: 0.7),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4)),
                            value: widget.receiptSettingData.isVendorMandatory,
                            onChanged: (val) {
                              widget.receiptSettingData.isVendorMandatory =
                                  val!;
                              setState(() {});
                            }),
                        InkWell(
                          onTap: () {
                            setState(() {
                              widget.receiptSettingData.isVendorMandatory =
                                  !widget.receiptSettingData.isVendorMandatory;
                            });
                          },
                          child: Text(staticTextTranslate('Ventory'),
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Checkbox(
                            activeColor: darkBlueColor,
                            side: const BorderSide(width: 0.7),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4)),
                            value:
                                widget.receiptSettingData.isDepartmentMandatory,
                            onChanged: (val) {
                              setState(() {
                                widget.receiptSettingData
                                    .isDepartmentMandatory = val!;
                              });
                            }),
                        InkWell(
                          onTap: () {
                            setState(() {
                              widget.receiptSettingData.isDepartmentMandatory =
                                  !widget
                                      .receiptSettingData.isDepartmentMandatory;
                            });
                          },
                          child: Text(staticTextTranslate('Department'),
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        Checkbox(
                            activeColor: darkBlueColor,
                            side: const BorderSide(width: 0.7),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4)),
                            value:
                                widget.receiptSettingData.showCustomCrateDate,
                            onChanged: (val) {
                              setState(() {
                                widget.receiptSettingData.showCustomCrateDate =
                                    val!;
                              });
                            }),
                        InkWell(
                          onTap: () {
                            setState(() {
                              widget.receiptSettingData.showCustomCrateDate =
                                  !widget
                                      .receiptSettingData.showCustomCrateDate;
                            });
                          },
                          child: Text(
                              staticTextTranslate('Show custom create date'),
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  width: 50,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Required Payment methods for Invoice'),
                    SizedBox(
                      height: 5,
                    ),
                    SizedBox(
                      width: 300,
                      child: Table(
                        children: [
                          TableRow(children: [
                            Container(
                              height: 25,
                              decoration:
                                  const BoxDecoration(color: Colors.black12),
                              alignment: Alignment.center,
                              child: const Text('Payment Method'),
                            ),
                            Container(
                              height: 25,
                              decoration:
                                  const BoxDecoration(color: Colors.black12),
                              alignment: Alignment.center,
                              child: const Text('Enabled'),
                            ),
                          ]),
                          for (var k
                              in widget.receiptSettingData.paymentTypeList.keys)
                            TableRow(
                                decoration: BoxDecoration(
                                    border: Border.all(width: 0.12)),
                                children: [
                                  Container(
                                    height: 25,
                                    decoration: BoxDecoration(),
                                    alignment: Alignment.center,
                                    child: Text(k),
                                  ),
                                  Container(
                                      height: 25,
                                      decoration: BoxDecoration(),
                                      alignment: Alignment.center,
                                      child: Checkbox(
                                        value: widget.receiptSettingData
                                                    .paymentTypeList[k] ==
                                                1
                                            ? true
                                            : false,
                                        onChanged: (v) {
                                          widget.receiptSettingData
                                                  .paymentTypeList[k] =
                                              v == true ? 1 : 0;
                                          setState(() {});
                                        },
                                      )),
                                ]),
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
