import 'package:bitpro_hive/model/settings/smpt_server_settings.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SmptServerTabSettings extends StatefulWidget {
  final SmptServerSettings smptServerSettings;
  const SmptServerTabSettings({super.key, required this.smptServerSettings});

  @override
  State<SmptServerTabSettings> createState() => _SmptServerTabSettingsState();
}

class _SmptServerTabSettingsState extends State<SmptServerTabSettings> {
  @override
  Widget build(BuildContext context) {
    bool canShowBtnCheckBox = false;
    if (widget.smptServerSettings.server.isNotEmpty &&
        widget.smptServerSettings.password.isNotEmpty &&
        widget.smptServerSettings.port.isNotEmpty &&
        widget.smptServerSettings.senderEmailName.isNotEmpty &&
        widget.smptServerSettings.username.isNotEmpty) {
      canShowBtnCheckBox = true;
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'SMTP server settings',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 10,
        ),
        SizedBox(
          width: 530,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(staticTextTranslate('Server'),
                  style: GoogleFonts.roboto(fontSize: 14)),
              const SizedBox(
                height: 5,
              ),
              SizedBox(
                height: 28,
                width: 350,
                child: TextFormField(
                  initialValue: widget.smptServerSettings.server,
                  style: GoogleFonts.roboto(fontSize: 14, height: 1.1),
                  decoration: const InputDecoration(
                      fillColor: Colors.white,
                      filled: true,
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(2)),
                          borderSide: BorderSide(width: 0.3)),
                      isDense: true,
                      contentPadding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                      border: OutlineInputBorder()),
                  onChanged: (val) => setState(() {
                    widget.smptServerSettings.server = val;
                  }),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          height: 5,
        ),
        SizedBox(
          width: 530,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(staticTextTranslate('Username'),
                  style: GoogleFonts.roboto(fontSize: 14)),
              const SizedBox(
                height: 5,
              ),
              SizedBox(
                height: 28,
                width: 350,
                child: TextFormField(
                  initialValue: widget.smptServerSettings.username,
                  style: GoogleFonts.roboto(fontSize: 14, height: 1.1),
                  decoration: const InputDecoration(
                      fillColor: Colors.white,
                      filled: true,
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(2)),
                          borderSide: BorderSide(width: 0.3)),
                      isDense: true,
                      contentPadding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                      border: OutlineInputBorder()),
                  onChanged: (val) => setState(() {
                    widget.smptServerSettings.username = val;
                  }),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          height: 5,
        ),
        SizedBox(
          width: 530,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(staticTextTranslate('Password'),
                  style: GoogleFonts.roboto(fontSize: 14)),
              const SizedBox(
                height: 5,
              ),
              SizedBox(
                height: 28,
                width: 350,
                child: TextFormField(
                  initialValue: widget.smptServerSettings.password,
                  style: GoogleFonts.roboto(fontSize: 14, height: 1.1),
                  decoration: const InputDecoration(
                      fillColor: Colors.white,
                      filled: true,
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(2)),
                          borderSide: BorderSide(width: 0.3)),
                      isDense: true,
                      contentPadding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                      border: OutlineInputBorder()),
                  onChanged: (val) => setState(() {
                    widget.smptServerSettings.password = val;
                  }),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          height: 5,
        ),
        SizedBox(
          width: 530,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(staticTextTranslate('Port'),
                  style: GoogleFonts.roboto(fontSize: 14)),
              const SizedBox(
                height: 5,
              ),
              SizedBox(
                height: 28,
                width: 350,
                child: TextFormField(
                  initialValue: widget.smptServerSettings.port,
                  style: GoogleFonts.roboto(fontSize: 14, height: 1.1),
                  decoration: const InputDecoration(
                      fillColor: Colors.white,
                      filled: true,
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(2)),
                          borderSide: BorderSide(width: 0.3)),
                      isDense: true,
                      contentPadding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                      border: OutlineInputBorder()),
                  onChanged: (val) => setState(() {
                    widget.smptServerSettings.port = val;
                  }),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          height: 5,
        ),
        SizedBox(
          width: 530,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(staticTextTranslate('Sender Email Name'),
                  style: GoogleFonts.roboto(fontSize: 14)),
              const SizedBox(
                height: 5,
              ),
              SizedBox(
                height: 28,
                width: 350,
                child: TextFormField(
                  initialValue: widget.smptServerSettings.senderEmailName,
                  style: GoogleFonts.roboto(fontSize: 14, height: 1.1),
                  decoration: const InputDecoration(
                      fillColor: Colors.white,
                      filled: true,
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(2)),
                          borderSide: BorderSide(width: 0.3)),
                      isDense: true,
                      contentPadding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                      border: OutlineInputBorder()),
                  onChanged: (val) => setState(() {
                    widget.smptServerSettings.senderEmailName = val;
                  }),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          height: 10,
        ),
        Row(children: [
          Checkbox(
              activeColor: darkBlueColor,
              side: const BorderSide(width: 0.7),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4)),
              value: widget.smptServerSettings.isSSLEnabled,
              onChanged: (val) {
                setState(() {
                  widget.smptServerSettings.isSSLEnabled = val!;
                });
              }),
          InkWell(
            onTap: () {
              setState(() {
                widget.smptServerSettings.isSSLEnabled =
                    !widget.smptServerSettings.isSSLEnabled;
              });
            },
            child: Text(staticTextTranslate('Is SSL Enabled'),
                style: TextStyle(
                  fontSize: getMediumFontSize,
                )),
          ),
        ]),
        SizedBox(
          height: 10,
        ),
        if (canShowBtnCheckBox) ...[
          Row(children: [
            Checkbox(
                activeColor: darkBlueColor,
                side: const BorderSide(width: 0.7),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4)),
                value: widget.smptServerSettings.enableSaveAndSendEmailButton,
                onChanged: (val) {
                  setState(() {
                    widget.smptServerSettings.enableSaveAndSendEmailButton =
                        val!;
                  });
                }),
            InkWell(
              onTap: () {
                setState(() {
                  widget.smptServerSettings.enableSaveAndSendEmailButton =
                      !widget.smptServerSettings.enableSaveAndSendEmailButton;
                });
              },
              child:
                  Text(staticTextTranslate('Enable save & send email button'),
                      style: TextStyle(
                        fontSize: getMediumFontSize,
                      )),
            ),
          ]),
          Row(children: [
            Checkbox(
                activeColor: darkBlueColor,
                side: const BorderSide(width: 0.7),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4)),
                value: widget.smptServerSettings.sendToEmailWhilePrintAndUpdate,
                onChanged: (val) {
                  setState(() {
                    widget.smptServerSettings.sendToEmailWhilePrintAndUpdate =
                        val!;
                  });
                }),
            InkWell(
              onTap: () {
                setState(() {
                  widget.smptServerSettings.sendToEmailWhilePrintAndUpdate =
                      !widget.smptServerSettings.sendToEmailWhilePrintAndUpdate;
                });
              },
              child: Text(
                  staticTextTranslate('Send to email while print and update'),
                  style: TextStyle(
                    fontSize: getMediumFontSize,
                  )),
            ),
          ]),
          SizedBox(
            height: 10,
          ),
        ]
      ],
    );
  }
}
