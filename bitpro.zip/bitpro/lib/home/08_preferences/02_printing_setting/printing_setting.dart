// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'dart:io';

import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/settings/smpt_server_settings.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:iconsax/iconsax.dart';
import 'package:printing/printing.dart';

import 'package:bitpro_hive/home/08_preferences/inventory_tag_size.dart';
import 'package:bitpro_hive/home/08_preferences/02_printing_setting/smpt_server.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';

import '../../../shared/global_variables/font_sizes.dart';
import '../../../shared/global_variables/static_text_translate.dart';

class PrintingTab02 extends StatefulWidget {
  final PrintingSetttings printingSetttings;
  final SmptServerSettings smptServerSettings;
  final List<Printer> allPrinterLst;

  const PrintingTab02({
    Key? key,
    required this.allPrinterLst,
    required this.printingSetttings,
    required this.smptServerSettings,
  }) : super(key: key);

  @override
  State<PrintingTab02> createState() => _PrintingTab02State();
}

class _PrintingTab02State extends State<PrintingTab02> {
  @override
  Widget build(BuildContext context) {
    File? headerFile;
    File? fotterFile;
    if (widget.printingSetttings.headerImgPath.isNotEmpty) {
      try {
        if (File(widget.printingSetttings.headerImgPath).existsSync()) {
          headerFile = File(widget.printingSetttings.headerImgPath);
        }
      } catch (e) {}
    }
    if (widget.printingSetttings.fotterImgPath.isNotEmpty) {
      try {
        if (File(widget.printingSetttings.fotterImgPath).existsSync()) {
          fotterFile = File(widget.printingSetttings.fotterImgPath);
        }
      } catch (e) {}
    }

    return SingleChildScrollView(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      SizedBox(
        width: 530,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(staticTextTranslate('Receipt Printer'),
                style: GoogleFonts.roboto(fontSize: 14)),
            Container(
              height: 28,
              width: 350,
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(width: 0.3),
                  borderRadius: BorderRadius.circular(2)),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  isExpanded: true,
                  hint: Text(staticTextTranslate('Select Printer'),
                      style: GoogleFonts.roboto(
                          fontSize: 15, color: Colors.black)),
                  items: widget.allPrinterLst.map((Printer value) {
                        return DropdownMenuItem<String>(
                          value: value.name,
                          child: Text(
                            value.name,
                            style: TextStyle(fontSize: getMediumFontSize),
                          ),
                        );
                      }).toList() +
                      [
                        DropdownMenuItem<String>(
                          value: 'Select Printer While Printing',
                          child: Text(
                            staticTextTranslate(
                                'Select Printer While Printing'),
                            style: TextStyle(fontSize: getMediumFontSize),
                          ),
                        )
                      ],
                  value: widget.printingSetttings.selectedPrinter == null
                      ? null
                      : widget.printingSetttings.selectedPrinter!.name,
                  onChanged: (value) {
                    if (value != null) {
                      Printer? printer;
                      // var box = Hive.box('bitpro_app');
                      if (value == 'Select Printer While Printing') {
                        printer = const Printer(
                            url: 'Select Printer While Printing',
                            name: 'Select Printer While Printing');
                        // box.put('active_printer', selectedPrinter!.toMap());
                      } else {
                        printer = widget.allPrinterLst
                            .firstWhere((element) => element.name == value);
                        // if (selectedPrinter != null) {
                        // box.put('active_printer', selectedPrinter!.toMap());
                        // }
                      }

                      widget.printingSetttings.selectedPrinter = printer;

                      setState(() {});
                    }
                  },
                ),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(
        height: 5,
      ),
      SizedBox(
        width: 530,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(staticTextTranslate('Default Receipt Template'),
                style: GoogleFonts.roboto(fontSize: 14)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(width: 0.3),
                  borderRadius: BorderRadius.circular(2)),
              width: 350,
              height: 28,
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  isExpanded: true,
                  value: widget.printingSetttings.selectedReceiptTemplate,
                  items: <String>[
                    'DES0001-A4',
                    'DES0002-A4',
                    'DES0003-A4',
                    'DES0004-A4',
                    'DES0005-A4',
                    '80 mm',
                    '80mm SPCS',
                    '80 mm No Vat',
                    'ECS-POS-80mm',
                    'KSA-001',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value,
                          style: GoogleFonts.roboto(
                              fontSize: 14, color: Colors.black)),
                    );
                  }).toList(),
                  onChanged: (val) {
                    if (val != null) {
                      setState(() {
                        widget.printingSetttings.selectedReceiptTemplate = val;
                      });
                    }
                  },
                ),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(
        height: 5,
      ),
      SizedBox(
        width: 530,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(staticTextTranslate('Default Quote Template'),
                style: GoogleFonts.roboto(fontSize: 14)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(width: 0.3),
                  borderRadius: BorderRadius.circular(2)),
              width: 350,
              height: 28,
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  isExpanded: true,
                  value: 'DES0003-A4',
                  items: <String>[
                    'DES0003-A4',
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value,
                          style: GoogleFonts.roboto(
                              fontSize: 14, color: Colors.black)),
                    );
                  }).toList(),
                  onChanged: (val) {
                    if (val != null) {
                      widget.printingSetttings.selectedQuotationTemplate = val;
                      setState(() {});
                    }
                    // setState(() {
                    //   selectedReceiptTemplate = val ?? '80 mm';
                    // });
                  },
                ),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(
        height: 20,
      ),
      SizedBox(
        width: 530,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(staticTextTranslate('Receipt Title (English)'),
                style: GoogleFonts.roboto(fontSize: 14)),
            const SizedBox(
              height: 5,
            ),
            SizedBox(
              height: 28,
              width: 350,
              child: TextFormField(
                initialValue: widget.printingSetttings.receiptTitleEng,
                style: GoogleFonts.roboto(fontSize: 14, height: 1.1),
                decoration: const InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2)),
                        borderSide: BorderSide(width: 0.3)),
                    isDense: true,
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                    border: OutlineInputBorder()),
                onChanged: (val) => setState(() {
                  widget.printingSetttings.receiptTitleEng = val;
                }),
              ),
            )
          ],
        ),
      ),
      const SizedBox(
        height: 5,
      ),
      SizedBox(
        width: 530,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(staticTextTranslate('Receipt Title (Arabic)'),
                style: GoogleFonts.roboto(fontSize: 14)),
            SizedBox(
              height: 28,
              width: 350,
              child: TextFormField(
                initialValue: widget.printingSetttings.receiptTitleArb,
                style: GoogleFonts.roboto(fontSize: 14, height: 1.4),
                decoration: const InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2)),
                        borderSide: BorderSide(width: 0.3)),
                    isDense: true,
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 8, horizontal: 5),
                    border: OutlineInputBorder()),
                onChanged: (val) => setState(() {
                  widget.printingSetttings.receiptTitleArb = val;
                }),
              ),
            )
          ],
        ),
      ),
      SizedBox(
        height: 20,
      ),
      SizedBox(
        width: 530,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              staticTextTranslate('Receipt Footer (English)'),
              style: GoogleFonts.roboto(fontSize: 14, height: 1.4),
            ),
            SizedBox(
              width: 350,
              height: 52,
              child: TextFormField(
                initialValue: widget.printingSetttings.receiptFotterEng,
                style:
                    const TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                maxLines: 3,
                decoration: const InputDecoration(
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2)),
                        borderSide: BorderSide(width: 0.3)),
                    fillColor: Colors.white,
                    filled: true,
                    isDense: true,
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                    border: OutlineInputBorder()),
                onChanged: (val) => setState(() {
                  widget.printingSetttings.receiptFotterEng = val;
                }),
              ),
            ),
          ],
        ),
      ),
      const SizedBox(
        height: 5,
      ),
      SizedBox(
        width: 530,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              staticTextTranslate('Receipt Footer (Arabic)'),
              style: TextStyle(fontSize: getMediumFontSize - 1),
            ),
            const SizedBox(
              height: 5,
            ),
            SizedBox(
              width: 350,
              height: 52,
              child: TextFormField(
                initialValue: widget.printingSetttings.receiptFotterArb,
                style:
                    const TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
                maxLines: 3,
                decoration: const InputDecoration(
                    fillColor: Colors.white,
                    filled: true,
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(2)),
                        borderSide: BorderSide(width: 0.3)),
                    isDense: true,
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 10, horizontal: 5),
                    border: OutlineInputBorder()),
                onChanged: (val) => setState(() {
                  widget.printingSetttings.receiptFotterArb = val;
                }),
              ),
            )
          ],
        ),
      ),
      const SizedBox(
        height: 10,
      ),
      SizedBox(
        width: 331,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Header',
              style: TextStyle(fontSize: 14),
            ),
            SizedBox(
              width: 10,
            ),
            if (headerFile != null) ...[
              Image.file(
                headerFile,
                width: 100,
                errorBuilder: (context, error, stackTrace) {
                  return Icon(Icons.error);
                },
                height: 40,
              ),
              SizedBox(
                width: 5,
              )
            ],
            ElevatedButton.icon(
                icon: const Icon(Icons.upload),
                style: ElevatedButton.styleFrom(
                    elevation: 0,
                    backgroundColor: Color.fromARGB(255, 12, 65, 114),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4))),
                onPressed: () async {
                  FilePickerResult? result = await FilePicker.platform
                      .pickFiles(
                          allowMultiple: false,
                          dialogTitle: staticTextTranslate('Header Image'),
                          type: FileType.image);

                  if (result != null && result.files.first.path != null) {
                    var box = Hive.box('bitpro_app');
                    await box.put('header_img_path', result.files.first.path);

                    widget.printingSetttings.headerImgPath =
                        result.files.first.path!;

                    showToast("Header image udated successfully", context);
                    setState(() {});
                  }
                },
                label: Text(staticTextTranslate('Upload Header'),
                    style: GoogleFonts.roboto(fontSize: 14))),
          ],
        ),
      ),
      const SizedBox(
        height: 5,
      ),
      SizedBox(
        width: 331,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Fotter',
              style: TextStyle(fontSize: 14),
            ),
            SizedBox(
              width: 10,
            ),
            if (fotterFile != null)
              Image.file(
                fotterFile,
                width: 100,
                height: 40,
                errorBuilder: (context, error, stackTrace) {
                  return Icon(Icons.error);
                },
              ),
            if (fotterFile != null)
              SizedBox(
                width: 10,
              ),
            ElevatedButton.icon(
                icon: const Icon(Icons.upload),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Color.fromARGB(255, 12, 65, 114),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4))),
                onPressed: () async {
                  FilePickerResult? result = await FilePicker.platform
                      .pickFiles(
                          allowMultiple: false,
                          dialogTitle: staticTextTranslate('Upload Image'),
                          type: FileType.image);

                  if (result != null && result.files.first.path != null) {
                    var box = Hive.box('bitpro_app');
                    await box.put('fotter_img_path', result.files.first.path);

                    widget.printingSetttings.fotterImgPath =
                        result.files.first.path!;
                    showToast("Fotter image udated successfully", context);
                    setState(() {});
                  }
                },
                label: Text(staticTextTranslate('Upload Footer '),
                    style: GoogleFonts.roboto(fontSize: 14))),
          ],
        ),
      ),
      const SizedBox(
        height: 20,
      ),
      OnPageButton(
        width: 200,
        label: 'Barcode Settings',
        icon: Iconsax.scan,
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => InventoryTagSize()));
        },
      ),
      SizedBox(
        height: 10,
      ),
      SmptServerTabSettings(
        smptServerSettings: widget.smptServerSettings,
      )
    ]));
  }
}
