import 'package:bitpro_hive/services/backup_manager/backup_manager.dart';
import 'package:flutter/material.dart';

class BackupSettingView extends StatefulWidget {
  const BackupSettingView({
    super.key,
  });

  @override
  State<BackupSettingView> createState() => _BackupSettingViewState();
}

class _BackupSettingViewState extends State<BackupSettingView> {
  String backupPath = '';

  BackupManager backupManager = BackupManager();

  @override
  void initState() {
    initData();
    super.initState();
  }

  initData() async {
    //backup path
    backupPath = await backupManager.getCurrentBackupPath();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.sizeOf(context);
    return Column(
      children: [
        SizedBox(
          height: 10,
        ),
        Container(
          padding: EdgeInsets.all(15),
          width: double.maxFinite,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(3),
              border: Border.all(width: 0.3),
              color: Colors.white),
          constraints: BoxConstraints(minHeight: 200),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Backup settings'),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Text('Backup Folder : '),
                  Container(
                    padding: EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(backupPath),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  SizedBox(
                    width: size.width * 0.08,
                  ),
                  ElevatedButton(
                      onPressed: () async {
                        await backupManager.openBackupFolder();
                      },
                      style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: Color.fromARGB(255, 12, 65, 114),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4))),
                      child: Text('Open Folder')),
                  SizedBox(
                    width: 10,
                  ),
                  ElevatedButton(
                      onPressed: () async {
                        await backupManager.changeBackupDirectory();
                        backupPath = await backupManager.getCurrentBackupPath();
                        setState(() {});
                      },
                      style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: Color.fromARGB(255, 12, 65, 114),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4))),
                      child: Text('Select Folder'))
                ],
              )
            ],
          ),
        ),
      ],
    );
  }
}
