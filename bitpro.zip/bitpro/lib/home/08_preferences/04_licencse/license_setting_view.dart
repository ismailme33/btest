// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:bitpro_hive/model/settings/license_setting_data.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class LicenseSettingView extends StatefulWidget {
  final LicenseSettingData licenseSettingData;

  final TextEditingController keyController;
  final TextEditingController authController;
  const LicenseSettingView({
    Key? key,
    required this.licenseSettingData,
    required this.keyController,
    required this.authController,
  }) : super(key: key);

  @override
  State<LicenseSettingView> createState() => _LicenseSettingViewState();
}

class _LicenseSettingViewState extends State<LicenseSettingView> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          staticTextTranslate(
              'Licensed Up to: ${DateFormat('MM-dd-yyyy').format(widget.licenseSettingData.expiry_date)}'),
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: getMediumFontSize, color: Colors.grey),
        ),
        const SizedBox(
          height: 15,
        ),
        Text(
          staticTextTranslate('Key'),
          style: GoogleFonts.roboto(fontSize: 14),
        ),
        const SizedBox(
          height: 5,
        ),
        Row(
          children: [
            SizedBox(
              height: 32,
              width: 330,
              child: TextFormField(
                obscureText: true,
                controller: widget.keyController,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                style: GoogleFonts.roboto(fontSize: 14, height: 2.3),
                decoration: const InputDecoration(
                    enabledBorder:
                        OutlineInputBorder(borderSide: BorderSide(width: 0.3)),
                    fillColor: Colors.white,
                    filled: true,
                    isDense: true,
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                    border: OutlineInputBorder()),
                onChanged: (val) => setState(() {
                  if (widget.licenseSettingData.showLicenseKeyError) {
                    widget.licenseSettingData.showLicenseKeyError = false;
                  }
                  setState(() {});
                }),
              ),
            ),
            if (widget.licenseSettingData.key != widget.keyController.text)
              IconButton(
                onPressed: () {
                  widget.keyController.text = widget.licenseSettingData.key;

                  setState(() {});
                },
                splashRadius: 2,
                tooltip: staticTextTranslate('Reset key'),
                icon: const Icon(
                  Icons.restore,
                  color: Colors.grey,
                ),
              )
          ],
        ),
        const SizedBox(
          height: 5,
        ),
        if (widget.licenseSettingData.showLicenseKeyError)
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              staticTextTranslate('Please enter a valid license key'),
              style:
                  TextStyle(fontSize: getSmallFontSize, color: Colors.red[800]),
            ),
          ),
        const SizedBox(
          height: 15,
        ),
        Text(
          staticTextTranslate('Auth'),
          style: GoogleFonts.roboto(fontSize: 14),
        ),
        const SizedBox(
          height: 5,
        ),
        Row(
          children: [
            SizedBox(
              height: 32,
              width: 330,
              child: TextFormField(
                obscureText: true,
                controller: widget.authController,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                style: GoogleFonts.roboto(fontSize: 14, height: 2.3),
                decoration: const InputDecoration(
                    enabledBorder:
                        OutlineInputBorder(borderSide: BorderSide(width: 0.3)),
                    fillColor: Colors.white,
                    filled: true,
                    isDense: true,
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                    border: OutlineInputBorder()),
                onChanged: (val) => setState(() {
                  if (widget.licenseSettingData.showLicenseAuthError) {
                    widget.licenseSettingData.showLicenseAuthError = false;
                  }
                  setState(() {});
                }),
              ),
            ),
            if (widget.licenseSettingData.auth != widget.authController.text)
              IconButton(
                onPressed: () {
                  widget.authController.text = widget.licenseSettingData.auth;

                  setState(() {});
                },
                splashRadius: 2,
                tooltip: staticTextTranslate('Reset auth'),
                icon: const Icon(
                  Icons.restore,
                  color: Colors.grey,
                ),
              )
          ],
        ),
        const SizedBox(
          height: 5,
        ),
        if (widget.licenseSettingData.showLicenseAuthError)
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              staticTextTranslate('Please enter a valid license auth'),
              style:
                  TextStyle(fontSize: getSmallFontSize, color: Colors.red[800]),
            ),
          ),
        const SizedBox(
          height: 5,
        ),
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton(
              onPressed: () async {
                DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
                WindowsDeviceInfo win = await deviceInfo.windowsInfo;
                await Clipboard.setData(ClipboardData(text: win.productId));
                showToast(staticTextTranslate('Copied!'), context);
              },
              child: Text(
                staticTextTranslate('Copy Device Id'),
                style: GoogleFonts.roboto(fontSize: 14),
              )),
        ),
      ],
    ));
  }
}
