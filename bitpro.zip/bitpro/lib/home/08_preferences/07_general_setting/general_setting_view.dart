import 'package:bitpro_hive/model/settings/default_settings_data.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:flutter/material.dart';

class GeneralSettingView extends StatefulWidget {
  final GeneralSettingsData generalSettingsData;
  const GeneralSettingView({super.key, required this.generalSettingsData});

  @override
  State<GeneralSettingView> createState() => _GeneralSettingViewState();
}

class _GeneralSettingViewState extends State<GeneralSettingView> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 10,
        ),
        Container(
          padding: EdgeInsets.all(15),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(3),
              border: Border.all(width: 0.3),
              color: Colors.white),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Employee general settings'),
              SizedBox(
                height: 10,
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: SizedBox(
                  width: 290,
                  child: BTextField(
                    fieldWidth: 85,
                    textFieldReadOnly: false,
                    label: 'Expiry notification days',
                    initialValue: widget
                        .generalSettingsData.expiryNotificationDays
                        .toString(),
                    validator: ((value) {
                      if (value!.isEmpty) {
                        return staticTextTranslate('Enter employee id');
                      } else if (int.tryParse(value) == null) {
                        return staticTextTranslate(
                            'Please enter a valid number.');
                      }
                      return null;
                    }),
                    onChanged: (val) {
                      if (int.tryParse(val) == null) {
                        setState(() {
                          widget.generalSettingsData.expiryNotificationDays =
                              int.parse(val);
                        });
                      }
                    },
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                  ),
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Checkbox(
                      activeColor: darkBlueColor,
                      side: const BorderSide(width: 0.7),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4)),
                      value: widget.generalSettingsData.isHijriDateEnable,
                      onChanged: (val) {
                        setState(() {
                          widget.generalSettingsData.isHijriDateEnable = val!;
                        });
                      }),
                  InkWell(
                    onTap: () {
                      setState(() {
                        widget.generalSettingsData.isHijriDateEnable =
                            !widget.generalSettingsData.isHijriDateEnable;
                      });
                    },
                    child: Text(staticTextTranslate('Enable Hijri Date'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(staticTextTranslate('Fields to show in receipt'),
                    style: TextStyle(
                      fontSize: getMediumFontSize,
                    )),
              ),
              SizedBox(
                height: 5,
              ),
              Row(
                children: [
                  Checkbox(
                      activeColor: darkBlueColor,
                      side: const BorderSide(width: 0.7),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4)),
                      value:
                          widget.generalSettingsData.showBarcodeInReceiptCreate,
                      onChanged: (val) {
                        setState(() {
                          widget.generalSettingsData
                              .showBarcodeInReceiptCreate = val!;
                        });
                      }),
                  InkWell(
                    onTap: () {
                      setState(() {
                        widget.generalSettingsData.showBarcodeInReceiptCreate =
                            !widget
                                .generalSettingsData.showBarcodeInReceiptCreate;
                      });
                    },
                    child: Text(staticTextTranslate('Barcode'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Checkbox(
                      activeColor: darkBlueColor,
                      side: const BorderSide(width: 0.7),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4)),
                      value: widget
                          .generalSettingsData.showItemCodeInReceiptCreate,
                      onChanged: (val) {
                        setState(() {
                          widget.generalSettingsData
                              .showItemCodeInReceiptCreate = val!;
                        });
                      }),
                  InkWell(
                    onTap: () {
                      setState(() {
                        widget.generalSettingsData.showItemCodeInReceiptCreate =
                            !widget.generalSettingsData
                                .showItemCodeInReceiptCreate;
                      });
                    },
                    child: Text(staticTextTranslate('Item Code'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  ),
                  SizedBox(
                    width: 10,
                  ),
                  Checkbox(
                      activeColor: darkBlueColor,
                      side: const BorderSide(width: 0.7),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4)),
                      value: widget
                          .generalSettingsData.showOriginalPriceInReceiptCreate,
                      onChanged: (val) {
                        setState(() {
                          widget.generalSettingsData
                              .showOriginalPriceInReceiptCreate = val!;
                        });
                      }),
                  InkWell(
                    onTap: () {
                      setState(() {
                        widget.generalSettingsData
                                .showOriginalPriceInReceiptCreate =
                            !widget.generalSettingsData
                                .showOriginalPriceInReceiptCreate;
                      });
                    },
                    child: Text(staticTextTranslate('Original Price'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  ),
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Row(children: [
                Checkbox(
                    activeColor: darkBlueColor,
                    side: const BorderSide(width: 0.7),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4)),
                    value: widget
                        .generalSettingsData.showOverallDiscountInReceiptCreate,
                    onChanged: (val) {
                      setState(() {
                        widget.generalSettingsData
                            .showOverallDiscountInReceiptCreate = val!;
                      });
                    }),
                InkWell(
                  onTap: () {
                    setState(() {
                      widget.generalSettingsData
                              .showOverallDiscountInReceiptCreate =
                          !widget.generalSettingsData
                              .showOverallDiscountInReceiptCreate;
                    });
                  },
                  child: Text(
                      staticTextTranslate(
                          'Show Cart Discount On Receipt Create'),
                      style: TextStyle(
                        fontSize: getMediumFontSize,
                      )),
                ),
              ]),
              SizedBox(
                height: 10,
              ),
              Row(
                children: [
                  Checkbox(
                      activeColor: darkBlueColor,
                      side: const BorderSide(width: 0.7),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4)),
                      value: widget.generalSettingsData
                          .showOverallDiscountPerTabInReceiptCreate,
                      onChanged: (val) {
                        setState(() {
                          widget.generalSettingsData
                              .showOverallDiscountPerTabInReceiptCreate = val!;
                        });
                      }),
                  InkWell(
                    onTap: () {
                      setState(() {
                        widget.generalSettingsData
                                .showOverallDiscountPerTabInReceiptCreate =
                            !widget.generalSettingsData
                                .showOverallDiscountPerTabInReceiptCreate;
                      });
                    },
                    child: Text(
                        staticTextTranslate(
                            'Show Cart "Discount Percent" Tab In Receipt Create'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
