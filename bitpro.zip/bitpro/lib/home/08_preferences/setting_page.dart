import 'package:bitpro_hive/home/08_preferences/01_company_setting/company_setting_tab.dart';
import 'package:bitpro_hive/home/08_preferences/02_printing_setting/printing_setting.dart';
import 'package:bitpro_hive/home/08_preferences/03_tax_setting/tax_setting_page.dart';
import 'package:bitpro_hive/home/08_preferences/04_licencse/license_setting_view.dart';
import 'package:bitpro_hive/home/08_preferences/06_receipt_setting/resceipt_setting_view.dart';
import 'package:bitpro_hive/home/08_preferences/07_general_setting/general_setting_view.dart';
import 'package:bitpro_hive/home/08_preferences/08_backup_setting/backup_setting_view.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/settings/company_details_settings.dart';
import 'package:bitpro_hive/model/settings/default_settings_data.dart';
import 'package:bitpro_hive/model/settings/license_setting_data.dart';
import 'package:bitpro_hive/model/settings/printing_setttings.dart';
import 'package:bitpro_hive/model/settings/receipt_details_data.dart';
import 'package:bitpro_hive/model/settings/smpt_server_settings.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/services/backup_manager/backup_manager.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:iconsax/iconsax.dart';
import 'package:printing/printing.dart';
import 'package:bitpro_hive/home/08_preferences/05_stores/add_edit_store/add_edit_store.dart';
import 'package:bitpro_hive/home/08_preferences/05_stores/store_tab.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_settings_db_service.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/shared/toast.dart';
import '../../shared/global_variables/font_sizes.dart';
import '../../shared/global_variables/static_text_translate.dart';

class SettingsPage extends StatefulWidget {
  final EmployeeData? userData;

  const SettingsPage({super.key, required this.userData});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool loading = true;
  int currentTabIndex = 0;
  //company settings
  late CompanyDetailsSettings companyDetailsSettings;

  //printing setting
  late PrintingSetttings printingSetttings;
  List<Printer> allPrinterLst = [];

  //server
  late SmptServerSettings smptServerSettings;

  //Tax percentage
  late TaxSettingsData taxSettingsData;

  late LicenseSettingData licenseSettingData;

  TextEditingController keyController = TextEditingController();
  TextEditingController authController = TextEditingController();

  //store tab fields
  StoreData? selectedStore;
  bool alowDeleteStore = true;
  List<StoreData> storeDataList = [];
  late StoreData defaultSelectedStoreData;

  //receipt tab fields
  late ReceiptSettingData receiptSettingData;

  //dafault setting
  late GeneralSettingsData generalSettingsData;

  final _formKey = GlobalKey<FormState>();
  var box = Hive.box('bitpro_app');
  @override
  void initState() {
    super.initState();
    initData();
  }

  initData() async {
    //getting company settings
    companyDetailsSettings =
        await HiveSettingsDbService().getCompanySettingsData();
    storeDataList = await HiveStoreDbService().fetchAllStoresData();
    defaultSelectedStoreData =
        await HiveStoreDbService().getSelectedStoreData();

    //getting printing settings
    allPrinterLst = await Printing.listPrinters();
    printingSetttings = await HiveSettingsDbService().getPrintingSettingsData();
    smptServerSettings =
        await HiveSettingsDbService().getSmtpServerSettingsData();

    //tax percentage
    taxSettingsData = await HiveSettingsDbService().getTaxSettingsData();

    //License data
    licenseSettingData = (await HiveSettingsDbService().getLicesnseSettingsData(
        context: context, resetIfLicenseIsNull: true))!;
    keyController.text = licenseSettingData.key;
    authController.text = licenseSettingData.auth;

    //
    receiptSettingData = await HiveSettingsDbService().getReceiptSettingsData();

    //general settings
    generalSettingsData =
        await HiveSettingsDbService().getGeneralSettingsData();

    setState(() {
      loading = false;
    });
  }

  fbStoreDataUpdate() async {
    setState(() {
      loading = true;
    });
    storeDataList = await HiveStoreDbService().fetchAllStoresData();

    setState(() {
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return showLoading();

    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 35,
                decoration: const BoxDecoration(
                    gradient: LinearGradient(
                        end: Alignment.bottomCenter,
                        colors: [
                          Color.fromARGB(255, 51, 51, 51),
                          Color.fromARGB(255, 51, 51, 51),
                        ],
                        begin: Alignment.topCenter)),
                child: Row(
                  children: [
                    InkWell(
                      onTap: () {
                        setState(() {
                          currentTabIndex = 0;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 0),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.6),
                            borderRadius: BorderRadius.circular(0),
                            gradient: currentTabIndex != 0
                                ? null
                                : const LinearGradient(
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 12, 65, 114),
                                      Color.fromARGB(255, 12, 65, 114),
                                    ],
                                    begin: Alignment.topCenter)),
                        child: Center(
                          child: Text(
                            staticTextTranslate('Company Details'),
                            style: GoogleFonts.roboto(
                                fontSize: 14, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          currentTabIndex = 1;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 0),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.6),
                            gradient: currentTabIndex != 1
                                ? null
                                : const LinearGradient(
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 12, 65, 114),
                                      Color.fromARGB(255, 12, 65, 114),
                                    ],
                                    begin: Alignment.topCenter)),
                        height: 35,
                        child: Center(
                          child: Text(
                            staticTextTranslate('Printing'),
                            style: GoogleFonts.roboto(
                                fontSize: 14, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          currentTabIndex = 2;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 0),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.6),
                            gradient: currentTabIndex != 2
                                ? null
                                : const LinearGradient(
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 12, 65, 114),
                                      Color.fromARGB(255, 12, 65, 114),
                                    ],
                                    begin: Alignment.topCenter)),
                        height: 35,
                        child: Center(
                          child: Text(
                            staticTextTranslate('Taxes'),
                            style: GoogleFonts.roboto(
                                fontSize: 14, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          currentTabIndex = 3;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 0),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.6),
                            gradient: currentTabIndex != 3
                                ? null
                                : const LinearGradient(
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 12, 65, 114),
                                      Color.fromARGB(255, 12, 65, 114),
                                    ],
                                    begin: Alignment.topCenter)),
                        height: 35,
                        child: Center(
                          child: Center(
                            child: Text(
                              staticTextTranslate('License'),
                              style: GoogleFonts.roboto(
                                  fontSize: 14, color: Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          currentTabIndex = 4;
                          selectedStore = null;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 0),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.6),
                            gradient: currentTabIndex != 4
                                ? null
                                : const LinearGradient(
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 12, 65, 114),
                                      Color.fromARGB(255, 12, 65, 114),
                                    ],
                                    begin: Alignment.topCenter)),
                        height: 35,
                        child: Center(
                          child: Text(
                            staticTextTranslate('Store'),
                            style: GoogleFonts.roboto(
                                fontSize: 14, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          currentTabIndex = 5;
                          selectedStore = null;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 0),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.6),
                            gradient: currentTabIndex != 5
                                ? null
                                : const LinearGradient(
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 12, 65, 114),
                                      Color.fromARGB(255, 12, 65, 114),
                                    ],
                                    begin: Alignment.topCenter)),
                        height: 35,
                        child: Center(
                          child: Text(
                            staticTextTranslate('Receipt'),
                            style: GoogleFonts.roboto(
                                fontSize: 14, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          currentTabIndex = 6;
                          selectedStore = null;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 4),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.6),
                            gradient: currentTabIndex != 6
                                ? null
                                : const LinearGradient(
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 12, 65, 114),
                                      Color.fromARGB(255, 12, 65, 114),
                                    ],
                                    begin: Alignment.topCenter)),
                        height: 35,
                        child: Center(
                          child: Text(
                            staticTextTranslate('General'),
                            style: GoogleFonts.roboto(
                                fontSize: 14, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        setState(() {
                          currentTabIndex = 7;
                          selectedStore = null;
                        });
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 4),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.6),
                            gradient: currentTabIndex != 7
                                ? null
                                : const LinearGradient(
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 12, 65, 114),
                                      Color.fromARGB(255, 12, 65, 114),
                                    ],
                                    begin: Alignment.topCenter)),
                        height: 35,
                        child: Center(
                          child: Text(
                            staticTextTranslate('Backup'),
                            style: GoogleFonts.roboto(
                                fontSize: 14, color: Colors.white),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
          Expanded(
            child: Padding(
                padding: const EdgeInsets.only(top: 10, left: 15, right: 15),
                child: currentTabIndex == 0
                    ? CompanySettingTab(
                        companyDetailsSettings: companyDetailsSettings,
                        defaultSelectedStoreData: defaultSelectedStoreData,
                      )
                    : currentTabIndex == 1
                        ? PrintingTab02(
                            smptServerSettings: smptServerSettings,
                            allPrinterLst: allPrinterLst,
                            printingSetttings: printingSetttings,
                          )
                        : currentTabIndex == 2
                            ? TaxSettingPage(taxSettingsData: taxSettingsData)
                            : currentTabIndex == 3
                                ? LicenseSettingView(
                                    authController: authController,
                                    keyController: keyController,
                                    licenseSettingData: licenseSettingData,
                                  )
                                : currentTabIndex == 4
                                    ? SettingStoreTab(
                                        storeDataList: storeDataList,
                                        selectStore:
                                            (StoreData? selectedStoreData) {
                                          selectedStore = selectedStoreData;
                                          setState(() {});
                                        },
                                      )
                                    : currentTabIndex == 5
                                        ? ResceiptSettingView(
                                            receiptSettingData:
                                                receiptSettingData)
                                        : currentTabIndex == 6
                                            ? GeneralSettingView(
                                                generalSettingsData:
                                                    generalSettingsData,
                                              )
                                            : BackupSettingView()),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              margin: EdgeInsets.only(top: 10),
              padding: EdgeInsets.all(10),
              width: double.maxFinite,
              color: Colors.grey,
              child: currentTabIndex == 4
                  ? storeTabButtons()
                  : Row(
                      children: [
                        OnPageButton(
                          icon: Iconsax.archive,
                          label: 'Save',
                          onPressed: () async {
                            setState(() {
                              loading = true;
                            });

                            if (currentTabIndex == 0) {
                              await HiveSettingsDbService()
                                  .addUpdateCompanySettingsData(
                                      companyDetailsSettings:
                                          companyDetailsSettings);
                            } else if (currentTabIndex == 1) {
                              await HiveSettingsDbService()
                                  .addUpdatePrintingSmtpSettings(
                                      printingSetttings: printingSetttings,
                                      smptServerSettings: smptServerSettings);
                            } else if (currentTabIndex == 2) {
                              await HiveSettingsDbService()
                                  .addUpdateTab3SettingsData(
                                      taxSettingsData: taxSettingsData);
                            } else if (currentTabIndex == 3) {
                              //null = empty string, -1 = key invalid, -2 = auth invalid, -3 = key & auth invalid
                              int? res = await HiveSettingsDbService()
                                  .checkLicenseKeyAuthIsValid(
                                      key: licenseSettingData.key,
                                      auth: licenseSettingData.auth);
                              if (res == null || res == -1 || res == -3) {
                                licenseSettingData.showLicenseKeyError = true;
                              }
                              if (res == null || res == -2 || res == -3) {
                                licenseSettingData.showLicenseAuthError = true;
                              }

                              licenseSettingData.expiry_date =
                                  DateTime.now().add(Duration(days: res!));

                              await HiveSettingsDbService()
                                  .addUpdateLicenseSettingsData(
                                      licenseSettingData: licenseSettingData);
                            } else if (currentTabIndex == 5) {
                              //receipt settings
                              await HiveSettingsDbService()
                                  .addUpdateReceiptSettingsData(
                                      receiptSettingData: receiptSettingData);
                            } else if (currentTabIndex == 6 &&
                                _formKey.currentState!.validate()) {
                              await HiveSettingsDbService()
                                  .addUpdateGenearalSettingsData(
                                      generalSettingsData: generalSettingsData);
                            }
                            showToast(
                                staticTextTranslate(
                                    'Settings saved, successfully'),
                                context);

                            setState(() {
                              loading = false;
                            });
                          },
                        ),
                      ],
                    ),
            ),
          )
        ],
      ),
    );
  }

  storeTabButtons() {
    return Row(
      children: [
        const SizedBox(
          width: 0,
        ),
        Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                gradient: const LinearGradient(
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromARGB(255, 12, 65, 114),
                      Color.fromARGB(255, 12, 65, 114),
                    ],
                    begin: Alignment.topCenter)),
            width: 38,
            height: 38,
            child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  elevation: 0,
                  padding: EdgeInsets.zero,
                  backgroundColor: Colors.transparent,
                ),
                onPressed: () {
                  fbStoreDataUpdate();
                },
                child: const Center(
                  child: Icon(
                    Icons.refresh,
                  ),
                ))),
        const SizedBox(
          width: 10,
        ),
        OnPageButton(
          label: 'Add Store',
          icon: Iconsax.add,
          onPressed: () async {
            bool res = await Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) =>
                        AddEditStore(storeDataLst: storeDataList)));

            if (res) {
              await fbStoreDataUpdate();
            }
          },
        ),
        const SizedBox(
          width: 10,
        ),
        Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              gradient: const LinearGradient(
                  end: Alignment.bottomCenter,
                  colors: [
                    Color.fromARGB(255, 12, 65, 114),
                    Color.fromARGB(255, 12, 65, 114),
                  ],
                  begin: Alignment.topCenter)),
          height: 38,
          width: 173,
          child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                  elevation: 0,
                  backgroundColor: Colors.transparent,
                  disabledBackgroundColor: Colors.grey[300],
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4))),
              onPressed: selectedStore == null
                  ? null
                  : () async {
                      bool res = await Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => AddEditStore(
                                    storeDataLst: storeDataList,
                                    editData: true,
                                    storeData: selectedStore,
                                  )));

                      if (res) {
                        await fbStoreDataUpdate();
                      }
                    },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Iconsax.edit,
                    size: 20,
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Text(
                    staticTextTranslate('Edit Store'),
                    style: TextStyle(
                      fontSize: getMediumFontSize,
                    ),
                  ),
                ],
              )),
        ),
      ],
    );
  }
}
