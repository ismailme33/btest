// import 'dart:async';

// import 'package:bitpro_hive/model/store_data.dart';
// import 'package:bitpro_hive/mysql_backend_setup/firebase_backend_setup.dart';
// import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';

// import 'package:bitpro_hive/shared/constant_data.dart';
// import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
// import 'package:bitpro_hive/shared/loading.dart';
// import 'package:bitpro_hive/shared/toast.dart';
// import 'package:bitpro_hive/widget/bTextField.dart';
// import 'package:bitpro_hive/wrapper.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:hive/hive.dart';
// import 'package:internet_connection_checker_plus/internet_connection_checker_plus.dart';

// class MysqlBackendSettings extends StatefulWidget {
//   final List<StoreData> tStoreDataList;
//   const MysqlBackendSettings({super.key, required this.tStoreDataList});

//   @override
//   State<MysqlBackendSettings> createState() => _MysqlBackendSettingsState();
// }

// class _MysqlBackendSettingsState extends State<MysqlBackendSettings> {
//   bool isLoading = true;
//   var formKey = GlobalKey<FormState>();

//   //Mysql Backend
//   Map<dynamic, dynamic>? _mysqlServerInfo;

//   late int fbFetchAndUpdateTimerInMin;

//   String fetchingInfo = '';
//   String updatingInfo = '';
//   bool online = true;
//   late StreamSubscription listener;
//   @override
//   void initState() {
//     listener =
//         InternetConnection().onStatusChange.listen((InternetStatus status) {
//       switch (status) {
//         case InternetStatus.connected:
//           // The internet is now connected
//           setState(() {
//             online = true;
//           });
//           break;
//         case InternetStatus.disconnected:
//           // The internet is now disconnected
//           setState(() {
//             online = false;
//           });
//           break;
//       }
//     });

//     initData();

//     super.initState();
//   }

//   @override
//   void dispose() {
//     listener.cancel();
//     super.dispose();
//   }

//   initData() async {
//     var box = Hive.box('bitpro_app');
//     _mysqlServerInfo = await box.get('Server_Data');
//     print(_mysqlServerInfo);
//     fbFetchAndUpdateTimerInMin =
//         (await box.get('fbFetchAndUpdateTimerInMin')) ??
//             defaultFbFetchAndUpdateTimerInMin;

//     if (_mysqlServerInfo != null &&
//         _mysqlServerInfo!['mysqlSetupDone'] &&
//         _mysqlServerInfo!['workstationSetupDone']) {
//       int selectedStoreCode = await HiveStoreDbService().getSelectedStoreCode();
//       int workstationNumber = await HiveStoreDbService().getWorkstationNumber();

//       int i = widget.tStoreDataList.indexWhere(
//           (element) => element.storeCode == selectedStoreCode.toString());

//       if (i != -1) {
//         _mysqlServerInfo!['defaultStore'] =
//             widget.tStoreDataList.elementAt(i).storeName;
//       }

//       _mysqlServerInfo!['workstationNumber'] = workstationNumber;
//     }
//     setState(() {
//       isLoading = false;
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       height: _mysqlServerInfo != null && _mysqlServerInfo!['mysqlSetupDone']
//           ? 270
//           : 150,
//       padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
//       decoration: BoxDecoration(
//           color: Colors.white,
//           borderRadius: BorderRadius.circular(4),
//           border: Border.all(
//               color: const Color.fromARGB(255, 0, 0, 0), width: 0.3)),
//       child: isLoading
//           ? Expanded(child: showLoading())
//           : Row(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Image.asset(
//                   'assets/icons/update.png',
//                   width: 30,
//                 ),
//                 const SizedBox(
//                   width: 15,
//                 ),
//                 Expanded(
//                   child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Align(
//                           alignment: Alignment.centerLeft,
//                           child: Text(
//                             'MySql Database',
//                             style: GoogleFonts.roboto(
//                                 fontSize: 18, fontWeight: FontWeight.bold),
//                           ),
//                         ),
//                         const SizedBox(
//                           height: 5,
//                         ),
//                         Row(
//                           children: [
//                             Text(
//                               'Status : ',
//                             ),
//                             if (_mysqlServerInfo != null &&
//                                 _mysqlServerInfo!['mysqlSetupDone'] &&
//                                 online)
//                               Row(
//                                 children: [
//                                   CircleAvatar(
//                                     radius: 5,
//                                     backgroundColor: Colors.green,
//                                   ),
//                                   SizedBox(
//                                     width: 4,
//                                   ),
//                                   Text(
//                                     'Online',
//                                   ),
//                                 ],
//                               )
//                             else
//                               Row(
//                                 children: [
//                                   CircleAvatar(
//                                     radius: 5,
//                                     backgroundColor: Colors.red,
//                                   ),
//                                   SizedBox(
//                                     width: 4,
//                                   ),
//                                   Text(
//                                     _mysqlServerInfo != null &&
//                                             _mysqlServerInfo!['mysqlSetupDone']
//                                         ? 'Ofline'
//                                         : "Not Connected",
//                                   ),
//                                 ],
//                               )
//                           ],
//                         ),
//                         const SizedBox(
//                           height: 10,
//                         ),
//                         if (_mysqlServerInfo != null &&
//                             _mysqlServerInfo!['mysqlSetupDone'])
//                           Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               const SizedBox(
//                                 height: 10,
//                               ),
//                               Text(
//                                 'Host Url : ${_mysqlServerInfo!['host']}',
//                                 style: TextStyle(fontSize: 12),
//                               ),
//                               const SizedBox(
//                                 height: 5,
//                               ),
//                               Text(
//                                 'Port : ${_mysqlServerInfo!['port']}',
//                                 style: TextStyle(fontSize: 12),
//                               ),
//                               const SizedBox(
//                                 height: 5,
//                               ),
//                               Text(
//                                 'User : ${_mysqlServerInfo!['user']}',
//                                 style: TextStyle(fontSize: 12),
//                               ),
//                               const SizedBox(
//                                 height: 5,
//                               ),
//                               if (_mysqlServerInfo!['password'] != null)
//                                 Text(
//                                   'Password : XXXXXXX',
//                                   style: TextStyle(fontSize: 12),
//                                 ),
//                               const SizedBox(
//                                 height: 5,
//                               ),
//                               Text(
//                                 'Default Store : ${_mysqlServerInfo!['defaultStore']}',
//                                 style: TextStyle(fontSize: 12),
//                               ),
//                               const SizedBox(
//                                 height: 5,
//                               ),
//                               Text(
//                                 'Workstation Number : ${_mysqlServerInfo!['workstationNumber']}',
//                                 style: TextStyle(fontSize: 12),
//                               ),
//                               const SizedBox(
//                                 height: 5,
//                               ),
//                             ],
//                           ),
//                         SizedBox(
//                           height: 10,
//                         ),
//                         Row(
//                           children: [
//                             OutlinedButton(
//                               onPressed: () async {
//                                 // Navigator.push(
//                                 //     context,
//                                 //     MaterialPageRoute(
//                                 //         builder: (context) =>
//                                 //             const MySqlBackendSetupPage(
//                                 //               isChangeOrMergingDatabase: true,
//                                 //             )));
//                               },
//                               child: Text(
//                                 staticTextTranslate(_mysqlServerInfo != null
//                                     ? 'Change Database'
//                                     : 'Connect Cloud Database'),
//                                 style: GoogleFonts.roboto(fontSize: 14),
//                               ),
//                             ),
//                           ],
//                         ),
//                         const SizedBox(
//                           height: 10,
//                         ),
//                         // if (_mysqlServerInfo != null)
//                         //   Form(
//                         //     key: formKey,
//                         //     child: Row(
//                         //       children: [
//                         //         SizedBox(
//                         //           width: 350,
//                         //           child: BTextField(
//                         //             textFieldReadOnly: false,
//                         //             label: 'Timer (In Min)',
//                         //             initialValue:
//                         //                 fbFetchAndUpdateTimerInMin.toString(),
//                         //             validator: (value) {
//                         //               if (value == null || value.isEmpty) {
//                         //                 return staticTextTranslate(
//                         //                     'Enter a value');
//                         //               } else if (int.tryParse(value) == null) {
//                         //                 return staticTextTranslate(
//                         //                     'Enter a valid value');
//                         //               }
//                         //               return null;
//                         //             },
//                         //             onChanged: (val) {
//                         //               if (val.isNotEmpty &&
//                         //                   int.tryParse(val) != null) {
//                         //                 setState(() {
//                         //                   fbFetchAndUpdateTimerInMin =
//                         //                       int.parse(val);
//                         //                 });
//                         //               }
//                         //             },
//                         //             autovalidateMode:
//                         //                 AutovalidateMode.onUserInteraction,
//                         //           ),
//                         //         ),
//                         //         const SizedBox(
//                         //           width: 10,
//                         //         ),
//                         //         OutlinedButton(
//                         //             onPressed: () async {
//                         //               if (formKey.currentState!.validate()) {
//                         //                 setState(() {
//                         //                   isLoading = true;
//                         //                 });
//                         //                 var box = Hive.box('bitpro_app');
//                         //                 await box.put(
//                         //                     'fbFetchAndUpdateTimerInMin',
//                         //                     fbFetchAndUpdateTimerInMin);
//                         //                 showToast('Timer udpated', context);
//                         //                 setState(() {
//                         //                   isLoading = false;
//                         //                 });

//                         //                 Navigator.pushAndRemoveUntil(
//                         //                   context,
//                         //                   MaterialPageRoute(
//                         //                       builder: (BuildContext context) =>
//                         //                           const Wrapper()),
//                         //                   ModalRoute.withName('/'),
//                         //                 );
//                         //               }
//                         //             },
//                         //             child: const Text('Update'))
//                         //       ],
//                         //     ),
//                         //   ),
//                       ]),
//                 ),
//                 Container(
//                     width: 600,
//                     decoration: BoxDecoration(
//                         // color: Colors.grey.shade100,
//                         border: Border.all()),
//                     padding: EdgeInsets.all(8),
//                     child: SingleChildScrollView(
//                         child: Column(children: [
//                       OutlinedButton(
//                         onPressed: () async {
//                           // fetchingInfo = "Fetching Please wait....";
//                           // updatingInfo = "";
//                           // fetchingInfo =
//                           //     await FetchingMysqlDataService(context: context)
//                           //         .fetchData();
//                           // updatingInfo = "Updating Please wait....";
//                           // setState(() {});

//                           // updatingInfo =
//                           //     await UpdatingMysqlDataService(context: context)
//                           //         .udpatingHiveDataInFirebase();
//                           // setState(() {});
//                         },
//                         child: Text(
//                           staticTextTranslate('Fetch & Update data in Backend'),
//                           style: GoogleFonts.roboto(fontSize: 14),
//                         ),
//                       ),
//                       SizedBox(
//                         height: 10,
//                       ),
//                       Row(
//                         children: [
//                           Text('Fetching info\n\n$fetchingInfo'),
//                           SizedBox(
//                             width: 10,
//                           ),
//                           Text('Updating info\n\n$updatingInfo'),
//                         ],
//                       ),
//                     ])))
//               ],
//             ),
//     );
//   }
// }
