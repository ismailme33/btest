import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class StoreMoreInfoWidget extends StatefulWidget {
  final StoreData storeData;
  final Function refreshFunction;

  const StoreMoreInfoWidget(
      {super.key, required this.storeData, required this.refreshFunction});

  @override
  State<StoreMoreInfoWidget> createState() => _StoreMoreInfoWidgetState();
}

class _StoreMoreInfoWidgetState extends State<StoreMoreInfoWidget> {
  FocusNode area = FocusNode();
  FocusNode country = FocusNode();
  FocusNode city = FocusNode();
  FocusNode buildingNumber = FocusNode();
  FocusNode postCode = FocusNode();
  FocusNode additionalNumber = FocusNode();
  FocusNode shortAddress = FocusNode();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(
            children: [
              BTextField(
                prefixIcon: Icons.flag,
                fieldWidth: 175,
                label: 'Country',
                focusNode: country,
                onFieldSubmitted: (v) {
                  city.requestFocus();
                },
                initialValue: widget.storeData.country,
                onChanged: (val) {
                  widget.storeData.country = val;
                  widget.refreshFunction();
                },
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
              const SizedBox(
                width: 10,
              ),
              BTextField(
                prefixIcon: Icons.location_city,
                fieldWidth: 175,
                label: 'City',
                focusNode: city,
                onFieldSubmitted: (v) {
                  buildingNumber.requestFocus();
                },
                initialValue: widget.storeData.city,
                onChanged: (val) {
                  widget.storeData.city = val;
                  widget.refreshFunction();
                },
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
            ],
          ),
          Row(
            children: [
              BTextField(
                fieldWidth: 175,
                label: 'Street',
                initialValue: widget.storeData.street,
                onFieldSubmitted: (v) {
                  area.requestFocus();
                },
                onChanged: (val) {
                  widget.storeData.street = val;
                  widget.refreshFunction();
                },
              ),
              SizedBox(
                width: 10,
              ),
              BTextField(
                prefixIcon: Icons.map,
                fieldWidth: 175,
                label: 'Area',
                focusNode: area,
                onFieldSubmitted: (v) {
                  country.requestFocus();
                },
                initialValue: widget.storeData.area,
                onChanged: (val) {
                  widget.storeData.area = val;
                  widget.refreshFunction();
                },
              ),
            ],
          ),
          Row(
            children: [
              BTextField(
                prefixIcon: Icons.home,
                fieldWidth: 175,
                label: 'Building Number',
                focusNode: buildingNumber,
                onFieldSubmitted: (v) {
                  postCode.requestFocus();
                },
                initialValue: widget.storeData.buildingNumber,
                onChanged: (val) {
                  widget.storeData.buildingNumber = val;
                  widget.refreshFunction();
                },
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
              const SizedBox(
                width: 10,
              ),
              BTextField(
                fieldWidth: 175,
                label: 'Post Code',
                focusNode: postCode,
                onFieldSubmitted: (v) {
                  additionalNumber.requestFocus();
                },
                initialValue: widget.storeData.postCode,
                onChanged: (val) {
                  widget.storeData.postCode = val;
                  widget.refreshFunction();
                },
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
            ],
          ),
          Row(
            children: [
              BTextField(
                fieldWidth: 175,
                label: 'Additional Number',
                focusNode: additionalNumber,
                onFieldSubmitted: (v) {
                  shortAddress.requestFocus();
                },
                initialValue: widget.storeData.additionalNumber,
                onChanged: (val) {
                  widget.storeData.additionalNumber = val;
                  widget.refreshFunction();
                },
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
              const SizedBox(
                width: 10,
              ),
              BTextField(
                fieldWidth: 175,
                label: 'Short Address',
                focusNode: shortAddress,
                initialValue: widget.storeData.shortAddress,
                onChanged: (val) {
                  widget.storeData.shortAddress = val;
                  widget.refreshFunction();
                },
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
