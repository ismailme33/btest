import 'dart:io';

import 'package:bitpro_hive/home/08_preferences/05_stores/add_edit_store/box_1/02_more_info_widget.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';

class StoreDetailsWidget extends StatefulWidget {
  final StoreData storeData;
  final Function onTabSaveFunction;

  const StoreDetailsWidget(
      {super.key, required this.storeData, required this.onTabSaveFunction});

  @override
  State<StoreDetailsWidget> createState() => _StoreDetailsWidgetState();
}

class _StoreDetailsWidgetState extends State<StoreDetailsWidget> {
  bool isLoading = false;

  bool loading = false;
  File? productImage;

  var formKey = GlobalKey<FormState>();

  FocusNode storeName = FocusNode();
  FocusNode arabicName = FocusNode();
  FocusNode subName = FocusNode();
  FocusNode address = FocusNode();
  FocusNode phone1 = FocusNode();
  FocusNode phone2 = FocusNode();
  FocusNode email = FocusNode();
  FocusNode vatNumber = FocusNode();
  FocusNode crNumber = FocusNode();
  FocusNode priceLevel = FocusNode();
  FocusNode bamkName = FocusNode();
  FocusNode accountNumber = FocusNode();
  FocusNode note = FocusNode();

  int selectedTabIndex = 0;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: 410,
        decoration: BoxDecoration(
            border: Border.all(width: 0.3),
            color: const Color(0xffE2E2E2),
            borderRadius: BorderRadius.circular(3)),
        child: isLoading
            ? showLoading(withScaffold: true)
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 35,
                    // padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(4),
                          topRight: Radius.circular(4)),
                      gradient: LinearGradient(
                          end: Alignment.bottomCenter,
                          colors: [
                            Color.fromARGB(255, 66, 66, 66),
                            Color.fromARGB(255, 0, 0, 0),
                          ],
                          begin: Alignment.topCenter),
                    ),
                    child: Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedTabIndex = 0;
                            });
                          },
                          child: Container(
                            width: 120,
                            height: 35,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                gradient: selectedTabIndex == 0
                                    ? LinearGradient(
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Color(0xff092F53),
                                          Color(0xff284F70),
                                        ],
                                        begin: Alignment.topCenter)
                                    : null),
                            alignment: Alignment.center,
                            child: Text(
                              staticTextTranslate(
                                "Store Details",
                              ),
                              style: GoogleFonts.roboto(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              selectedTabIndex = 1;
                            });
                          },
                          child: Container(
                            width: 120,
                            height: 35,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(4),
                                gradient: selectedTabIndex == 1
                                    ? LinearGradient(
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Color(0xff092F53),
                                          Color(0xff284F70),
                                        ],
                                        begin: Alignment.topCenter)
                                    : null),
                            alignment: Alignment.center,
                            child: Text(
                              staticTextTranslate(
                                "More Info",
                              ),
                              style: GoogleFonts.roboto(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(
                      child: selectedTabIndex == 0
                          ? fieldsWidget()
                          : StoreMoreInfoWidget(
                              storeData: widget.storeData,
                              refreshFunction: () {
                                setState(() {});
                              })),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      height: 60,
                      width: double.maxFinite,
                      decoration: const BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(3),
                          bottomRight: Radius.circular(3),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            OnPageButton(
                              icon: Iconsax.archive,
                              label: 'Save',
                              onPressed: () {
                                widget.onTabSaveFunction();
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
      ),
    );
  }

  fieldsWidget() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          BTextField(
            fieldWidth: 175,
            textFieldReadOnly: true,
            label: 'Store Code',
            initialValue: widget.storeData.storeCode,
            onChanged: (val) => setState(() {
              widget.storeData.storeCode = val;
            }),
            autovalidateMode: AutovalidateMode.onUserInteraction,
          ),
          BTextField(
            keyboardType: TextInputType.multiline,
            textFieldHeight: null,
            prefixIcon: Icons.store,
            textFieldReadOnly: false,
            label: 'Store Name',
            focusNode: storeName,
            onFieldSubmitted: (v) {
              arabicName.requestFocus();
            },
            initialValue: widget.storeData.storeName,
            validator: ((value) {
              if (value == null || value.isEmpty) {
                return staticTextTranslate('Enter store name');
              }
              return null;
            }),
            onChanged: (val) => setState(() {
              widget.storeData.storeName = val;
            }),
            autovalidateMode: AutovalidateMode.onUserInteraction,
          ),
          BTextField(
            keyboardType: TextInputType.multiline,
            textFieldHeight: null,
            prefixIcon: Icons.store,
            textFieldReadOnly: false,
            label: 'Store Name (Second Language)',
            focusNode: arabicName,
            onFieldSubmitted: (v) {
              subName.requestFocus();
            },
            initialValue: widget.storeData.storeArabicName,
            onChanged: (val) => setState(() {
              widget.storeData.storeArabicName = val;
            }),
          ),
          BTextField(
            textFieldReadOnly: false,
            label: 'Sub Name',
            focusNode: subName,
            onFieldSubmitted: (v) {
              address.requestFocus();
            },
            initialValue: widget.storeData.subName,
            onChanged: (val) => setState(() {
              widget.storeData.subName = val;
            }),
            autovalidateMode: AutovalidateMode.onUserInteraction,
          ),
          BTextField(
            textFieldReadOnly: false,
            label: 'Address',
            focusNode: address,
            onFieldSubmitted: (v) {
              phone1.requestFocus();
            },
            initialValue: widget.storeData.address,
            textFieldHeight: 4,
            onChanged: (val) => setState(() {
              widget.storeData.address = val;
            }),
            autovalidateMode: AutovalidateMode.onUserInteraction,
          ),
          const SizedBox(
            height: 25,
          ),
          Row(
            children: [
              BTextField(
                prefixIcon: Icons.phone,
                fieldWidth: 175,
                textFieldReadOnly: false,
                label: 'Phone 1',
                focusNode: phone1,
                onFieldSubmitted: (v) {
                  phone2.requestFocus();
                },
                initialValue: widget.storeData.phone1,
                onChanged: (val) => setState(() {
                  widget.storeData.phone1 = val;
                }),
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
              const SizedBox(
                width: 10,
              ),
              BTextField(
                prefixIcon: Icons.phone,
                fieldWidth: 175,
                textFieldReadOnly: false,
                label: 'Phone 2',
                focusNode: phone2,
                onFieldSubmitted: (v) {
                  email.requestFocus();
                },
                initialValue: widget.storeData.phone2,
                onChanged: (val) => setState(() {
                  widget.storeData.phone2 = val;
                }),
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
            ],
          ),
          BTextField(
            prefixIcon: Icons.email,
            textFieldReadOnly: false,
            label: 'Email',
            focusNode: email,
            onFieldSubmitted: (v) {
              vatNumber.requestFocus();
            },
            initialValue: widget.storeData.email,
            onChanged: (val) => setState(() {
              widget.storeData.email = val;
            }),
            autovalidateMode: AutovalidateMode.onUserInteraction,
          ),
          Row(
            children: [
              BTextField(
                fieldWidth: 175,
                textFieldReadOnly: false,
                label: 'TIN Number',
                focusNode: vatNumber,
                onFieldSubmitted: (v) {
                  crNumber.requestFocus();
                },
                initialValue: widget.storeData.vatNumber,
                onChanged: (val) => setState(() {
                  widget.storeData.vatNumber = val;
                }),
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
              const SizedBox(
                width: 10,
              ),
              BTextField(
                fieldWidth: 175,
                textFieldReadOnly: false,
                label: 'CR Number',
                focusNode: crNumber,
                onFieldSubmitted: (v) {
                  priceLevel.requestFocus();
                },
                initialValue: widget.storeData.crNumber,
                onChanged: (val) => setState(() {
                  widget.storeData.crNumber = val;
                }),
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              BTextField(
                prefixIcon: Icons.price_change,
                fieldWidth: 175,
                textFieldReadOnly: false,
                label: 'Price Level',
                focusNode: priceLevel,
                onFieldSubmitted: (v) {
                  bamkName.requestFocus();
                },
                initialValue: widget.storeData.priceLevel,
                onChanged: (val) => setState(() {
                  widget.storeData.priceLevel = val;
                }),
                autovalidateMode: AutovalidateMode.onUserInteraction,
              ),
              SizedBox(
                width: 10,
              ),
              SizedBox(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      staticTextTranslate('Is active'),
                      style: GoogleFonts.roboto(
                          fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 1,
                    ),
                    Container(
                      width: 175,
                      height: 27,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border.all(
                            width: 0.6,
                            color: const Color.fromARGB(255, 43, 43, 43),
                          ),
                          borderRadius: BorderRadius.circular(2)),
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: DropdownButton<String>(
                        underline: const SizedBox(),
                        isExpanded: true,
                        padding: EdgeInsets.zero,
                        hint: Text(
                          staticTextTranslate('Select Role'),
                          style: TextStyle(
                              fontSize: getMediumFontSize + 2,
                              fontWeight: FontWeight.w400),
                        ),
                        value:
                            widget.storeData.isEnabled ? 'active' : 'inactive',
                        items: ['active', 'inactive'].map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(
                              value,
                              style: TextStyle(
                                  fontSize: getMediumFontSize + 2,
                                  fontWeight: FontWeight.w400),
                            ),
                          );
                        }).toList(),
                        onChanged: (val) {
                          if (val != null) {
                            setState(() {
                              widget.storeData.isEnabled =
                                  val == 'active' ? true : false;
                            });
                          }
                        },
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
          BTextField(
            prefixIcon: Icons.account_balance,
            textFieldReadOnly: false,
            label: 'Bank Name',
            focusNode: bamkName,
            onFieldSubmitted: (v) {
              accountNumber.requestFocus();
            },
            initialValue: widget.storeData.bankName,
            onChanged: (val) => setState(() {
              widget.storeData.bankName = val;
            }),
            autovalidateMode: AutovalidateMode.onUserInteraction,
          ),
          BTextField(
            prefixIcon: Icons.numbers,
            textFieldReadOnly: false,
            label: 'Account Number',
            focusNode: accountNumber,
            initialValue: widget.storeData.accountNumber,
            onChanged: (val) => setState(() {
              widget.storeData.accountNumber = val;
            }),
            autovalidateMode: AutovalidateMode.onUserInteraction,
          ),
          BTextField(
            textFieldReadOnly: false,
            label: 'Note',
            focusNode: note,
            initialValue: widget.storeData.note,
            onChanged: (val) => setState(() {
              widget.storeData.note = val;
            }),
            autovalidateMode: AutovalidateMode.onUserInteraction,
          ),
          const SizedBox(
            height: 5,
          ),
        ]),
      ),
    );
  }
}
