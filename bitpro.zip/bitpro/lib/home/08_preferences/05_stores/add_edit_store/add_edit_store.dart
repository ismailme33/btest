import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/home/08_preferences/05_stores/add_edit_store/box_1/01_store_detials_widget.dart';

import 'package:bitpro_hive/home/08_preferences/05_stores/add_edit_store/box_2/box_2.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/upload_image_service.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import '../../../../shared/custom_top_nav_bar.dart';
import '../../../../shared/dialogs/discard_changes_dialog.dart';

class AddEditStore extends StatefulWidget {
  final bool editData;
  final StoreData? storeData;
  final List<StoreData> storeDataLst;
  const AddEditStore(
      {super.key,
      this.editData = false,
      this.storeData,
      required this.storeDataLst});

  @override
  State<AddEditStore> createState() => _AddEditStoreState();
}

class _AddEditStoreState extends State<AddEditStore> {
  var formKey = GlobalKey<FormState>();
  bool loading = false;

  StoreData storeData = StoreData(
      docId: getRandomString(20),
      note: '',
      storeCode: '',
      storeName: '',
      subName: '',
      address: '',
      phone1: '',
      phone2: '',
      email: '',
      vatNumber: '',
      crNumber: '',
      priceLevel: '',
      bankName: '',
      accountNumber: '',
      isEnabled: true,
      logoPath: '',
      additionalNumber: '',
      area: '',
      buildingNumber: '',
      city: '',
      country: '',
      postCode: '',
      shortAddress: '',
      storeArabicName: '',
      street: '',
      storeDocumentData: [
        StoreDocumentData(
            documentName: 'CR number',
            docId: getRandomString(12),
            donNotAllowDeleting: true,
            documentNumber: null,
            documentIssueDate: null,
            documentExpiryDate: null,
            documentFilePath: null),
        StoreDocumentData(
            documentName: 'VAT number',
            docId: getRandomString(12),
            donNotAllowDeleting: true,
            documentNumber: null,
            documentIssueDate: null,
            documentExpiryDate: null,
            documentFilePath: null)
      ]);
  @override
  void initState() {
    super.initState();
    initData();
  }

  initData() async {
    if (widget.editData && widget.storeData != null) {
      storeData = widget.storeData!;
    } else {
      storeData.storeCode =
          (int.parse(widget.storeDataLst.last.storeCode) + 1).toString();
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return CustomNavBar(
        pageName: 'Store',
        child: Scaffold(
          backgroundColor: homeBgColor,
          body: SafeArea(
              child: Container(
                  color: homeBgColor,
                  child: Row(
                    children: [
                      Container(
                        color: const Color.fromARGB(255, 43, 43, 43),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SideMenuButton(
                              label: 'Back',
                              iconPath: 'assets/icons/back.png',
                              buttonFunction: () {
                                showDiscardChangesDialog(context);
                              },
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        width: 0,
                      ),
                      Form(
                        key: formKey,
                        child: StoreDetailsWidget(
                          storeData: storeData,
                          onTabSaveFunction: () {
                            onTapSaveButton();
                          },
                        ),
                      ),
                      Expanded(
                        child: CreateStoreBox2Widget(
                          storeData: storeData,
                        ),
                      )
                    ],
                  ))),
        ));
  }

  onTapSaveButton() async {
    if (formKey.currentState!.validate() && storeData.storeName.isNotEmpty) {
      setState(() {
        loading = true;
      });

      for (int i = 0; i < storeData.storeDocumentData.length; i++) {
        if (storeData.storeDocumentData[i].saveit &&
            storeData.storeDocumentData[i].documentFilePath != null) {
          String newPathString = await uploadImageService(
              file: File(storeData.storeDocumentData[i].documentFilePath!),
              folderFilePath:
                  '${storeData.docId}/empDocumentDataLst/${storeData.storeDocumentData[i].documentName}_${storeData.storeDocumentData[i].documentNumber}${storeData.storeDocumentData[i].documentFilePath!.substring(storeData.storeDocumentData[i].documentFilePath!.indexOf('.'))}');
          storeData.storeDocumentData[i].documentFilePath = newPathString;
          storeData.storeDocumentData[i].saveit = false;
        }
      }

      //saving logo
      if (storeData.logoPath.isNotEmpty &&
          (widget.storeData != null &&
              widget.storeData!.logoPath != storeData.logoPath)) {
        String newPathString = await uploadImageService(
            file: File(storeData.logoPath),
            folderFilePath:
                '${storeData.docId}/logoimg_${storeData.logoPath.substring(storeData.logoPath.indexOf('.'))}');
        storeData.logoPath = newPathString;
      }
      await HiveStoreDbService().addEditStoreData(storeData);
      Navigator.pop(context, true);
      setState(() {
        loading = false;
      });
    }
  }
}
