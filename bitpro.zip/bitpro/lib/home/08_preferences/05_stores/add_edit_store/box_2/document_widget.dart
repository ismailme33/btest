import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/dialogs/confirm_delete_doc_dialog.dart';
import 'package:bitpro_hive/shared/image_view_dialog.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/bottom_panel_for_dialog.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:io';

import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:file_picker/file_picker.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:intl/intl.dart';

class CreateStoreDocumentWidget extends StatefulWidget {
  final StoreData storeData;
  const CreateStoreDocumentWidget({
    super.key,
    required this.storeData,
  });

  @override
  State<CreateStoreDocumentWidget> createState() =>
      _CreateStoreDocumentWidgetState();
}

class _CreateStoreDocumentWidgetState extends State<CreateStoreDocumentWidget> {
  List<StoreDocumentData> selectedItemLst = [];
  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(8.0),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: ExpansionTile(
            initiallyExpanded: true,
            backgroundColor: Color.fromARGB(255, 51, 51, 51),
            // minTileHeight: 20,
            iconColor: Colors.white,
            collapsedIconColor: Colors.white,
            shape: Border.symmetric(
                horizontal: BorderSide.none, vertical: BorderSide.none),
            collapsedBackgroundColor: Color.fromARGB(255, 51, 51, 51),
            tilePadding: EdgeInsets.only(right: 20),
            childrenPadding: EdgeInsets.zero,
            title: Align(
              alignment: Alignment.centerLeft,
              child: Container(
                padding: EdgeInsets.only(left: 0, top: 0),
                height: 28,
                width: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                ),
                alignment: Alignment.center,
                child: Text(
                  "Documents",
                  style: GoogleFonts.roboto(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Colors.white),
                ),
              ),
            ),
            children: [
              Container(
                padding: EdgeInsets.all(15),
                decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(width: 0.4),
                    borderRadius: BorderRadius.circular(4)),
                child: Column(
                  children: [
                    Row(
                      children: [
                        InkWell(
                          onTap: () async {
                            StoreDocumentData? storeDocumentData =
                                await showCreateDocumentDialog(
                                    context: context);
                            if (storeDocumentData != null) {
                              widget.storeData.storeDocumentData
                                  .add(storeDocumentData);
                            }
                            setState(() {});
                          },
                          child: Container(
                            width: 70,
                            height: 30,
                            decoration: BoxDecoration(
                                color: const Color.fromARGB(255, 0, 0, 0),
                                borderRadius: BorderRadius.circular(4)),
                            child: const Icon(
                              Icons.add,
                              color: Colors.white,
                              size: 18,
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        InkWell(
                          onTap: () async {
                            if (selectedItemLst.length == 1) {
                              StoreDocumentData? storeDocumentData =
                                  await showCreateDocumentDialog(
                                      context: context,
                                      empDocData: selectedItemLst.first);
                              if (storeDocumentData != null) {
                                // widget.employeeData.empDocumentDataLst
                                //     .add(storeDocumentData);
                                int i = widget.storeData.storeDocumentData
                                    .indexOf(selectedItemLst.first);
                                widget.storeData.storeDocumentData[i] =
                                    storeDocumentData;
                                selectedItemLst = [];
                              }
                              setState(() {});
                            }
                          },
                          child: Container(
                            width: 70,
                            height: 30,
                            decoration: BoxDecoration(
                                color: selectedItemLst.length == 1
                                    ? const Color.fromARGB(255, 0, 0, 0)
                                    : Colors.grey,
                                borderRadius: BorderRadius.circular(4)),
                            child: const Icon(
                              Icons.edit,
                              color: Colors.white,
                              size: 18,
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        InkWell(
                          onTap: () async {
                            bool allowDeleting = true;

                            for (var s in selectedItemLst) {
                              if (s.documentName == 'CR number' ||
                                  s.documentName == 'VAT number') {
                                allowDeleting = false;
                              }
                            }
                            if (allowDeleting) {
                              bool res =
                                  await showConfirmDeleteDocDialog(context);
                              if (res && selectedItemLst.isNotEmpty) {
                                for (var s in selectedItemLst) {
                                  widget.storeData.storeDocumentData.remove(s);
                                }
                                selectedItemLst = [];
                                setState(() {});
                              }
                            } else {
                              showToast(
                                  'Store CR number, VAT number cannot be deleted',
                                  context);
                            }
                          },
                          child: Container(
                            width: 70,
                            height: 30,
                            decoration: BoxDecoration(
                                color: selectedItemLst.isNotEmpty
                                    ? const Color.fromARGB(255, 0, 0, 0)
                                    : Colors.grey,
                                borderRadius: BorderRadius.circular(4)),
                            child: const Icon(
                              Icons.cancel,
                              color: Colors.white,
                              size: 18,
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        InkWell(
                          onTap: () async {
                            if (selectedItemLst.length == 1) {
                              if (selectedItemLst.first.documentFilePath ==
                                      null ||
                                  selectedItemLst
                                      .first.documentFilePath!.isEmpty) {
                                showToast("Image not found", context);
                              } else {
                                imageViewDialog(context,
                                    selectedItemLst.first.documentFilePath!);
                              }
                            }
                          },
                          child: Container(
                            width: 70,
                            height: 30,
                            decoration: BoxDecoration(
                                color: selectedItemLst.isNotEmpty
                                    ? const Color.fromARGB(255, 0, 0, 0)
                                    : Colors.grey,
                                borderRadius: BorderRadius.circular(4)),
                            child: const Icon(
                              Icons.remove_red_eye_sharp,
                              color: Colors.white,
                              size: 18,
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(
                      height: 10,
                    ),
                    // storeDocumentData
                    Table(
                      columnWidths: const {
                        0: FlexColumnWidth(1),
                        1: FlexColumnWidth(4),
                        2: FlexColumnWidth(4),
                        3: FlexColumnWidth(4),
                        4: FlexColumnWidth(4),
                        5: FlexColumnWidth(2),
                      },
                      border: TableBorder.all(width: 0.5),
                      children: [
                        TableRow(children: [
                          SizedBox(
                            height: 25,
                            child: Transform.scale(
                                scale: .8,
                                child: Checkbox(
                                    value: widget.storeData.storeDocumentData
                                            .isNotEmpty &&
                                        selectedItemLst.length ==
                                            widget.storeData.storeDocumentData
                                                .length,
                                    onChanged: (v) {
                                      if (selectedItemLst.length ==
                                          widget.storeData.storeDocumentData
                                              .length) {
                                        selectedItemLst = [];
                                      } else {
                                        selectedItemLst =
                                            widget.storeData.storeDocumentData;
                                      }
                                      setState(() {});
                                    })),
                          ),
                          Container(
                              color: Colors.transparent,
                              height: 25,
                              alignment: Alignment.center,
                              child: const Text(
                                'Document Name',
                                style: TextStyle(fontSize: 14),
                              )),
                          Container(
                              height: 25,
                              alignment: Alignment.center,
                              child: const Text(
                                'Document number',
                                style: TextStyle(fontSize: 14),
                              )),
                          Container(
                              height: 25,
                              alignment: Alignment.center,
                              child: const Text(
                                'Issue Date',
                                style: TextStyle(fontSize: 14),
                              )),
                          Container(
                              height: 25,
                              alignment: Alignment.center,
                              child: const Text(
                                'Expiry Date',
                                style: TextStyle(fontSize: 14),
                              )),
                        ]),
                        for (StoreDocumentData d
                            in widget.storeData.storeDocumentData)
                          TableRow(children: [
                            GestureDetector(
                              onTap: () {
                                if (selectedItemLst.length ==
                                    widget.storeData.storeDocumentData.length) {
                                  selectedItemLst = [];
                                } else {
                                  selectedItemLst = [d];
                                }
                                setState(() {});
                              },
                              child: Container(
                                color: Colors.transparent,
                                height: 25,
                                child: Transform.scale(
                                    scale: .8,
                                    child: Checkbox(
                                        value: selectedItemLst.contains(d),
                                        onChanged: (v) {
                                          if (selectedItemLst.length ==
                                              widget.storeData.storeDocumentData
                                                  .length) {
                                            selectedItemLst = [];
                                          } else {
                                            selectedItemLst = [d];
                                          }
                                          setState(() {});
                                        })),
                              ),
                            ),
                            GestureDetector(
                              onTap: () {
                                if (selectedItemLst.length ==
                                    widget.storeData.storeDocumentData.length) {
                                  selectedItemLst = [];
                                } else {
                                  selectedItemLst = [d];
                                }
                                setState(() {});
                              },
                              child: Container(
                                  color: Colors.transparent,
                                  height: 25,
                                  alignment: Alignment.center,
                                  child: Text(
                                    d.documentName,
                                    style: const TextStyle(fontSize: 14),
                                  )),
                            ),
                            GestureDetector(
                              onTap: () {
                                if (selectedItemLst.length ==
                                    widget.storeData.storeDocumentData.length) {
                                  selectedItemLst = [];
                                } else {
                                  selectedItemLst = [d];
                                }
                                setState(() {});
                              },
                              child: Container(
                                  color: Colors.transparent,
                                  height: 25,
                                  alignment: Alignment.center,
                                  child: Text(
                                    d.documentNumber ?? '',
                                    style: const TextStyle(fontSize: 14),
                                  )),
                            ),
                            GestureDetector(
                              onTap: () {
                                if (selectedItemLst.length ==
                                    widget.storeData.storeDocumentData.length) {
                                  selectedItemLst = [];
                                } else {
                                  selectedItemLst = [d];
                                }
                                setState(() {});
                              },
                              child: Container(
                                  color: Colors.transparent,
                                  height: 25,
                                  alignment: Alignment.center,
                                  child: Text(
                                    d.documentIssueDate == null ||
                                            d.documentIssueDate!.isEmpty
                                        ? ''
                                        : DateFormat('MMM d, yyyy').format(
                                            DateTime.parse(
                                                d.documentIssueDate!)),
                                    style: const TextStyle(fontSize: 14),
                                  )),
                            ),
                            GestureDetector(
                              onTap: () {
                                if (selectedItemLst.length ==
                                    widget.storeData.storeDocumentData.length) {
                                  selectedItemLst = [];
                                } else {
                                  selectedItemLst = [d];
                                }
                                setState(() {});
                              },
                              child: Container(
                                  color: Colors.transparent,
                                  height: 25,
                                  alignment: Alignment.center,
                                  child: Text(
                                    d.documentExpiryDate == null ||
                                            d.documentExpiryDate!.isEmpty
                                        ? ''
                                        : DateFormat('MMM d, yyyy').format(
                                            DateTime.parse(
                                                d.documentExpiryDate!)),
                                    style: const TextStyle(fontSize: 14),
                                  )),
                            ),
                          ])
                      ],
                    )
                  ],
                ),
              )
            ],
          ),
        ));
  }

  Future<StoreDocumentData?> showCreateDocumentDialog({
    context,
    StoreDocumentData? empDocData,
  }) async {
    String documentName = '';
    String? documentNumber = '';
    String? documentIssueDate = '';
    String? documentExpiryDate = '';
    File? documentFile;

    if (empDocData != null) {
      documentName = empDocData.documentName;
      documentNumber = empDocData.documentNumber;
      documentIssueDate = empDocData.documentIssueDate;
      documentExpiryDate = empDocData.documentExpiryDate;
      documentFile = empDocData.documentFilePath == null
          ? null
          : File(empDocData.documentFilePath!);
    }

    return await showDialog(
        context: context,
        builder: (context2) {
          return StatefulBuilder(builder: (context, setState) {
            return Dialog(
              child: SizedBox(
                width: 450,
                height: 420,
                child: Column(
                  children: [
                    BlackTopPanelForDialogWindow(label: 'Document'),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.all(25),
                        child: Column(
                          children: [
                            BTextField(
                              textFieldReadOnly: false,
                              label: 'Document Name',

                              initialValue: documentName,
                              // validator: ((value) {}),
                              onChanged: (val) => setState(() {
                                documentName = val;
                              }),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            BTextField(
                              textFieldReadOnly: false,
                              label: 'Document Number',
                              initialValue: documentNumber,
                              // validator: ((value) {}),
                              onChanged: (val) => setState(() {
                                documentNumber = val;
                              }),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    staticTextTranslate('Document Issue Date'),
                                    style: GoogleFonts.roboto(
                                      fontSize: getMediumFontSize + 2,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  SizedBox(
                                    width: 240,
                                    child: GestureDetector(
                                      onTap: () async {
                                        DateTime? dateTime =
                                            await showDatePicker(
                                          context: context,
                                          currentDate: DateTime.now(),
                                          initialDate: DateTime.tryParse(
                                              documentIssueDate ?? ''),
                                          firstDate: DateTime(1900),
                                          lastDate: DateTime(2050),
                                        );
                                        if (dateTime != null) {
                                          documentIssueDate =
                                              dateTime.toString();

                                          setState(() {});
                                        }
                                      },
                                      child: Container(
                                        width: 200,
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: const Color.fromARGB(
                                                    255, 0, 0, 0),
                                                width: 0.4),
                                            borderRadius:
                                                BorderRadius.circular(4)),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 7),
                                        child: Row(
                                          children: [
                                            Text(
                                              documentIssueDate == null ||
                                                      documentIssueDate!.isEmpty
                                                  ? staticTextTranslate(
                                                      'Click to Select Date')
                                                  : DateFormat('dd / MM / yyyy')
                                                      .format(DateTime.parse(
                                                          documentIssueDate!)),
                                              style: GoogleFonts.roboto(
                                                  fontSize: 17,
                                                  height: 1.3,
                                                  color: documentIssueDate ==
                                                          null
                                                      ? const Color.fromARGB(
                                                          255, 0, 0, 0)
                                                      : Colors.black),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    staticTextTranslate('Document Exp Date'),
                                    style: GoogleFonts.roboto(
                                      fontSize: getMediumFontSize + 2,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  SizedBox(
                                    width: 240,
                                    child: GestureDetector(
                                      onTap: () async {
                                        DateTime? dateTime =
                                            await showDatePicker(
                                          context: context,
                                          currentDate: DateTime.now(),
                                          initialDate: DateTime.tryParse(
                                              documentExpiryDate ?? ''),
                                          firstDate: DateTime(1900),
                                          lastDate: DateTime(2050),
                                        );
                                        if (dateTime != null) {
                                          documentExpiryDate =
                                              dateTime.toString();

                                          setState(() {});
                                        }
                                      },
                                      child: Container(
                                        width: 200,
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: const Color.fromARGB(
                                                    255, 0, 0, 0),
                                                width: 0.4),
                                            borderRadius:
                                                BorderRadius.circular(4)),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 7),
                                        child: Row(
                                          children: [
                                            Text(
                                              documentExpiryDate == null ||
                                                      documentExpiryDate!
                                                          .isEmpty
                                                  ? staticTextTranslate(
                                                      'Click to Select Date')
                                                  : DateFormat('dd / MM / yyyy')
                                                      .format(DateTime.parse(
                                                          documentExpiryDate!)),
                                              style: GoogleFonts.roboto(
                                                  fontSize: 17,
                                                  height: 1.3,
                                                  color: documentExpiryDate ==
                                                          null
                                                      ? const Color.fromARGB(
                                                          255, 0, 0, 0)
                                                      : Colors.black),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                Text(
                                  'Document File',
                                  style: GoogleFonts.roboto(
                                    fontSize: 16,
                                  ),
                                ),
                                Spacer(),
                                SizedBox(
                                  height: 80,
                                  width: 80,
                                  child: documentFile != null
                                      ? Image.file(
                                          documentFile!,
                                          width: 200,
                                          height: 50,
                                        )
                                      : null,
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                // documentFile
                                OutlinedButton.icon(
                                    icon: const Icon(Icons.upload),
                                    style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.transparent,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(4))),
                                    onPressed: () async {
                                      FilePickerResult? result =
                                          await FilePicker.platform.pickFiles(
                                              allowMultiple: false,
                                              dialogTitle: staticTextTranslate(
                                                  'Header Image'),
                                              type: FileType.image);

                                      if (result != null &&
                                          result.files.first.path != null) {
                                        // var box = Hive.box('bitpro_app');
                                        // await box.put(
                                        //     'header_img_path', result.files.first.path);
                                        // headerImgPath = result.files.first.path!;
                                        documentFile =
                                            File(result.files.first.path!);
                                        setState(() {});
                                      }
                                    },
                                    label: Text(
                                        staticTextTranslate('Choose Image'),
                                        style:
                                            GoogleFonts.roboto(fontSize: 14))),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    BottomPanelForDialog(buttons: [
                      OnPageGreyButton(
                        label: 'Cancel',
                        onPressed: () {
                          Navigator.pop(context2);
                        },
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      OnPageButton(
                          label: 'Save',
                          onPressed: () {
                            if (documentName.isNotEmpty) {
                              Navigator.pop(
                                  context,
                                  StoreDocumentData(
                                      docId: empDocData != null
                                          ? empDocData.docId
                                          : getRandomString(12),
                                      documentName: documentName,
                                      documentNumber: documentNumber,
                                      documentIssueDate: documentIssueDate,
                                      documentExpiryDate: documentExpiryDate,
                                      documentFilePath: documentFile?.path,
                                      saveit: true));
                            } else {
                              showToast('Please enter document name.', context);
                            }
                          },
                          icon: Icons.save)
                    ]),
                  ],
                ),
              ),
            );
          });
        });
  }
}
