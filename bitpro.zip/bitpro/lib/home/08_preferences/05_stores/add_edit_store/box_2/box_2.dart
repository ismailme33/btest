import 'dart:io';

import 'package:bitpro_hive/home/08_preferences/05_stores/add_edit_store/box_2/document_widget.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CreateStoreBox2Widget extends StatefulWidget {
  final StoreData storeData;
  const CreateStoreBox2Widget({super.key, required this.storeData});

  @override
  State<CreateStoreBox2Widget> createState() => _CreateStoreBox2WidgetState();
}

class _CreateStoreBox2WidgetState extends State<CreateStoreBox2Widget> {
  final GlobalKey _menuKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: double.maxFinite,
        decoration: BoxDecoration(
            border: Border.all(width: 0.3),
            color: const Color(0xffE2E2E2),
            borderRadius: BorderRadius.circular(3)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 35,
              width: double.maxFinite,
              // padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(4), topRight: Radius.circular(4)),
                gradient: LinearGradient(
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromARGB(255, 66, 66, 66),
                      Color.fromARGB(255, 0, 0, 0),
                    ],
                    begin: Alignment.topCenter),
              ),
              child: Row(
                children: [
                  Container(
                    width: 120,
                    height: 35,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        gradient: LinearGradient(
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xff092F53),
                              Color(0xff284F70),
                            ],
                            begin: Alignment.topCenter)),
                    alignment: Alignment.center,
                    child: Text(
                      "Files & Docs",
                      style: GoogleFonts.roboto(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CreateStoreDocumentWidget(storeData: widget.storeData),
                    imagePickerWidget()
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  imagePickerWidget() {
    return Padding(
      padding: const EdgeInsets.only(left: 5.0),
      child: SizedBox(
        width: 200,
        height: 200,
        child: Card(
          shape: RoundedRectangleBorder(
              side: const BorderSide(width: 0.5, color: Colors.grey),
              borderRadius: BorderRadius.circular(4)),
          elevation: 0,
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.only(
                top: 10, bottom: 10.0, left: 10, right: 10),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(staticTextTranslate('Store Logo'),
                          style: TextStyle(
                            fontSize: getMediumFontSize,
                          )),
                      PopupMenuButton(
                          splashRadius: 1,
                          key: _menuKey,
                          itemBuilder: (_) => <PopupMenuItem<String>>[
                                PopupMenuItem<String>(
                                    value: 'upload',
                                    child: Text(
                                        staticTextTranslate(
                                            widget.storeData.logoPath.isNotEmpty
                                                ? "Change Image"
                                                : 'Upload Image'),
                                        style: TextStyle(
                                          fontSize: getMediumFontSize,
                                        ))),
                                PopupMenuItem<String>(
                                    value: 'remove',
                                    child: Text(
                                        staticTextTranslate('Remove Image'),
                                        style: TextStyle(
                                          fontSize: getMediumFontSize,
                                        ))),
                              ],
                          icon: Icon(
                            Icons.menu,
                            size: 19,
                          ),
                          onSelected: (val) async {
                            if (val == 'remove') {
                              widget.storeData.logoPath = '';
                              // productImage = null;
                              setState(() {});
                            } else if (val == 'upload') {
                              FilePickerResult? result =
                                  await FilePicker.platform.pickFiles(
                                      allowMultiple: false,
                                      dialogTitle:
                                          staticTextTranslate('Product Image'),
                                      type: FileType.image);

                              if (result != null) {
                                widget.storeData.logoPath =
                                    result.files.first.path!;
                                setState(() {});
                              }
                            }
                          }),
                    ],
                  ),
                  const SizedBox(
                    height: 0,
                  ),
                  if (widget.storeData.logoPath.isNotEmpty)
                    Image.file(
                      File(widget.storeData.logoPath),
                      width: 190,
                      height: 115,
                      fit: BoxFit.contain,
                    )
                  else
                    SizedBox(
                      width: 190,
                      height: 115,
                      child: Icon(Icons.image,
                          size: 100, color: Colors.grey.shade200),
                    )
                ]),
          ),
        ),
      ),
    );
  }
}
