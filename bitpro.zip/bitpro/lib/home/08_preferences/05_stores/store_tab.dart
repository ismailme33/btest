import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/widget/filter_container.dart';
import 'package:bitpro_hive/widget/filter_text_fileds/fiter_textfield.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

class SettingStoreTab extends StatefulWidget {
  final storeNameFilterController = TextEditingController();

  final Function(StoreData?) selectStore;
  final List<StoreData> storeDataList;

  SettingStoreTab(
      {super.key, required this.selectStore, required this.storeDataList});

  @override
  State<SettingStoreTab> createState() => _SettingStoreTabState();
}

class _SettingStoreTabState extends State<SettingStoreTab> {
  final List<BitproGridColumnModel> _bitproGridColumnModel = [
    BitproGridColumnModel(
      columnName: 'S.No.',
      label: 'S.no.',
      width: 100.0, // Default width since not explicitly set
      visible: false,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'storeCode',
      label: 'Store code',
      width: 140.0, // Default width
      visible: true,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'storeName',
      label: staticTextTranslate('Store Name'),
      width: 155.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'subName',
      label: staticTextTranslate('Sub Name'),
      width: 145.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'address1',
      label: staticTextTranslate('Address 1'),
      width: 140.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'phone1',
      label: staticTextTranslate('Phone 1'),
      width: 122.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'phone2',
      label: staticTextTranslate('Phone 2'),
      width: 122.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'vatNumber',
      label: staticTextTranslate('Vat Number'),
      width: 156.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'email',
      label: staticTextTranslate('Email'),
      width: 130.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'bankName',
      label: staticTextTranslate('Bank Name'),
      width: 148.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'accountNumber',
      label: staticTextTranslate('Account Number'),
      width: 235.0, // Default width
      allowEditing: false,
    ),
  ];
  DataGridController dataGridController = DataGridController();
  bool isLoading = true;
  final Color dGvColor = const Color.fromARGB(255, 231, 231, 231);
  late StoreDataSource storeDataSource;
  List<StoreData> tStoreDataList = [];

  @override
  void initState() {
    initData();
    super.initState();
  }

  initData() async {
    tStoreDataList = widget.storeDataList;
    tStoreDataList.sort((a, b) => a.storeCode.compareTo(b.storeCode));
    storeDataSource = StoreDataSource(storeData: tStoreDataList);

    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.storeDataList != tStoreDataList) {
      tStoreDataList = widget.storeDataList;
      storeDataSource = StoreDataSource(storeData: tStoreDataList);
    }

    if (isLoading) return showLoading();
    return Column(children: [
      // MysqlBackendSettings(
      //   tStoreDataList: tStoreDataList,
      // ),
      Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(4),
              color: Colors.white,
              border: Border.all(width: 0.3)),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Column(
              children: [
                FilterContainer(fiterFields: [
                  FilterTextField(
                      icon: Icon(Icons.search),
                      onPressed: () {
                        storeDataSource =
                            StoreDataSource(storeData: tStoreDataList);
                        setState(() {});
                      },
                      onChanged: (val) {
                        storeDataSource = StoreDataSource(
                            storeData: tStoreDataList
                                .where((e) => e.storeName.contains(val))
                                .toList());
                        setState(() {});
                      },
                      hintText: 'Store Name'),
                  FilterTextField(
                      icon: Icon(Icons.search),
                      onPressed: () {
                        storeDataSource =
                            StoreDataSource(storeData: tStoreDataList);
                        setState(() {});
                      },
                      onChanged: (val) {
                        storeDataSource = StoreDataSource(
                            storeData: tStoreDataList
                                .where((e) => e.subName.contains(val))
                                .toList());
                        setState(() {});
                      },
                      hintText: 'Sub Name'),
                ]),
                SizedBox(
                  height: 5,
                ),
                BitproGridTable(
                  dataGridController: dataGridController,
                  source: storeDataSource,
                  allowEditing: false,
                  allowSorting: true,
                  bitproGridColumnModel: _bitproGridColumnModel,
                  onChangeRefershFunction: () {
                    var id = '';

                    for (var c in dataGridController.selectedRow!.getCells()) {
                      if (c.columnName == 'storeCode') {
                        id = c.value;
                      }
                    }
                    widget.selectStore(tStoreDataList
                        .firstWhere((element) => element.storeCode == id));
                    setState(() {});
                  },
                ),
              ],
            ),
          ),
        ),
      ),
      const SizedBox(
        width: 20,
      ),
    ]);
  }
}

class StoreDataSource extends DataGridSource {
  StoreDataSource({required List<StoreData> storeData}) {
    _employeeData = storeData
        .map<DataGridRow>((e) => DataGridRow(cells: [
              DataGridCell<int>(
                  columnName: 'S.No.', value: storeData.indexOf(e) + 1),
              DataGridCell<String>(columnName: 'storeCode', value: e.storeCode),
              DataGridCell<String>(columnName: 'storeName', value: e.storeName),
              DataGridCell<String>(columnName: 'subName', value: e.subName),
              DataGridCell<String>(columnName: 'address1', value: e.address),
              DataGridCell<String>(columnName: 'phone1', value: e.phone1),
              DataGridCell<String>(columnName: 'phone2', value: e.phone2),
              DataGridCell<String>(columnName: 'vatNumber', value: e.vatNumber),
              DataGridCell<String>(columnName: 'email', value: e.email),
              DataGridCell<String>(columnName: 'bankName', value: e.bankName),
              DataGridCell<String>(
                  columnName: 'accountNumber', value: e.accountNumber),
            ]))
        .toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    // bool isReturnReceipt = false;

    // if (row
    //         .getCells()
    //         .indexWhere((e) => e.columnName == 'type' && e.value == 'Return') !=
    //     -1) isReturnReceipt = true;
    return DataGridRowAdapter(
        color: row.getCells()[0].value.isEven
            ? const Color.fromARGB(255, 246, 247, 255)
            : Colors.white,
        cells: row.getCells().map<Widget>((e) {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
            child: Text(
              overflow: TextOverflow.ellipsis,
              e.value.toString(),
              style: GoogleFonts.roboto(
                  fontSize: getMediumFontSize, fontWeight: FontWeight.w500),
            ),
          );
        }).toList());
  }
}
