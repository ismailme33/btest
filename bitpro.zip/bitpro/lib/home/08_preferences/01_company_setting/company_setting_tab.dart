import 'package:bitpro_hive/model/settings/company_details_settings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CompanySettingTab extends StatefulWidget {
  final CompanyDetailsSettings companyDetailsSettings;

  final StoreData defaultSelectedStoreData;
  const CompanySettingTab(
      {super.key,
      required this.companyDetailsSettings,
      required this.defaultSelectedStoreData});

  @override
  State<CompanySettingTab> createState() => _CompanySettingTabState();
}

class _CompanySettingTabState extends State<CompanySettingTab> {
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Text(
          staticTextTranslate('Company name'),
          style: GoogleFonts.roboto(fontSize: 14),
        ),
        const SizedBox(
          height: 5,
        ),
        SizedBox(
          width: 350,
          child: TextFormField(
            initialValue: widget.companyDetailsSettings.companyName,
            style: GoogleFonts.roboto(fontSize: 15, height: 1.5),
            decoration: const InputDecoration(
                fillColor: Colors.white,
                filled: true,
                isDense: true,
                contentPadding:
                    EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                border: OutlineInputBorder(
                  borderSide: BorderSide(width: 0.3),
                ),
                enabledBorder:
                    OutlineInputBorder(borderSide: BorderSide(width: 0.3))),
            onChanged: (val) => setState(() {
              widget.companyDetailsSettings.companyName = val;
            }),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(4),
            border: Border.all(width: 0.3),
            color: const Color.fromARGB(255, 236, 248, 250),
          ),
          height: 140,
          child: Row(
            children: [
              Container(
                child: const Icon(
                  Icons.store,
                  size: 40,
                  color: Color.fromARGB(255, 131, 148, 153),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 230,
                    child: Text(
                      staticTextTranslate(
                          widget.companyDetailsSettings.workstationNumber ==
                                  null
                              ? 'Selected store'
                              : 'Store & Workstation Details'),
                      style: GoogleFonts.roboto(
                          fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: Container(
                      width: 233,
                      decoration: const BoxDecoration(
                          border: Border(bottom: BorderSide(width: 0.4))),
                    ),
                  ),
                  SizedBox(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Store Name : ',
                          style: GoogleFonts.roboto(fontSize: 16),
                        ),
                        Text(widget.defaultSelectedStoreData.storeName,
                            style: GoogleFonts.roboto(fontSize: 16)),
                      ],
                    ),
                  ),
                  if (widget.companyDetailsSettings.workstationNumber != null)
                    SizedBox(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Workstation : ',
                              style: GoogleFonts.roboto(fontSize: 16)),
                          Text(
                              widget.companyDetailsSettings.workstationNumber
                                  .toString(),
                              style: GoogleFonts.roboto(fontSize: 16)),
                        ],
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(
          height: 20,
        ),
      ],
    );
  }
}
