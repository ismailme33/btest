import 'package:bitpro_hive/home/05_reports/report_pages/profit_and_loss_report_page.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:bitpro_hive/home/03_purchase/voucher/voucher_page.dart';
import 'package:bitpro_hive/model/user_group_data.dart';

class PurchasePage extends StatefulWidget {
  final EmployeeData userData;
  final UserGroupData currentUserRole;

  const PurchasePage(
      {super.key, required this.userData, required this.currentUserRole});

  @override
  State<PurchasePage> createState() => _PurchasePageState();
}

class _PurchasePageState extends State<PurchasePage> {
  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 15,
      runSpacing: 15,
      children: [
        if (widget.currentUserRole.purchaseVoucher)
          OnPageButton(
            label: 'Voucher',
            icon: Iconsax.receipt_2,
            width: 150,
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          VoucherPage(userData: widget.userData)));
            },
          )
      ],
    );
  }
}
