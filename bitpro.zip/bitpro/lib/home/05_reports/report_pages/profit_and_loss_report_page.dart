import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';

class ProfitAndLossReportData {
  double totalSalesWithoutTax;
  double totalSalesWithTax;
  double totalPurchaseWithoutTax;
  double totalCost;
  double taxPercentage;
  double totalTax;

  ProfitAndLossReportData({
    required this.totalSalesWithoutTax,
    required this.totalSalesWithTax,
    required this.totalPurchaseWithoutTax,
    required this.totalCost,
    required this.taxPercentage,
    required this.totalTax,
  });
  double getTotalProfit() {
    return double.parse(
        (totalSalesWithoutTax - totalCost).toStringAsFixed(digit));
  }

  double getMarginPercentage() {
    if (totalSalesWithoutTax == 0) return 0.0;
    return double.parse(((getTotalProfit() / totalSalesWithoutTax) * 100)
        .toStringAsFixed(digit));
  }

  double getDifference() {
    return double.parse((totalSalesWithoutTax - totalPurchaseWithoutTax)
        .toStringAsFixed(digit));
  }
}

double repFontSize = 12.0;
double arabicFontSize = 10.0;

profitAndLosssReportPage({
  required DateTime? fromDate,
  required String selectedStoreName,
  required DateTime? toDate,
  //
  required ProfitAndLossReportData profitAndLossReportData,
  // required double totalSalesWithoutTax,
  // required double totalSalesWithTax,
  // required double totalPurchaseWithoutTax,
  // required double totalCost,
  // required double totalProfit,
  // required double difference,
  // required double taxPercentage,
  // required double totalTax,
  // required double totalMargin,
  // required double totalQty,
  // required double tax,
  // required double totalDiscount,
  // required double total,
  // required double totalCost,
  // required double taxPer,
  required arabicNormalFont,
  required englishRegularFont,
  required englishBoldFont,
}) async {
  final doc = pw.Document();

  var image = await imageFromAssetBundle('assets/icons/bitpro.png');

  doc.addPage(pw.MultiPage(
      orientation: pw.PageOrientation.natural,
      pageFormat: PdfPageFormat.a4.landscape,
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      margin: const pw.EdgeInsets.all(15),
      footer: (c) {
        return pw.Row(children: [
          pw.Expanded(child: pw.SizedBox(width: 5)),
          pw.Text('Page ${c.pageNumber} of ${c.pagesCount}',
              style: pw.TextStyle(font: englishRegularFont, fontSize: 9)),
          pw.SizedBox(width: 20)
        ]);
      },
      build: (context) {
        return [
          pw.Container(
              color: PdfColors.white,
              child: pw.Container(
                  decoration: pw.BoxDecoration(
                      borderRadius: pw.BorderRadius.circular(4)),
                  alignment: pw.Alignment.centerLeft,
                  padding: const pw.EdgeInsets.symmetric(
                      horizontal: 12, vertical: 15),
                  child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Row(
                          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: pw.CrossAxisAlignment.start,
                          children: [
                            pw.Image(image, height: 35),
                            pw.Column(
                              children: [
                                pw.Text(
                                  'Profit and Loss Report',
                                  style: pw.TextStyle(
                                    font: englishBoldFont,
                                    fontSize: 15,
                                  ),
                                ),
                                pw.SizedBox(
                                  height: 5,
                                ),
                                pw.Text(
                                  'Date : ${DateFormat('dd-MM-yyyy').format(fromDate!)} to ${DateFormat('dd-MM-yyyy').format(toDate!)}',
                                  style: pw.TextStyle(
                                      font: englishRegularFont,
                                      fontSize: repFontSize),
                                ),
                              ],
                            ),
                            pw.Text(
                              'Printed on : ${DateFormat('dd-MM-yyyy').format(DateTime.now())}',
                              style: pw.TextStyle(
                                  font: englishRegularFont,
                                  fontSize: repFontSize),
                            ),
                          ],
                        ),
                        pw.SizedBox(
                          height: 22,
                        ),
                        profitAndLossReportChartWidget(
                            totalSalesWithoutTax:
                                profitAndLossReportData.totalSalesWithoutTax,
                            totalCost: profitAndLossReportData.totalCost,
                            totalProfit:
                                profitAndLossReportData.getTotalProfit(),
                            totalPurchaseWithoutTax:
                                profitAndLossReportData.totalPurchaseWithoutTax,
                            difference:
                                profitAndLossReportData.getDifference()),
                        pw.SizedBox(
                          height: 22,
                        ),
                        pw.Table(
                          children: [
                            pw.TableRow(
                                decoration: const pw.BoxDecoration(
                                  color: PdfColor.fromInt(0xff2a77b5),
                                ),
                                children: [
                                  pw.Container(
                                      height: 32,
                                      padding: const pw.EdgeInsets.symmetric(
                                          horizontal: 10),
                                      child: pw.Column(
                                        mainAxisAlignment:
                                            pw.MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.start,
                                        children: [
                                          pw.Text(
                                              staticTextTranslate(
                                                  'Total Sales'),
                                              style: pw.TextStyle(
                                                  font: englishBoldFont,
                                                  fontSize: engSelectedLanguage
                                                      ? repFontSize
                                                      : repFontSize,
                                                  color: PdfColors.white,
                                                  fontWeight:
                                                      pw.FontWeight.bold))
                                        ],
                                      )),
                                  pw.Container(
                                      height: 35,
                                      child: pw.Column(
                                        mainAxisAlignment:
                                            pw.MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.end,
                                        children: [
                                          pw.Text('Total Sales WT',
                                              style: pw.TextStyle(
                                                font: englishRegularFont,
                                                fontSize: repFontSize,
                                                color: PdfColors.white,
                                              ))
                                        ],
                                      )),
                                  pw.Container(
                                      height: 35,
                                      child: pw.Column(
                                        mainAxisAlignment:
                                            pw.MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.end,
                                        children: [
                                          pw.Text(
                                              'Tax (${profitAndLossReportData.taxPercentage}%)',
                                              style: pw.TextStyle(
                                                font: englishRegularFont,
                                                fontSize: repFontSize,
                                                color: PdfColors.white,
                                              ))
                                        ],
                                      )),
                                  pw.Container(
                                      height: 35,
                                      child: pw.Column(
                                        mainAxisAlignment:
                                            pw.MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.end,
                                        children: [
                                          pw.Text('Cost',
                                              style: pw.TextStyle(
                                                font: englishRegularFont,
                                                fontSize: repFontSize,
                                                color: PdfColors.white,
                                              ))
                                        ],
                                      )),
                                  pw.Container(
                                      height: 35,
                                      child: pw.Column(
                                        mainAxisAlignment:
                                            pw.MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.end,
                                        children: [
                                          pw.Text('Margin %',
                                              style: pw.TextStyle(
                                                font: englishRegularFont,
                                                fontSize: repFontSize,
                                                color: PdfColors.white,
                                              ))
                                        ],
                                      )),
                                  pw.Container(
                                      height: 35,
                                      child: pw.Column(
                                        mainAxisAlignment:
                                            pw.MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            pw.CrossAxisAlignment.center,
                                        children: [
                                          pw.Text('Total Profit',
                                              style: pw.TextStyle(
                                                font: englishRegularFont,
                                                fontSize: repFontSize,
                                                color: PdfColors.white,
                                              ))
                                        ],
                                      ))
                                ]),
                            pw.TableRow(
                                decoration: const pw.BoxDecoration(
                                    border: pw.Border(
                                  bottom: pw.BorderSide(color: PdfColors.black),
                                )),
                                children: [
                                  pw.Container(
                                      height: 20,
                                      alignment: pw.Alignment.centerLeft,
                                      child: pw.Text(
                                        '${profitAndLossReportData.totalSalesWithoutTax}',
                                      )),
                                  pw.Container(
                                      height: 20,
                                      alignment: pw.Alignment.centerRight,
                                      child: pw.Text(
                                          '${profitAndLossReportData.totalSalesWithTax}',
                                          style: pw.TextStyle(
                                            font: englishRegularFont,
                                            fontSize: repFontSize,
                                          ))),
                                  pw.Container(
                                      height: 20,
                                      alignment: pw.Alignment.centerRight,
                                      child: pw.Text(
                                          '${profitAndLossReportData.totalTax}',
                                          style: pw.TextStyle(
                                            font: englishRegularFont,
                                            fontSize: repFontSize,
                                          ))),
                                  pw.Container(
                                      height: 20,
                                      alignment: pw.Alignment.centerRight,
                                      child: pw.Text(
                                          '${profitAndLossReportData.totalCost}',
                                          style: pw.TextStyle(
                                            font: englishRegularFont,
                                            fontSize: repFontSize,
                                          ))),
                                  pw.Container(
                                      height: 20,
                                      alignment: pw.Alignment.centerRight,
                                      child: pw.Text(
                                          '${profitAndLossReportData.getMarginPercentage()}',
                                          style: pw.TextStyle(
                                            font: englishRegularFont,
                                            fontSize: repFontSize,
                                          ))),
                                  pw.Container(
                                      height: 20,
                                      alignment: pw.Alignment.center,
                                      child: pw.Text(
                                          '${profitAndLossReportData.getTotalProfit()}',
                                          style: pw.TextStyle(
                                            font: englishRegularFont,
                                            fontSize: repFontSize,
                                          ))),
                                ])
                          ],
                        ),
                      ])))
        ];
      }));
  return await doc.save();
}

pw.Widget profitAndLossReportChartWidget({
  required double totalSalesWithoutTax,
  required double totalCost,
  required double totalProfit,
  required double totalPurchaseWithoutTax,
  required double difference,
}) {
  return pw.Row(
    children: [
      pw.Expanded(
        child: donutChart(
          title1: 'Total Cost',
          title2: 'Total Profit',
          label1: 'Cost',
          label2: 'Profit',
          totalSales: totalSalesWithoutTax,
          value1: totalCost,
          value2: totalProfit,
        ),
      ),
      pw.SizedBox(width: 16),
      // Right Chart: Purchase and Sales
      pw.Expanded(
        child: donutChart(
          title1: 'Total Purchase',
          title2: 'Difference',
          label1: 'Sales',
          label2: 'Purchase',
          totalSales: totalSalesWithoutTax,
          value1: totalPurchaseWithoutTax,
          value2: difference,
        ),
      ),
    ],
  );
}

pw.Widget donutChart({
  required String title1,
  required String title2,
  required String label1,
  required String label2,
  required double totalSales,
  required double value1, // Cost or Purchase
  required double value2, // Profit or Difference
}) {
  // Calculate proportions for the CircularProgressIndicator
  final proportion1 = value1 / totalSales; // 0.75 (Cost or Purchase)
  final proportion2 = value2 / totalSales; // 0.25 (Profit or Difference)
  print(proportion1);
  print(proportion2);
  return pw.Container(
    padding: pw.EdgeInsets.all(16.0),
    decoration: pw.BoxDecoration(
      border: pw.Border.all(color: PdfColors.black),
      borderRadius: pw.BorderRadius.circular(10),
    ),
    child: pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceEvenly,
      children: [
        // Donut Chart
        pw.Stack(
          alignment: pw.Alignment.center,
          children: [
            // Background circle (Cost or Purchase)
            pw.SizedBox(
              width: 100,
              height: 100,
              child: pw.CircularProgressIndicator(
                value: proportion1, // 0.75
                strokeWidth: 10,
                color: PdfColor.fromInt(0xffc77261),
                backgroundColor: PdfColor.fromInt(0xff67788d),
              ),
            ),
          ],
        ),
        // Text labels
        pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Text(
              'Total Sales (Without Tax)',
              style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
            ),
            pw.Text(
              totalSales.toStringAsFixed(2),
              style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 8),
            pw.Text(
              title1,
              style: pw.TextStyle(fontSize: 14),
            ),
            pw.Text(
              value1.toStringAsFixed(2),
              style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 8),
            pw.Text(
              title2,
              style: pw.TextStyle(fontSize: 14),
            ),
            pw.Text(
              value2.toStringAsFixed(2),
              style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
            ),
          ],
        ),
      ],
    ),
  );
}
