import 'dart:typed_data';
import 'package:screenshot/screenshot.dart';
import 'package:flutter/material.dart';

Future<Uint8List> captureWidgetAsImage({
  required Widget widget,
}) async {
  // Create a ScreenshotController
  final controller = ScreenshotController();

  // Capture the widget as a ui.Image
  return await controller.captureFromWidget(widget);
}
