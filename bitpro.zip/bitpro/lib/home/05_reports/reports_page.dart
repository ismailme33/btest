import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/home/05_reports/report_pages/profit_and_loss_report_page.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/model/voucher/local_voucher_data.dart';
import 'package:bitpro_hive/services/hive/hive_merchandise_db_service/inventory_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_receipt_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_settings_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_voucher_db_service/hive_voucher_db_service.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:bitpro_hive/home/05_reports/report_pages/puchase_report_page.dart';
import 'package:bitpro_hive/model/inventory_data.dart';
import 'package:bitpro_hive/shared/customer_expanded_tile.dart';
import 'package:bitpro_hive/home/05_reports/pdf_viewer_page.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import '../../model/voucher/db_voucher_data.dart';
import '../../shared/custom_top_nav_bar.dart';
import '../../shared/global_variables/font_sizes.dart';
import '../../shared/global_variables/static_text_translate.dart';

class ReportsPage extends StatefulWidget {
  final EmployeeData userData;

  const ReportsPage({Key? key, required this.userData}) : super(key: key);

  @override
  State<ReportsPage> createState() => _ReportsPageState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _ReportsPageState extends State<ReportsPage> {
  DateTime? fromDate;
  DateTime? toDate;
  bool showFromDateError = false;
  bool showToDateError = false;
  List<ReceiptOrQuotationData> dbReceiptDataLst = [];
  List<DbVoucherData> dbVoucherDataLst = [];
  List<InventoryData> allInventoryDataLst = [];
  String selectedPage = '';

  bool showPageDetails = false;
  // double taxPerForReceipt = double.parse(defaultTaxPercentge);
  String datatype = 'All Document';

  bool isLoading = true;

  late StoreData defaultSelectedStoreData;
  List<StoreData> storeDataList = [];
  late TaxSettingsData taxSettingsData;

  @override
  void initState() {
    hiveFetchData();
    super.initState();
  }

  hiveFetchData() async {
    taxSettingsData = await HiveSettingsDbService().getTaxSettingsData();
    dbReceiptDataLst = await HiveReceiptDbService().fetchAllReceiptData();
    dbVoucherDataLst = await HiveVoucherDbService().fetchAllVoucherData();
    allInventoryDataLst =
        await HiveInventoryDbService().fetchAllInventoryData();

    storeDataList = await HiveStoreDbService().fetchAllStoresData();
    defaultSelectedStoreData =
        await HiveStoreDbService().getSelectedStoreData();
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return showLoading(withScaffold: true);
    }

    return CustomNavBar(
      pageName: 'Reports',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Container(
            color: Colors.grey,
            child: Row(
              children: [
                Container(
                  color: const Color.fromARGB(255, 43, 43, 43),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        height: 0,
                      ),
                      SideMenuButton(
                        label: 'Back',
                        iconPath: 'assets/icons/back.png',
                        buttonFunction: () {
                          Navigator.pop(context);
                        },
                      ),
                      SideMenuButton(
                        label: 'Refresh',
                        iconPath: 'assets/icons/refresh.png',
                        buttonFunction: () async {
                          setState(() {
                            isLoading = true;
                          });
                          await hiveFetchData();
                        },
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  width: 0,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        height: 0,
                      ),
                      Expanded(
                        child: Card(
                            shape: RoundedRectangleBorder(
                                side: const BorderSide(
                                    width: 0.5, color: Colors.grey),
                                borderRadius: BorderRadius.circular(3)),
                            elevation: 0,
                            color: Colors.grey,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Container(
                                  height:
                                      MediaQuery.of(context).size.height * 0.9,
                                  margin: const EdgeInsets.all(3),
                                  width: 270,
                                  decoration: BoxDecoration(
                                      // color: homeBgColor,
                                      color:
                                          const Color.fromARGB(255, 43, 43, 43),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Colors.grey,
                                          blurRadius: 2.0,
                                        ),
                                      ],
                                      borderRadius: BorderRadius.circular(4)),
                                  child: Column(children: [
                                    CustomExpansionTile(
                                      iconColor: Colors.white,
                                      collapsedIconColor: Colors.white,
                                      leading: null,
                                      trailing: const SizedBox(),
                                      title: Text(
                                        staticTextTranslate("Sales Report"),
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: getMediumFontSize + 2,
                                        ),
                                      ),
                                      expandedAlignment: Alignment.centerLeft,
                                      children: <Widget>[
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedPage = 'Sales Summary';

                                              showPageDetails = false;
                                              fromDate = null;
                                              toDate = null;
                                            });
                                          },
                                          child: Container(
                                            width: double.maxFinite,
                                            padding: const EdgeInsets.only(
                                                left: 35, top: 0, bottom: 10),
                                            child: Text(
                                              staticTextTranslate(
                                                  "Sales Summary"),
                                              style: TextStyle(
                                                  fontSize: getMediumFontSize,
                                                  color: selectedPage ==
                                                          "Sales Summary"
                                                      ? Colors.blue
                                                      : Colors.white),
                                            ),
                                          ),
                                        ),
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedPage =
                                                  'Profit & Loss Report';

                                              showPageDetails = false;
                                              fromDate = null;
                                              toDate = null;
                                            });
                                          },
                                          child: Container(
                                            width: double.maxFinite,
                                            padding: const EdgeInsets.only(
                                                left: 35, top: 0, bottom: 10),
                                            child: Text(
                                              staticTextTranslate(
                                                  "Profit & Loss Report"),
                                              style: TextStyle(
                                                  fontSize: getMediumFontSize,
                                                  color: selectedPage ==
                                                          "Profit & Loss Report"
                                                      ? Colors.blue
                                                      : Colors.white),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const Divider(
                                      color: Colors.grey,
                                    ),
                                    CustomExpansionTile(
                                      iconColor: Colors.white,
                                      collapsedIconColor: Colors.white,
                                      leading: null,
                                      trailing: const SizedBox(),
                                      title: Text(
                                        staticTextTranslate("Purchase Report"),
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: getMediumFontSize + 2,
                                        ),
                                      ),
                                      expandedAlignment: Alignment.centerLeft,
                                      children: <Widget>[
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedPage = "Purchase Summary";
                                              showPageDetails = false;
                                              fromDate = null;
                                              toDate = null;
                                            });
                                          },
                                          child: Container(
                                            width: double.maxFinite,
                                            padding: const EdgeInsets.only(
                                                left: 35, top: 0, bottom: 10),
                                            child: Text(
                                              staticTextTranslate(
                                                  "Purchase Summary"),
                                              style: TextStyle(
                                                  fontSize: getMediumFontSize,
                                                  color: selectedPage ==
                                                          "Purchase Summary"
                                                      ? Colors.blue
                                                      : Colors.white),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const Divider(
                                      color: Colors.grey,
                                    ),
                                    CustomExpansionTile(
                                      iconColor: Colors.white,
                                      collapsedIconColor: Colors.white,
                                      leading: null,
                                      trailing: const SizedBox(),
                                      title: Text(
                                        staticTextTranslate("Tax Report"),
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: getMediumFontSize + 2,
                                        ),
                                      ),
                                      expandedAlignment: Alignment.centerLeft,
                                      children: <Widget>[
                                        GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              selectedPage = "Tax Summary";
                                              showPageDetails = false;
                                              fromDate = null;
                                              toDate = null;
                                            });
                                          },
                                          child: Container(
                                            width: double.maxFinite,
                                            padding: const EdgeInsets.only(
                                                left: 35, top: 5, bottom: 10),
                                            child: Text(
                                              staticTextTranslate(
                                                  "Tax Summary"),
                                              style: TextStyle(
                                                  fontSize: getMediumFontSize,
                                                  color: selectedPage ==
                                                          "Tax Summary"
                                                      ? Colors.blue
                                                      : Colors.white),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const Divider(
                                      color: Colors.grey,
                                    ),
                                    const Expanded(
                                      child: SizedBox(
                                        height: 10,
                                      ),
                                    )
                                  ]),
                                ),
                                if (selectedPage.isNotEmpty)
                                  Expanded(child: detailsScreen())
                              ],
                            )),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  detailsScreen() {
    return Container(
        height: MediaQuery.of(context).size.height * 0.9,
        margin: const EdgeInsets.all(03),
        decoration: BoxDecoration(
            border: Border.all(
                width: 0.0, color: const Color.fromARGB(255, 255, 255, 255)),
            boxShadow: const [
              BoxShadow(
                color: Color.fromARGB(255, 255, 255, 255),
                blurRadius: 0.0,
              ),
            ],
            color: homeBgColor,
            borderRadius: BorderRadius.circular(3)),
        padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (!showPageDetails) selectDateDialog(),
            Directionality(
                textDirection: TextDirection.ltr,
                child: showPageDetails && selectedPage == "Sales Summary"
                    ? salesSummary()
                    : showPageDetails && selectedPage == "Profit & Loss Report"
                        ? profitAndLossSummary()
                        : showPageDetails && selectedPage == "Tax Summary"
                            ? taxSummary()
                            : showPageDetails &&
                                    selectedPage == "Purchase Summary"
                                ? purchaseSummary()
                                : const SizedBox())
          ],
        ));
  }

  profitAndLossSummary() {
    List<ReceiptOrQuotationData> sortedDbReceiptDataLst = [];

    for (ReceiptOrQuotationData d in dbReceiptDataLst) {
      if (d.isReceiptType()) {
        if (defaultSelectedStoreData.docId == 'All Store' ||
            d.receiptBasicInfo!.selectedStoreDocId ==
                defaultSelectedStoreData.docId) {
          DateTime date = DateTime(
            d.createdDate.year,
            d.createdDate.month,
            d.createdDate.day,
          );

          if (date.compareTo(fromDate!) != -1 && date.compareTo(toDate!) != 1) {
            if (d.receiptBasicInfo!.receiptType == datatype ||
                datatype == 'All Document') {
              sortedDbReceiptDataLst.add(d);
            }
          }
        }
      }
    }

    sortedDbReceiptDataLst.sort((a, b) =>
        a.receiptBasicInfo!.receiptNo.compareTo(b.receiptBasicInfo!.receiptNo));

    List<DbVoucherData> sortedDbVoucherDataLst = getSortedDbVoucherDataLst();

    double totalSalesWithoutTax = 0;
    double totalSalesWithTax = 0;
    double totalPurchaseWithoutTax = 0; //
    double totalCost = 0;
    double taxPercentage = 0;
    double totalTax = 0;

    //receipt
    for (var s in sortedDbReceiptDataLst) {
      taxPercentage = double.parse(s.lineItemTotalData.totalTaxPercentage);
      if (s.receiptBasicInfo!.receiptType == 'Return') {
        totalSalesWithoutTax -=
            double.parse(s.lineItemTotalData.totalBeforeTax);
        totalSalesWithTax -= double.parse(s.lineItemTotalData.receiptTotal);
        for (LineItemData i in s.lineItemsData) {
          totalCost -=
              double.parse(s.lineItemTotalData.totalQty) * double.parse(i.cost);
        }
        totalTax -= double.parse(s.lineItemTotalData.totalTaxValue);
      } else {
        totalSalesWithoutTax +=
            double.parse(s.lineItemTotalData.totalBeforeTax);
        totalSalesWithTax += double.parse(s.lineItemTotalData.receiptTotal);
        for (var i in s.lineItemsData) {
          totalCost +=
              double.parse(s.lineItemTotalData.totalQty) * double.parse(i.cost);
        }
        totalTax += double.parse(s.lineItemTotalData.totalTaxValue);
      }
    }
    totalCost = double.parse(totalCost.toStringAsFixed(digit));
    //voucher
    for (var s in sortedDbVoucherDataLst) {
      if (s.voucherType == 'Return') {
        totalPurchaseWithoutTax -= double.parse(s.voucherTotal);
      } else {
        totalPurchaseWithoutTax += double.parse(s.voucherTotal);
      }
    }

    return ReportPdfViewer(
      selectedStoreName: defaultSelectedStoreData.storeName,
      totalCost: totalCost, inventoryDataLst: allInventoryDataLst,
      fromDate: fromDate,

      selectedPage: selectedPage,
      sortedDbVoucherDataLst: const [],
      sortedDbReceiptDataLst: sortedDbReceiptDataLst,
      tax: 0,
      taxPer: taxSettingsData.taxPercentage,
      toDate: toDate,
      total: 0,
      totalDiscount: 0,
      totalQty: 0,
      //
      profitAndLossReportData: ProfitAndLossReportData(
        totalSalesWithoutTax: totalSalesWithoutTax,
        totalSalesWithTax: totalSalesWithTax,
        totalPurchaseWithoutTax: totalPurchaseWithoutTax,
        totalCost: totalCost,
        taxPercentage: taxPercentage,
        totalTax: totalTax,
      ),

      purTaxValue: -1,
      purTotalSalesWithTax: -1,
      salesTaxValue: -1,
      salesTotalSales: -1,
      salesTotalSalesWithTax: -1,
    );
  }

  List<DbVoucherData> getSortedDbVoucherDataLst() {
    List<DbVoucherData> sortedDbVoucherDataLst = [];

    for (DbVoucherData d in dbVoucherDataLst) {
      if (defaultSelectedStoreData.docId == 'All Store' ||
          d.selectedStoreDocId == defaultSelectedStoreData.docId) {
        DateTime date = DateTime(
          d.createdDate.year,
          d.createdDate.month,
          d.createdDate.day,
        );

        if (date.compareTo(fromDate!) != -1 && date.compareTo(toDate!) != 1) {
          if (d.voucherType == datatype || datatype == 'All Document') {
            sortedDbVoucherDataLst.add(d);
          }
        }
      }
    }

    sortedDbVoucherDataLst.sort((a, b) => a.voucherNo.compareTo(b.voucherNo));
    return sortedDbVoucherDataLst;
  }

  purchaseSummary() {
    List<DbVoucherData> sortedDbVoucherDataLst = getSortedDbVoucherDataLst();
    double totalQty = 0;
    double tax = 0;
    double totalDiscount = 0;
    double total = 0;

    for (var s in sortedDbVoucherDataLst) {
      if (s.voucherType == 'Return') {
        totalQty -= double.parse(s.qtyRecieved);
        // for (var i in s.selectedItems)
        //   totalCost -= double.parse(s.totalQty) * double.parse(i['cost']);
        tax -= double.parse(calculateTaxValue(
            dbVoucherData: s, inventoryDataLst: allInventoryDataLst));
        totalDiscount -= double.parse(s.discountValue);
        total -= double.parse(s.voucherTotal);
      } else {
        totalQty += double.parse(s.qtyRecieved);
        // for (var i in s.selectedItems)
        //   totalCost += double.parse(s.totalQty) * double.parse(i['cost']);
        tax += double.parse(calculateTaxValue(
            dbVoucherData: s, inventoryDataLst: allInventoryDataLst));
        totalDiscount += double.parse(s.discountValue);
        total += double.parse(s.voucherTotal);
      }
    }

    return ReportPdfViewer(
      selectedStoreName: defaultSelectedStoreData.storeName,
      inventoryDataLst: allInventoryDataLst,
      totalCost: 0,

      fromDate: fromDate,
      selectedPage: selectedPage,
      sortedDbVoucherDataLst: sortedDbVoucherDataLst,
      sortedDbReceiptDataLst: const [],
      tax: tax,
      taxPer: taxSettingsData.taxPercentage,
      toDate: toDate,
      total: total,
      totalDiscount: totalDiscount,
      totalQty: totalQty,
      //
      purTaxValue: -1,
      purTotalSalesWithTax: -1,
      salesTaxValue: -1,
      salesTotalSales: -1,
      salesTotalSalesWithTax: -1,
    );
  }

  calculateTotalCost(ReceiptOrQuotationData d) {
    double totalCost = 0;
    for (LineItemData i in d.lineItemsData) {
      totalCost += double.parse(i.cost);
    }
    return totalCost;
  }

  taxSummary() {
    //sales stuff
    List<ReceiptOrQuotationData> sortedDbReceiptDataLst = [];
    for (ReceiptOrQuotationData d in dbReceiptDataLst) {
      if (d.isReceiptType()) {
        DateTime date = DateTime(
          d.createdDate.year,
          d.createdDate.month,
          d.createdDate.day,
        );

        if (date.compareTo(fromDate!) != -1 && date.compareTo(toDate!) != 1) {
          if (d.receiptBasicInfo!.receiptType == datatype ||
              datatype == 'All Document') {
            sortedDbReceiptDataLst.add(d);
          }
        }
      }
    }

    double salesTaxValue = 10;
    double salesTotalSalesWithTax = 0;
    double salesTotalSales = 0;

    for (var s in sortedDbReceiptDataLst) {
      if (s.isReceiptType()) {
        if (s.receiptBasicInfo!.receiptType == 'Return') {
          salesTotalSalesWithTax -=
              double.parse(s.lineItemTotalData.receiptTotal);
        } else {
          salesTotalSalesWithTax +=
              double.parse(s.lineItemTotalData.receiptTotal);
        }
      }
    }

    salesTaxValue = double.parse(
        calculateVatTaxForReceipt(salesTotalSalesWithTax.toString()));
    salesTotalSales = salesTotalSalesWithTax - salesTaxValue;

    //Purchase stuff
    List<DbVoucherData> sortedDbVoucherDataLst = [];
    for (DbVoucherData d in dbVoucherDataLst) {
      DateTime date = DateTime(
        DateTime.parse(d.purchaseInvoiceDate).year,
        DateTime.parse(d.purchaseInvoiceDate).month,
        DateTime.parse(d.purchaseInvoiceDate).day,
      );

      if (date.compareTo(fromDate!) != -1 && date.compareTo(toDate!) != 1) {
        if (d.voucherType == datatype || datatype == 'All Document') {
          sortedDbVoucherDataLst.add(d);
        }
      }
    }

    double purTaxValue = 0;
    double purTotalSalesWithTax = 0;
    for (var s in sortedDbVoucherDataLst) {
      if (s.voucherType == 'Return') {
        purTotalSalesWithTax -= double.parse(s.voucherTotal);
        //calculating tax value
        purTaxValue += calculateTaxValueForVoucher(
            s.selectedItems.map((e) => LocalVoucherData.fromMap(e)).toList(),
            s.discountValue,
            s.tax);
      } else {
        purTotalSalesWithTax += double.parse(s.voucherTotal);
        //calculating tax value
        purTaxValue += calculateTaxValueForVoucher(
            s.selectedItems.map((e) => LocalVoucherData.fromMap(e)).toList(),
            s.discountValue,
            s.tax);
      }
    }

    return ReportPdfViewer(
      selectedStoreName: defaultSelectedStoreData.storeName,
      totalCost: 0, inventoryDataLst: allInventoryDataLst,
      fromDate: fromDate,
      selectedPage: selectedPage,

      sortedDbVoucherDataLst: sortedDbVoucherDataLst,
      sortedDbReceiptDataLst: sortedDbReceiptDataLst,
      taxPer: taxSettingsData.taxPercentage,
      toDate: toDate,
      tax: -1,
      total: -1,
      totalDiscount: -1,
      totalQty: -1,
      //
      purTaxValue: purTaxValue,
      purTotalSalesWithTax: purTotalSalesWithTax,
      salesTaxValue: salesTaxValue,
      salesTotalSales: salesTotalSales,
      salesTotalSalesWithTax: salesTotalSalesWithTax,
    );
  }

  salesSummary() {
    List<ReceiptOrQuotationData> sortedDbReceiptDataLst = [];

    for (ReceiptOrQuotationData d in dbReceiptDataLst) {
      if (d.isReceiptType()) {
        if (defaultSelectedStoreData.docId == 'All Store' ||
            d.receiptBasicInfo!.selectedStoreDocId ==
                defaultSelectedStoreData.docId) {
          DateTime date = DateTime(
            d.createdDate.year,
            d.createdDate.month,
            d.createdDate.day,
          );

          if (date.compareTo(fromDate!) != -1 && date.compareTo(toDate!) != 1) {
            if (d.receiptBasicInfo!.receiptType == datatype ||
                datatype == 'All Document') {
              sortedDbReceiptDataLst.add(d);
            }
          }
        }
      }
    }

    sortedDbReceiptDataLst.sort((a, b) =>
        a.receiptBasicInfo!.receiptNo.compareTo(b.receiptBasicInfo!.receiptNo));

    double totalQty = 0;
    double totalCost = 0;
    double tax = 0;
    double totalDiscount = 0;
    double total = 0;

    for (var s in sortedDbReceiptDataLst) {
      if (s.receiptBasicInfo!.receiptType == 'Return') {
        totalQty -= double.parse(s.lineItemTotalData.totalQty);
        for (LineItemData i in s.lineItemsData) {
          totalCost -=
              double.parse(s.lineItemTotalData.totalQty) * double.parse(i.cost);
        }
        tax -= double.parse(s.lineItemTotalData.totalTaxValue
            // calculateVatTax(s.subTotal)
            );
        totalDiscount -= double.parse(s.lineItemTotalData.totalDiscountValue);
        total -= double.parse(s.lineItemTotalData.receiptTotal);
      } else {
        totalQty += double.parse(s.lineItemTotalData.totalQty);
        for (var i in s.lineItemsData) {
          totalCost +=
              double.parse(s.lineItemTotalData.totalQty) * double.parse(i.cost);
        }
        tax += double.parse(s.lineItemTotalData.totalTaxValue
            // calculateVatTax(s.subTotal)
            );
        totalDiscount += double.parse(s.lineItemTotalData.totalDiscountValue);
        total += double.parse(s.lineItemTotalData.receiptTotal);
      }
    }

    return ReportPdfViewer(
      selectedStoreName: defaultSelectedStoreData.storeName,
      totalCost: totalCost, inventoryDataLst: allInventoryDataLst,
      fromDate: fromDate,

      selectedPage: selectedPage,
      sortedDbVoucherDataLst: const [],
      sortedDbReceiptDataLst: sortedDbReceiptDataLst,
      tax: tax,
      taxPer: taxSettingsData.taxPercentage,
      toDate: toDate,
      total: total,
      totalDiscount: totalDiscount,
      totalQty: totalQty,
      //
      purTaxValue: -1,
      purTotalSalesWithTax: -1,
      salesTaxValue: -1,
      salesTotalSales: -1,
      salesTotalSalesWithTax: -1,
    );
  }

  selectDateDialog() {
    return Container(
        decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: const [
              BoxShadow(
                color: Colors.grey,
                blurRadius: 8.0,
              ),
            ],
            borderRadius: BorderRadius.circular(4)),
        height: 420,
        width: 500,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            // height: 55,
            width: double.maxFinite,
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
            decoration: const BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(4), topRight: Radius.circular(4)),
                gradient: LinearGradient(
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromARGB(255, 66, 66, 66),
                      Color.fromARGB(255, 0, 0, 0),
                    ],
                    begin: Alignment.topCenter)),
            child: Text(
              staticTextTranslate('Reports'),
              style: TextStyle(
                color: Colors.white,
                fontSize: getMediumFontSize + 5,
              ),
            ),
          ),
          const SizedBox(
            height: 30,
          ),
          Padding(
            padding: EdgeInsets.only(left: 20.0),
            child: Text(
              'Select date range, document type and click run to show reports',
              style: GoogleFonts.roboto(fontSize: 14),
            ),
          ),
          Expanded(
              child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(
                children: [
                  SizedBox(
                    width: 170,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(staticTextTranslate('Select Date From'),
                            style: TextStyle(
                              fontSize: getMediumFontSize,
                            )),
                        const SizedBox(
                          height: 5,
                        ),
                        GestureDetector(
                          onTap: () async {
                            DateTime? dateTime = await showDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime(1900),
                              lastDate: DateTime(2050),
                            );

                            if (dateTime != null) {
                              if (toDate != null &&
                                  toDate!.compareTo(dateTime) == -1) {
                                toDate = null;
                                showToDateError = true;
                              }

                              setState(() {
                                fromDate = dateTime;
                                showFromDateError = false;
                              });
                            }
                          },
                          child: Container(
                            width: 200,
                            height: 32,
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(4)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 15, vertical: 5),
                            child: Row(
                              children: [
                                Text(
                                  fromDate == null
                                      ? staticTextTranslate('Select Date')
                                      : DateFormat('dd / MM / yyyy')
                                          .format(fromDate!),
                                  style: TextStyle(
                                      fontSize: getMediumFontSize + 2,
                                      color: fromDate == null
                                          ? Colors.grey
                                          : Colors.black),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        if (showFromDateError)
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: Text(
                                staticTextTranslate('Please select from date'),
                                style: TextStyle(
                                    fontSize: getMediumFontSize,
                                    color: Colors.red[700])),
                          )
                      ],
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  SizedBox(
                    width: 170,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(staticTextTranslate('To'),
                            style: TextStyle(
                              fontSize: getMediumFontSize,
                            )),
                        const SizedBox(
                          height: 5,
                        ),
                        GestureDetector(
                          onTap: () async {
                            DateTime? dateTime = await showDatePicker(
                              context: context,
                              initialDate: fromDate ?? DateTime.now(),
                              firstDate: fromDate ?? DateTime(1900),
                              lastDate: DateTime(2050),
                            );
                            if (dateTime != null) {
                              setState(() {
                                toDate = dateTime;
                                showToDateError = false;
                              });
                            }
                          },
                          child: Container(
                            width: 170,
                            height: 35,
                            decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                                borderRadius: BorderRadius.circular(4)),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 15, vertical: 5),
                            child: Row(
                              children: [
                                Text(
                                  toDate == null
                                      ? staticTextTranslate('Select Date')
                                      : DateFormat('dd / MM / yyyy')
                                          .format(toDate!),
                                  style: TextStyle(
                                      fontSize: getMediumFontSize + 2,
                                      color: toDate == null
                                          ? Colors.grey
                                          : Colors.black),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        if (showToDateError)
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: Text(
                              staticTextTranslate('Please select to date'),
                              style: TextStyle(
                                  fontSize: getMediumFontSize,
                                  color: Colors.red[700]),
                            ),
                          )
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Text(
                'Document type',
                style: TextStyle(
                    fontSize: 14,
                    color: selectedPage == "Tax Summary"
                        ? Colors.grey
                        : Colors.black),
              ),
              const SizedBox(
                height: 5,
              ),
              Container(
                height: 32,
                width: 168,
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                    border: Border.all(
                        width: 0.6,
                        color: selectedPage == "Tax Summary"
                            ? Colors.grey
                            : Colors.black),
                    borderRadius: BorderRadius.circular(3)),
                child: DropdownButton<String>(
                  isExpanded: true,
                  underline: const SizedBox(),
                  items: <String>['All Document', 'Return', 'Regular']
                      .map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value,
                          style: TextStyle(
                            fontSize: getMediumFontSize + 2,
                          )),
                    );
                  }).toList(),
                  value: datatype,
                  onChanged: selectedPage == "Tax Summary"
                      ? null
                      : (val) {
                          datatype = val ?? 'All Document';
                          setState(() {});
                        },
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Text(
                'Selected Store',
                style: TextStyle(
                    fontSize: 14,
                    color: selectedPage == "Tax Summary"
                        ? Colors.grey
                        : Colors.black),
              ),
              const SizedBox(
                height: 5,
              ),
              Container(
                height: 32,
                width: 168,
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                    border: Border.all(
                        width: 0.6,
                        color: selectedPage == "Tax Summary"
                            ? Colors.grey
                            : Colors.black),
                    borderRadius: BorderRadius.circular(3)),
                child: DropdownButton<String>(
                  isExpanded: true,
                  underline: const SizedBox(),
                  items: [
                        DropdownMenuItem<String>(
                          value: 'All Store',
                          child: Text('All Store',
                              style: TextStyle(
                                fontSize: getMediumFontSize + 2,
                              )),
                        )
                      ] +
                      storeDataList.map((StoreData value) {
                        return DropdownMenuItem<String>(
                          value: value.docId,
                          child: Text(value.storeName,
                              style: TextStyle(
                                fontSize: getMediumFontSize + 2,
                              )),
                        );
                      }).toList(),
                  value: defaultSelectedStoreData.docId,
                  onChanged: selectedPage == "Tax Summary"
                      ? null
                      : (val) {
                          if (val != null) {
                            if (val == 'All Store') {
                              defaultSelectedStoreData = StoreData(
                                docId: 'All Store',
                                storeCode: 'All Store',
                                storeName: 'All Store',
                                address: 'All Store',
                                note: 'All Store',
                                accountNumber: '',
                                crNumber: '',
                                isEnabled: true,
                                storeDocumentData: [],
                                subName: '',
                                phone1: 'All Store',
                                phone2: 'All Store',
                                vatNumber: 'All Store',
                                priceLevel: 'All Store',
                                logoPath: 'All Store',
                                email: 'All Store',
                                bankName: 'All Store',
                                additionalNumber: '',
                                area: '',
                                buildingNumber: '',
                                city: '',
                                country: '',
                                postCode: '',
                                shortAddress: '',
                                storeArabicName: '',
                                street: '',
                              );
                            } else {
                              int i = storeDataList.indexWhere(
                                  (element) => element.docId == val);
                              if (i != -1) {
                                defaultSelectedStoreData =
                                    storeDataList.elementAt(i);
                              }
                            }
                          }
                          setState(() {});
                        },
                ),
              )
            ]),
          )),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              decoration: const BoxDecoration(
                  color: Color(0xffdddfe8),
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(4),
                      bottomRight: Radius.circular(4))),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(4),
                        gradient: const LinearGradient(
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xff092F53),
                              Color(0xff284F70),
                            ],
                            begin: Alignment.topCenter)),
                    height: 45,
                    width: 120,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4))),
                        onPressed: () async {
                          bool showData = true;
                          if (toDate == null) {
                            showToDateError = true;
                            showData = false;
                          }
                          if (fromDate == null) {
                            showFromDateError = true;
                            showData = false;
                          }
                          if (showData) showPageDetails = true;
                          setState(() {});
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(
                              Iconsax.shapes,
                              size: 19,
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(staticTextTranslate('Run'),
                                style: TextStyle(
                                  fontSize: getMediumFontSize,
                                )),
                          ],
                        )),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    height: 45,
                    width: 120,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8))),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.cancel_outlined,
                                color: Colors.black, size: 20),
                            const SizedBox(
                              width: 10,
                            ),
                            Text(staticTextTranslate('Cancel'),
                                style: TextStyle(
                                    fontSize: getMediumFontSize,
                                    color: Colors.black)),
                          ],
                        )),
                  ),
                ],
              ),
            ),
          )
        ]));
  }

  String calculateVatTaxForReceipt(String val) {
    double p = double.parse(val);

    return doubleToString(p / (1 + (100 / taxSettingsData.taxPercentage)));
  }

  double calculateVatTaxForVoucher(
      {required String val, required double percentage}) {
    double p = double.parse(val);

    return double.tryParse(doubleToString(p / (1 + (100 / percentage)))) ?? 0;
  }

  double calculateTaxValueForVoucher(List<LocalVoucherData> fullVoucherData,
      String discountValue, String tax) {
    double t = 0;
    for (LocalVoucherData v in fullVoucherData) {
      double d = 0;
      d = double.tryParse(v.cost) ?? 0;
      if (double.tryParse(v.qty) != null) t += d * double.tryParse(v.qty)!;
    }
    if (discountValue.isNotEmpty) {
      double dis = double.tryParse(discountValue) ?? 0;
      if (dis != 0) {
        t = t - dis;
      }
    }
    double taxValue = 0;
    //tax
    if (tax.isNotEmpty) {
      double tx = double.tryParse(tax) ?? 0;

      if (tx != 0) taxValue = (t * tx / 100);
    }

    return double.tryParse(doubleToString(taxValue)) ?? 0;
  }
}
