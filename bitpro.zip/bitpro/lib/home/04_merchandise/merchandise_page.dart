import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:bitpro_hive/home/04_merchandise/department/department_page.dart';
import 'package:bitpro_hive/home/04_merchandise/inventory/inventory_page.dart';
import 'package:bitpro_hive/home/04_merchandise/vendor/vendor_page.dart';
import 'package:bitpro_hive/model/user_group_data.dart';

class MerchandisePage extends StatefulWidget {
  final EmployeeData userData;
  final UserGroupData currentUserRole;
  const MerchandisePage(
      {super.key, required this.userData, required this.currentUserRole});

  @override
  State<MerchandisePage> createState() => _MerchandisePageState();
}

class _MerchandisePageState extends State<MerchandisePage> {
  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 15,
      runSpacing: 15,
      children: [
        if (widget.currentUserRole.inventory)
          OnPageButton(
            label: 'Inventory',
            width: 150,
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          InventoryPage(userData: widget.userData)));
            },
            icon: Iconsax.d_square,
          ),
        if (widget.currentUserRole.vendors)
          OnPageButton(
            label: 'Vendors',
            width: 150,
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => VendorPage(
                            userData: widget.userData,
                          )));
            },
            icon: Iconsax.building,
          ),
        if (widget.currentUserRole.departments)
          OnPageButton(
            label: 'Department',
            width: 160,
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DepartmentPage(
                            userData: widget.userData,
                          )));
            },
            icon: Iconsax.layer,
          ),
        // if (widget.currentUserRole.adjustment)
        //   OnPageButton(
        //     label: 'Adjustment',
        //     width: 160,
        //     onPressed: () {},
        //     icon: Iconsax.pen_tool,
        //   ),
      ],
    );
  }
}
