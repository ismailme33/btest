import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:google_fonts/google_fonts.dart';

class UnitTextField extends StatefulWidget {
  final String label;
  final List<String> availableInvUnits;
  final String? initialValue;
  final Function(String) onChanged;
  final String? Function(String?)? validator;
  final double bradius;
  final double fieldWidth;
  final bool redStarEnabled;
  final String bottomTxt;
  final TextInputType? keyboardType;
  final bool enabled;
  final double height;
  final bool autoFocus;

  const UnitTextField({
    Key? key,
    required this.label,
    required this.onChanged,
    this.validator,
    this.initialValue,
    this.bradius = 2,
    this.fieldWidth = 360,
    this.redStarEnabled = false,
    this.bottomTxt = '',
    this.keyboardType = const TextInputType.numberWithOptions(decimal: true),
    this.enabled = true,
    this.height = 1.1,
    this.autoFocus = false,
    required this.availableInvUnits,
  }) : super(key: key);

  @override
  _UnitTextFieldState createState() => _UnitTextFieldState();
}

class _UnitTextFieldState extends State<UnitTextField> {
  late TextEditingController _controller;
  String _selectedUnit = '';

  @override
  void initState() {
    super.initState();

    _selectedUnit = widget.initialValue ?? '';
    _controller = TextEditingController(text: _selectedUnit);
    _controller.addListener(_onTextChanged);
  }

  void _onTextChanged() {
    final input = _controller.text.trim();
    // final parts = input.split(' ').where((part) => part.isNotEmpty).toList();
    // double? value;
    // String unit = _selectedUnit;

    // if (parts.isNotEmpty) {
    //   value = double.tryParse(parts[0]);
    //   if (parts.length > 1) {
    //     final inputUnit = parts.sublist(1).join(' ');
    //     if (widget.availableInvUnits.contains(inputUnit)) {
    //       _selectedUnit = inputUnit;
    //       unit = inputUnit;
    //     }
    //   }
    // }

    widget.onChanged(input);
  }

  @override
  void dispose() {
    _controller.removeListener(_onTextChanged);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.fieldWidth,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                widget.label,
                style: GoogleFonts.roboto(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              widget.redStarEnabled
                  ? Text(
                      ' *',
                      style: GoogleFonts.roboto(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.red,
                      ),
                    )
                  : const SizedBox(),
            ],
          ),
          const SizedBox(height: 2),
          TypeAheadField<String>(
            textFieldConfiguration: TextFieldConfiguration(
              controller: _controller,
              enabled: widget.enabled,
              autofocus: widget.autoFocus,
              style: GoogleFonts.roboto(
                height: widget.height,
                fontSize: 17, // Assuming getMediumFontSize + 1 ≈ 16 + 1
                fontWeight: FontWeight.w400,
              ),
              decoration: InputDecoration(
                fillColor: Colors.white,
                filled: true,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 9,
                  horizontal: 5,
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(width: 0.3),
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(widget.bradius),
                    topRight: Radius.circular(widget.bradius),
                    bottomLeft: const Radius.circular(2),
                    topLeft: const Radius.circular(2),
                  ),
                ),
                border: OutlineInputBorder(
                  borderSide: const BorderSide(width: 0.3),
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(widget.bradius),
                    topRight: Radius.circular(widget.bradius),
                    bottomLeft: const Radius.circular(2),
                    topLeft: const Radius.circular(2),
                  ),
                ),
              ),
            ),
            suggestionsCallback: (pattern) {
              final input = pattern.trim();
              final spaceIndex = input.lastIndexOf(' ');
              final unitPart =
                  spaceIndex != -1 ? input.substring(spaceIndex + 1) : input;
              return widget.availableInvUnits
                  .where((unit) =>
                      unit.toLowerCase().startsWith(unitPart.toLowerCase()))
                  .toList();
            },
            itemBuilder: (context, suggestion) {
              return ListTile(
                title: Text(
                  suggestion,
                  style: GoogleFonts.roboto(fontSize: 16),
                ),
              );
            },
            onSuggestionSelected: (suggestion) {
              final input = _controller.text;
              final spaceIndex = input.lastIndexOf(' ');
              final valuePart =
                  spaceIndex != -1 ? input.substring(0, spaceIndex) : '';
              _controller.text = '$valuePart $suggestion'.trim();
              setState(() {
                _selectedUnit = suggestion;
              });
              _onTextChanged();
            },
            noItemsFoundBuilder: (context) => const SizedBox.shrink(),
          ),
          widget.bottomTxt.isNotEmpty
              ? const SizedBox(height: 2)
              : const SizedBox(),
          widget.bottomTxt.isNotEmpty
              ? Text(
                  widget.bottomTxt,
                  style: GoogleFonts.roboto(fontSize: 11, color: Colors.black),
                )
              : const SizedBox(),
          const SizedBox(height: 8),
        ],
      ),
    );
  }
}
