import 'dart:io';
import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/home/04_merchandise/inventory/unit_text_field.dart';
import 'package:bitpro_hive/model/department_data.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/settings/receipt_details_data.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/model/vendor_data.dart';
import 'package:bitpro_hive/services/hive/hive_merchandise_db_service/department_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_merchandise_db_service/inventory_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_merchandise_db_service/vendors_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_settings_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/services/save_image_file.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/onpage_panel.dart';
import 'package:bitpro_hive/widget/string_related/get_random_barcode_string.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import 'package:bitpro_hive/model/inventory_data.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import '../../../shared/custom_top_nav_bar.dart';
import '../../../shared/dialogs/discard_changes_dialog.dart';

class CreateEditInventoryPage extends StatefulWidget {
  final EmployeeData userData;
  final bool edit;
  final InventoryData? selectedRowData;
  final List<InventoryData> inventoryDataLst;
  final String newInventoryId;
  final bool hideCustomTab;
  const CreateEditInventoryPage({
    Key? key,
    required this.userData,
    this.edit = false,
    this.hideCustomTab = false,
    this.selectedRowData,
    required this.inventoryDataLst,
    required this.newInventoryId,
  }) : super(key: key);

  @override
  State<CreateEditInventoryPage> createState() =>
      _CreateEditInventoryPageState();
}

class _CreateEditInventoryPageState extends State<CreateEditInventoryPage> {
  String? itemCode;
  String? selectedVendorId;
  String? englishProductName;
  String? selectedDepartmentId;
  String cost = '0';
  String? description;
  String? barcode;
  var formKey = GlobalKey<FormState>();
  bool loading = true;
  File? productImage;
  final GlobalKey _menuKey = GlobalKey();
  final TextEditingController _vendorTypeAheadController =
      TextEditingController();
  final TextEditingController _departmenttypeAheadController =
      TextEditingController();
  TextEditingController marginController = TextEditingController(text: '0');
  TextEditingController priceWtController = TextEditingController(text: '0');
  TextEditingController priceController = TextEditingController(text: '0');
  final priceWtfocus = FocusNode();
  final barcodefocus = FocusNode();
  late TaxSettingsData taxSettingsData;

  bool productPriceCanChange = false;

  List<VendorData> allVendorDataLst = [];
  List<DepartmentData> allDepartmentDataLst = [];

  late int selectedStoreCode;
  late int workstationNumber;

  Color cColor = Colors.red;
  IconData cIcon = Icons.warning;

  late ReceiptSettingData receiptSettingData;

  // String decimalUnit = '';
  String selectedUnit = '';

  List<String> availableInvUnits = [];
  @override
  void initState() {
    super.initState();
    hiveInitData();
  }

  commonInit() async {
    availableInvUnits =
        await HiveInventoryDbService().fetchAllInventoryUnitData();

    selectedStoreCode = await HiveStoreDbService().getSelectedStoreCode();
    workstationNumber = await HiveStoreDbService().getWorkstationNumber();
    //updating tax
    taxSettingsData = await HiveSettingsDbService().getTaxSettingsData();

    receiptSettingData = await HiveSettingsDbService().getReceiptSettingsData();

    barcode = randomBarcodeGenerate();
    if (widget.edit && widget.selectedRowData != null) {
      itemCode = widget.selectedRowData!.itemCode;
      productPriceCanChange = widget.selectedRowData!.productPriceCanChange;
      var vd = allVendorDataLst
          .where((e) => e.vendorId == widget.selectedRowData!.selectedVendorId);
      if (vd.isNotEmpty) {
        selectedVendorId = vd.first.vendorId;
        _vendorTypeAheadController.text = vd.first.vendorName;
      }

      englishProductName = widget.selectedRowData!.productName;

      var dp = allDepartmentDataLst.where((e) =>
          e.departmentId == widget.selectedRowData!.selectedDepartmentId);
      if (dp.isNotEmpty) {
        selectedDepartmentId = dp.first.departmentId;
        _departmenttypeAheadController.text = dp.first.departmentName;
      }

      cost = double.parse(widget.selectedRowData!.cost).toStringAsFixed(digit);
      description = widget.selectedRowData!.description;
      priceController = TextEditingController(
          text: double.parse(widget.selectedRowData!.price)
              .toStringAsFixed(digit));

      marginController = TextEditingController(
          text: double.parse(widget.selectedRowData!.margin)
              .toStringAsFixed(digit));

      priceWtController = TextEditingController(
          text: double.parse(widget.selectedRowData!.priceWT)
              .toStringAsFixed(digit));
      barcode = widget.selectedRowData!.barcode;
      cColor = Colors.green;
      cIcon = Icons.done;
      selectedUnit = widget.selectedRowData!.unit;
    } else {
      itemCode = widget.newInventoryId;
    }
    setState(() {
      loading = false;
    });
  }

  hiveInitData() async {
    //fetching data
    allVendorDataLst = await HiveVendorDbService().fetchAllVendorsData();
    allDepartmentDataLst =
        await HiveDepartmentDbService().fetchAllDepartmentsData();
    await commonInit();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.hideCustomTab) {
      return childBody();
    }

    return CustomNavBar(pageName: 'Inventory', child: childBody());
  }

  childBody() {
    return Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
            child: Row(children: [
          Container(
            color: const Color.fromARGB(255, 43, 43, 43),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SideMenuButton(
                  label: 'Back',
                  iconPath: 'assets/icons/back.png',
                  buttonFunction: () {
                    showDiscardChangesDialog(context);
                  },
                ),
                SideMenuButton(
                    label: 'Save',
                    iconPath: 'assets/icons/save.png',
                    buttonFunction: () => onTapSaveButton())
              ],
            ),
          ),
          Expanded(
            child: loading
                ? showLoading()
                : Form(
                    key: formKey,
                    child: Row(
                      children: [
                        OnPagePanel(
                            widht: 650,
                            imagePickerWidget: imagePickerWidget(),
                            columnForTextField: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    BTextField(
                                      prefixIcon: Icons.tag,
                                      fieldWidth: 175,
                                      textFieldReadOnly: false,
                                      label: 'Item Code / SKU',
                                      initialValue: itemCode,
                                      validator: ((value) {
                                        if (value!.isEmpty) {
                                          return staticTextTranslate(
                                              'Enter item code');
                                        } else if ((widget.edit &&
                                                widget.selectedRowData!
                                                        .itemCode !=
                                                    value) ||
                                            !widget.edit) {
                                          if (widget.inventoryDataLst
                                              .where((e) => e.itemCode == value)
                                              .isNotEmpty) {
                                            return staticTextTranslate(
                                                'Item code is already in use');
                                          }
                                        }
                                        return null;
                                      }),
                                      onChanged: (val) => setState(() {
                                        itemCode = val;
                                      }),
                                      autovalidateMode:
                                          AutovalidateMode.onUserInteraction,
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    BTextField(
                                      prefixIcon: Icons.qr_code,
                                      focusNode: barcodefocus,
                                      fieldWidth: 175,
                                      textFieldReadOnly: false,
                                      label: 'Barcode',
                                      initialValue: barcode,
                                      onChanged: (val) => setState(() {
                                        barcode = val;
                                      }),
                                      autovalidateMode:
                                          AutovalidateMode.onUserInteraction,
                                    ),
                                  ],
                                ),
                                BTextField(
                                  autovalidate: true,
                                  textFieldHeight: null,
                                  validator: (p0) {
                                    if (p0 == '') {
                                      return 'Product Name is Required';
                                    }
                                  },
                                  keyboardType: TextInputType.multiline,
                                  redStarEnabled: true,
                                  bradius: 0,
                                  textFieldReadOnly: false,
                                  label: 'Product Name',
                                  initialValue: englishProductName,
                                  onChanged: (val) => setState(() {
                                    if (val.isEmpty) {
                                      cColor = Colors.red;
                                      cIcon = Icons.warning;
                                    } else {
                                      cColor = Colors.green;
                                      cIcon = Icons.done;
                                    }
                                    englishProductName = val;
                                  }),
                                  autovalidateMode:
                                      AutovalidateMode.onUserInteraction,
                                ),
                                UnitTextField(
                                  fieldWidth: 175,
                                  label: 'Unit',
                                  initialValue: selectedUnit,
                                  onChanged: (unit) {
                                    setState(() {
                                      selectedUnit = unit;
                                    });
                                  },
                                  availableInvUnits: availableInvUnits,
                                ),
                                Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        staticTextTranslate('Vendor'),
                                        style: GoogleFonts.roboto(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      SizedBox(
                                        height: 2,
                                      ),
                                      SizedBox(
                                        width: 360,
                                        child: TypeAheadFormField<VendorData>(
                                          getImmediateSuggestions: false,
                                          enabled: !widget.edit,
                                          textFieldConfiguration:
                                              TextFieldConfiguration(
                                            style: const TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w400),
                                            controller:
                                                _vendorTypeAheadController,
                                            decoration: InputDecoration(
                                              prefixIcon: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 5),
                                                child: Icon(
                                                  Icons.factory,
                                                  size: 18,
                                                ),
                                              ),
                                              prefixIconConstraints:
                                                  BoxConstraints(
                                                      minHeight: 0,
                                                      minWidth: 0),
                                              isDense: true,
                                              fillColor: Colors.white,
                                              filled: true,
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                      vertical: 8,
                                                      horizontal: 5),
                                              hintStyle: TextStyle(
                                                  color: Colors.grey[600]),
                                              border: const OutlineInputBorder(
                                                borderSide:
                                                    BorderSide(width: 0.2),
                                                borderRadius: BorderRadius.all(
                                                  Radius.circular(2),
                                                ),
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: const BorderSide(
                                                    width: 0.3),
                                                borderRadius:
                                                    BorderRadius.circular(2),
                                              ),
                                            ),
                                          ),
                                          noItemsFoundBuilder: (context) {
                                            return Padding(
                                              padding:
                                                  const EdgeInsets.all(5.0),
                                              child: Text(
                                                  staticTextTranslate(
                                                      'No Items Found!'),
                                                  style: TextStyle(
                                                    fontSize:
                                                        getMediumFontSize - 1,
                                                  )),
                                            );
                                          },
                                          validator: (val) {
                                            if (receiptSettingData
                                                    .isVendorMandatory &&
                                                (val!.isEmpty ||
                                                    allVendorDataLst
                                                        .where((e) => e
                                                            .vendorName
                                                            .toLowerCase()
                                                            .contains(val
                                                                .toLowerCase()))
                                                        .toList()
                                                        .isEmpty)) {
                                              return staticTextTranslate(
                                                'Select a vendor',
                                              );
                                            }

                                            return null;
                                          },
                                          suggestionsCallback: (pattern) {
                                            return allVendorDataLst
                                                .where((e) => e.vendorName
                                                    .toLowerCase()
                                                    .contains(
                                                        pattern.toLowerCase()))
                                                .toList();
                                          },
                                          itemBuilder:
                                              (context, VendorData suggestion) {
                                            return ListTile(
                                              title: Text(suggestion.vendorName,
                                                  style: TextStyle(
                                                    fontSize: getMediumFontSize,
                                                  )),
                                              subtitle: Text(
                                                  'Vendor Code: ${suggestion.vendorId}'),
                                            );
                                          },
                                          transitionBuilder: (context,
                                              suggestionsBox, controller) {
                                            return suggestionsBox;
                                          },
                                          onSuggestionSelected:
                                              (VendorData suggestion) {
                                            _vendorTypeAheadController.text =
                                                suggestion.vendorName;

                                            setState(() {
                                              selectedVendorId =
                                                  suggestion.vendorId;
                                            });
                                          },
                                        ),
                                      )
                                    ]),
                                const SizedBox(
                                  height: 8,
                                ),
                                Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        staticTextTranslate('Department'),
                                        style: GoogleFonts.roboto(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      SizedBox(
                                        height: 2,
                                      ),
                                      SizedBox(
                                        width: 360,
                                        child: TypeAheadFormField(
                                          getImmediateSuggestions: false,
                                          enabled: !widget.edit,
                                          validator: (val) {
                                            if (receiptSettingData
                                                    .isDepartmentMandatory &&
                                                (val!.isEmpty ||
                                                    allDepartmentDataLst
                                                        .where((e) => e
                                                            .departmentName
                                                            .toLowerCase()
                                                            .contains(val
                                                                .toLowerCase()))
                                                        .toList()
                                                        .isEmpty)) {
                                              return staticTextTranslate(
                                                  'Select a department');
                                            }
                                            return null;
                                          },
                                          noItemsFoundBuilder: (context) {
                                            return Padding(
                                              padding:
                                                  const EdgeInsets.all(10.0),
                                              child: Text(
                                                  staticTextTranslate(
                                                      'No Items Found!'),
                                                  style: TextStyle(
                                                    fontSize: getMediumFontSize,
                                                  )),
                                            );
                                          },
                                          textFieldConfiguration:
                                              TextFieldConfiguration(
                                            controller:
                                                _departmenttypeAheadController,
                                            style: const TextStyle(
                                                fontSize: 14,
                                                fontWeight: FontWeight.w400),
                                            decoration: InputDecoration(
                                              prefixIcon: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 5),
                                                child: Icon(
                                                  Icons.inventory,
                                                  size: 18,
                                                ),
                                              ),
                                              prefixIconConstraints:
                                                  BoxConstraints(
                                                      minHeight: 0,
                                                      minWidth: 0),
                                              isDense: true,
                                              fillColor: Colors.white,
                                              filled: true,
                                              contentPadding:
                                                  const EdgeInsets.symmetric(
                                                      vertical: 8,
                                                      horizontal: 5),
                                              hintStyle: TextStyle(
                                                  color: Colors.grey[600]),
                                              border: const OutlineInputBorder(
                                                borderRadius: BorderRadius.all(
                                                  Radius.circular(2),
                                                ),
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: const BorderSide(
                                                    width: 0.3),
                                                borderRadius:
                                                    BorderRadius.circular(2),
                                              ),
                                            ),
                                          ),
                                          suggestionsCallback: (pattern) {
                                            return allDepartmentDataLst
                                                .where((e) => e.departmentName
                                                    .toLowerCase()
                                                    .contains(
                                                        pattern.toLowerCase()))
                                                .toList();
                                          },
                                          itemBuilder: (context,
                                              DepartmentData suggestion) {
                                            return ListTile(
                                              title: Text(
                                                  suggestion.departmentName,
                                                  style: TextStyle(
                                                    fontSize: getMediumFontSize,
                                                  )),
                                            );
                                          },
                                          transitionBuilder: (context,
                                              suggestionsBox, controller) {
                                            return suggestionsBox;
                                          },
                                          onSuggestionSelected:
                                              (DepartmentData suggestion) {
                                            _departmenttypeAheadController
                                                    .text =
                                                suggestion.departmentName;
                                            setState(() {
                                              selectedDepartmentId =
                                                  suggestion.departmentId;
                                            });
                                          },
                                        ),
                                      )
                                    ]),
                                const SizedBox(
                                  height: 8,
                                ),
                                BTextField(
                                  textFieldHeight: null,
                                  keyboardType: TextInputType.multiline,
                                  textFieldReadOnly: false,
                                  label: 'Description',
                                  initialValue: description,
                                  onChanged: (val) => setState(() {
                                    description = val;
                                  }),
                                  autovalidateMode:
                                      AutovalidateMode.onUserInteraction,
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                Row(
                                  children: [
                                    BTextField(
                                      fieldWidth: 175,
                                      textFieldReadOnly: false,
                                      keyboardType: TextInputType.number,
                                      label: 'Cost',
                                      initialValue: cost,
                                      validator: ((val) {
                                        if (double.tryParse(val!) == null) {
                                          return staticTextTranslate(
                                              'Enter a number');
                                        }
                                        return null;
                                      }),
                                      onChanged: (val) => setState(() {
                                        cost = val;
                                        marginController.text =
                                            calculateMargin();
                                      }),
                                      autovalidateMode:
                                          AutovalidateMode.onUserInteraction,
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    BTextField(
                                      fieldWidth: 175,
                                      textFieldReadOnly: false,
                                      label: 'Margin',
                                      controller: marginController,
                                      onChanged: (val) => setState(() {
                                        //  FocusScope.of(context)
                                        //                                             .requestFocus(priceWtfocus);
                                      }),
                                      autovalidateMode:
                                          AutovalidateMode.onUserInteraction,
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    BTextField(
                                      fieldWidth: 175,
                                      textFieldReadOnly: false,
                                      label: 'Price',
                                      controller: priceController,
                                      validator: (val) {
                                        if (double.tryParse(val!) == null) {
                                          return staticTextTranslate(
                                              'Enter a number');
                                        }
                                        return null;
                                      },
                                      onChanged: (val) => setState(() {
                                        marginController.text =
                                            calculateMargin();
                                        priceWtController.text =
                                            calculatePriceWt();
                                      }),
                                      autovalidateMode:
                                          AutovalidateMode.onUserInteraction,
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    BTextField(
                                      fieldWidth: 175,
                                      validator: (val) {
                                        if (double.tryParse(val!) == null) {
                                          return staticTextTranslate(
                                              'Enter a number');
                                        }
                                        return null;
                                      },
                                      autovalidateMode:
                                          AutovalidateMode.onUserInteraction,
                                      textFieldReadOnly: false,
                                      label: 'Price W/T',
                                      controller: priceWtController,
                                      onChanged: (val) => setState(() {
                                        priceController.text = calculatePrice();

                                        marginController.text =
                                            calculateMargin();
                                      }),
                                    ),
                                  ],
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                SizedBox(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Checkbox(
                                        fillColor: WidgetStateProperty
                                            .resolveWith<Color>(
                                                (Set<WidgetState> states) {
                                          if (states
                                              .contains(WidgetState.selected)) {
                                            return darkBlueColor; // Color when checked
                                          }
                                          return Colors
                                              .white; // Color when unchecked
                                        }),
                                        side: BorderSide(width: 0.9),
                                        activeColor: darkBlueColor,
                                        value: productPriceCanChange,
                                        onChanged: (newValue) => setState(() =>
                                            productPriceCanChange =
                                                newValue ?? false),
                                      ),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Text(
                                          staticTextTranslate(
                                              'Price can change'),
                                          style: TextStyle(
                                              fontSize: getMediumFontSize,
                                              fontWeight: FontWeight.bold)),
                                      SizedBox(
                                        width: 5,
                                      ),
                                      Tooltip(
                                        message:
                                            'If checked, the price can be changed while making a sale, \nit will ask for price while adding item to the invoice',
                                        child: Icon(
                                          Icons.info_outline,
                                          size: 15,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ],
                            ),
                            rowForButton: Row(
                              children: [
                                OnPageButton(
                                  icon: Iconsax.archive,
                                  label: 'Save',
                                  onPressed: () {
                                    onTapSaveButton();
                                  },
                                ),
                              ],
                            ),
                            topLabel: 'Inventory Details'),
                      ],
                    ),
                  ),
          )
        ])));
  }

  imagePickerWidget() {
    return Padding(
      padding: const EdgeInsets.only(top: 12.0),
      child: SizedBox(
        width: 200,
        height: 200,
        child: Card(
          shape: RoundedRectangleBorder(
              side: const BorderSide(width: 0.5, color: Colors.grey),
              borderRadius: BorderRadius.circular(4)),
          elevation: 0,
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.only(
                top: 10, bottom: 22.0, left: 22, right: 10),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(staticTextTranslate('Product Image'),
                          style: TextStyle(
                            fontSize: getMediumFontSize,
                          )),
                      PopupMenuButton(
                          splashRadius: 1,
                          key: _menuKey,
                          itemBuilder: (_) => <PopupMenuItem<String>>[
                                if (productImage != null)
                                  PopupMenuItem<String>(
                                      value: 'change',
                                      child: Text(
                                          staticTextTranslate('Change Image'),
                                          style: TextStyle(
                                            fontSize: getMediumFontSize,
                                          ))),
                                if (productImage == null)
                                  PopupMenuItem<String>(
                                      value: 'upload',
                                      child: Text(
                                          staticTextTranslate('Upload Image'),
                                          style: TextStyle(
                                            fontSize: getMediumFontSize,
                                          ))),
                                if (productImage != null)
                                  PopupMenuItem<String>(
                                      value: 'cancel',
                                      child: Text(
                                          staticTextTranslate('Remove Image'),
                                          style: TextStyle(
                                            fontSize: getMediumFontSize,
                                          ))),
                              ],
                          icon: Icon(
                            Icons.menu,
                            size: 19,
                          ),
                          onSelected: (val) async {
                            if (val == 'cancel') {
                              productImage = null;
                              setState(() {});
                            } else if (val == 'upload' || val == 'change') {
                              FilePickerResult? result =
                                  await FilePicker.platform.pickFiles(
                                      allowMultiple: false,
                                      dialogTitle:
                                          staticTextTranslate('Product Image'),
                                      type: FileType.image);

                              if (result != null) {
                                productImage = File(result.files.first.path!);
                                setState(() {});
                              }
                            }
                          }),
                    ],
                  ),
                  const SizedBox(
                    height: 0,
                  ),
                  if ((widget.edit &&
                          widget.selectedRowData != null &&
                          widget.selectedRowData!.productImg.isNotEmpty) &&
                      productImage == null)
                    if (File(widget.selectedRowData!.productImg).existsSync())
                      Image.file(
                        File(widget.selectedRowData!.productImg),
                        width: 180,
                        height: 120,
                        fit: BoxFit.contain,
                      ),
                  if (productImage != null)
                    Image.file(
                      productImage!,
                      width: 180,
                      height: 120,
                      fit: BoxFit.contain,
                    ),
                  if (!widget.edit && productImage == null)
                    SizedBox(
                      width: 180,
                      height: 120,
                      child: Icon(Icons.image,
                          size: 80, color: Colors.grey.shade200),
                    )
                ]),
          ),
        ),
      ),
    );
  }

  onTapSaveButton() async {
    if (formKey.currentState!.validate() &&
        englishProductName != null &&
        englishProductName!.isNotEmpty) {
      setState(() {
        loading = true;
      });

      StoreData selectedStoreData =
          await HiveStoreDbService().getSelectedStoreData();

      await HiveInventoryDbService().addEditInventoryData(
          productImgFile: productImage,
          inventoryData: InventoryData(
            unit: selectedUnit,
            isNewInventory: !widget.edit,
            selectedStoreDocId: selectedStoreData.docId,
            itemCode: itemCode!,
            selectedVendorId: selectedVendorId,
            productName: englishProductName!,
            selectedDepartmentId: selectedDepartmentId,
            cost: cost,
            description: description ?? '',
            price: priceController.text,
            margin: marginController.text,
            priceWT: priceWtController.text,
            productImg: 'productImage',
            createdDate: widget.edit && widget.selectedRowData != null
                ? widget.selectedRowData!.createdDate
                : DateTime.now(),
            createdBy: widget.edit && widget.selectedRowData != null
                ? widget.selectedRowData!.createdBy
                : widget.userData.empBasicInfoData.username,
            docId: widget.edit && widget.selectedRowData != null
                ? widget.selectedRowData!.docId
                : getRandomString(20),
            proImgUrl: widget.edit && widget.selectedRowData != null
                ? widget.selectedRowData!.productImg
                : null,
            ohQtyForDifferentStores:
                widget.edit && widget.selectedRowData != null
                    ? widget.selectedRowData!.ohQtyForDifferentStores
                    : {},
            barcode: barcode!,
            productPriceCanChange: productPriceCanChange,
            fbModifiedDate:
                widget.edit ? widget.selectedRowData!.fbModifiedDate : null,
            fbUploadedDate:
                widget.edit ? widget.selectedRowData!.fbUploadedDate : null,
          ));
      Navigator.pop(context, true);
    }
  }

  String calculateMargin() {
    if (priceController.text.isEmpty) return '';
    double c = double.parse(cost);
    double p = double.parse(priceController.text);

    return doubleToString(p - c);
  }

  String calculatePriceWt() {
    if (priceController.text.isEmpty) return '';

    double p = double.parse(priceController.text);
    double total = p * (1 + (taxSettingsData.taxPercentage / 100));

    return total.toStringAsFixed(2);
  }

  String calculatePrice() {
    if (priceWtController.text.isEmpty) return '';

    double p = double.parse(priceWtController.text);

    return doubleToString(
        p - (p / (1 + (100 / taxSettingsData.taxPercentage))));
  }
}
