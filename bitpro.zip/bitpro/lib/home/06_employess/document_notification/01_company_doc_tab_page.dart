import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:bitpro_hive/shared/loading.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'package:intl/intl.dart';
import '../../../shared/global_variables/font_sizes.dart';
import '../../../shared/global_variables/static_text_translate.dart';

class CompanyDocTabPage extends StatefulWidget {
  final EmployeeData userData;
  final Function onTapItem;
  final List<StoreData> storeDataList;
  final int expiryNotificationDays;
  final DataGridController dataGridController1;
  const CompanyDocTabPage(
      {super.key,
      required this.userData,
      required this.onTapItem,
      required this.storeDataList,
      required this.expiryNotificationDays,
      required this.dataGridController1});

  @override
  State<CompanyDocTabPage> createState() => _CompanyDocTabPageState();
}

class _CompanyDocTabPageState extends State<CompanyDocTabPage> {
  final List<BitproGridColumnModel> _bitproGridColumnModel = [
    BitproGridColumnModel(
        columnName: 'serialNumberForStyleColor',
        visible: false,
        label: 'serialNumberForStyleColor',
        width: double.nan),
    BitproGridColumnModel(
        columnName: 'doc_id',
        visible: false,
        label: 'doc_id',
        width: double.nan),
    BitproGridColumnModel(
        columnName: 'store_name',
        label: staticTextTranslate('Store Name'),
        width: 135),
    BitproGridColumnModel(
        columnName: 'cr_number',
        label: staticTextTranslate('CR Number'),
        width: 169),
    BitproGridColumnModel(
        columnName: 'document_name',
        label: staticTextTranslate('Document Name'),
        width: 151,
        allowEditing: true),
    BitproGridColumnModel(
        columnName: 'document_number',
        label: staticTextTranslate('Document Number'),
        width: 170),
    BitproGridColumnModel(
        columnName: 'expiry_date',
        label: staticTextTranslate('Expiry Date'),
        width: 150),
    BitproGridColumnModel(
        columnName: 'day_left',
        label: staticTextTranslate('Day Left'),
        width: 90),
  ];
  String? selectedSearchedStoreDocId;
  String empId = '';
  String empName = '';
  EmployeeDataSource? employeeDataSource;
  DateTime? rangeStartDate;
  DateTime? rangeEndDate;
  bool loading = false;

  var employeeIdController = TextEditingController();
  var employeeNameController = TextEditingController();

  List<StoreData> storeDataList = [];
  DataGridController dataGridController1 = DataGridController();
  @override
  void initState() {
    super.initState();
    storeDataList = widget.storeDataList;
    employeeDataSource = EmployeeDataSource(
        expiryNotificationDays: widget.expiryNotificationDays,
        storeDataList: storeDataList);
  }

  @override
  Widget build(BuildContext context) {
    if (storeDataList != widget.storeDataList) {
      storeDataList = widget.storeDataList;
      employeeDataSource = EmployeeDataSource(
          expiryNotificationDays: widget.expiryNotificationDays,
          storeDataList: storeDataList);
    }
    return Expanded(
      child: Card(
          shape: RoundedRectangleBorder(
              side: const BorderSide(width: 0.5, color: Colors.grey),
              borderRadius: BorderRadius.circular(5)),
          elevation: 0,
          color: Colors.white,
          child: Column(
            children: [
              if (loading) Expanded(child: showLoading()),
              if (!loading)
                BitproGridTable(
                  onChangeRefershFunction: () {
                    setState(() {});
                  },
                  dataGridController: dataGridController1,
                  source: employeeDataSource!,
                  allowEditing: false,
                  allowSorting: true,
                  bitproGridColumnModel: _bitproGridColumnModel,
                ),
            ],
          )),
    );
  }
}

/// Custom business object class which contains properties to hold the detailed
/// information about the employee which will be rendered in datagrid.
class Employee {
  /// Creates the employee class with required details.
  Employee(
    this.id,
    this.name,
    this.userRole,
    this.username,
    this.maxDiscount,
    this.createdDate,
    this.createdBy,
  );

  /// Id of an employee.
  final int id;

  /// Name of an employee.
  final String name;

  /// Designation of an employee.
  final String userRole;

  /// Salary of an employee.
  final String username;
  final String maxDiscount;
  final String createdDate;
  final String createdBy;
}

/// An object to set the employee collection data source to the datagrid. This
/// is used to map the employee data to the datagrid widget.
class EmployeeDataSource extends DataGridSource {
  /// Creates the employee data source class with required details.
  EmployeeDataSource(
      {required int expiryNotificationDays,
      required List<StoreData> storeDataList}) {
    List<Map<String, dynamic>> docLst = [];

    for (var e in storeDataList) {
      for (var c in e.storeDocumentData) {
        if (c.documentExpiryDate != null && c.documentExpiryDate!.isNotEmpty) {
          int diff = DateTime.parse(c.documentExpiryDate!)
              .difference(DateTime(DateTime.now().year, DateTime.now().month,
                  DateTime.now().day))
              .inDays;

          if (diff.isNegative || diff <= expiryNotificationDays) {
            docLst.add({
              "doc_id": c.docId,
              "store_name": e.storeName,
              "cr_number": e.crNumber,
              "document_name": c.documentName,
              "expiry_date": c.documentExpiryDate,
              "day_left": diff.isNegative ? 0 : diff,
              'document_number': c.documentNumber ?? '',
            });
          }
        }
      }
    }

    _employeeData = docLst
        .map<DataGridRow>((e) => DataGridRow(cells: [
              DataGridCell<int>(
                  columnName: 'serialNumberForStyleColor',
                  value: docLst.indexOf(e) + 1),
              DataGridCell<String>(columnName: 'doc_id', value: e['doc_id']),
              DataGridCell<String>(
                  columnName: 'store_name', value: e['store_name']),
              DataGridCell<String>(
                  columnName: 'cr_number', value: e['cr_number']),
              DataGridCell<String>(
                  columnName: 'document_name', value: e['document_name']),
              DataGridCell<String>(
                  columnName: 'document_number',
                  value: e['document_number'] ?? ''),
              DataGridCell<String>(
                  columnName: 'expiry_date',
                  value: DateFormat('MMM d, yyyy')
                      .format(DateTime.parse(e['expiry_date']))),
              DataGridCell<String>(
                  columnName: 'day_left', value: e['day_left'].toString()),
            ]))
        .toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        color: row.getCells()[0].value.isEven
            ? const Color(0xffF1F1F1)
            : Colors.white,
        cells: row.getCells().map<Widget>((e) {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(2.0),
            child: Text(
              e.value.toString(),
              style: GoogleFonts.roboto(
                fontSize: getMediumFontSize + 1,
              ),
            ),
          );
        }).toList());
  }
}
