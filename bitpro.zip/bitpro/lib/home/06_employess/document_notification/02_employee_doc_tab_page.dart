import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/widget/filter_container.dart';
import 'package:bitpro_hive/widget/filter_text_fileds/fiter_textfield.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:bitpro_hive/shared/loading.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

import 'package:intl/intl.dart';
import '../../../shared/global_variables/font_sizes.dart';
import '../../../shared/global_variables/static_text_translate.dart';

class EmployeeDocTabPage extends StatefulWidget {
  final EmployeeData userData;
  final Function onTapItem;
  final List<EmployeeData> employeesDataLst;
  final List<StoreData> storeDataList;
  final int expiryNotificationDays;
  final DataGridController dataGridController2;
  const EmployeeDocTabPage(
      {super.key,
      required this.userData,
      required this.onTapItem,
      required this.employeesDataLst,
      required this.storeDataList,
      required this.expiryNotificationDays,
      required this.dataGridController2});

  @override
  State<EmployeeDocTabPage> createState() => _EmployeeDocTabPageState();
}

class _EmployeeDocTabPageState extends State<EmployeeDocTabPage> {
  final List<BitproGridColumnModel> _bitproGridColumnModel = [
    BitproGridColumnModel(
        columnName: 'serialNumberForStyleColor',
        visible: false,
        label: 'serialNumberForStyleColor',
        width: double.nan),
    BitproGridColumnModel(
        columnName: 'doc_id',
        visible: false,
        label: 'doc_id',
        width: double.nan),
    BitproGridColumnModel(
        columnName: 'emp_full_name',
        label: staticTextTranslate('Employee Full Name'),
        width: 215),
    BitproGridColumnModel(
        columnName: 'store_name',
        label: staticTextTranslate('Store Name'),
        width: 155),
    BitproGridColumnModel(
        columnName: 'document_name',
        label: staticTextTranslate('Document Name'),
        width: 180,
        allowEditing: true),
    BitproGridColumnModel(
        columnName: 'document_number',
        label: staticTextTranslate('Document Number'),
        width: 200),
    BitproGridColumnModel(
        columnName: 'expiry_date',
        label: staticTextTranslate('Expiry Date'),
        width: 150),
    BitproGridColumnModel(
        columnName: 'hijri_expiry_date',
        label: staticTextTranslate('Hijri Expiry Date'),
        width: 180),
    BitproGridColumnModel(
        columnName: 'day_left',
        label: staticTextTranslate('Day Left'),
        width: 125),
  ];
  List<EmployeeData> employeesDataLst = [];

  String? selectedSearchedStoreDocId;
  String? selectedSearchedStoreSubname;
  String empId = '';
  String empName = '';
  EmployeeDataSource? employeeDataSource;
  DateTime? rangeStartDate;
  DateTime? rangeEndDate;
  bool loading = false;

  var employeeIdController = TextEditingController();
  var employeeNameController = TextEditingController();
  final _subNameTypeAheadController = TextEditingController();
  final _storeNameTypeAheadController = TextEditingController();

  List<StoreData> storeDataList = [];
  DataGridController dataGridController2 = DataGridController();
  @override
  void initState() {
    super.initState();
    employeesDataLst = widget.employeesDataLst;
    storeDataList = widget.storeDataList;

    employeeDataSource = EmployeeDataSource(
        employeeData: employeesDataLst,
        expiryNotificationDays: widget.expiryNotificationDays,
        storeDataList: storeDataList);
  }

  searchEmpId(String id) {
    empId = id;
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (id.isEmpty) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          expiryNotificationDays: widget.expiryNotificationDays,
          storeDataList: storeDataList);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      if (ud.empBasicInfoData.employeeId
          .toLowerCase()
          .contains(id.toLowerCase())) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        employeeData: filteredEmployeesDataLst,
        expiryNotificationDays: widget.expiryNotificationDays,
        storeDataList: storeDataList);
    setState(() {});
  }

  searchEmpStore(String storeDocId) {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (storeDocId.isEmpty || storeDocId == staticTextTranslate('All Store')) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          expiryNotificationDays: widget.expiryNotificationDays,
          storeDataList: storeDataList);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      if (ud.empWorkAndRolesData.assignedStoreDocId == storeDocId) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        employeeData: filteredEmployeesDataLst,
        expiryNotificationDays: widget.expiryNotificationDays,
        storeDataList: storeDataList);
    setState(() {});
  }

  searchEmpStoreSubName(String storeDocId) {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (storeDocId.isEmpty ||
        storeDocId == staticTextTranslate('All Sub Name')) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          expiryNotificationDays: widget.expiryNotificationDays,
          storeDataList: storeDataList);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      if (ud.empWorkAndRolesData.assignedStoreDocId == storeDocId) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        employeeData: filteredEmployeesDataLst,
        expiryNotificationDays: widget.expiryNotificationDays,
        storeDataList: storeDataList);
    setState(() {});
  }

  searchEmpName(String name) {
    empName = name;
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (name.isEmpty) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          expiryNotificationDays: widget.expiryNotificationDays,
          storeDataList: storeDataList);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      String nam =
          '${ud.empBasicInfoData.firstName.toLowerCase()} ${ud.empBasicInfoData.lastName.toLowerCase()}';
      if (nam.contains(name.toLowerCase())) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        employeeData: filteredEmployeesDataLst,
        expiryNotificationDays: widget.expiryNotificationDays,
        storeDataList: storeDataList);
    setState(() {});
  }

  filterAccordingSelectedDate() {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (rangeStartDate != null && rangeEndDate != null) {
      for (var emp in employeesDataLst) {
        DateTime createdDate = DateTime.parse(emp.empBasicInfoData.createdDate);
        DateTime tmp =
            DateTime(createdDate.year, createdDate.month, createdDate.day);
        if (tmp.compareTo(rangeStartDate!) != -1 &&
            (tmp.compareTo(rangeEndDate!) != 1)) {
          filteredEmployeesDataLst.add(emp);
        }
      }
    } else if (rangeStartDate != null) {
      var res = employeesDataLst.where((e) =>
          DateTime.parse(e.empBasicInfoData.createdDate).day ==
              rangeStartDate!.day &&
          DateTime.parse(e.empBasicInfoData.createdDate).month ==
              rangeStartDate!.month &&
          DateTime.parse(e.empBasicInfoData.createdDate).year ==
              rangeStartDate!.year);

      filteredEmployeesDataLst = res.toList();
    }

    employeeDataSource = EmployeeDataSource(
        employeeData: filteredEmployeesDataLst,
        expiryNotificationDays: widget.expiryNotificationDays,
        storeDataList: storeDataList);
    rangeStartDate = null;
    rangeEndDate = null;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (widget.employeesDataLst != employeesDataLst) {
      employeesDataLst = widget.employeesDataLst;
      storeDataList = widget.storeDataList;
      employeeDataSource = EmployeeDataSource(
          employeeData: widget.employeesDataLst,
          expiryNotificationDays: widget.expiryNotificationDays,
          storeDataList: storeDataList);
    }
    return Expanded(
      child: Card(
          shape: RoundedRectangleBorder(
              side: const BorderSide(width: 0.5, color: Colors.grey),
              borderRadius: BorderRadius.circular(5)),
          elevation: 0,
          color: Colors.white,
          child: Column(
            children: [
              //filter
              filterWidget(),
              if (loading) Expanded(child: showLoading()),
              if (!loading)
                BitproGridTable(
                  onChangeRefershFunction: () {
                    setState(() {});
                  },
                  dataGridController: dataGridController2,
                  source: employeeDataSource!,
                  allowEditing: false,
                  allowSorting: true,
                  bitproGridColumnModel: _bitproGridColumnModel,
                ),
            ],
          )),
    );
  }

  filterWidget() {
    return FilterContainer(fiterFields: [
      FilterTextField(
        onPressed: () {
          employeeIdController.clear();
          searchEmpId('');
        },
        icon: Icon(
            employeeIdController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: employeeIdController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        controller: employeeIdController,
        hintText: 'Employee ID',
        onChanged: (val) {
          searchEmpId(val);
        },
      ),
      FilterTextField(
        onPressed: () {
          employeeNameController.clear();
          searchEmpId('');
        },
        icon: Icon(
            employeeNameController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: employeeNameController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        controller: employeeNameController,
        hintText: 'Employee Name',
        onChanged: (val) {
          searchEmpName(val);
        },
      ),
      Container(
        width: 230,
        height: 32,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.5),
            color: const Color.fromARGB(255, 255, 255, 255),
            borderRadius: BorderRadius.circular(5)),
        padding: const EdgeInsets.only(
          right: 10,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              padding: const EdgeInsets.only(top: 3),
              onPressed: () {
                _storeNameTypeAheadController.clear();
                searchEmpStore('');
                setState(() {});
              },
              splashRadius: 1,
              icon: Icon(
                  _storeNameTypeAheadController.text.isEmpty
                      ? CupertinoIcons.search
                      : Icons.clear,
                  size: 18,
                  color: _storeNameTypeAheadController.text.isEmpty
                      ? Colors.grey[600]
                      : Colors.black),
            ),
            Flexible(
              child: TypeAheadFormField(
                getImmediateSuggestions: false,
                textFieldConfiguration: TextFieldConfiguration(
                  controller: _storeNameTypeAheadController,
                  decoration: InputDecoration(
                    hintText: staticTextTranslate('Store Name'),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                    contentPadding: const EdgeInsets.only(bottom: 16, right: 5),
                    border: InputBorder.none,
                  ),
                ),
                suggestionsCallback: (pattern) {
                  return storeDataList
                      .where((e) => e.storeName
                          .toLowerCase()
                          .contains(pattern.toLowerCase()))
                      .toList();
                },
                noItemsFoundBuilder: (context) {
                  return Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(staticTextTranslate('No Items Found!'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                itemBuilder: (context, StoreData suggestion) {
                  return ListTile(
                    title: Text(suggestion.storeName,
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                transitionBuilder: (context, suggestionsBox, controller) {
                  return suggestionsBox;
                },
                onSuggestionSelected: (StoreData suggestion) {
                  _storeNameTypeAheadController.text = suggestion.storeName;
                  setState(() {
                    searchEmpStore(suggestion.docId);
                    setState(() {});
                  });
                },
              ),
            ),
          ],
        ),
      ),
      Container(
        width: 230,
        height: 32,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.5),
            color: const Color.fromARGB(255, 255, 255, 255),
            borderRadius: BorderRadius.circular(5)),
        padding: const EdgeInsets.only(
          right: 10,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              padding: const EdgeInsets.only(top: 3),
              onPressed: () {
                _subNameTypeAheadController.clear();
                searchEmpStoreSubName('');
                setState(() {});
              },
              splashRadius: 1,
              icon: Icon(
                  _subNameTypeAheadController.text.isEmpty
                      ? CupertinoIcons.search
                      : Icons.clear,
                  size: 18,
                  color: _subNameTypeAheadController.text.isEmpty
                      ? Colors.grey[600]
                      : Colors.black),
            ),
            Flexible(
              child: TypeAheadFormField(
                getImmediateSuggestions: false,
                textFieldConfiguration: TextFieldConfiguration(
                  controller: _subNameTypeAheadController,
                  decoration: InputDecoration(
                    hintText: staticTextTranslate('Sub Name'),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                    contentPadding: const EdgeInsets.only(bottom: 16, right: 5),
                    border: InputBorder.none,
                  ),
                ),
                suggestionsCallback: (pattern) {
                  return storeDataList
                      .where((e) => e.subName.isNotEmpty)
                      .toList()
                      .where((e) => e.subName
                          .toLowerCase()
                          .contains(pattern.toLowerCase()))
                      .toList();
                },
                noItemsFoundBuilder: (context) {
                  return Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(staticTextTranslate('No Items Found!'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                itemBuilder: (context, StoreData suggestion) {
                  return ListTile(
                    title: Text(suggestion.subName,
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                transitionBuilder: (context, suggestionsBox, controller) {
                  return suggestionsBox;
                },
                onSuggestionSelected: (StoreData suggestion) {
                  _subNameTypeAheadController.text = suggestion.storeName;
                  setState(() {
                    searchEmpStoreSubName(suggestion.docId);
                    setState(() {});
                  });
                },
              ),
            ),
          ],
        ),
      ),
    ]);
  }
}

/// Custom business object class which contains properties to hold the detailed
/// information about the employee which will be rendered in datagrid.
class Employee {
  /// Creates the employee class with required details.
  Employee(
    this.id,
    this.name,
    this.userRole,
    this.username,
    this.maxDiscount,
    this.createdDate,
    this.createdBy,
  );

  /// Id of an employee.
  final int id;

  /// Name of an employee.
  final String name;

  /// Designation of an employee.
  final String userRole;

  /// Salary of an employee.
  final String username;
  final String maxDiscount;
  final String createdDate;
  final String createdBy;
}

/// An object to set the employee collection data source to the datagrid. This
/// is used to map the employee data to the datagrid widget.
class EmployeeDataSource extends DataGridSource {
  /// Creates the employee data source class with required details.
  EmployeeDataSource(
      {required List<EmployeeData> employeeData,
      required int expiryNotificationDays,
      required List<StoreData> storeDataList}) {
    List<Map<String, dynamic>> docLst = [];

    for (var e in employeeData) {
      for (var c in e.empDocumentDataLst) {
        if (c.documentExpiryDate != null && c.documentExpiryDate!.isNotEmpty) {
          int diff = DateTime.parse(c.documentExpiryDate!)
              .difference(DateTime(DateTime.now().year, DateTime.now().month,
                  DateTime.now().day))
              .inDays;

          if (diff.isNegative || diff <= expiryNotificationDays) {
            String storeName = "";

            int i = storeDataList.indexWhere(
                (s) => s.docId == e.empWorkAndRolesData.assignedStoreDocId);
            if (i != -1) {
              storeName = storeDataList[i].storeName;
            }
            docLst.add({
              "emp_full_name":
                  '${e.empBasicInfoData.firstName} ${e.empBasicInfoData.lastName}',
              "doc_id": c.docId,
              "store_name": storeName,
              "document_name": c.documentName,
              "expiry_date": c.documentExpiryDate,
              "day_left": diff.isNegative ? 0 : diff,
              'document_number': c.documentNumber ?? '',
            });
          }
        }
      }
    }

    _employeeData = docLst
        .map<DataGridRow>((e) => DataGridRow(cells: [
              DataGridCell<int>(
                  columnName: 'serialNumberForStyleColor',
                  value: docLst.indexOf(e) + 1),
              DataGridCell<String>(columnName: 'doc_id', value: e['doc_id']),
              DataGridCell<String>(
                  columnName: 'emp_full_name', value: e['emp_full_name']),
              DataGridCell<String>(
                  columnName: 'store_name', value: e['store_name']),
              DataGridCell<String>(
                  columnName: 'document_name', value: e['document_name']),
              DataGridCell<String>(
                  columnName: 'document_number',
                  value: e['document_number'] ?? ''),
              DataGridCell<String>(
                  columnName: 'expiry_date',
                  value: DateFormat('MMM d, yyyy')
                      .format(DateTime.parse(e['expiry_date']))),
              DataGridCell<String>(
                columnName: 'hijri_expiry_date',
                value: HijriCalendar.fromDate(
                        DateTime.parse(e['expiry_date'] ?? ''))
                    .toFormat("dd MMMM yyyy"),
              ),
              DataGridCell<String>(
                  columnName: 'day_left', value: e['day_left'].toString()),
            ]))
        .toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        color: row.getCells()[0].value.isEven
            ? const Color(0xffF1F1F1)
            : Colors.white,
        cells: row.getCells().map<Widget>((e) {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(2.0),
            child: Text(
              e.value.toString(),
              style: GoogleFonts.roboto(
                fontSize: getMediumFontSize + 1,
              ),
            ),
          );
        }).toList());
  }
}
