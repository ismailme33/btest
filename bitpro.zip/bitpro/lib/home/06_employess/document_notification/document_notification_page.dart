import 'package:bitpro_hive/home/06_employess/document_notification/01_company_doc_tab_page.dart';
import 'package:bitpro_hive/home/06_employess/document_notification/02_employee_doc_tab_page.dart';
import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/settings/default_settings_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_settings_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_user_db_service.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/widget/bottom_panel_for_dialog.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:bitpro_hive/shared/custom_top_nav_bar.dart';
import 'package:hijri/hijri_calendar.dart';
import 'package:jhijri_picker/jhijri_picker.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:intl/intl.dart';

class DocumentNotificationPage extends StatefulWidget {
  final EmployeeData userData;
  const DocumentNotificationPage({super.key, required this.userData});

  @override
  State<DocumentNotificationPage> createState() =>
      _DocumentNotificationPageState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _DocumentNotificationPageState extends State<DocumentNotificationPage> {
  int selectedTabIndex = 0;
//doc_name, expiry_date and doc_id
  // List? selectedDocIds;

  String? selectedDocId;

  List<EmployeeData> employeesDataLst = [];
  List<StoreData> storeDataList = [];

  late GeneralSettingsData generalSettingsData;

  bool isLoading = true;

  DataGridController dataGridController1 = DataGridController();
  DataGridController dataGridController2 = DataGridController();
  @override
  void initState() {
    super.initState();
    hiveFetchData();
  }

  hiveFetchData() async {
    storeDataList = await HiveStoreDbService().fetchAllStoresData();
    employeesDataLst = await HiveUserDbService().fetchAllUserData();
    generalSettingsData =
        await HiveSettingsDbService().getGeneralSettingsData();

    setState(() {
      isLoading = false;
    });
  }

  onTapItem(String docId) {
    selectedDocId = docId;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return showLoading();
    return CustomNavBar(
      pageName: 'Document Notification',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Container(
            color: homeBgColor,
            child: Container(
              color: homeBgColor,
              child: Row(
                children: [
                  Container(
                    color: const Color.fromARGB(255, 43, 43, 43),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 0,
                        ),
                        SideMenuButton(
                          label: 'Back',
                          iconPath: 'assets/icons/back.png',
                          buttonFunction: () {
                            Navigator.pop(context);
                          },
                        ),
                        SideMenuButton(
                          label: 'Edit',
                          enable: selectedDocId != null,
                          iconPath: 'assets/icons/edit.png',
                          buttonFunction: () async {
                            if (selectedDocId != null) {
                              String docID = selectedDocId!;

                              //checking in store
                              for (var s in storeDataList) {
                                int i = s.storeDocumentData
                                    .indexWhere((e) => e.docId == docID);
                                if (i != -1) {
                                  String? expiryDate =
                                      s.storeDocumentData[i].documentExpiryDate;
                                  if (expiryDate != null) {
                                    Map? res = await showCreateDocumentDialog(
                                        context: context,
                                        expiryDate: expiryDate,
                                        showHijriDatePicker: false,
                                        noteData: s.note);
                                    if (res != null) {
                                      s.storeDocumentData[i]
                                              .documentExpiryDate =
                                          res['documentExpiryDate'];
                                      s.note = res['note'];
                                      await HiveStoreDbService()
                                          .addEditStoreData(s);
                                      storeDataList = await HiveStoreDbService()
                                          .fetchAllStoresData();
                                      showToast(
                                          "Document Expiry date udpate successfully",
                                          context);
                                      break;
                                    }
                                  }
                                }
                              }

                              //checkign in employee
                              for (var s in employeesDataLst) {
                                int i = s.empDocumentDataLst
                                    .indexWhere((e) => e.docId == docID);

                                // int j = s.empCertificateDataLst
                                //     .indexWhere((e) => e.docId == docID);
                                if (i != -1) {
                                  String? expiryDate = s
                                      .empDocumentDataLst[i].documentExpiryDate;
                                  if (expiryDate != null) {
                                    Map? res = await showCreateDocumentDialog(
                                        context: context,
                                        expiryDate: expiryDate,
                                        noteData:
                                            s.empBasicInfoData.note ?? '');

                                    if (res != null) {
                                      s.empDocumentDataLst[i]
                                              .documentExpiryDate =
                                          res['documentExpiryDate'];
                                      s.empDocumentDataLst[i]
                                              .documentHijriExpiryDate =
                                          res['documentExpiryDate'];

                                      s.empBasicInfoData.note = res['note'];
                                      await HiveUserDbService().addEditUser(s);
                                      employeesDataLst =
                                          await HiveUserDbService()
                                              .fetchAllUserData();
                                      showToast(
                                          "Document Expiry date udpate successfully",
                                          context);

                                      break;
                                    }
                                  }
                                }
                              }

                              setState(() {});
                            } else {
                              showToast('Please select an item', context);
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    width: 0,
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(left: 6, right: 6, top: 6),
                          height: 35,
                          // padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                          decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(4),
                                topRight: Radius.circular(4)),
                            gradient: LinearGradient(
                                end: Alignment.bottomCenter,
                                colors: [
                                  Color.fromARGB(255, 51, 51, 51),
                                  Color.fromARGB(255, 51, 51, 51),
                                ],
                                begin: Alignment.topCenter),
                          ),
                          child: Row(
                            children: [
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    selectedTabIndex = 0;
                                  });
                                },
                                child: Container(
                                  width: 120,
                                  height: 35,
                                  decoration: BoxDecoration(
                                      border: Border.all(width: 0.6),
                                      borderRadius: BorderRadius.circular(0),
                                      gradient: selectedTabIndex == 0
                                          ? const LinearGradient(
                                              end: Alignment.bottomCenter,
                                              colors: [
                                                Color.fromARGB(
                                                    255, 12, 65, 114),
                                                Color.fromARGB(
                                                    255, 12, 65, 114),
                                              ],
                                              begin: Alignment.topCenter)
                                          : null),
                                  alignment: Alignment.center,
                                  child: Text(
                                    "Employee Doc",
                                    style: GoogleFonts.roboto(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.white),
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    selectedTabIndex = 1;
                                  });
                                },
                                child: Container(
                                  width: 120,
                                  height: 35,
                                  decoration: BoxDecoration(
                                      border: Border.all(width: 0.6),
                                      borderRadius: BorderRadius.circular(0),
                                      gradient: selectedTabIndex == 1
                                          ? const LinearGradient(
                                              end: Alignment.bottomCenter,
                                              colors: [
                                                Color.fromARGB(
                                                    255, 12, 65, 114),
                                                Color.fromARGB(
                                                    255, 12, 65, 114),
                                              ],
                                              begin: Alignment.topCenter)
                                          : null),
                                  alignment: Alignment.center,
                                  child: Text(
                                    "Company Doc",
                                    style: GoogleFonts.roboto(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.white),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (selectedTabIndex == 1)
                          CompanyDocTabPage(
                            dataGridController1: dataGridController1,
                            storeDataList: storeDataList,
                            expiryNotificationDays:
                                generalSettingsData.expiryNotificationDays,
                            onTapItem: onTapItem,
                            userData: widget.userData,
                          )
                        else
                          EmployeeDocTabPage(
                            dataGridController2: dataGridController2,
                            expiryNotificationDays:
                                generalSettingsData.expiryNotificationDays,
                            storeDataList: storeDataList,
                            employeesDataLst: employeesDataLst,
                            onTapItem: onTapItem,
                            userData: widget.userData,
                          ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<Map?> showCreateDocumentDialog(
      {required context,
      required String expiryDate,
      required String noteData,
      bool showHijriDatePicker = true}) async {
    String documentExpiryDate = expiryDate;
    String note = noteData;
    return await showDialog(
        context: context,
        builder: (context2) {
          return StatefulBuilder(builder: (context, setState) {
            return Dialog(
              child: SizedBox(
                width: 460,
                height: 340,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    BlackTopPanelForDialogWindow(label: 'Update Expiry Date'),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.all(25),
                        child: Column(
                          children: [
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    staticTextTranslate('Expiry Date'),
                                    style: GoogleFonts.roboto(
                                      fontSize: getMediumFontSize + 2,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  SizedBox(
                                    width: 240,
                                    height: 28,
                                    child: GestureDetector(
                                      onTap: () async {
                                        DateTime? dateTime =
                                            await showDatePicker(
                                          context: context,
                                          currentDate: DateTime.now(),
                                          initialDate: DateTime.tryParse(
                                              documentExpiryDate),
                                          firstDate: DateTime(1900),
                                          lastDate: DateTime(2050),
                                        );
                                        if (dateTime != null) {
                                          documentExpiryDate =
                                              dateTime.toString();

                                          setState(() {});
                                        }
                                      },
                                      child: Container(
                                        width: 200,
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: const Color.fromARGB(
                                                    255, 0, 0, 0),
                                                width: 0.4),
                                            borderRadius:
                                                BorderRadius.circular(2)),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 5, vertical: 5),
                                        child: Row(
                                          children: [
                                            Text(
                                              documentExpiryDate.isEmpty
                                                  ? staticTextTranslate(
                                                      'Click to Select Date')
                                                  : DateFormat('dd / MM / yyyy')
                                                      .format(DateTime.parse(
                                                          documentExpiryDate)),
                                              style: GoogleFonts.roboto(
                                                  fontSize: 16,
                                                  height: 1.1,
                                                  color: const Color.fromARGB(
                                                      255, 0, 0, 0)),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            if (showHijriDatePicker &&
                                generalSettingsData.isHijriDateEnable)
                              SizedBox(
                                height: 10,
                              ),
                            if (showHijriDatePicker &&
                                generalSettingsData.isHijriDateEnable)
                              SizedBox(
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      staticTextTranslate('Doc Exp Hijri Date'),
                                      style: GoogleFonts.roboto(
                                        fontSize: getMediumFontSize + 2,
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    SizedBox(
                                      width: 240,
                                      height: 28,
                                      child: GestureDetector(
                                        onTap: () async {
                                          // JPickerValue? res =
                                          await showGlobalDatePicker(
                                            context: context,
                                            startDate: JDateModel(
                                                dateTime: DateTime.parse(
                                                    "1984-12-24")),
                                            selectedDate: JDateModel(
                                                dateTime: DateTime.tryParse(
                                                    documentExpiryDate)),
                                            onChange: (datetime) {
                                              documentExpiryDate =
                                                  datetime.date.toString();

                                              setState(() {});
                                            },
                                            endDate: JDateModel(
                                                dateTime: DateTime.parse(
                                                    "2050-09-20")),
                                            pickerMode: DatePickerMode.day,
                                            pickerTheme: Theme.of(context),
                                            okButtonText: "Ok",
                                            cancelButtonText: "Cancel",
                                            onOk: (value) {
                                              debugPrint(value.toString());
                                              Navigator.pop(context, value);
                                            },
                                            onCancel: () {
                                              Navigator.pop(context);
                                            },
                                            primaryColor: Colors.blue,
                                            backgroundColor: Colors.white,
                                            borderRadius:
                                                const Radius.circular(10),
                                          );
                                        },
                                        child: Container(
                                          width: 200,
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              border: Border.all(
                                                  color: const Color.fromARGB(
                                                      255, 0, 0, 0),
                                                  width: 0.4),
                                              borderRadius:
                                                  BorderRadius.circular(2)),
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 5, vertical: 5),
                                          child: Row(
                                            children: [
                                              Text(
                                                documentExpiryDate.isEmpty
                                                    ? staticTextTranslate(
                                                        'Click to Select Date')
                                                    : HijriCalendar.fromDate(
                                                            DateTime.parse(
                                                                documentExpiryDate))
                                                        .toFormat(
                                                            "dd MMMM yyyy"),
                                                style: GoogleFonts.roboto(
                                                    fontSize: 16,
                                                    height: 1.1,
                                                    color: Colors.black),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            SizedBox(
                              height: 10,
                            ),
                            BTextField(
                              textFieldHeight: 3,
                              textFieldReadOnly: false,
                              initialValue: note,
                              label: 'Note',
                              onChanged: (v) {
                                setState(() {
                                  note = v;
                                });
                              },
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                            ),
                          ],
                        ),
                      ),
                    ),
                    BottomPanelForDialog(buttons: [
                      OnPageGreyButton(
                        label: 'Cancel',
                        onPressed: () {
                          Navigator.pop(context2);
                        },
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      OnPageButton(
                          label: 'Save',
                          onPressed: () {
                            Navigator.pop(context2, {
                              "documentExpiryDate":
                                  DateTime.parse(documentExpiryDate).toString(),
                              "note": note,
                            });
                          },
                          icon: Icons.save)
                    ])
                  ],
                ),
              ),
            );
          });
        });
  }
}
