import 'dart:io';

import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_1/box_1_widget.dart';
import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_2/box_2_widget.dart';
import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/upload_image_service.dart';
import 'package:bitpro_hive/services/hive/hive_user_db_service.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/material.dart';
import 'package:bitpro_hive/model/user_group_data.dart';
import 'package:bitpro_hive/shared/custom_top_nav_bar.dart';
import 'package:bitpro_hive/shared/dialogs/discard_changes_dialog.dart';
import 'package:bitpro_hive/shared/loading.dart';
import '../../../../shared/global_variables/color.dart';

class CreateEditEmployeesPage extends StatefulWidget {
  final List<UserGroupData> userGroupsDataLst;
  final EmployeeData userData;
  final List<EmployeeData> empLstData;
  final bool edit;
  final EmployeeData? selectedRowData;

  const CreateEditEmployeesPage({
    super.key,
    required this.userGroupsDataLst,
    required this.userData,
    this.edit = false,
    this.selectedRowData,
    required this.empLstData,
  });

  @override
  State<CreateEditEmployeesPage> createState() =>
      _CreateEditEmployeesPageState();
}

class _CreateEditEmployeesPageState extends State<CreateEditEmployeesPage> {
  bool isLoading = true;

  // int selectedTabIndex = 0; // basic_info, work & roles and personal

  EmployeeData employeeData = EmployeeData(
      empBasicInfoData: EmpBasicInfoData(
        employeeId: '1100000001',
        employeedStatus: 'active',
        firstName: '',
        note: '',
        lastName: '',
        email: '',
        username: '',
        password: '',
        createdDate: DateTime.now().toString(),
        createdBy: '',
      ),
      empWorkAndRolesData: EmpWorkAndRolesData(
          assignedStoreDocId: null,
          department: null,
          position: '',
          title: null,
          discountPercentage: '0',
          userGroupId: '',
          dateOfJoining: null,
          employeeType: null,
          workingCity: null,
          workPhone: null,
          workMobilePhone: null),
      empPersonalData: EmpPersonalData(
          personalMobile: null,
          otherEmail: null,
          birthDate: null,
          gender: null,
          maritalStatus: null,
          citizenship: null,
          address: null,
          homeAddress: null,
          emergencyContactName: null,
          relationship: null,
          emergencyPhone: null,
          employeeImagePath: null),
      empDocumentDataLst: [
        EmpDocumentData(
            docId: getRandomString(12),
            documentName: 'NATIONAL /RESIDENT ID',
            donNotAllowDeleting: true,
            documentHijriExpiryDate: null,
            documentNumber: null,
            documentIssueDate: null,
            documentExpiryDate: null,
            documentFilePath: null),
        EmpDocumentData(
            docId: getRandomString(12),
            documentName: 'PASSPORT',
            documentHijriExpiryDate: null,
            donNotAllowDeleting: true,
            documentNumber: null,
            documentIssueDate: null,
            documentExpiryDate: null,
            documentFilePath: null),
        EmpDocumentData(
            docId: getRandomString(12),
            documentName: 'DRIVING LICENSE',
            documentNumber: null,
            documentHijriExpiryDate: null,
            documentIssueDate: null,
            documentExpiryDate: null,
            documentFilePath: null)
      ],
      empCertificateDataLst: [],
      empEducationDataLst: [],
      empDependentDataLst: [],
      empWorkExperienceDataLst: [],
      openRegister: null,
      docId: getRandomString(20));

  @override
  void initState() {
    initData();
    super.initState();
  }

  initData() async {
    if (widget.edit && widget.selectedRowData != null) {
      employeeData = widget.selectedRowData!;
    } else {
      employeeData.empBasicInfoData.createdBy =
          widget.userData.empBasicInfoData.username;
      employeeData.empBasicInfoData.employeeId =
          (int.parse(widget.empLstData.first.empBasicInfoData.employeeId) + 1)
              .toString();
    }
    setState(() {
      isLoading = false;
    });
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return CustomNavBar(
      pageName: 'Employee',
      child: isLoading
          ? showLoading()
          : Scaffold(
              backgroundColor: homeBgColor,
              body: SafeArea(
                child: Container(
                  color: homeBgColor,
                  child: Row(
                    children: [
                      Container(
                        color: const Color.fromARGB(255, 43, 43, 43),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SideMenuButton(
                              label: 'Back',
                              iconPath: 'assets/icons/back.png',
                              buttonFunction: () {
                                showDiscardChangesDialog(context);
                              },
                            ),
                            SideMenuButton(
                                label: 'Save',
                                iconPath: 'assets/icons/save.png',
                                buttonFunction: () {
                                  onTapSaveButton();
                                })
                          ],
                        ),
                      ),
                      const SizedBox(
                        width: 0,
                      ),
                      Expanded(
                        child: Form(
                          key: _formKey,
                          child: Row(
                            children: [
                              //box1
                              CreateEmpBox1Widget(
                                isEdit: widget.edit,
                                userDataLst: widget.empLstData,
                                onTabSaveFunction: onTapSaveButton,
                                userData: employeeData,
                                userGroupsDataLst: widget.userGroupsDataLst,
                              ),
                              //box 2
                              Expanded(
                                  child: CreateEmpBox2Widget(
                                employeeData: employeeData,
                              ))
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
    );
  }

  onTapSaveButton() async {
    if (employeeData.empWorkAndRolesData.userGroupId.isEmpty) {
      showToast('Please select a user group', context);
    }
    if (_formKey.currentState!.validate() &&
        employeeData.empWorkAndRolesData.userGroupId.isNotEmpty) {
      setState(() {
        isLoading = true;
      });
      for (int i = 0; i < employeeData.empDocumentDataLst.length; i++) {
        if (employeeData.empDocumentDataLst[i].saveit &&
            employeeData.empDocumentDataLst[i].documentFilePath != null) {
          String newPathString = await uploadImageService(
              file: File(employeeData.empDocumentDataLst[i].documentFilePath!),
              folderFilePath:
                  '${employeeData.docId}/empDocumentDataLst/${employeeData.empDocumentDataLst[i].documentName}_${employeeData.empDocumentDataLst[i].documentNumber}${employeeData.empDocumentDataLst[i].documentFilePath!.substring(employeeData.empDocumentDataLst[i].documentFilePath!.indexOf('.'))}');
          employeeData.empDocumentDataLst[i].documentFilePath = newPathString;
          employeeData.empDocumentDataLst[i].saveit = false;
        }
      }
      for (int i = 0; i < employeeData.empCertificateDataLst.length; i++) {
        if (employeeData.empCertificateDataLst[i].saveit &&
            employeeData.empCertificateDataLst[i].documentFilePath != null) {
          String newPathString = await uploadImageService(
              file:
                  File(employeeData.empCertificateDataLst[i].documentFilePath!),
              folderFilePath:
                  '${employeeData.docId}/empCertificateDataLst/${employeeData.empCertificateDataLst[i].certificationName}_${employeeData.empCertificateDataLst[i].documentNumber}${employeeData.empCertificateDataLst[i].documentFilePath!.substring(employeeData.empCertificateDataLst[i].documentFilePath!.indexOf('.'))}');
          employeeData.empCertificateDataLst[i].documentFilePath =
              newPathString;
          employeeData.empCertificateDataLst[i].saveit = false;
        }
      }
      for (int i = 0; i < employeeData.empEducationDataLst.length; i++) {
        if (employeeData.empEducationDataLst[i].saveit &&
            employeeData.empEducationDataLst[i].documentFilePath != null) {
          String newPathString = await uploadImageService(
              file: File(employeeData.empEducationDataLst[i].documentFilePath!),
              folderFilePath:
                  '${employeeData.docId}/empEducationDataLst/${employeeData.empEducationDataLst[i].schoolCollegeName}_${employeeData.empEducationDataLst[i].degreeDiplomaName}${employeeData.empEducationDataLst[i].documentFilePath!.substring(employeeData.empEducationDataLst[i].documentFilePath!.indexOf('.'))}');
          employeeData.empEducationDataLst[i].documentFilePath = newPathString;
          employeeData.empEducationDataLst[i].saveit = false;
        }
      }
      for (int i = 0; i < employeeData.empWorkExperienceDataLst.length; i++) {
        if (employeeData.empWorkExperienceDataLst[i].saveit &&
            employeeData.empWorkExperienceDataLst[i].documentFilePath != null) {
          String newPathString = await uploadImageService(
              file: File(
                  employeeData.empWorkExperienceDataLst[i].documentFilePath!),
              folderFilePath:
                  '${employeeData.docId}/empWorkExperienceDataLst/${employeeData.empWorkExperienceDataLst[i].previousCompanyName}_${employeeData.empWorkExperienceDataLst[i].jobTitle}${employeeData.empWorkExperienceDataLst[i].documentFilePath!.substring(employeeData.empWorkExperienceDataLst[i].documentFilePath!.indexOf('.'))}');
          employeeData.empWorkExperienceDataLst[i].documentFilePath =
              newPathString;
          employeeData.empWorkExperienceDataLst[i].saveit = false;
        }
      }
      await HiveUserDbService().addEditUser(employeeData);
      setState(() {
        isLoading = false;
      });
      Navigator.pop(context, true);
    }
  }
}
