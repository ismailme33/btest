import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_2/01_document_widget.dart';
import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_2/02_certificates_widget.dart';
import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_2/03_education_widget.dart';
import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_2/04_work_experience_widget.dart';
import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_2/05_dependent.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class CreateEmpBox2Widget extends StatefulWidget {
  final EmployeeData employeeData;
  const CreateEmpBox2Widget({super.key, required this.employeeData});

  @override
  State<CreateEmpBox2Widget> createState() => _CreateEmpBox2WidgetState();
}

class _CreateEmpBox2WidgetState extends State<CreateEmpBox2Widget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: double.maxFinite,
        decoration: BoxDecoration(
            border: Border.all(width: 0.3),
            color: const Color(0xffE2E2E2),
            borderRadius: BorderRadius.circular(3)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 35,
              width: double.maxFinite,
              // padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(4), topRight: Radius.circular(4)),
                gradient: LinearGradient(
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromARGB(255, 51, 51, 51),
                      Color.fromARGB(255, 51, 51, 51),
                    ],
                    begin: Alignment.topCenter),
              ),
              child: Row(
                children: [
                  Container(
                    width: 120,
                    height: 35,
                    decoration: BoxDecoration(
                        border: Border.symmetric(
                            vertical: BorderSide(color: Colors.grey)),
                        borderRadius: BorderRadius.circular(0),
                        gradient: LinearGradient(
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(0xff092F53),
                              Color(0xff284F70),
                            ],
                            begin: Alignment.topCenter)),
                    alignment: Alignment.center,
                    child: Text(
                      "Files & Docs",
                      style: GoogleFonts.roboto(
                          fontSize: 14,
                          fontWeight: FontWeight.w400,
                          color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    DocumentWidget(
                      employeeData: widget.employeeData,
                    ),
                    CertificateWidget(
                      employeeData: widget.employeeData,
                    ),
                    EducationWidget(
                      employeeData: widget.employeeData,
                    ),
                    WorkExperenceWidget(
                      employeeData: widget.employeeData,
                    ),
                    DependentWidget(
                      employeeData: widget.employeeData,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
