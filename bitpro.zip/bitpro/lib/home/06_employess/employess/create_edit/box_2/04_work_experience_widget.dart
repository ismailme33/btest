import 'package:bitpro_hive/shared/image_view_dialog.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/shared/dialogs/confirm_delete_doc_dialog.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/bottom_panel_for_dialog.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:io';

import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:file_picker/file_picker.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:intl/intl.dart';

class WorkExperenceWidget extends StatefulWidget {
  final EmployeeData employeeData;
  const WorkExperenceWidget({
    super.key,
    required this.employeeData,
  });

  @override
  State<WorkExperenceWidget> createState() => _WorkExperenceWidgetState();
}

class _WorkExperenceWidgetState extends State<WorkExperenceWidget> {
  List<EmpWorkExperienceData> selectedItemLst = [];
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: ExpansionTile(
          initiallyExpanded: false,
          backgroundColor: Color.fromARGB(255, 51, 51, 51),
          minTileHeight: 20,
          iconColor: Colors.white,
          collapsedIconColor: Colors.white,
          shape: Border.symmetric(
              horizontal: BorderSide.none, vertical: BorderSide.none),
          collapsedBackgroundColor: Color.fromARGB(255, 51, 51, 51),
          tilePadding: EdgeInsets.only(right: 20),
          childrenPadding: EdgeInsets.zero,
          title: Row(
            children: [
              Container(
                padding: EdgeInsets.only(left: 15),
                height: 28,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(4),
                ),
                alignment: Alignment.center,
                child: Text(
                  "Work Experience",
                  style: GoogleFonts.roboto(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: Colors.white),
                ),
              ),
            ],
          ),
          children: [
            Container(
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(width: 0.4),
                  borderRadius: BorderRadius.circular(4)),
              child: Column(
                children: [
                  Row(
                    children: [
                      InkWell(
                        onTap: () async {
                          EmpWorkExperienceData? empWorkExperienceData =
                              await showCreateDialog(context: context);
                          if (empWorkExperienceData != null) {
                            widget.employeeData.empWorkExperienceDataLst
                                .add(empWorkExperienceData);
                          }
                          setState(() {});
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 0, 0, 0),
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.add,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () async {
                          if (selectedItemLst.length == 1) {
                            EmpWorkExperienceData? empWorkExperienceData =
                                await showCreateDialog(
                                    context: context,
                                    empDocData: selectedItemLst.first);
                            if (empWorkExperienceData != null) {
                              int i = widget
                                  .employeeData.empWorkExperienceDataLst
                                  .indexOf(selectedItemLst.first);
                              widget.employeeData.empWorkExperienceDataLst[i] =
                                  empWorkExperienceData;
                              selectedItemLst = [];
                            }
                            setState(() {});
                          }
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: selectedItemLst.length == 1
                                  ? const Color.fromARGB(255, 0, 0, 0)
                                  : Colors.grey,
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () async {
                          bool res = await showConfirmDeleteDocDialog(context);
                          if (res && selectedItemLst.isNotEmpty) {
                            for (var s in selectedItemLst) {
                              widget.employeeData.empWorkExperienceDataLst
                                  .remove(s);
                            }
                            selectedItemLst = [];
                            setState(() {});
                          }
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: selectedItemLst.isNotEmpty
                                  ? const Color.fromARGB(255, 0, 0, 0)
                                  : Colors.grey,
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.cancel,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () async {
                          if (selectedItemLst.length == 1) {
                            if (selectedItemLst.first.documentFilePath ==
                                    null ||
                                selectedItemLst
                                    .first.documentFilePath!.isEmpty) {
                              showToast("Image not found", context);
                            } else {
                              imageViewDialog(context,
                                  selectedItemLst.first.documentFilePath!);
                            }
                          }
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: selectedItemLst.isNotEmpty
                                  ? const Color.fromARGB(255, 0, 0, 0)
                                  : Colors.grey,
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.remove_red_eye_sharp,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(
                    height: 10,
                  ),
                  // empWorkExperienceData
                  Table(
                    columnWidths: const {
                      0: FlexColumnWidth(1),
                      1: FlexColumnWidth(4),
                      2: FlexColumnWidth(4),
                      3: FlexColumnWidth(4),
                      4: FlexColumnWidth(4),
                      5: FlexColumnWidth(2),
                    },
                    border: TableBorder.all(width: 0.8),
                    children: [
                      TableRow(children: [
                        SizedBox(
                          height: 25,
                          child: Transform.scale(
                              scale: .8,
                              child: Checkbox(
                                  value: widget
                                          .employeeData
                                          .empWorkExperienceDataLst
                                          .isNotEmpty &&
                                      selectedItemLst.length ==
                                          widget.employeeData
                                              .empWorkExperienceDataLst.length,
                                  onChanged: (v) {
                                    if (selectedItemLst.length ==
                                        widget.employeeData
                                            .empWorkExperienceDataLst.length) {
                                      selectedItemLst = [];
                                    } else {
                                      selectedItemLst = widget.employeeData
                                          .empWorkExperienceDataLst;
                                    }
                                    setState(() {});
                                  })),
                        ),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'Prev. Company Name',
                              style: TextStyle(fontSize: 14),
                            )),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'Job Title',
                              style: TextStyle(fontSize: 14),
                            )),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'From date',
                              style: TextStyle(fontSize: 14),
                            )),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'To date',
                              style: TextStyle(fontSize: 14),
                            )),
                        // Container(
                        //     height: 25,
                        //     alignment: Alignment.center,
                        //     child: const Icon(
                        //       Icons.file_present_rounded,
                        //       size: 18,
                        //     )),
                      ]),
                      for (EmpWorkExperienceData d
                          in widget.employeeData.empWorkExperienceDataLst)
                        TableRow(children: [
                          Container(
                            height: 25,
                            child: Transform.scale(
                                scale: .8,
                                child: Checkbox(
                                    value: selectedItemLst.contains(d),
                                    onChanged: (v) {
                                      if (selectedItemLst.contains(d)) {
                                        selectedItemLst = [];
                                      } else {
                                        selectedItemLst = [d];
                                      }
                                      setState(() {});
                                    })),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.previousCompanyName,
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.jobTitle ?? '',
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.fromDate == null || d.fromDate!.isEmpty
                                      ? ''
                                      : DateFormat('MMM d, yyyy')
                                          .format(DateTime.parse(d.fromDate!)),
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.toDate == null || d.toDate!.isEmpty
                                      ? ''
                                      : DateFormat('MMM d, yyyy')
                                          .format(DateTime.parse(d.toDate!)),
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                        ])
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<EmpWorkExperienceData?> showCreateDialog({
    context,
    EmpWorkExperienceData? empDocData,
  }) async {
    String perviousCompanyName = '';
    String? jobTitle = '';
    String? fromDate = '';
    String? toDate = '';
    File? documentFile;

    if (empDocData != null) {
      perviousCompanyName = empDocData.previousCompanyName;
      jobTitle = empDocData.jobTitle;
      fromDate = empDocData.fromDate;
      toDate = empDocData.toDate;
      documentFile = empDocData.documentFilePath != null
          ? File(empDocData.documentFilePath!)
          : null;
    }

    return await showDialog(
        context: context,
        builder: (context2) {
          return StatefulBuilder(builder: (context, setState) {
            return Dialog(
              child: SizedBox(
                width: 480,
                height: 420,
                child: Column(
                  children: [
                    BlackTopPanelForDialogWindow(label: 'Work Experence'),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.all(25),
                        child: Column(
                          children: [
                            BTextField(
                              textFieldReadOnly: false,
                              label: 'Pervious company name',

                              initialValue: perviousCompanyName,
                              // validator: ((value) {}),
                              onChanged: (val) => setState(() {
                                perviousCompanyName = val;
                              }),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            BTextField(
                              textFieldReadOnly: false,
                              label: 'Job title',
                              initialValue: jobTitle,
                              // validator: ((value) {}),
                              onChanged: (val) => setState(() {
                                jobTitle = val;
                              }),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    staticTextTranslate('From Date'),
                                    style: GoogleFonts.roboto(
                                      fontSize: getMediumFontSize + 2,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  SizedBox(
                                    width: 240,
                                    child: GestureDetector(
                                      onTap: () async {
                                        DateTime? dateTime =
                                            await showDatePicker(
                                          context: context,
                                          currentDate: DateTime.now(),
                                          initialDate:
                                              DateTime.tryParse(fromDate ?? ''),
                                          firstDate: DateTime(1900),
                                          lastDate: DateTime(2050),
                                        );
                                        if (dateTime != null) {
                                          fromDate = dateTime.toString();

                                          setState(() {});
                                        }
                                      },
                                      child: Container(
                                        width: 200,
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: const Color.fromARGB(
                                                    255, 0, 0, 0),
                                                width: 0.4),
                                            borderRadius:
                                                BorderRadius.circular(4)),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 7),
                                        child: Row(
                                          children: [
                                            Text(
                                              fromDate == null ||
                                                      fromDate!.isEmpty
                                                  ? staticTextTranslate(
                                                      'Click to Select Date')
                                                  : DateFormat('dd / MM / yyyy')
                                                      .format(DateTime.parse(
                                                          fromDate!)),
                                              style: GoogleFonts.roboto(
                                                  fontSize: 17,
                                                  height: 1.3,
                                                  color: fromDate == null
                                                      ? const Color.fromARGB(
                                                          255, 0, 0, 0)
                                                      : Colors.black),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    staticTextTranslate('To Date'),
                                    style: GoogleFonts.roboto(
                                      fontSize: getMediumFontSize + 2,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  SizedBox(
                                    width: 240,
                                    child: GestureDetector(
                                      onTap: () async {
                                        DateTime? dateTime =
                                            await showDatePicker(
                                          context: context,
                                          currentDate: DateTime.now(),
                                          initialDate:
                                              DateTime.tryParse(toDate ?? ''),
                                          firstDate: DateTime(1900),
                                          lastDate: DateTime(2050),
                                        );
                                        if (dateTime != null) {
                                          toDate = dateTime.toString();

                                          setState(() {});
                                        }
                                      },
                                      child: Container(
                                        width: 200,
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: const Color.fromARGB(
                                                    255, 0, 0, 0),
                                                width: 0.4),
                                            borderRadius:
                                                BorderRadius.circular(4)),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 7),
                                        child: Row(
                                          children: [
                                            Text(
                                              toDate == null || toDate!.isEmpty
                                                  ? staticTextTranslate(
                                                      'Click to Select Date')
                                                  : DateFormat('dd / MM / yyyy')
                                                      .format(DateTime.parse(
                                                          toDate!)),
                                              style: GoogleFonts.roboto(
                                                  fontSize: 17,
                                                  height: 1.3,
                                                  color: toDate == null
                                                      ? const Color.fromARGB(
                                                          255, 0, 0, 0)
                                                      : Colors.black),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Row(
                              children: [
                                Text(
                                  'Document File',
                                  style: GoogleFonts.roboto(
                                    fontSize: 16,
                                  ),
                                ),
                                Spacer(),
                                SizedBox(
                                  height: 80,
                                  width: 80,
                                  child: documentFile != null
                                      ? Image.file(
                                          documentFile!,
                                          width: 200,
                                          height: 50,
                                        )
                                      : null,
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                // documentFile
                                OutlinedButton.icon(
                                    icon: const Icon(Icons.upload),
                                    style: ElevatedButton.styleFrom(
                                        backgroundColor: Colors.transparent,
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(4))),
                                    onPressed: () async {
                                      FilePickerResult? result =
                                          await FilePicker.platform.pickFiles(
                                              allowMultiple: false,
                                              dialogTitle: staticTextTranslate(
                                                  'Header Image'),
                                              type: FileType.image);

                                      if (result != null &&
                                          result.files.first.path != null) {
                                        // var box = Hive.box('bitpro_app');
                                        // await box.put(
                                        //     'header_img_path', result.files.first.path);
                                        // headerImgPath = result.files.first.path!;
                                        documentFile =
                                            File(result.files.first.path!);
                                        setState(() {});
                                      }
                                    },
                                    label: Text(
                                        staticTextTranslate('Choose Image'),
                                        style:
                                            GoogleFonts.roboto(fontSize: 14))),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    BottomPanelForDialog(
                      buttons: [
                        OnPageGreyButton(
                          label: 'Cancel',
                          onPressed: () {
                            Navigator.pop(context2);
                          },
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        OnPageButton(
                            label: 'Save',
                            onPressed: () {
                              if (perviousCompanyName.isNotEmpty) {
                                Navigator.pop(
                                    context,
                                    EmpWorkExperienceData(
                                        docId: empDocData != null
                                            ? empDocData.docId
                                            : getRandomString(12),
                                        previousCompanyName:
                                            perviousCompanyName,
                                        jobTitle: jobTitle,
                                        fromDate: fromDate,
                                        toDate: toDate,
                                        documentFilePath: documentFile?.path,
                                        saveit: true));
                              } else {
                                showToast('Please enter previous company name.',
                                    context);
                              }
                            },
                            icon: Icons.save),
                      ],
                    ),
                  ],
                ),
              ),
            );
          });
        });
  }
}
