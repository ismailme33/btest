import 'package:bitpro_hive/shared/image_view_dialog.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/shared/dialogs/confirm_delete_doc_dialog.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/bottom_panel_for_dialog.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:io';

import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:file_picker/file_picker.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:intl/intl.dart';

class EducationWidget extends StatefulWidget {
  final EmployeeData employeeData;
  const EducationWidget({
    super.key,
    required this.employeeData,
  });

  @override
  State<EducationWidget> createState() => _EducationWidgetState();
}

class _EducationWidgetState extends State<EducationWidget> {
  List<EmpEducationData> selectedItemLst = [];
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: ExpansionTile(
          initiallyExpanded: false,
          backgroundColor: Color.fromARGB(255, 66, 66, 66),
          minTileHeight: 20,
          iconColor: Colors.white,
          collapsedIconColor: Colors.white,
          shape: Border.symmetric(
              horizontal: BorderSide.none, vertical: BorderSide.none),
          collapsedBackgroundColor: Color.fromARGB(255, 66, 66, 66),
          tilePadding: EdgeInsets.only(right: 20),
          childrenPadding: EdgeInsets.zero,
          title: Container(
            height: 28,
            width: double.maxFinite,

            // padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(4), topRight: Radius.circular(4)),
              // gradient: LinearGradient(
              //     end: Alignment.bottomCenter,
              //     colors: [
              //       Color.fromARGB(255, 66, 66, 66),
              //       Color.fromARGB(255, 0, 0, 0),
              //     ],
              //     begin: Alignment.topCenter),
            ),
            child: Row(
              children: [
                Container(
                  width: 92,
                  height: 35,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    "Education",
                    style: GoogleFonts.roboto(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
          children: [
            Container(
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(width: 0.4),
                  borderRadius: BorderRadius.circular(4)),
              child: Column(
                children: [
                  Row(
                    children: [
                      InkWell(
                        onTap: () async {
                          EmpEducationData? empDocumentData =
                              await showCreateDialog(context: context);
                          if (empDocumentData != null) {
                            widget.employeeData.empEducationDataLst
                                .add(empDocumentData);
                          }
                          setState(() {});
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 0, 0, 0),
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.add,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () async {
                          if (selectedItemLst.length == 1) {
                            EmpEducationData? empDocumentData =
                                await showCreateDialog(
                                    context: context,
                                    empDocData: selectedItemLst.first);
                            if (empDocumentData != null) {
                              int i = widget.employeeData.empEducationDataLst
                                  .indexOf(selectedItemLst.first);
                              widget.employeeData.empEducationDataLst[i] =
                                  empDocumentData;
                              selectedItemLst = [];
                            }
                            setState(() {});
                          }
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: selectedItemLst.length == 1
                                  ? const Color.fromARGB(255, 0, 0, 0)
                                  : Colors.grey,
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () async {
                          bool res = await showConfirmDeleteDocDialog(context);
                          if (res && selectedItemLst.isNotEmpty) {
                            for (var s in selectedItemLst) {
                              widget.employeeData.empEducationDataLst.remove(s);
                            }
                            selectedItemLst = [];
                            setState(() {});
                          }
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: selectedItemLst.isNotEmpty
                                  ? const Color.fromARGB(255, 0, 0, 0)
                                  : Colors.grey,
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.cancel,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () async {
                          if (selectedItemLst.length == 1) {
                            if (selectedItemLst.first.documentFilePath ==
                                    null ||
                                selectedItemLst
                                    .first.documentFilePath!.isEmpty) {
                              showToast("Image not found", context);
                            } else {
                              imageViewDialog(context,
                                  selectedItemLst.first.documentFilePath!);
                            }
                          }
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: selectedItemLst.isNotEmpty
                                  ? const Color.fromARGB(255, 0, 0, 0)
                                  : Colors.grey,
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.remove_red_eye_sharp,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(
                    height: 10,
                  ),
                  // empDocumentData
                  Table(
                    columnWidths: const {
                      0: FlexColumnWidth(1),
                      1: FlexColumnWidth(4),
                      2: FlexColumnWidth(4),
                      3: FlexColumnWidth(4),
                      4: FlexColumnWidth(4),
                      5: FlexColumnWidth(2),
                    },
                    border: TableBorder.all(width: 0.4),
                    children: [
                      TableRow(children: [
                        SizedBox(
                          height: 25,
                          child: Transform.scale(
                              scale: .8,
                              child: Checkbox(
                                  value: widget.employeeData.empEducationDataLst
                                          .isNotEmpty &&
                                      selectedItemLst.length ==
                                          widget.employeeData
                                              .empEducationDataLst.length,
                                  onChanged: (v) {
                                    if (selectedItemLst.length ==
                                        widget.employeeData.empEducationDataLst
                                            .length) {
                                      selectedItemLst = [];
                                    } else {
                                      selectedItemLst = widget
                                          .employeeData.empEducationDataLst;
                                    }
                                    setState(() {});
                                  })),
                        ),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'School/College',
                              style: TextStyle(fontSize: 14),
                            )),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'Degree/Diploma',
                              style: TextStyle(fontSize: 14),
                            )),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'Field(s) of study',
                              style: TextStyle(fontSize: 14),
                            )),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'Date of completion',
                              style: TextStyle(fontSize: 14),
                            )),
                      ]),
                      for (EmpEducationData d
                          in widget.employeeData.empEducationDataLst)
                        TableRow(children: [
                          Container(
                            height: 25,
                            child: Transform.scale(
                                scale: .8,
                                child: Checkbox(
                                    value: selectedItemLst.contains(d),
                                    onChanged: (v) {
                                      if (selectedItemLst.contains(d)) {
                                        selectedItemLst = [];
                                      } else {
                                        selectedItemLst = [d];
                                      }
                                      setState(() {});
                                    })),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.schoolCollegeName,
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.degreeDiplomaName ?? '',
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.fieldsOfStudy ?? '',
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.dateOfCompletion == null
                                      ? ''
                                      : DateFormat('MMM d, yyyy').format(
                                          DateTime.parse(d.dateOfCompletion!)),
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                        ])
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<EmpEducationData?> showCreateDialog({
    context,
    EmpEducationData? empDocData,
  }) async {
    String schoolCollegeName = '';
    String? degreeDiplomaName;
    String? fieldsOfStudy;
    String? dateOfCompletion;
    File? documentFile;

    TextEditingController fieldsOfStudyController =
        TextEditingController(text: '');

    if (empDocData != null) {
      schoolCollegeName = empDocData.schoolCollegeName;
      degreeDiplomaName = empDocData.degreeDiplomaName ?? '';
      fieldsOfStudy = empDocData.fieldsOfStudy ?? '';
      fieldsOfStudyController.text = empDocData.fieldsOfStudy ?? '';
      dateOfCompletion = empDocData.dateOfCompletion ?? '';

      documentFile = empDocData.documentFilePath != null
          ? File(empDocData.documentFilePath!)
          : null;
    }

    return await showDialog(
        context: context,
        builder: (context2) {
          return StatefulBuilder(builder: (context, setState) {
            return Dialog(
              child: SizedBox(
                width: 480,
                height: 420,
                child: Column(
                  children: [
                    BlackTopPanelForDialogWindow(label: 'Education'),
                    Expanded(
                        child: Padding(
                      padding: EdgeInsets.all(25),
                      child: Column(
                        children: [
                          BTextField(
                            textFieldReadOnly: false,
                            label: 'School College Name',

                            initialValue: schoolCollegeName,
                            // validator: ((value) {}),
                            onChanged: (val) => setState(() {
                              schoolCollegeName = val;
                            }),
                            autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          BTextField(
                            textFieldReadOnly: false,
                            label: 'Degree/Diploma',
                            initialValue: degreeDiplomaName,
                            // validator: ((value) {}),
                            onChanged: (val) => setState(() {
                              degreeDiplomaName = val;
                            }),
                            autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          BTextField(
                            textFieldReadOnly: false,
                            controller: fieldsOfStudyController,
                            label: 'Fields Of Study',
                            onChanged: (v) {
                              setState(() {
                                fieldsOfStudy = v;
                              });
                            },
                            autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          // BTextField(
                          //   textFieldReadOnly: true,
                          //   controller: dateOfCompletionDateController,
                          //   label: 'Date Of Completion',
                          //   onTap: () async {
                          //     DateTime? dateTime = await showDatePicker(
                          //       context: context,
                          //       currentDate:
                          //           DateTime.tryParse(dateOfCompletion),
                          //       firstDate: DateTime(2000),
                          //       lastDate: DateTime(3000),
                          //     );
                          //     if (dateTime != null) {
                          //       dateOfCompletion = dateTime.toString();
                          //       dateOfCompletionDateController.text =
                          //           DateFormat('MMM d, yyyy').format(dateTime);
                          //       setState(() {});
                          //     }
                          //   },
                          //   onChanged: (v) {},
                          //   autovalidateMode:
                          //       AutovalidateMode.onUserInteraction,
                          // ),
                          SizedBox(
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  staticTextTranslate('Date Of Completion'),
                                  style: GoogleFonts.roboto(
                                    fontSize: getMediumFontSize + 2,
                                  ),
                                ),
                                const SizedBox(
                                  height: 5,
                                ),
                                SizedBox(
                                  width: 240,
                                  child: GestureDetector(
                                    onTap: () async {
                                      DateTime? dateTime = await showDatePicker(
                                        context: context,
                                        currentDate: DateTime.now(),
                                        initialDate: DateTime.tryParse(
                                            dateOfCompletion ?? ''),
                                        firstDate: DateTime(1900),
                                        lastDate: DateTime(2050),
                                      );
                                      if (dateTime != null) {
                                        dateOfCompletion = dateTime.toString();

                                        setState(() {});
                                      }
                                    },
                                    child: Container(
                                      width: 200,
                                      decoration: BoxDecoration(
                                          color: Colors.white,
                                          border: Border.all(
                                              color: const Color.fromARGB(
                                                  255, 0, 0, 0),
                                              width: 0.4),
                                          borderRadius:
                                              BorderRadius.circular(4)),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10, vertical: 7),
                                      child: Row(
                                        children: [
                                          Text(
                                            dateOfCompletion == null ||
                                                    dateOfCompletion!.isEmpty
                                                ? staticTextTranslate(
                                                    'Click to Select Date')
                                                : DateFormat('dd / MM / yyyy')
                                                    .format(DateTime.parse(
                                                        dateOfCompletion!)),
                                            style: GoogleFonts.roboto(
                                                fontSize: 17,
                                                height: 1.3,
                                                color: dateOfCompletion == null
                                                    ? const Color.fromARGB(
                                                        255, 0, 0, 0)
                                                    : Colors.black),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                )
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            children: [
                              Text(
                                'Document File',
                                style: GoogleFonts.roboto(
                                  fontSize: 16,
                                ),
                              ),
                              Spacer(),
                              SizedBox(
                                height: 80,
                                width: 80,
                                child: documentFile != null
                                    ? Image.file(
                                        documentFile!,
                                        width: 200,
                                        height: 50,
                                      )
                                    : null,
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              // documentFile
                              OutlinedButton.icon(
                                  icon: const Icon(Icons.upload),
                                  style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.transparent,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(4))),
                                  onPressed: () async {
                                    FilePickerResult? result =
                                        await FilePicker.platform.pickFiles(
                                            allowMultiple: false,
                                            dialogTitle: staticTextTranslate(
                                                'Header Image'),
                                            type: FileType.image);

                                    if (result != null &&
                                        result.files.first.path != null) {
                                      // var box = Hive.box('bitpro_app');
                                      // await box.put(
                                      //     'header_img_path', result.files.first.path);
                                      // headerImgPath = result.files.first.path!;
                                      documentFile =
                                          File(result.files.first.path!);
                                      setState(() {});
                                    }
                                  },
                                  label: Text(
                                      staticTextTranslate('Choose Image'),
                                      style: GoogleFonts.roboto(fontSize: 14))),
                            ],
                          ),
                        ],
                      ),
                    )),
                    BottomPanelForDialog(buttons: [
                      OnPageGreyButton(
                        label: 'Cancel',
                        onPressed: () {
                          Navigator.pop(context2);
                        },
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      OnPageButton(
                          label: 'Save',
                          onPressed: () {
                            if (schoolCollegeName.isNotEmpty) {
                              Navigator.pop(
                                  context,
                                  EmpEducationData(
                                      docId: empDocData != null
                                          ? empDocData.docId
                                          : getRandomString(12),
                                      schoolCollegeName: schoolCollegeName,
                                      degreeDiplomaName: degreeDiplomaName,
                                      fieldsOfStudy: fieldsOfStudy,
                                      dateOfCompletion: dateOfCompletion,
                                      documentFilePath: documentFile?.path,
                                      saveit: true));
                            } else {
                              showToast(
                                  'Please enter school/collegeName', context);
                            }
                          },
                          icon: Icons.save)
                    ]),
                  ],
                ),
              ),
            );
          });
        });
  }
}
