import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/shared/dialogs/confirm_delete_doc_dialog.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/bottom_panel_for_dialog.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:intl/intl.dart';

class DependentWidget extends StatefulWidget {
  final EmployeeData employeeData;
  const DependentWidget({
    super.key,
    required this.employeeData,
  });

  @override
  State<DependentWidget> createState() => _DependentWidgetState();
}

class _DependentWidgetState extends State<DependentWidget> {
  List<EmpDependentData> selectedItemLst = [];
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: ExpansionTile(
          initiallyExpanded: false,
          backgroundColor: Color.fromARGB(255, 51, 51, 51),
          minTileHeight: 20,
          iconColor: Colors.white,
          collapsedIconColor: Colors.white,
          shape: Border.symmetric(
              horizontal: BorderSide.none, vertical: BorderSide.none),
          collapsedBackgroundColor: Color.fromARGB(255, 51, 51, 51),
          tilePadding: EdgeInsets.only(right: 20),
          childrenPadding: EdgeInsets.zero,
          title: Container(
            padding: EdgeInsets.only(
              left: 15,
              top: 5,
            ),
            height: 28,
            width: double.maxFinite,

            // padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(4), topRight: Radius.circular(4)),
            ),
            child: Text(
              "Dependent",
              style: GoogleFonts.roboto(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: Colors.white),
            ),
          ),
          children: [
            Container(
              padding: EdgeInsets.all(15),
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(width: 0.4),
                  borderRadius: BorderRadius.circular(4)),
              child: Column(
                children: [
                  Row(
                    children: [
                      InkWell(
                        onTap: () async {
                          EmpDependentData? empWorkExperienceData =
                              await showCreateDialog(context: context);
                          if (empWorkExperienceData != null) {
                            widget.employeeData.empDependentDataLst
                                .add(empWorkExperienceData);
                          }
                          setState(() {});
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: const Color.fromARGB(255, 0, 0, 0),
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.add,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () async {
                          if (selectedItemLst.length == 1) {
                            EmpDependentData? empWorkExperienceData =
                                await showCreateDialog(
                                    context: context,
                                    empDocData: selectedItemLst.first);
                            if (empWorkExperienceData != null) {
                              int i = widget.employeeData.empDependentDataLst
                                  .indexOf(selectedItemLst.first);
                              widget.employeeData.empDependentDataLst[i] =
                                  empWorkExperienceData;
                              selectedItemLst = [];
                            }
                            setState(() {});
                          }
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: selectedItemLst.length == 1
                                  ? const Color.fromARGB(255, 0, 0, 0)
                                  : Colors.grey,
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      InkWell(
                        onTap: () async {
                          bool res = await showConfirmDeleteDocDialog(context);
                          if (res && selectedItemLst.isNotEmpty) {
                            for (var s in selectedItemLst) {
                              widget.employeeData.empDependentDataLst.remove(s);
                            }
                            selectedItemLst = [];
                            setState(() {});
                          }
                        },
                        child: Container(
                          width: 70,
                          height: 30,
                          decoration: BoxDecoration(
                              color: selectedItemLst.isNotEmpty
                                  ? const Color.fromARGB(255, 0, 0, 0)
                                  : Colors.grey,
                              borderRadius: BorderRadius.circular(4)),
                          child: const Icon(
                            Icons.cancel,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(
                    height: 10,
                  ),
                  // empWorkExperienceData
                  Table(
                    columnWidths: const {
                      0: FlexColumnWidth(1),
                      1: FlexColumnWidth(4),
                      2: FlexColumnWidth(4),
                      3: FlexColumnWidth(4),
                      4: FlexColumnWidth(2),
                    },
                    border: TableBorder.all(width: 0.4),
                    children: [
                      TableRow(children: [
                        SizedBox(
                          height: 25,
                          child: Transform.scale(
                              scale: .8,
                              child: Checkbox(
                                  value: widget.employeeData.empDependentDataLst
                                          .isNotEmpty &&
                                      selectedItemLst.length ==
                                          widget.employeeData
                                              .empDependentDataLst.length,
                                  onChanged: (v) {
                                    if (selectedItemLst.length ==
                                        widget.employeeData.empDependentDataLst
                                            .length) {
                                      selectedItemLst = [];
                                    } else {
                                      selectedItemLst = widget
                                          .employeeData.empDependentDataLst;
                                    }
                                    setState(() {});
                                  })),
                        ),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'Name',
                              style: TextStyle(fontSize: 14),
                            )),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'Relationship',
                              style: TextStyle(fontSize: 14),
                            )),
                        Container(
                            height: 25,
                            alignment: Alignment.center,
                            child: const Text(
                              'Date of birth',
                              style: TextStyle(fontSize: 14),
                            )),
                        // Container(
                        //     height: 25,
                        //     alignment: Alignment.center,
                        //     child: const Icon(
                        //       Icons.file_present_rounded,
                        //       size: 18,
                        //     )),
                      ]),
                      for (EmpDependentData d
                          in widget.employeeData.empDependentDataLst)
                        TableRow(children: [
                          Container(
                            height: 25,
                            child: Transform.scale(
                                scale: .8,
                                child: Checkbox(
                                    value: selectedItemLst.contains(d),
                                    onChanged: (v) {
                                      if (selectedItemLst.contains(d)) {
                                        selectedItemLst = [];
                                      } else {
                                        selectedItemLst = [d];
                                      }
                                      setState(() {});
                                    })),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.name,
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.relationshipName ?? '',
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                          GestureDetector(
                            onTap: () {
                              if (selectedItemLst.contains(d)) {
                                selectedItemLst = [];
                              } else {
                                selectedItemLst = [d];
                              }
                              setState(() {});
                            },
                            child: Container(
                                color: Colors.transparent,
                                height: 25,
                                alignment: Alignment.center,
                                child: Text(
                                  d.dateOfBirth == null ||
                                          d.dateOfBirth!.isEmpty
                                      ? ''
                                      : DateFormat('MMM d, yyyy').format(
                                          DateTime.parse(d.dateOfBirth!)),
                                  style: const TextStyle(fontSize: 14),
                                )),
                          ),
                        ])
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<EmpDependentData?> showCreateDialog({
    context,
    EmpDependentData? empDocData,
  }) async {
    String name = '';
    String? relationship = '';
    String? dateofbirth = '';

    if (empDocData != null) {
      name = empDocData.name;
      relationship = empDocData.relationshipName;
      dateofbirth = empDocData.dateOfBirth;
    }

    return await showDialog(
        context: context,
        builder: (context2) {
          return StatefulBuilder(builder: (context, setState) {
            return Dialog(
              child: SizedBox(
                width: 440,
                height: 300,
                child: Column(
                  children: [
                    BlackTopPanelForDialogWindow(label: 'Dependent'),
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.all(25),
                        child: Column(
                          children: [
                            BTextField(
                              textFieldReadOnly: false,
                              label: 'Name',

                              initialValue: name,
                              // validator: ((value) {}),
                              onChanged: (val) => setState(() {
                                name = val;
                              }),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            BTextField(
                              textFieldReadOnly: false,
                              label: 'Relationship',
                              initialValue: relationship,
                              // validator: ((value) {}),
                              onChanged: (val) => setState(() {
                                relationship = val;
                              }),
                              autovalidateMode:
                                  AutovalidateMode.onUserInteraction,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            // BTextField(
                            //   textFieldReadOnly: true,
                            //   controller: dateofbirthController,
                            //   label: 'Date of birth',
                            //   onTap: () async {
                            //     DateTime? dateTime = await showDatePicker(
                            //       context: context,
                            //       currentDate: DateTime.tryParse(dateofbirth),
                            //       firstDate: DateTime(2000),
                            //       lastDate: DateTime(3000),
                            //     );
                            //     if (dateTime != null) {
                            //       dateofbirth = dateTime.toString();
                            //       dateofbirthController.text =
                            //           DateFormat('MMM d, yyyy')
                            //               .format(dateTime);
                            //       setState(() {});
                            //     }
                            //   },
                            //   onChanged: (v) {},
                            //   autovalidateMode:
                            //       AutovalidateMode.onUserInteraction,
                            // ),
                            SizedBox(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    staticTextTranslate('Date of birth'),
                                    style: GoogleFonts.roboto(
                                      fontSize: getMediumFontSize + 2,
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  SizedBox(
                                    width: 240,
                                    child: GestureDetector(
                                      onTap: () async {
                                        DateTime? dateTime =
                                            await showDatePicker(
                                          context: context,
                                          currentDate: DateTime.now(),
                                          initialDate: DateTime.tryParse(
                                              dateofbirth ?? ''),
                                          firstDate: DateTime(1900),
                                          lastDate: DateTime(2050),
                                        );
                                        if (dateTime != null) {
                                          dateofbirth = dateTime.toString();

                                          setState(() {});
                                        }
                                      },
                                      child: Container(
                                        width: 200,
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: const Color.fromARGB(
                                                    255, 0, 0, 0),
                                                width: 0.4),
                                            borderRadius:
                                                BorderRadius.circular(4)),
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 7),
                                        child: Row(
                                          children: [
                                            Text(
                                              dateofbirth == null ||
                                                      dateofbirth!.isEmpty
                                                  ? staticTextTranslate(
                                                      'Click to Select Date')
                                                  : DateFormat('dd / MM / yyyy')
                                                      .format(DateTime.parse(
                                                          dateofbirth!)),
                                              style: GoogleFonts.roboto(
                                                  fontSize: 17,
                                                  height: 1.3,
                                                  color: dateofbirth == null
                                                      ? const Color.fromARGB(
                                                          255, 0, 0, 0)
                                                      : Colors.black),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                    BottomPanelForDialog(buttons: [
                      OnPageGreyButton(
                        label: 'Cancel',
                        onPressed: () {
                          Navigator.pop(context2);
                        },
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      OnPageButton(
                          label: 'Save',
                          onPressed: () {
                            if (name.isNotEmpty) {
                              Navigator.pop(
                                  context,
                                  EmpDependentData(
                                      docId: empDocData != null
                                          ? empDocData.docId
                                          : getRandomString(12),
                                      name: name,
                                      relationshipName: relationship,
                                      dateOfBirth: dateofbirth,
                                      saveit: true));
                            } else {
                              showToast('Please fill the form', context);
                            }
                          },
                          icon: Icons.save)
                    ]),
                  ],
                ),
              ),
            );
          });
        });
  }
}
