import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/model/user_group_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:intl/intl.dart';

class Tab2WorkAndRoles extends StatefulWidget {
  final List<UserGroupData> userGroupsDataLst;
  final EmployeeData userData;
  const Tab2WorkAndRoles(
      {super.key, required this.userGroupsDataLst, required this.userData});

  @override
  State<Tab2WorkAndRoles> createState() => _Tab2WorkAndRolesState();
}

class _Tab2WorkAndRolesState extends State<Tab2WorkAndRoles> {
//

  final TextEditingController _departmenttypeAheadController =
      TextEditingController();
  final TextEditingController _positionedtypeAheadController =
      TextEditingController();
  final TextEditingController _titletypeAheadController =
      TextEditingController();
  // String? selectedDepartmentId;
  List<StoreData> storeDataList = [];
  final TextEditingController _storetypeAheadController =
      TextEditingController();

  bool isLoading = true;

  FocusNode departmentFocusNode = FocusNode();
  FocusNode positionFocusNode = FocusNode();
  FocusNode titleFocusNode = FocusNode();
  FocusNode discountPercentageFocusNode = FocusNode();
  FocusNode userGroupFocusNode = FocusNode();
  FocusNode dateOfJoiningFocusNode = FocusNode();
  FocusNode employeeTypeFocusNode = FocusNode();
  FocusNode workingCityFocusNode = FocusNode();
  FocusNode workPhoneFocusNode = FocusNode();
  FocusNode workMobilePhoneFocusNode = FocusNode();

  List empDepartmentLst = [];
  List empPositionLst = [];
  List empTitleLst = [];
  var box = Hive.box('bitpro_app');
  @override
  void initState() {
    super.initState();
    hiveInitData();
  }

  hiveInitData() async {
    //fetching data
    storeDataList = await HiveStoreDbService().fetchAllStoresData();

    if (storeDataList.any((e) =>
        e.docId == widget.userData.empWorkAndRolesData.assignedStoreDocId)) {
      _storetypeAheadController.text = storeDataList
          .where((e) =>
              e.docId == widget.userData.empWorkAndRolesData.assignedStoreDocId)
          .first
          .storeName;
    }
    _departmenttypeAheadController.text =
        widget.userData.empWorkAndRolesData.department ?? '';
    _positionedtypeAheadController.text =
        widget.userData.empWorkAndRolesData.position ?? '';
    _titletypeAheadController.text =
        widget.userData.empWorkAndRolesData.title ?? '';

    empDepartmentLst = await box.get('empDepartmentLst') ?? [];
    empPositionLst = await box.get('empPositionLst') ?? [];
    empTitleLst = await box.get('empTitleLst') ?? [];

    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return showLoading(withScaffold: true);

    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  staticTextTranslate('Assigned Store'),
                  style: GoogleFonts.roboto(
                      fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 1,
                ),
                SizedBox(
                  width: 360,
                  height: 27,
                  child: TypeAheadFormField(
                    getImmediateSuggestions: false,
                    // enabled: !widget.edit,

                    noItemsFoundBuilder: (context) {
                      return Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text(staticTextTranslate('No Items Found!'),
                            style: TextStyle(
                              fontSize: getMediumFontSize,
                            )),
                      );
                    },
                    textFieldConfiguration: TextFieldConfiguration(
                      controller: _storetypeAheadController,
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w400),
                      decoration: InputDecoration(
                          isDense: true,
                          fillColor: Colors.white,
                          filled: true,
                          contentPadding: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 5),
                          hintStyle: TextStyle(color: Colors.grey[600]),
                          border: const OutlineInputBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(2),
                            ),
                          )),
                    ),
                    suggestionsCallback: (pattern) {
                      return storeDataList
                          .where((e) => e.storeName
                              .toLowerCase()
                              .contains(pattern.toLowerCase()))
                          .toList();
                    },
                    itemBuilder: (context, StoreData suggestion) {
                      return ListTile(
                        title: Text(suggestion.storeName,
                            style: TextStyle(
                              fontSize: getMediumFontSize,
                            )),
                      );
                    },
                    transitionBuilder: (context, suggestionsBox, controller) {
                      return suggestionsBox;
                    },
                    onSuggestionSelected: (StoreData suggestion) {
                      _storetypeAheadController.text = suggestion.storeName;
                      setState(() {
                        widget.userData.empWorkAndRolesData.assignedStoreDocId =
                            suggestion.docId;
                      });
                    },
                  ),
                )
              ]),
        ),
        const SizedBox(
          height: 5,
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    staticTextTranslate('Department'),
                    style: GoogleFonts.roboto(
                        fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  SizedBox(
                    width: 175,
                    height: 27,
                    child: TypeAheadFormField(
                      getImmediateSuggestions: false,
                      noItemsFoundBuilder: (context) {
                        return Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Text(staticTextTranslate('No Items Found!'),
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        );
                      },
                      textFieldConfiguration: TextFieldConfiguration(
                        controller: _departmenttypeAheadController,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w400),
                        decoration: InputDecoration(
                            isDense: true,
                            fillColor: Colors.white,
                            filled: true,
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 7, horizontal: 5),
                            hintStyle: TextStyle(color: Colors.grey[600]),
                            border: const OutlineInputBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(2),
                              ),
                            )),
                      ),
                      suggestionsCallback: (pattern) {
                        var lst = empDepartmentLst
                            .where((e) =>
                                e.toLowerCase().contains(pattern.toLowerCase()))
                            .toList();
                        if (lst.isEmpty && pattern.isNotEmpty)
                          return ['#NewItem'];
                        return lst;
                      },
                      itemBuilder: (context, suggestion) {
                        if (suggestion == '#NewItem') {
                          return ListTile(
                            title: Text('Add new',
                                style: TextStyle(
                                  fontSize: getMediumFontSize,
                                )),
                            subtitle: Text(_departmenttypeAheadController.text),
                          );
                        }

                        return ListTile(
                          title: Text(suggestion,
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        );
                      },
                      transitionBuilder: (context, suggestionsBox, controller) {
                        return suggestionsBox;
                      },
                      onSuggestionSelected: (suggestion) {
                        if (suggestion == '#NewItem') {
                          if (empDepartmentLst.contains(
                                  _departmenttypeAheadController.text) ==
                              false) {
                            empDepartmentLst
                                .add(_departmenttypeAheadController.text);
                            box.put('empDepartmentLst', empDepartmentLst);
                            showToast("Added", context);
                          }
                        } else {
                          _departmenttypeAheadController.text = suggestion;
                        }

                        setState(() {
                          widget.userData.empWorkAndRolesData.department =
                              suggestion == '#NewItem'
                                  ? _departmenttypeAheadController.text
                                  : suggestion;
                        });
                      },
                    ),
                  )
                ]),
            const SizedBox(
              width: 10,
            ),
            Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    staticTextTranslate('Position'),
                    style: GoogleFonts.roboto(
                        fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  SizedBox(
                    width: 175,
                    height: 27,
                    child: TypeAheadFormField(
                      getImmediateSuggestions: false,
                      noItemsFoundBuilder: (context) {
                        return Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Text(staticTextTranslate('No Items Found!'),
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        );
                      },
                      textFieldConfiguration: TextFieldConfiguration(
                        controller: _positionedtypeAheadController,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w400),
                        decoration: InputDecoration(
                            isDense: true,
                            fillColor: Colors.white,
                            filled: true,
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 7, horizontal: 5),
                            hintStyle: TextStyle(color: Colors.grey[600]),
                            border: const OutlineInputBorder(
                              borderRadius: BorderRadius.all(
                                Radius.circular(2),
                              ),
                            )),
                      ),
                      suggestionsCallback: (pattern) {
                        var lst = empPositionLst
                            .where((e) =>
                                e.toLowerCase().contains(pattern.toLowerCase()))
                            .toList();
                        if (lst.isEmpty && pattern.isNotEmpty)
                          return ['#NewItem'];
                        return lst;
                      },
                      itemBuilder: (context, suggestion) {
                        if (suggestion == '#NewItem') {
                          return ListTile(
                            title: Text('Add new',
                                style: TextStyle(
                                  fontSize: getMediumFontSize,
                                )),
                            subtitle: Text(_positionedtypeAheadController.text),
                          );
                        }

                        return ListTile(
                          title: Text(suggestion,
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        );
                      },
                      transitionBuilder: (context, suggestionsBox, controller) {
                        return suggestionsBox;
                      },
                      onSuggestionSelected: (suggestion) {
                        if (suggestion == '#NewItem') {
                          if (empPositionLst.contains(
                                  _positionedtypeAheadController.text) ==
                              false) {
                            empPositionLst
                                .add(_positionedtypeAheadController.text);
                            box.put('empPositionLst', empPositionLst);
                            showToast("Added", context);
                          }
                        } else {
                          _positionedtypeAheadController.text = suggestion;
                        }

                        setState(() {
                          widget.userData.empWorkAndRolesData.position =
                              suggestion == '#NewItem'
                                  ? _departmenttypeAheadController.text
                                  : suggestion;
                        });
                      },
                    ),
                  )
                ]),
          ],
        ),
        const SizedBox(
          height: 5,
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    staticTextTranslate('Title'),
                    style: GoogleFonts.roboto(
                        fontSize: 14, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  SizedBox(
                    width: 175,
                    height: 27,
                    child: TypeAheadFormField(
                      getImmediateSuggestions: false,
                      noItemsFoundBuilder: (context) {
                        return Text(staticTextTranslate('No Items Found!'),
                            style: TextStyle(
                              fontSize: getMediumFontSize,
                            ));
                      },
                      textFieldConfiguration: TextFieldConfiguration(
                        controller: _titletypeAheadController,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w400),
                        decoration: InputDecoration(
                            isDense: true,
                            fillColor: Colors.white,
                            filled: true,
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 7, horizontal: 5),
                            hintStyle: TextStyle(color: Colors.grey[600]),
                            enabledBorder: const OutlineInputBorder(
                              borderSide: BorderSide(width: 0.4),
                              borderRadius: BorderRadius.all(
                                Radius.circular(2),
                              ),
                            ),
                            border: const OutlineInputBorder(
                              borderSide: BorderSide(width: 0.3),
                              borderRadius: BorderRadius.all(
                                Radius.circular(2),
                              ),
                            )),
                      ),
                      suggestionsCallback: (pattern) {
                        var lst = empTitleLst
                            .where((e) =>
                                e.toLowerCase().contains(pattern.toLowerCase()))
                            .toList();
                        if (lst.isEmpty && pattern.isNotEmpty)
                          return ['#NewItem'];
                        return lst;
                      },
                      itemBuilder: (context, suggestion) {
                        if (suggestion == '#NewItem') {
                          return ListTile(
                            title: Text('Add new',
                                style: TextStyle(
                                  fontSize: getMediumFontSize,
                                )),
                            subtitle: Text(_titletypeAheadController.text),
                          );
                        }

                        return ListTile(
                          title: Text(suggestion,
                              style: TextStyle(
                                fontSize: getMediumFontSize,
                              )),
                        );
                      },
                      transitionBuilder: (context, suggestionsBox, controller) {
                        return suggestionsBox;
                      },
                      onSuggestionSelected: (suggestion) {
                        if (suggestion == '#NewItem') {
                          if (empTitleLst
                                  .contains(_titletypeAheadController.text) ==
                              false) {
                            empTitleLst.add(_titletypeAheadController.text);
                            box.put('empTitleLst', empTitleLst);
                            showToast("Added", context);
                          }
                        } else {
                          _titletypeAheadController.text = suggestion;
                        }

                        setState(() {
                          widget.userData.empWorkAndRolesData.title =
                              suggestion == '#NewItem'
                                  ? _titletypeAheadController.text
                                  : suggestion;
                        });
                      },
                    ),
                  )
                ]),
            // BTextField(
            //   textFieldReadOnly: false,
            //   label: 'Title',
            //   focusNode: titleFocusNode,
            //   initialValue: widget.userData.empWorkAndRolesData.title,
            //   onFieldSubmitted: (v) {
            //     discountPercentageFocusNode.requestFocus();
            //   },
            //   onChanged: (val) => setState(() {
            //     widget.userData.empWorkAndRolesData.title = val;
            //   }),
            //   autovalidateMode: AutovalidateMode.onUserInteraction,
            // ),
            const SizedBox(
              width: 10,
            ),
            BTextField(
              prefixIcon: Icons.percent,
              fieldWidth: 175,
              focusNode: discountPercentageFocusNode,
              textFieldReadOnly: false,
              label: 'Discount Percentage',
              initialValue:
                  widget.userData.empWorkAndRolesData.discountPercentage,
              validator: ((val) {
                if (double.tryParse(val!) == null) {
                  return staticTextTranslate('Enter a valid number');
                } else if (double.parse(val) < 0 || double.parse(val) > 110) {
                  return staticTextTranslate('Enter a value between 0 - 100%');
                }
                return null;
              }),
              onChanged: (val) => setState(() {
                widget.userData.empWorkAndRolesData.discountPercentage = val;
              }),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
          ],
        ),
        const SizedBox(
          height: 25,
        ),
        Row(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      staticTextTranslate('User Group'),
                      style: GoogleFonts.roboto(
                          fontSize: 14, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      staticTextTranslate(' *'),
                      style: GoogleFonts.roboto(
                          color: Colors.red,
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
                SizedBox(
                  height: 1,
                ),
                Container(
                  width: 175,
                  height: 27,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                        width: 0.5,
                        color: const Color.fromARGB(255, 43, 43, 43),
                      ),
                      borderRadius: BorderRadius.circular(2)),
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: DropdownButton<String>(
                    underline: const SizedBox(),
                    isExpanded: true,
                    focusNode: userGroupFocusNode,
                    padding: EdgeInsets.zero,
                    hint: Text(
                      staticTextTranslate('Select User Group'),
                      style: TextStyle(
                          fontSize: getMediumFontSize,
                          fontWeight: FontWeight.w400),
                    ),
                    value:
                        widget.userData.empWorkAndRolesData.userGroupId.isEmpty
                            ? null
                            : widget.userData.empWorkAndRolesData.userGroupId,
                    items: widget.userGroupsDataLst.map((UserGroupData value) {
                      return DropdownMenuItem<String>(
                        value: value.name,
                        child: Text(
                          value.name,
                          style: TextStyle(
                              fontSize: getMediumFontSize,
                              fontWeight: FontWeight.w400),
                        ),
                      );
                    }).toList(),
                    onChanged: (val) {
                      if (val != null) {
                        setState(() {
                          widget.userData.empWorkAndRolesData.userGroupId = val;
                        });
                      }
                    },
                  ),
                )
              ],
            ),
            const SizedBox(
              width: 10,
            ),
            // if (showDropDownError)
            //   Text(
            //     staticTextTranslate('Select a role'),
            //     style:
            //         TextStyle(fontSize: getSmallFontSize, color: Colors.red[800]),
            //   ),

            // BTextField(
            //   textFieldReadOnly: false,
            //   label: 'Date of Joining',
            //   initialValue: widget.userData.empWorkAndRolesData.dateOfJoining,
            //   onChanged: (val) => setState(() {
            //     widget.userData.empWorkAndRolesData.dateOfJoining = val;
            //   }),
            //   autovalidateMode: AutovalidateMode.onUserInteraction,
            // ),
            SizedBox(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    staticTextTranslate('Date of Joining'),
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 1,
                  ),
                  SizedBox(
                    width: 175,
                    height: 27,
                    child: GestureDetector(
                      onTap: () async {
                        DateTime? dateTime = await showDatePicker(
                          context: context,
                          currentDate: DateTime.now(),
                          initialDate: DateTime.tryParse(widget
                                  .userData.empWorkAndRolesData.dateOfJoining ??
                              ''),
                          firstDate: DateTime(1900),
                          lastDate: DateTime(2050),
                        );
                        if (dateTime != null) {
                          widget.userData.empWorkAndRolesData.dateOfJoining =
                              dateTime.toString();

                          setState(() {});
                        }
                      },
                      child: Container(
                        width: 200,
                        height: 28,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                                color: const Color.fromARGB(255, 0, 0, 0),
                                width: 0.4),
                            borderRadius: BorderRadius.circular(2)),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 5),
                        child: Row(
                          children: [
                            Text(
                              widget.userData.empWorkAndRolesData
                                              .dateOfJoining ==
                                          null ||
                                      widget.userData.empWorkAndRolesData
                                          .dateOfJoining!.isEmpty
                                  ? staticTextTranslate('Click to Select Date')
                                  : DateFormat('dd / MM / yyyy').format(
                                      DateTime.parse(widget.userData
                                          .empWorkAndRolesData.dateOfJoining!)),
                              style: GoogleFonts.roboto(
                                  fontSize: 14,
                                  height: 1.1,
                                  color: widget.userData.empWorkAndRolesData
                                              .dateOfJoining ==
                                          null
                                      ? const Color.fromARGB(255, 76, 75, 75)
                                      : Colors.black),
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 8,
        ),
        BTextField(
          prefixIcon: Icons.work,
          fieldWidth: 175,
          textFieldReadOnly: false,
          label: 'Employee Type',
          focusNode: employeeTypeFocusNode,
          initialValue: widget.userData.empWorkAndRolesData.employeeType,
          onFieldSubmitted: (v) {
            workingCityFocusNode.requestFocus();
          },
          onChanged: (val) => setState(() {
            widget.userData.empWorkAndRolesData.employeeType = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),
        const SizedBox(
          height: 25,
        ),
        BTextField(
          prefixIcon: Icons.location_city,
          fieldWidth: 175,
          textFieldReadOnly: false,
          label: 'Working city',
          focusNode: workingCityFocusNode,
          initialValue: widget.userData.empWorkAndRolesData.workingCity,
          onFieldSubmitted: (v) {
            workPhoneFocusNode.requestFocus();
          },
          onChanged: (val) => setState(() {
            widget.userData.empWorkAndRolesData.workingCity = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),
        Row(
          children: [
            BTextField(
              prefixIcon: Icons.phone,
              fieldWidth: 175,
              textFieldReadOnly: false,
              label: 'Work phone',
              onFieldSubmitted: (v) {
                workMobilePhoneFocusNode.requestFocus();
              },
              focusNode: workPhoneFocusNode,
              initialValue: widget.userData.empWorkAndRolesData.workPhone,
              onChanged: (val) => setState(() {
                widget.userData.empWorkAndRolesData.workPhone = val;
              }),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
            const SizedBox(
              width: 10,
            ),
            BTextField(
              prefixIcon: Icons.phone,
              fieldWidth: 175,
              textFieldReadOnly: false,
              label: 'Work Mobile Phone',
              focusNode: workMobilePhoneFocusNode,
              initialValue: widget.userData.empWorkAndRolesData.workMobilePhone,
              onChanged: (val) => setState(() {
                widget.userData.empWorkAndRolesData.workMobilePhone = val;
              }),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
          ],
        ),
      ]),
    );
  }
}
