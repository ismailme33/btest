import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/user_group_data.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class Tab3Personal extends StatefulWidget {
  final List<UserGroupData> userGroupsDataLst;
  final EmployeeData userData;
  const Tab3Personal(
      {super.key, required this.userGroupsDataLst, required this.userData});

  @override
  State<Tab3Personal> createState() => _Tab3PersonalState();
}

class _Tab3PersonalState extends State<Tab3Personal> {
  FocusNode personalMobileFocusNode = FocusNode();
  FocusNode otherEmailFocusNode = FocusNode();
  FocusNode birthDateFocusNode = FocusNode();

  FocusNode maritalStatusFocusNode = FocusNode();
  FocusNode citizenshipFocusNode = FocusNode();
  FocusNode addressFocusNode = FocusNode();
  FocusNode homeAddressFocusNode = FocusNode();
  FocusNode emergencyContactNameFocusNode = FocusNode();
  FocusNode relationshipFocusNode = FocusNode();
  FocusNode emergencyPhoneFocusNode = FocusNode();
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(
          height: 5,
        ),
        BTextField(
          fieldWidth: 175,
          textFieldReadOnly: false,
          prefixIcon: Icons.phone,
          label: 'Personal Mobile',
          focusNode: personalMobileFocusNode,
          onFieldSubmitted: (v) {
            otherEmailFocusNode.requestFocus();
          },
          initialValue: widget.userData.empPersonalData.personalMobile,
          onChanged: (val) => setState(() {
            widget.userData.empPersonalData.personalMobile = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),

        BTextField(
          textFieldReadOnly: false,
          prefixIcon: Icons.email,
          label: 'Other email',
          focusNode: otherEmailFocusNode,
          initialValue: widget.userData.empPersonalData.otherEmail,
          onChanged: (val) => setState(() {
            widget.userData.empPersonalData.otherEmail = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),

        // BTextField(
        //   textFieldReadOnly: false,
        //   label: 'Birth Date',
        //   initialValue: widget.userData.empPersonalData.birthDate,
        //   onChanged: (val) => setState(() {
        //     widget.userData.empPersonalData.birthDate = val;
        //   }),
        //   autovalidateMode: AutovalidateMode.onUserInteraction,
        // ),
        SizedBox(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                staticTextTranslate('Birth Date'),
                style: GoogleFonts.roboto(
                    fontSize: getMediumFontSize, fontWeight: FontWeight.bold),
              ),
              const SizedBox(
                height: 2,
              ),
              SizedBox(
                width: 360,
                height: 27,
                child: GestureDetector(
                  onTap: () async {
                    DateTime? dateTime = await showDatePicker(
                      context: context,
                      currentDate: DateTime.now(),
                      initialDate: DateTime.tryParse(
                          widget.userData.empPersonalData.birthDate ?? ''),
                      firstDate: DateTime(1900),
                      lastDate: DateTime(2050),
                    );
                    if (dateTime != null) {
                      widget.userData.empPersonalData.birthDate =
                          dateTime.toString();

                      setState(() {});
                    }
                  },
                  child: Container(
                    width: 310,
                    decoration: BoxDecoration(
                        color: Colors.white,
                        border: Border.all(
                            color: const Color.fromARGB(255, 0, 0, 0),
                            width: 0.4),
                        borderRadius: BorderRadius.circular(2)),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                    child: Row(
                      children: [
                        Text(
                          widget.userData.empPersonalData.birthDate == null ||
                                  widget.userData.empPersonalData.birthDate!
                                      .isEmpty
                              ? staticTextTranslate('Click to Select Date')
                              : DateFormat('dd / MM / yyyy').format(
                                  DateTime.parse(widget
                                      .userData.empPersonalData.birthDate!)),
                          style: GoogleFonts.roboto(
                              fontSize: 14,
                              height: 1.1,
                              color:
                                  widget.userData.empPersonalData.birthDate ==
                                          null
                                      ? const Color.fromARGB(255, 0, 0, 0)
                                      : Colors.black),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
        SizedBox(
          height: 8,
        ),

        Row(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  staticTextTranslate('Gender'),
                  style: GoogleFonts.roboto(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(
                  height: 2,
                ),
                Container(
                  width: 175,
                  height: 27,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                        width: 0.5,
                        color: const Color.fromARGB(255, 43, 43, 43),
                      ),
                      borderRadius: BorderRadius.circular(2)),
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: DropdownButton<String>(
                    underline: const SizedBox(),
                    isExpanded: true,
                    padding: EdgeInsets.zero,
                    hint: Text(
                      staticTextTranslate('Select Gender'),
                      style: TextStyle(
                          fontSize: getMediumFontSize,
                          fontWeight: FontWeight.w400),
                    ),
                    value: widget.userData.empPersonalData.gender,
                    items: ['Male', 'Female'].map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          value,
                          style: TextStyle(
                              fontSize: getMediumFontSize + 2,
                              fontWeight: FontWeight.w400),
                        ),
                      );
                    }).toList(),
                    onChanged: (val) {
                      setState(() {
                        widget.userData.empPersonalData.gender = val;
                      });
                    },
                  ),
                )
              ],
            ),
            const SizedBox(
              width: 10,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  staticTextTranslate('Marital Status'),
                  style: GoogleFonts.roboto(
                      fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 2,
                ),
                Container(
                  width: 175,
                  height: 27,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                        width: 0.5,
                        color: const Color.fromARGB(255, 43, 43, 43),
                      ),
                      borderRadius: BorderRadius.circular(2)),
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: DropdownButton<String>(
                    underline: const SizedBox(),
                    isExpanded: true,
                    padding: EdgeInsets.zero,
                    hint: Text(
                      staticTextTranslate('Select Marital Status'),
                      style: TextStyle(
                          fontSize: getMediumFontSize,
                          fontWeight: FontWeight.w400),
                    ),
                    value: widget.userData.empPersonalData.maritalStatus,
                    items:
                        ['Married', 'Single', 'Divorced'].map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          value,
                          style: TextStyle(
                              fontSize: getMediumFontSize + 2,
                              fontWeight: FontWeight.w400),
                        ),
                      );
                    }).toList(),
                    onChanged: (val) {
                      setState(() {
                        widget.userData.empPersonalData.maritalStatus = val;
                      });
                    },
                  ),
                )
              ],
            ),
          ],
        ),
        const SizedBox(
          height: 8,
        ),
        BTextField(
          prefixIcon: Icons.flag,
          fieldWidth: 175,
          textFieldReadOnly: false,
          label: 'Citizenship',
          focusNode: citizenshipFocusNode,
          onFieldSubmitted: (v) {
            addressFocusNode.requestFocus();
          },
          initialValue: widget.userData.empPersonalData.citizenship,
          onChanged: (val) => setState(() {
            widget.userData.empPersonalData.citizenship = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),

        BTextField(
          textFieldReadOnly: false,
          height: 2,
          label: 'Address',
          focusNode: addressFocusNode,
          onFieldSubmitted: (v) {
            homeAddressFocusNode.requestFocus();
          },
          initialValue: widget.userData.empPersonalData.address,
          onChanged: (val) => setState(() {
            widget.userData.empPersonalData.address = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),

        BTextField(
          height: 2,
          textFieldReadOnly: false,
          label: 'Home Address',
          focusNode: homeAddressFocusNode,
          onFieldSubmitted: (v) {
            emergencyContactNameFocusNode.requestFocus();
          },
          initialValue: widget.userData.empPersonalData.homeAddress,
          onChanged: (val) => setState(() {
            widget.userData.empPersonalData.homeAddress = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),
        const SizedBox(
          height: 5,
        ),

        BTextField(
          prefixIcon: Icons.person,
          textFieldReadOnly: false,
          label: 'Emergency contact Person Name',
          focusNode: emergencyContactNameFocusNode,
          onFieldSubmitted: (v) {
            relationshipFocusNode.requestFocus();
          },
          initialValue: widget.userData.empPersonalData.emergencyContactName,
          onChanged: (val) => setState(() {
            widget.userData.empPersonalData.emergencyContactName = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),

        Row(
          children: [
            BTextField(
              fieldWidth: 175,
              textFieldReadOnly: false,
              label: 'Relationship',
              focusNode: relationshipFocusNode,
              onFieldSubmitted: (v) {
                emergencyPhoneFocusNode.requestFocus();
              },
              initialValue: widget.userData.empPersonalData.relationship,
              onChanged: (val) => setState(() {
                widget.userData.empPersonalData.relationship = val;
              }),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
            const SizedBox(
              width: 10,
            ),
            BTextField(
              prefixIcon: Icons.phone,
              fieldWidth: 175,
              textFieldReadOnly: false,
              label: 'Emergency phone',
              focusNode: emergencyPhoneFocusNode,
              initialValue: widget.userData.empPersonalData.emergencyPhone,
              onChanged: (val) => setState(() {
                widget.userData.empPersonalData.emergencyPhone = val;
              }),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
          ],
        ),
      ]),
    );
  }
}
