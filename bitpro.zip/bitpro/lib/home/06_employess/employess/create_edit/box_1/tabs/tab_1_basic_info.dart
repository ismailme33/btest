import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/user_group_data.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class Tab1BasicInfo extends StatefulWidget {
  final List<UserGroupData> userGroupsDataLst;
  final EmployeeData userData;
  final List<EmployeeData> userDataLst;
  final bool isEdit;
  const Tab1BasicInfo(
      {super.key,
      required this.userGroupsDataLst,
      required this.userData,
      required this.isEdit,
      required this.userDataLst});

  @override
  State<Tab1BasicInfo> createState() => _Tab1BasicInfoState();
}

class _Tab1BasicInfoState extends State<Tab1BasicInfo> {
  String localPassword = '';

  var formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool showDropDownError = false;

  FocusNode lastNameFocusNode = FocusNode();
  FocusNode emailFocusNode = FocusNode();
  FocusNode usernameFocusNode = FocusNode();
  FocusNode passwordFocusNode = FocusNode();
  FocusNode confirmPaswordFocusNode = FocusNode();
  FocusNode noteNode = FocusNode();

  @override
  void initState() {
    super.initState();
    localPassword = widget.userData.empBasicInfoData.password;
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return showLoading(withScaffold: true);
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BTextField(
              fieldWidth: 175,
              textFieldReadOnly: true,
              label: 'Employee Id',
              initialValue: widget.userData.empBasicInfoData.employeeId,
              onChanged: (val) => setState(() {}),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
            SizedBox(
              width: 10,
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  staticTextTranslate('Employee Status'),
                  style: GoogleFonts.roboto(
                      fontSize: 14, fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 1,
                ),
                Container(
                  width: 175,
                  height: 27,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(
                        width: 0.5,
                        color: const Color.fromARGB(255, 43, 43, 43),
                      ),
                      borderRadius: BorderRadius.circular(2)),
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: DropdownButton<String>(
                    underline: const SizedBox(),
                    isExpanded: true,
                    padding: EdgeInsets.zero,
                    hint: Text(
                      staticTextTranslate('Select Role'),
                      style: TextStyle(
                          fontSize: getMediumFontSize + 2,
                          fontWeight: FontWeight.w400),
                    ),
                    value: widget.userData.empBasicInfoData.employeedStatus,
                    items: ['active', 'inactive'].map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          value,
                          style: TextStyle(
                              fontSize: getMediumFontSize + 2,
                              fontWeight: FontWeight.w400),
                        ),
                      );
                    }).toList(),
                    onChanged: (val) {
                      if (val != null) {
                        setState(() {
                          showDropDownError = false;
                          widget.userData.empBasicInfoData.employeedStatus =
                              val;
                        });
                      }
                    },
                  ),
                )
              ],
            ),
          ],
        ),
        Row(
          children: [
            BTextField(
              fieldWidth: 175,
              redStarEnabled: true,
              textFieldReadOnly: false,
              label: 'First Name',
              initialValue: widget.userData.empBasicInfoData.firstName,
              onFieldSubmitted: (val) {
                lastNameFocusNode.requestFocus();
              },
              validator: ((value) {
                if (value!.isEmpty) {
                  return staticTextTranslate('Enter your name');
                }
                return null;
              }),
              onChanged: (val) => setState(() {
                widget.userData.empBasicInfoData.firstName = val;
              }),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
            const SizedBox(
              width: 10,
            ),
            BTextField(
              fieldWidth: 175,
              redStarEnabled: true,
              focusNode: lastNameFocusNode,
              textFieldReadOnly: false,
              onFieldSubmitted: (val) {
                emailFocusNode.requestFocus();
              },
              label: 'Last Name',
              initialValue: widget.userData.empBasicInfoData.lastName,
              onChanged: (val) => setState(() {
                widget.userData.empBasicInfoData.lastName = val;
              }),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
          ],
        ),
        BTextField(
          focusNode: emailFocusNode,
          prefixIcon: Icons.email,
          textFieldReadOnly: false,
          label: 'Email',
          onFieldSubmitted: (val) {
            usernameFocusNode.requestFocus();
          },
          initialValue: widget.userData.empBasicInfoData.email,
          onChanged: (val) => setState(() {
            widget.userData.empBasicInfoData.email = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),
        const SizedBox(
          height: 25,
        ),
        BTextField(
          prefixIcon: Icons.person,
          redStarEnabled: true,
          fieldWidth: 175,
          focusNode: usernameFocusNode,
          textFieldReadOnly: widget.isEdit,
          label: 'Username',
          onFieldSubmitted: (val) {
            passwordFocusNode.requestFocus();
          },
          initialValue: widget.userData.empBasicInfoData.username,
          validator: ((value) {
            if (value == null || value.isEmpty) {
              return staticTextTranslate('Enter your username');
            } else if (widget.isEdit == false) {
              if (widget.userDataLst
                  .where((e) => e.empBasicInfoData.username == value)
                  .isNotEmpty) {
                return staticTextTranslate('Username is already in use');
              }
            }
            return null;
          }),
          onChanged: (val) => setState(() {
            widget.userData.empBasicInfoData.username = val;
          }),
          autovalidateMode: AutovalidateMode.onUserInteraction,
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BTextField(
              prefixIcon: Icons.lock,
              redStarEnabled: true,
              fieldWidth: 175,
              focusNode: passwordFocusNode,
              textFieldReadOnly: false,
              label: 'Password',
              onFieldSubmitted: (val) {
                confirmPaswordFocusNode.requestFocus();
              },
              initialValue: widget.userData.empBasicInfoData.password,
              validator: ((value) {
                if (value!.isEmpty) {
                  return staticTextTranslate('Enter your password');
                }
                return null;
              }),
              onChanged: (val) => setState(() {
                localPassword = val;
              }),
              autovalidateMode: AutovalidateMode.onUserInteraction,
              obscureText: true,
            ),
            const SizedBox(
              width: 10,
            ),
            BTextField(
              prefixIcon: Icons.lock,
              redStarEnabled: true,
              fieldWidth: 175,
              focusNode: confirmPaswordFocusNode,
              textFieldReadOnly: false,
              label: 'Confirm Password',
              initialValue: widget.userData.empBasicInfoData.password,
              validator: ((value) {
                if (value!.isEmpty) {
                  return staticTextTranslate('Re enter your password');
                }
                if (localPassword !=
                    widget.userData.empBasicInfoData.password) {
                  return staticTextTranslate(
                      'Please make sure your passwords match.');
                }
                return null;
              }),
              onFieldSubmitted: (val) {
                noteNode.requestFocus();
              },
              obscureText: true,
              onChanged: (val) => setState(() {
                widget.userData.empBasicInfoData.password = val;
              }),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
          ],
        ),
        const SizedBox(
          height: 25,
        ),
        BTextField(
          textFieldHeight: 3,
          focusNode: noteNode,
          textFieldReadOnly: false,
          label: 'Note',
          initialValue: widget.userData.empBasicInfoData.note,
          onChanged: (val) => setState(() {
            widget.userData.empBasicInfoData.note = val;
          }),
        ),
        Row(
          children: [
            BTextField(
              fieldWidth: 175,
              textFieldReadOnly: true,
              label: 'Added Time',
              initialValue: DateFormat('dd / MM / yyyy').format(
                  DateTime.parse(widget.userData.empBasicInfoData.createdDate)),
              autovalidateMode: AutovalidateMode.onUserInteraction,
              onChanged: (v) {},
            ),
            const SizedBox(
              width: 10,
            ),
            BTextField(
              fieldWidth: 175,
              textFieldReadOnly: false,
              label: 'Added By',
              initialValue: widget.userData.empBasicInfoData.createdBy,
              onChanged: (val) => setState(() {}),
              autovalidateMode: AutovalidateMode.onUserInteraction,
            ),
          ],
        ),
      ]),
    );
  }
}
