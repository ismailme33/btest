// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';

import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_1/tabs/tab_1_basic_info.dart';
import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_1/tabs/tab_2_work_and_roles.dart';
import 'package:bitpro_hive/home/06_employess/employess/create_edit/box_1/tabs/tab_3_personal.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/user_group_data.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';

class CreateEmpBox1Widget extends StatefulWidget {
  final List<UserGroupData> userGroupsDataLst;
  final EmployeeData userData;
  final List<EmployeeData> userDataLst;
  final Function onTabSaveFunction;
  final bool isEdit;
  const CreateEmpBox1Widget({
    Key? key,
    required this.userGroupsDataLst,
    required this.userData,
    required this.onTabSaveFunction,
    required this.isEdit,
    required this.userDataLst,
  }) : super(key: key);

  @override
  State<CreateEmpBox1Widget> createState() => _CreateEmpBox1WidgetState();
}

class _CreateEmpBox1WidgetState extends State<CreateEmpBox1Widget> {
  int selectedTabIndex = 0;
  bool isLoading = false;
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: 410,
        decoration: BoxDecoration(
            border: Border.all(width: 0.3),
            color: const Color(0xffE2E2E2),
            borderRadius: BorderRadius.circular(3)),
        child: isLoading
            ? showLoading(withScaffold: true)
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 35,
                    // padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(4),
                          topRight: Radius.circular(4)),
                      gradient: LinearGradient(
                          end: Alignment.bottomCenter,
                          colors: [
                            Color.fromARGB(255, 51, 51, 51),
                            Color.fromARGB(255, 51, 51, 51),
                            // Color.fromARGB(255, 0, 0, 0),
                          ],
                          begin: Alignment.topCenter),
                    ),
                    child: Row(
                      children: [
                        InkWell(
                          onTap: () {
                            setState(() {
                              selectedTabIndex = 0;
                            });
                          },
                          child: Container(
                            width: 120,
                            height: 35,
                            decoration: BoxDecoration(
                                border: Border.symmetric(
                                    vertical: BorderSide(color: Colors.grey)),
                                borderRadius: BorderRadius.circular(0),
                                gradient: selectedTabIndex == 0
                                    ? LinearGradient(
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Color.fromARGB(255, 12, 65, 114),
                                          Color.fromARGB(255, 12, 65, 114),
                                        ],
                                        begin: Alignment.topCenter)
                                    : null),
                            alignment: Alignment.center,
                            child: Text(
                              "Basic Info",
                              style: GoogleFonts.roboto(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            setState(() {
                              selectedTabIndex = 1;
                            });
                          },
                          child: Container(
                            width: 120,
                            height: 35,
                            decoration: BoxDecoration(
                                border: Border.symmetric(
                                    vertical: BorderSide(color: Colors.grey)),
                                borderRadius: BorderRadius.circular(2),
                                gradient: selectedTabIndex == 1
                                    ? LinearGradient(
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Color.fromARGB(255, 12, 65, 114),
                                          Color.fromARGB(255, 12, 65, 114),
                                        ],
                                        begin: Alignment.topCenter)
                                    : null),
                            alignment: Alignment.center,
                            child: Text(
                              "Work & Roles",
                              style: GoogleFonts.roboto(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.white),
                            ),
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            setState(() {
                              selectedTabIndex = 2;
                            });
                          },
                          child: Container(
                            width: 120,
                            height: 35,
                            decoration: BoxDecoration(
                                border: Border.symmetric(
                                    vertical: BorderSide(color: Colors.grey)),
                                borderRadius: BorderRadius.circular(0),
                                gradient: selectedTabIndex == 2
                                    ? LinearGradient(
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Color(0xff092F53),
                                          Color(0xff284F70),
                                        ],
                                        begin: Alignment.topCenter)
                                    : null),
                            alignment: Alignment.center,
                            child: Text(
                              "Personal",
                              style: GoogleFonts.roboto(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.white),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                  Expanded(
                      child: SingleChildScrollView(
                    child: selectedTabIndex == 0
                        ? Tab1BasicInfo(
                            userDataLst: widget.userDataLst,
                            isEdit: widget.isEdit,
                            userData: widget.userData,
                            userGroupsDataLst: widget.userGroupsDataLst,
                          )
                        : selectedTabIndex == 1
                            ? Tab2WorkAndRoles(
                                userData: widget.userData,
                                userGroupsDataLst: widget.userGroupsDataLst,
                              )
                            : Tab3Personal(
                                userData: widget.userData,
                                userGroupsDataLst: widget.userGroupsDataLst,
                              ),
                  )),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Container(
                      width: double.maxFinite,
                      decoration: const BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(3),
                          bottomRight: Radius.circular(3),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Row(
                          children: [
                            OnPageButton(
                              icon: Iconsax.archive,
                              label: 'Save',
                              onPressed: () async {
                                widget.onTabSaveFunction();
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
      ),
    );
  }
}
