import 'package:bitpro_hive/home/06_employess/document_notification/document_notification_page.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:bitpro_hive/home/06_employess/employess/employees_list_page.dart';
import 'package:bitpro_hive/home/06_employess/user_groups/user_group_page.dart';
import 'package:bitpro_hive/model/user_group_data.dart';
import '../../../model/employee_data.dart';

class EmployeesPage extends StatefulWidget {
  final EmployeeData userData;
  final UserGroupData currentUserRole;

  const EmployeesPage({
    super.key,
    required this.userData,
    required this.currentUserRole,
  });

  @override
  State<EmployeesPage> createState() => _EmployeesPageState();
}

class _EmployeesPageState extends State<EmployeesPage> {
  @override
  Widget build(BuildContext context) {
    return Wrap(spacing: 15, runSpacing: 15, children: [
      if (widget.currentUserRole.employees)
        OnPageButton(
          label: 'Employees',
          width: 160,
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => EmployeesListPage(
                          userData: widget.userData,
                        )));
          },
          icon: Iconsax.user,
        ),
      if (widget.currentUserRole.groups)
        OnPageButton(
          label: 'User Groups',
          width: 170,
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => UserGroupPage(
                          userData: widget.userData,
                        )));
          },
          icon: Iconsax.lock_1,
        ),
      OnPageButton(
        label: 'Document Notification',
        width: 230,
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => DocumentNotificationPage(
                        userData: widget.userData,
                      )));
        },
        icon: Iconsax.notification,
      ),
    ]);
  }
}
