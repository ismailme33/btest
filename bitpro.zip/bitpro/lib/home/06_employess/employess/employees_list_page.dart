import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_user_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_user_group_db_service.dart';
import 'package:bitpro_hive/widget/filter_container.dart';
import 'package:bitpro_hive/widget/filter_text_fileds/fiter_textfield.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/home/06_employess/employess/create_edit/create_edit_employess_page.dart';
import 'package:bitpro_hive/model/user_group_data.dart';
import 'package:bitpro_hive/shared/custom_top_nav_bar.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

import '../../../shared/global_variables/font_sizes.dart';
import '../../../shared/global_variables/static_text_translate.dart';

class EmployeesListPage extends StatefulWidget {
  final EmployeeData userData;
  const EmployeesListPage({super.key, required this.userData});

  @override
  State<EmployeesListPage> createState() => _EmployeesListPageState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _EmployeesListPageState extends State<EmployeesListPage> {
  final List<BitproGridColumnModel> _bitproGridColumnModel = [
    BitproGridColumnModel(
        columnName: 'serialNumberForStyleColor',
        visible: false,
        label: 'serialNumberForStyleColor',
        width: double.nan),
    BitproGridColumnModel(
        columnName: 'id', label: staticTextTranslate('Emp. Id'), width: 120),
    BitproGridColumnModel(
        columnName: 'name',
        label: staticTextTranslate('Employee Name'),
        width: 180),
    BitproGridColumnModel(
        columnName: 'role',
        label: staticTextTranslate('User Role'),
        width: 135),
    BitproGridColumnModel(
        columnName: 'username',
        label: staticTextTranslate('Username'),
        width: 140),
    BitproGridColumnModel(
        columnName: 'discount',
        label: staticTextTranslate('Max Discount %'),
        width: 175),
    BitproGridColumnModel(
        columnName: 'assigned_store',
        label: staticTextTranslate('Store'),
        width: 125),
    BitproGridColumnModel(
        columnName: 'active', label: staticTextTranslate('Active'), width: 120),
    BitproGridColumnModel(
        columnName: 'department',
        label: staticTextTranslate('Department'),
        width: 150),
    BitproGridColumnModel(
        columnName: 'title', label: staticTextTranslate('Title'), width: 150),
    BitproGridColumnModel(
        columnName: 'position',
        label: staticTextTranslate('Position'),
        width: 135),
    BitproGridColumnModel(
        columnName: 'created date',
        label: staticTextTranslate('Created Date'),
        width: 170),
    BitproGridColumnModel(
        columnName: 'created by',
        label: staticTextTranslate('Created by'),
        width: 150),
  ];
  List<EmployeeData> employeesDataLst = [];

  DataGridController dataGridController = DataGridController();
  String? selectedSearchedRole;
  String? selectedSearchedStore;
  String? selectedSearchedStoreSubname;
  // String empId = '';
  // String empName = '';
  EmployeeDataSource? employeeDataSource;
  DateTime? rangeStartDate;
  DateTime? rangeEndDate;
  bool loading = true;

  var employeeIdController = TextEditingController();
  var employeeNameController = TextEditingController();
  var idNumberController = TextEditingController();
  final _roleTypeAheadController = TextEditingController();
  final _storeTypeAheadController = TextEditingController();
  final _subNameTypeAheadController = TextEditingController();
  List<UserGroupData> userGroupsDataLst = [];
  bool showInactiveEmployees = false;
  List<StoreData> storeDataList = [];
  @override
  void initState() {
    super.initState();
    hiveFetchData();
  }

  commonInit() async {
    employeesDataLst.sort((b, a) => a.empBasicInfoData.createdDate
        .compareTo(b.empBasicInfoData.createdDate));
    employeeDataSource = EmployeeDataSource(
        employeeData: employeesDataLst,
        storeDataList: storeDataList,
        userGroupsDataLst: userGroupsDataLst,
        showInactiveEmployees: showInactiveEmployees);
    setState(() {
      loading = false;
    });
  }

  hiveFetchData() async {
    storeDataList = await HiveStoreDbService().fetchAllStoresData();
    employeesDataLst = await HiveUserDbService().fetchAllUserData();
    userGroupsDataLst = await HiveUserGroupDbService().fetchAllUserGroups();
    await commonInit();
  }

  searchEmpId(String id) {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (id.isEmpty) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          storeDataList: storeDataList,
          userGroupsDataLst: userGroupsDataLst,
          showInactiveEmployees: showInactiveEmployees);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      if (ud.empBasicInfoData.employeeId
          .toLowerCase()
          .contains(id.toLowerCase())) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        employeeData: filteredEmployeesDataLst,
        storeDataList: storeDataList,
        userGroupsDataLst: userGroupsDataLst,
        showInactiveEmployees: showInactiveEmployees);
    setState(() {});
  }

  searchEmpRole(String role) {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (role.isEmpty || role == staticTextTranslate('All Roles')) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          storeDataList: storeDataList,
          userGroupsDataLst: userGroupsDataLst,
          showInactiveEmployees: showInactiveEmployees);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      if (ud.empWorkAndRolesData.userGroupId == role) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        storeDataList: storeDataList,
        userGroupsDataLst: userGroupsDataLst,
        employeeData: filteredEmployeesDataLst,
        showInactiveEmployees: showInactiveEmployees);
    setState(() {});
  }

  searchEmpStore(String storeDocId) {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (storeDocId.isEmpty || storeDocId == staticTextTranslate('All Stores')) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          storeDataList: storeDataList,
          userGroupsDataLst: userGroupsDataLst,
          showInactiveEmployees: showInactiveEmployees);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      if (ud.empWorkAndRolesData.assignedStoreDocId == storeDocId) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        storeDataList: storeDataList,
        userGroupsDataLst: userGroupsDataLst,
        employeeData: filteredEmployeesDataLst,
        showInactiveEmployees: showInactiveEmployees);
    setState(() {});
  }

  searchEmpStoreSubName(String storeDocId) {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (storeDocId.isEmpty ||
        storeDocId == staticTextTranslate('All Sub Name')) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          storeDataList: storeDataList,
          userGroupsDataLst: userGroupsDataLst,
          showInactiveEmployees: showInactiveEmployees);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      if (ud.empWorkAndRolesData.assignedStoreDocId == storeDocId) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        storeDataList: storeDataList,
        userGroupsDataLst: userGroupsDataLst,
        employeeData: filteredEmployeesDataLst,
        showInactiveEmployees: showInactiveEmployees);
    setState(() {});
  }

  searchEmpName(String name) {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (name.isEmpty) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          storeDataList: storeDataList,
          userGroupsDataLst: userGroupsDataLst,
          showInactiveEmployees: showInactiveEmployees);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      String nam =
          '${ud.empBasicInfoData.firstName.toLowerCase()} ${ud.empBasicInfoData.lastName.toLowerCase()}';
      if (nam.contains(name.toLowerCase())) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        employeeData: filteredEmployeesDataLst,
        storeDataList: storeDataList,
        userGroupsDataLst: userGroupsDataLst,
        showInactiveEmployees: showInactiveEmployees);
    setState(() {});
  }

  searchIdNumber(String name) {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (name.isEmpty) {
      employeeDataSource = EmployeeDataSource(
          employeeData: employeesDataLst,
          storeDataList: storeDataList,
          userGroupsDataLst: userGroupsDataLst,
          showInactiveEmployees: showInactiveEmployees);
      setState(() {});
      return;
    }

    for (var ud in employeesDataLst) {
      // String nam =
      //     '${ud.empBasicInfoData.firstName.toLowerCase()} ${ud.empBasicInfoData.lastName.toLowerCase()}';
      if (ud.empDocumentDataLst.any((d) =>
          d.documentName == "NATIONAL /RESIDENT ID" &&
          d.documentNumber != null &&
          d.documentNumber!.contains(name))) {
        filteredEmployeesDataLst.add(ud);
      }
    }
    employeeDataSource = EmployeeDataSource(
        employeeData: filteredEmployeesDataLst,
        storeDataList: storeDataList,
        userGroupsDataLst: userGroupsDataLst,
        showInactiveEmployees: showInactiveEmployees);
    setState(() {});
  }

  filterAccordingSelectedDate() {
    List<EmployeeData>? filteredEmployeesDataLst = [];
    if (rangeStartDate != null && rangeEndDate != null) {
      for (var emp in employeesDataLst) {
        DateTime createdDate = DateTime.parse(emp.empBasicInfoData.createdDate);
        DateTime tmp =
            DateTime(createdDate.year, createdDate.month, createdDate.day);
        if (tmp.compareTo(rangeStartDate!) != -1 &&
            (tmp.compareTo(rangeEndDate!) != 1)) {
          filteredEmployeesDataLst.add(emp);
        }
      }
    } else if (rangeStartDate != null) {
      var res = employeesDataLst.where((e) =>
          DateTime.parse(e.empBasicInfoData.createdDate).day ==
              rangeStartDate!.day &&
          DateTime.parse(e.empBasicInfoData.createdDate).month ==
              rangeStartDate!.month &&
          DateTime.parse(e.empBasicInfoData.createdDate).year ==
              rangeStartDate!.year);

      filteredEmployeesDataLst = res.toList();
    }

    employeeDataSource = EmployeeDataSource(
        employeeData: filteredEmployeesDataLst,
        storeDataList: storeDataList,
        userGroupsDataLst: userGroupsDataLst,
        showInactiveEmployees: showInactiveEmployees);
    rangeStartDate = null;
    rangeEndDate = null;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return CustomNavBar(
      pageName: 'Employee',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Container(
            color: homeBgColor,
            child: Container(
              color: homeBgColor,
              child: Row(
                children: [
                  Container(
                    color: const Color.fromARGB(255, 43, 43, 43),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 0,
                        ),
                        SideMenuButton(
                          label: 'Back',
                          iconPath: 'assets/icons/back.png',
                          buttonFunction: () {
                            Navigator.pop(context);
                          },
                        ),
                        SideMenuButton(
                          label: 'Create',
                          iconPath: 'assets/icons/plus.png',
                          buttonFunction: () async {
                            if (!loading) {
                              bool? res = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          CreateEditEmployeesPage(
                                            userGroupsDataLst:
                                                userGroupsDataLst,
                                            empLstData: employeesDataLst,
                                            userData: widget.userData,
                                          )));

                              if (res != null && res) {
                                setState(() {
                                  loading = true;
                                });
                                hiveFetchData();
                              }
                            }
                          },
                        ),
                        SideMenuButton(
                          label: 'Edit',
                          enable: dataGridController.selectedRow != null,
                          iconPath: 'assets/icons/edit.png',
                          buttonFunction: () async {
                            if (dataGridController.selectedRow != null) {
                              if (!loading) {
                                var id = '';

                                for (var c in dataGridController.selectedRow!
                                    .getCells()) {
                                  if (c.columnName == 'id') {
                                    id = c.value;
                                  }
                                }

                                bool? res = await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            CreateEditEmployeesPage(
                                              userGroupsDataLst:
                                                  userGroupsDataLst,
                                              empLstData: employeesDataLst,
                                              selectedRowData: employeesDataLst
                                                  .where((e) =>
                                                      e.empBasicInfoData
                                                          .employeeId ==
                                                      id)
                                                  .first,
                                              userData: widget.userData,
                                              edit: true,
                                            )));
                                if (res != null && res) {
                                  setState(() {
                                    loading = true;
                                  });
                                  hiveFetchData();
                                }
                              }
                            }
                          },
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        SideMenuButton(
                          label: 'Refresh',
                          iconPath: 'assets/icons/refresh.png',
                          buttonFunction: () async {
                            if (!loading) {
                              setState(() {
                                loading = true;
                              });

                              await hiveFetchData();
                            }
                          },
                        ),
                        SideMenuButton(
                          label: 'Date Range',
                          iconPath: 'assets/icons/date.png',
                          buttonFunction: () {
                            showDialog(
                                context: context,
                                builder: (context) {
                                  return Dialog(
                                    child: SizedBox(
                                      width: 400,
                                      height: 380,
                                      child: SfDateRangePicker(
                                          onSelectionChanged:
                                              (DateRangePickerSelectionChangedArgs
                                                  args) {
                                            if (args.value is PickerDateRange) {
                                              rangeStartDate =
                                                  args.value.startDate;
                                              rangeEndDate = args.value.endDate;
                                              setState(() {});
                                            }
                                          },
                                          onCancel: () {
                                            Navigator.pop(context);
                                          },
                                          onSubmit: (var p0) {
                                            filterAccordingSelectedDate();
                                            Navigator.pop(context);
                                          },
                                          cancelText: 'CANCEL',
                                          confirmText: 'OK',
                                          showTodayButton: false,
                                          showActionButtons: true,
                                          view: DateRangePickerView.month,
                                          selectionMode:
                                              DateRangePickerSelectionMode
                                                  .range),
                                    ),
                                  );
                                });
                          },
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        SideMenuButton(
                          label: showInactiveEmployees
                              ? 'Hide InActive'
                              : 'Show InActive',
                          iconPath: 'assets/icons/refresh.png',
                          buttonFunction: () async {
                            setState(() {
                              showInactiveEmployees = !showInactiveEmployees;
                              employeeDataSource = EmployeeDataSource(
                                  employeeData: employeesDataLst,
                                  storeDataList: storeDataList,
                                  userGroupsDataLst: userGroupsDataLst,
                                  showInactiveEmployees: showInactiveEmployees);
                            });
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    width: 0,
                  ),
                  Expanded(
                    child: Card(
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                width: 0.5, color: Colors.grey),
                            borderRadius: BorderRadius.circular(5)),
                        elevation: 0,
                        color: Colors.white,
                        child: Column(
                          children: [
                            //filter
                            filterWidget(),
                            if (loading) Expanded(child: showLoading()),
                            if (!loading)
                              BitproGridTable(
                                onChangeRefershFunction: () {
                                  setState(() {});
                                },
                                dataGridController: dataGridController,
                                source: employeeDataSource!,
                                allowEditing: false,
                                allowSorting: true,
                                bitproGridColumnModel: _bitproGridColumnModel,
                              ),
                          ],
                        )),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  filterWidget() {
    return FilterContainer(fiterFields: [
      FilterTextField(
        onPressed: () {
          employeeIdController.clear();
          searchEmpId('');
        },
        icon: Icon(
            employeeIdController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: employeeIdController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        controller: employeeIdController,
        hintText: 'Employee ID',
        onChanged: (val) {
          searchEmpId(val);
        },
      ),
      FilterTextField(
        onPressed: () {
          employeeNameController.clear();
          searchEmpId('');
        },
        icon: Icon(
            employeeNameController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: employeeNameController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        controller: employeeNameController,
        hintText: 'Employee Name',
        onChanged: (val) {
          searchEmpName(val);
        },
      ),
      // Container(
      //   width: 200,
      //   height: 32,
      //   decoration: BoxDecoration(
      //       border: Border.all(color: Colors.grey, width: 0.5),
      //       color: const Color.fromARGB(255, 255, 255, 255),
      //       borderRadius: BorderRadius.circular(3)),
      //   padding: const EdgeInsets.only(right: 10, top: 1, bottom: 3),
      //   child: Row(
      //     children: [
      //       const SizedBox(
      //         width: 12,
      //       ),
      //       Icon(
      //         CupertinoIcons.search,
      //         size: 18,
      //         color: Colors.grey[600],
      //       ),
      //       const SizedBox(
      //         width: 10,
      //       ),
      //       Flexible(
      //         child: DropdownButton<String>(
      //           underline: const SizedBox(),
      //           isExpanded: true,
      //           hint: Text(staticTextTranslate('User Role'),
      //               style: TextStyle(
      //                 fontSize: getMediumFontSize + 2,
      //               )),
      //           value: selectedSearchedRole,
      //           items: [
      //                 DropdownMenuItem<String>(
      //                   value: 'All Roles',
      //                   child: Text(staticTextTranslate('All Roles'),
      //                       style: TextStyle(
      //                         fontSize: getMediumFontSize,
      //                       )),
      //                 )
      //               ] +
      //               userGroupsDataLst.map((UserGroupData value) {
      //                 return DropdownMenuItem<String>(
      //                   value: value.name,
      //                   child: Text(staticTextTranslate(value.name),
      //                       style: TextStyle(
      //                         fontSize: getMediumFontSize,
      //                       )),
      //                 );
      //               }).toList(),
      //           onChanged: (val) {
      //             setState(() {
      //               selectedSearchedRole = val;
      //               searchEmpRole(val!);
      //             });
      //           },
      //         ),
      //       ),
      //     ],
      //   ),
      // ),
      Container(
        width: 230,
        height: 32,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.5),
            color: const Color.fromARGB(255, 255, 255, 255),
            borderRadius: BorderRadius.circular(5)),
        padding: const EdgeInsets.only(
          right: 10,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              padding: const EdgeInsets.only(top: 3),
              onPressed: () {
                _roleTypeAheadController.clear();

                searchEmpRole('');
                setState(() {});
              },
              splashRadius: 1,
              icon: Icon(
                  _roleTypeAheadController.text.isEmpty
                      ? CupertinoIcons.search
                      : Icons.clear,
                  size: 18,
                  color: _roleTypeAheadController.text.isEmpty
                      ? Colors.grey[600]
                      : Colors.black),
            ),
            Flexible(
              child: TypeAheadFormField(
                getImmediateSuggestions: false,
                textFieldConfiguration: TextFieldConfiguration(
                  controller: _roleTypeAheadController,
                  decoration: InputDecoration(
                    hintText: staticTextTranslate('User Role'),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                    contentPadding: const EdgeInsets.only(bottom: 16, right: 5),
                    border: InputBorder.none,
                  ),
                ),
                suggestionsCallback: (pattern) {
                  return userGroupsDataLst
                      .where((e) =>
                          e.name.toLowerCase().contains(pattern.toLowerCase()))
                      .toList();
                },
                noItemsFoundBuilder: (context) {
                  return Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(staticTextTranslate('No Items Found!'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                itemBuilder: (context, UserGroupData suggestion) {
                  return ListTile(
                    title: Text(suggestion.name,
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                transitionBuilder: (context, suggestionsBox, controller) {
                  return suggestionsBox;
                },
                onSuggestionSelected: (UserGroupData suggestion) {
                  _roleTypeAheadController.text = suggestion.name;
                  setState(() {
                    searchEmpRole(suggestion.name);
                    setState(() {});
                  });
                },
              ),
            ),
          ],
        ),
      ),
      // Container(
      //   width: 200,
      //   height: 32,
      //   decoration: BoxDecoration(
      //       border: Border.all(color: Colors.grey, width: 0.5),
      //       color: const Color.fromARGB(255, 255, 255, 255),
      //       borderRadius: BorderRadius.circular(3)),
      //   padding: const EdgeInsets.only(right: 10, top: 1, bottom: 3),
      //   child: Row(
      //     children: [
      //       const SizedBox(
      //         width: 12,
      //       ),
      //       Icon(
      //         CupertinoIcons.search,
      //         size: 18,
      //         color: Colors.grey[600],
      //       ),
      //       const SizedBox(
      //         width: 10,
      //       ),
      //       Flexible(
      //         child: DropdownButton<String>(
      //           underline: const SizedBox(),
      //           isExpanded: true,
      //           hint: Text(staticTextTranslate('Assigned Store'),
      //               style: TextStyle(
      //                 fontSize: getMediumFontSize + 2,
      //               )),
      //           value: selectedSearchedStore,
      //           items: [
      //                 DropdownMenuItem<String>(
      //                   value: 'All Stores',
      //                   child: Text(staticTextTranslate('All Stores'),
      //                       style: TextStyle(
      //                         fontSize: getMediumFontSize,
      //                       )),
      //                 )
      //               ] +
      //               storeDataList.map((StoreData value) {
      //                 return DropdownMenuItem<String>(
      //                   value: value.docId,
      //                   child: Text(staticTextTranslate(value.storeName),
      //                       style: TextStyle(
      //                         fontSize: getMediumFontSize,
      //                       )),
      //                 );
      //               }).toList(),
      //           onChanged: (val) {
      //             setState(() {
      //               selectedSearchedStore = val;
      //               searchEmpStore(val!);
      //             });
      //           },
      //         ),
      //       ),
      //     ],
      //   ),
      // ),
      Container(
        width: 230,
        height: 32,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.5),
            color: const Color.fromARGB(255, 255, 255, 255),
            borderRadius: BorderRadius.circular(5)),
        padding: const EdgeInsets.only(
          right: 10,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              padding: const EdgeInsets.only(top: 3),
              onPressed: () {
                _storeTypeAheadController.clear();

                searchEmpStore('');
                setState(() {});
              },
              splashRadius: 1,
              icon: Icon(
                  _storeTypeAheadController.text.isEmpty
                      ? CupertinoIcons.search
                      : Icons.clear,
                  size: 18,
                  color: _storeTypeAheadController.text.isEmpty
                      ? Colors.grey[600]
                      : Colors.black),
            ),
            Flexible(
              child: TypeAheadFormField(
                getImmediateSuggestions: false,
                textFieldConfiguration: TextFieldConfiguration(
                  controller: _storeTypeAheadController,
                  decoration: InputDecoration(
                    hintText: staticTextTranslate('Assigned Store'),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                    contentPadding: const EdgeInsets.only(bottom: 16, right: 5),
                    border: InputBorder.none,
                  ),
                ),
                suggestionsCallback: (pattern) {
                  return storeDataList
                      .where((e) => e.storeName
                          .toLowerCase()
                          .contains(pattern.toLowerCase()))
                      .toList();
                },
                noItemsFoundBuilder: (context) {
                  return Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(staticTextTranslate('No Items Found!'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                itemBuilder: (context, StoreData suggestion) {
                  return ListTile(
                    title: Text(suggestion.storeName,
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                transitionBuilder: (context, suggestionsBox, controller) {
                  return suggestionsBox;
                },
                onSuggestionSelected: (StoreData suggestion) {
                  _storeTypeAheadController.text = suggestion.storeName;
                  setState(() {
                    searchEmpStore(suggestion.docId);
                    setState(() {});
                  });
                },
              ),
            ),
          ],
        ),
      ),
      // Container(
      //   width: 200,
      //   height: 32,
      //   decoration: BoxDecoration(
      //       border: Border.all(color: Colors.grey, width: 0.5),
      //       color: const Color.fromARGB(255, 255, 255, 255),
      //       borderRadius: BorderRadius.circular(3)),
      //   padding: const EdgeInsets.only(right: 10, top: 1, bottom: 3),
      //   child: Row(
      //     children: [
      //       const SizedBox(
      //         width: 12,
      //       ),
      //       Icon(
      //         CupertinoIcons.search,
      //         size: 18,
      //         color: Colors.grey[600],
      //       ),
      //       const SizedBox(
      //         width: 10,
      //       ),
      //       Flexible(
      //         child: DropdownButton<String>(
      //           underline: const SizedBox(),
      //           isExpanded: true,
      //           hint: Text(staticTextTranslate('Sub Name'),
      //               style: TextStyle(
      //                 fontSize: getMediumFontSize + 2,
      //               )),
      //           value: selectedSearchedStoreSubname,
      //           items: [
      //                 DropdownMenuItem<String>(
      //                   value: 'All Sub Name',
      //                   child: Text(staticTextTranslate('All Sub Name'),
      //                       style: TextStyle(
      //                         fontSize: getMediumFontSize,
      //                       )),
      //                 )
      //               ] +
      //               storeDataList
      //                   .where((e) => e.subName.isNotEmpty)
      //                   .toList()
      //                   .map((StoreData value) {
      //                 return DropdownMenuItem<String>(
      //                   value: value.docId,
      //                   child: Text(staticTextTranslate(value.subName),
      //                       style: TextStyle(
      //                         fontSize: getMediumFontSize,
      //                       )),
      //                 );
      //               }).toList(),
      //           onChanged: (val) {
      //             setState(() {
      //               selectedSearchedStoreSubname = val;
      //               searchEmpStoreSubName(val!);
      //             });
      //           },
      //         ),
      //       ),
      //     ],
      //   ),
      // ),
      Container(
        width: 230,
        height: 32,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.5),
            color: const Color.fromARGB(255, 255, 255, 255),
            borderRadius: BorderRadius.circular(5)),
        padding: const EdgeInsets.only(
          right: 10,
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              padding: const EdgeInsets.only(top: 3),
              onPressed: () {
                _subNameTypeAheadController.clear();
                searchEmpStoreSubName('');
                setState(() {});
              },
              splashRadius: 1,
              icon: Icon(
                  _subNameTypeAheadController.text.isEmpty
                      ? CupertinoIcons.search
                      : Icons.clear,
                  size: 18,
                  color: _subNameTypeAheadController.text.isEmpty
                      ? Colors.grey[600]
                      : Colors.black),
            ),
            Flexible(
              child: TypeAheadFormField(
                getImmediateSuggestions: false,
                textFieldConfiguration: TextFieldConfiguration(
                  controller: _subNameTypeAheadController,
                  decoration: InputDecoration(
                    hintText: staticTextTranslate('Sub Name'),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                    contentPadding: const EdgeInsets.only(bottom: 16, right: 5),
                    border: InputBorder.none,
                  ),
                ),
                suggestionsCallback: (pattern) {
                  return storeDataList
                      .where((e) => e.subName.isNotEmpty)
                      .toList()
                      .where((e) => e.subName
                          .toLowerCase()
                          .contains(pattern.toLowerCase()))
                      .toList();
                },
                noItemsFoundBuilder: (context) {
                  return Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Text(staticTextTranslate('No Items Found!'),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                itemBuilder: (context, StoreData suggestion) {
                  return ListTile(
                    title: Text(suggestion.subName,
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                        )),
                  );
                },
                transitionBuilder: (context, suggestionsBox, controller) {
                  return suggestionsBox;
                },
                onSuggestionSelected: (StoreData suggestion) {
                  _subNameTypeAheadController.text = suggestion.storeName;
                  setState(() {
                    searchEmpStoreSubName(suggestion.docId);
                    setState(() {});
                  });
                },
              ),
            ),
          ],
        ),
      ),
      FilterTextField(
        onPressed: () {
          idNumberController.clear();
          searchEmpId('');
        },
        icon: Icon(
            idNumberController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: idNumberController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        controller: idNumberController,
        hintText: 'ID number',
        onChanged: (val) {
          searchIdNumber(val);
        },
      ),
    ]);
  }
}

/// Custom business object class which contains properties to hold the detailed
/// information about the employee which will be rendered in datagrid.
// class Employee {
//   /// Creates the employee class with required details.
//   Employee(
//     this.id,
//     this.name,
//     this.userRole,
//     this.username,
//     this.maxDiscount,
//     this.createdDate,
//     this.createdBy,
//   );

//   /// Id of an employee.
//   final int id;

//   /// Name of an employee.
//   final String name;

//   /// Designation of an employee.
//   final String userRole;

//   /// Salary of an employee.
//   final String username;
//   final String maxDiscount;
//   final String createdDate;
//   final String createdBy;
// }

/// An object to set the employee collection data source to the datagrid. This
/// is used to map the employee data to the datagrid widget.
class EmployeeDataSource extends DataGridSource {
  /// Creates the employee data source class with required details.
  EmployeeDataSource(
      {required List<EmployeeData> employeeData,
      required List<UserGroupData> userGroupsDataLst,
      required List<StoreData> storeDataList,
      required bool showInactiveEmployees}) {
    _employeeData = employeeData
        .where((e) =>
            (showInactiveEmployees == false &&
                e.empBasicInfoData.employeedStatus == 'active') ||
            (showInactiveEmployees == true &&
                e.empBasicInfoData.employeedStatus != 'active'))
        .toList()
        .map<DataGridRow>((EmployeeData e) {
      String userGroupName = '';
      String storeName = '';

      int i = userGroupsDataLst
          .indexWhere((u) => u.name == e.empWorkAndRolesData.userGroupId);
      int j = storeDataList.indexWhere(
          (u) => u.docId == e.empWorkAndRolesData.assignedStoreDocId);

      if (i != -1) {
        userGroupName = userGroupsDataLst[i].name;
      }
      if (j != -1) {
        storeName = storeDataList[j].storeName;
      }
      return DataGridRow(cells: [
        DataGridCell<int>(
            columnName: 'serialNumberForStyleColor',
            value: employeeData.indexOf(e) + 1),
        DataGridCell<String>(
            columnName: 'id', value: e.empBasicInfoData.employeeId),
        DataGridCell<String>(
            columnName: 'name',
            value:
                '${e.empBasicInfoData.firstName} ${e.empBasicInfoData.lastName}'),
        DataGridCell<String>(columnName: 'role', value: userGroupName),
        DataGridCell<String>(
            columnName: 'username', value: e.empBasicInfoData.username),
        DataGridCell<String>(
            columnName: 'discount',
            value: e.empWorkAndRolesData.discountPercentage ?? '0'),
        DataGridCell<String>(columnName: 'assigned_store', value: storeName),
        DataGridCell<String>(
            columnName: 'active', value: e.empBasicInfoData.employeedStatus),
        DataGridCell<String>(
            columnName: 'department',
            value: e.empWorkAndRolesData.department ?? ''),
        DataGridCell<String>(
            columnName: 'title', value: e.empWorkAndRolesData.title ?? ""),
        DataGridCell<String>(
            columnName: 'position',
            value: e.empWorkAndRolesData.position ?? ''),
        DataGridCell<String>(
            columnName: 'created date',
            value: DateFormat.yMd()
                .add_jm()
                .format(DateTime.parse(e.empBasicInfoData.createdDate))),
        DataGridCell<String>(
            columnName: 'created by', value: e.empBasicInfoData.createdBy),
      ]);
    }).toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        color: row.getCells()[0].value.isEven
            ? const Color(0xffF1F1F1)
            : Colors.white,
        cells: row.getCells().map<Widget>((e) {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(2.0),
            child: Text(
              overflow: TextOverflow.ellipsis,
              e.value.toString(),
              style: GoogleFonts.roboto(
                  fontSize: getMediumFontSize, fontWeight: FontWeight.w500),
            ),
          );
        }).toList());
  }
}
