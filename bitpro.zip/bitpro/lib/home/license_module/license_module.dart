import 'dart:convert';
import 'dart:io';
import 'package:bitpro_hive/model/settings/license_setting_data.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_settings_db_service.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../shared/global_variables/static_text_translate.dart';
import '../../shared/toast.dart';

class LicenseModule extends StatefulWidget {
  final DateTime? licenseExpiredDate;
  final bool showDifferentDeviceKey;
  const LicenseModule(
      {super.key,
      this.showDifferentDeviceKey = false,
      this.licenseExpiredDate});

  @override
  State<LicenseModule> createState() => _LicenseModuleState();
}

// const String key1 = 'mxuTkzdFyY4O3HcHyDNI'; // - for 30 days
// const String key2 = 'YdoYt2AQD01D0gqJEqkW'; // - for 365 days

class _LicenseModuleState extends State<LicenseModule> {
  String licenseKey = '';
  String licenseAuth = '';

  bool showLicenseKeyError = false;
  bool showLicenseAuthError = false;

  bool isLoading = false;

  @override
  Widget build(BuildContext context) {
    if (isLoading) return showLoading();
    return Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
            child: Container(
                color: Color.fromARGB(255, 19, 56, 73),
                // decoration: const BoxDecoration(
                //       image: DecorationImage(
                //           image: AssetImage('assets/bcc.jpg'),
                //           fit: BoxFit.fill,
                //           opacity: 50),
                //     ),
                padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
                child: Center(
                  child: SizedBox(
                    width: 500,
                    height: 650,
                    child: Card(
                      color: Color.fromARGB(255, 231, 236, 243),
                      elevation: 10,
                      child: Container(
                        padding: EdgeInsets.all(45),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                'Bitpro License',
                                style: TextStyle(
                                    fontSize: getExtraLargeFontSize + 12,
                                    fontWeight: FontWeight.w500,
                                    color:
                                        const Color.fromARGB(255, 0, 62, 112)),
                              ),
                              const SizedBox(
                                height: 5,
                              ),
                              Text(
                                'Your License has been expired! please contact admin',
                                style: TextStyle(
                                    fontSize: getExtraLargeFontSize,
                                    color: Colors.red),
                              ),
                              Text(
                                'or bitpro support to get Licencse.',
                                style: TextStyle(
                                    fontSize: getExtraLargeFontSize,
                                    color: Colors.red),
                              ),
                              SizedBox(
                                height: 30,
                              ),
                              Container(
                                width: 360,
                                child: Column(
                                  children: [
                                    SizedBox(
                                      height: 35,
                                      child: TextFormField(
                                        obscureText: true,
                                        decoration: const InputDecoration(
                                          filled: true,
                                          fillColor: Colors.white,
                                          contentPadding: EdgeInsets.all(5),
                                          hintText: 'Key',
                                          border: OutlineInputBorder(
                                              borderRadius: BorderRadius.all(
                                                Radius.circular(2),
                                              ),
                                              borderSide:
                                                  BorderSide(width: 0.2)),
                                        ),
                                        initialValue: licenseKey,
                                        onChanged: (val) {
                                          setState(() {
                                            licenseKey = val;
                                            if (showLicenseKeyError) {
                                              showLicenseKeyError = false;
                                            }
                                          });
                                        },
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    if (showLicenseKeyError)
                                      Align(
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          'Please enter a valid license key',
                                          style: TextStyle(
                                              fontSize: getSmallFontSize,
                                              color: Colors.red[800]),
                                        ),
                                      ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    SizedBox(
                                      height: 35,
                                      child: TextFormField(
                                        obscureText: true,
                                        decoration: const InputDecoration(
                                            filled: true,
                                            fillColor: Colors.white,
                                            contentPadding: EdgeInsets.all(5),
                                            hintText: 'Auth',
                                            border: OutlineInputBorder(
                                                borderRadius: BorderRadius.all(
                                                  Radius.circular(2),
                                                ),
                                                borderSide:
                                                    BorderSide(width: 0.2))),
                                        initialValue: licenseAuth,
                                        onChanged: (val) {
                                          setState(() {
                                            licenseAuth = val;
                                            if (showLicenseAuthError) {
                                              showLicenseAuthError = false;
                                            }
                                          });
                                        },
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    if (showLicenseAuthError)
                                      Align(
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          'Please enter a valid license auth',
                                          style: TextStyle(
                                              fontSize: getSmallFontSize,
                                              color: Colors.red[800]),
                                        ),
                                      ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                  ],
                                ),
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  OnPageGreyButton(
                                    width: 175,
                                    label: 'Cancel',
                                    onPressed: () {
                                      exit(0);
                                    },
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  OnPageButton(
                                      width: 175,
                                      label: 'Submit',
                                      onPressed: () async {
                                        setState(() {
                                          isLoading = true;
                                        });
                                        Codec<String, String> stringToBase64 =
                                            utf8.fuse(base64);
                                        bool callApi = true;
                                        int? noOfDays;
                                        DeviceInfoPlugin deviceInfo =
                                            DeviceInfoPlugin();
                                        WindowsDeviceInfo win =
                                            await deviceInfo.windowsInfo;
                                        if (licenseKey.isEmpty) {
                                          showLicenseKeyError = true;
                                          callApi = false;
                                        } else {
                                          //key
                                          try {
                                            String keysDecoded = stringToBase64
                                                .decode(licenseKey); //MzY1

                                            if (win.productId != keysDecoded) {
                                              showLicenseKeyError = true;
                                              callApi = false;
                                            }
                                          } catch (e) {
                                            showLicenseKeyError = true;
                                            callApi = false;
                                          }
                                        }

                                        if (licenseAuth.isEmpty) {
                                          showLicenseAuthError = true;
                                          callApi = false;
                                        } else {
                                          //auth
                                          try {
                                            String decoded = stringToBase64
                                                .decode(licenseAuth);

                                            noOfDays = int.tryParse(decoded);

                                            if (noOfDays == null) {
                                              showLicenseAuthError = true;
                                              callApi = false;
                                            }
                                          } catch (e) {
                                            showLicenseAuthError = true;
                                            callApi = false;
                                          }
                                        }

                                      

                                        if (callApi && noOfDays != null) {
                                          DateTime d = DateTime.now();
                                          await HiveSettingsDbService()
                                              .addUpdateLicenseSettingsData(
                                                  licenseSettingData:
                                                      LicenseSettingData(
                                                          key: licenseKey,
                                                          auth: licenseAuth,
                                                          expiry_date: d.add(
                                                              Duration(
                                                                  days:
                                                                      noOfDays)),
                                                          windownsProductId:
                                                              win.productId,
                                                          showLicenseAuthError:
                                                              showLicenseAuthError,
                                                          showLicenseKeyError:
                                                              showLicenseKeyError));
                                        } else {
                                          setState(() {
                                            isLoading = false;
                                          });
                                        }
                                      },
                                      icon: Iconsax.arrow_right_1,
                                      backgroundColor: licenseKey.isEmpty
                                          ? Colors.grey
                                          : Colors.transparent),
                                ],
                              ),
                              const SizedBox(
                                height: 30,
                              ),
                              if (widget.licenseExpiredDate != null)
                                Align(
                                  alignment: Alignment.center,
                                  child: Text(
                                    widget.showDifferentDeviceKey
                                        ? "Please enter your license. Didn't found any license key, connected to this device."
                                        : 'Your Bitpro License key is expired on ${DateFormat('MM-dd-yyyy').format(widget.licenseExpiredDate!)}. Please renew your license.',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: getSmallFontSize,
                                        color: Colors.red[800]),
                                  ),
                                ),
                              TextButton(
                                  onPressed: () async {
                                    DeviceInfoPlugin deviceInfo =
                                        DeviceInfoPlugin();

                                    WindowsDeviceInfo win =
                                        await deviceInfo.windowsInfo;

                                    await Clipboard.setData(
                                        ClipboardData(text: win.productId));
                                    showToast(staticTextTranslate('Copied!'),
                                        context);
                                  },
                                  child: Text(
                                    staticTextTranslate('Copy Device Id'),
                                    style: TextStyle(
                                        fontSize: getMediumFontSize,
                                        color: Colors.grey),
                                  )),
                              const SizedBox(
                                height: 20,
                              ),
                              Icon(Iconsax.message),
                              SizedBox(
                                height: 20,
                              ),
                              Text(
                                'Email: support@bitproglobal.com',
                                style: TextStyle(
                                  fontSize: getExtraLargeFontSize,
                                ),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Text('Whatsapp: +966 5421 21061'),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                '+966570624971 | +919019567513',
                                style: TextStyle(),
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              TextButton(
                                  onPressed: () async {
                                    const url =
                                        'https://www.bitproglobal.com/contact';
                                    if (await canLaunch(url)) {
                                      await launch(url);
                                    } else {
                                      throw 'Could not launch $url';
                                    }
                                  },
                                  child: Text('www.bitproglobal.com'))
                            ]),
                      ),
                    ),
                  ),
                ))));
  }
}
