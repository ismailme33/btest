import 'package:bitpro_hive/home/01_dashboard/dashboard_stats/dashboard_stats.dart';
import 'package:bitpro_hive/home/01_dashboard/payment_method/payment_method_page.dart';
import 'package:bitpro_hive/home/01_dashboard/top_selling_department/top_selling_department.dart';
import 'package:bitpro_hive/home/01_dashboard/weekly_stats/weekly_stats.dart';
import 'package:bitpro_hive/model/department_data.dart';
import 'package:bitpro_hive/model/inventory_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/model/voucher/db_voucher_data.dart';
import 'package:bitpro_hive/services/hive/hive_merchandise_db_service/department_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_merchandise_db_service/inventory_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_receipt_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_voucher_db_service/hive_voucher_db_service.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List<StoreData> allStoreDataLst = [];
  List<ReceiptOrQuotationData> allReceiptDataLst = [];
  List<DbVoucherData> allVoucherDataLst = [];
  List<DepartmentData> allDepartmentDataLst = [];
  List<InventoryData> allInventoryDataLst = [];
  bool isLoading = true;
  @override
  void initState() {
    initData();

    super.initState();
  }

  initData() async {
    allStoreDataLst = await HiveStoreDbService().fetchAllStoresData();
    allReceiptDataLst = await HiveReceiptDbService().fetchAllReceiptData();
    allVoucherDataLst = await HiveVoucherDbService().fetchAllVoucherData();
    allDepartmentDataLst =
        await HiveDepartmentDbService().fetchAllDepartmentsData();
    allInventoryDataLst =
        await HiveInventoryDbService().fetchAllInventoryData();
    isLoading = false;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return showLoading();
    return SingleChildScrollView(
      child: Container(
        margin: const EdgeInsets.only(right: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DashboardStats(
              allStoreDataLst: allStoreDataLst,
              allReceiptDataLst: allReceiptDataLst,
              allVoucherDataLst: allVoucherDataLst,
            ),
            const SizedBox(
              height: 5,
            ),
            SizedBox(
              width: 1010,
              child: Row(
                children: [
                  Expanded(
                      child: PaymentMethodPage(
                    allReceiptDataLst: allReceiptDataLst,
                  )),
                  const SizedBox(
                    width: 5,
                  ),
                  Expanded(
                      child: TopSellingDepartmentStats(
                    allInventoryDataLst: allInventoryDataLst,
                    allDepartmentDataLst: allDepartmentDataLst,
                    allReceiptDataLst: allReceiptDataLst,
                  )),
                ],
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            WeeklyStats(
              allStoreDataLst: allStoreDataLst,
              allReceiptDataLst: allReceiptDataLst,
            ),
            const SizedBox(
              height: 20,
            )
          ],
        ),
      ),
    );
  }
}
