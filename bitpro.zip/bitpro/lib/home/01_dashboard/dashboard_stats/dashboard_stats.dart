import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/model/voucher/db_voucher_data.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/string_related/get_today_date.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

class DashboardStats extends StatefulWidget {
  final List<StoreData> allStoreDataLst;
  final List<ReceiptOrQuotationData> allReceiptDataLst;
  final List<DbVoucherData> allVoucherDataLst;
  const DashboardStats(
      {super.key,
      required this.allStoreDataLst,
      required this.allReceiptDataLst,
      required this.allVoucherDataLst});

  @override
  State<DashboardStats> createState() => _DashboardStatsState();
}

class _DashboardStatsState extends State<DashboardStats> {
  //Dashboard selection
  String selectedDashboardStore = 'All Stores';
  late DateTime rangeStartDate;
  DateTime? rangeEndDate;

  List<ReceiptOrQuotationData> filteredReceiptDataLst = [];
  List<DbVoucherData> filteredVoucherDataLst = [];
  @override
  void initState() {
    rangeStartDate = getTodayDate();
    initData('All Stores');
    super.initState();
  }

  initData(
    String selectedStoreDocId,
  ) {
    //receipt filtering
    List<ReceiptOrQuotationData> filterLst1 = selectedStoreDocId == 'All Stores'
        ? widget.allReceiptDataLst
        : widget.allReceiptDataLst
            .where((e) =>
                e.receiptBasicInfo!.selectedStoreDocId == selectedStoreDocId)
            .toList();

    filteredReceiptDataLst = filterLst1.where((element) {
      if (rangeEndDate != null) {
        DateTime d = DateTime(element.createdDate.year,
            element.createdDate.month, element.createdDate.day);

        if (d.compareTo(rangeStartDate) != -1 &&
            d.compareTo(rangeEndDate!) != 1) {
          return true;
        }
        return false;
      }
      return element.createdDate.year == rangeStartDate.year &&
          element.createdDate.month == rangeStartDate.month &&
          element.createdDate.day == rangeStartDate.day;
    }).toList();

    //voucher filtering
    List<DbVoucherData> filterLst2 = selectedStoreDocId == 'All Stores'
        ? widget.allVoucherDataLst
        : widget.allVoucherDataLst
            .where((e) => e.selectedStoreDocId == selectedStoreDocId)
            .toList();

    filteredVoucherDataLst = filterLst2.where((element) {
      if (rangeEndDate != null) {
        DateTime d = DateTime(element.createdDate.year,
            element.createdDate.month, element.createdDate.day);

        if (d.compareTo(rangeStartDate) != -1 &&
            d.compareTo(rangeEndDate!) != 1) {
          return true;
        }
        return false;
      }
      return element.createdDate.year == rangeStartDate.year &&
          element.createdDate.month == rangeStartDate.month &&
          element.createdDate.day == rangeStartDate.day;
    }).toList();
    setState(() {});
  }

  double getTotalSales() {
    double value = 0;

    for (var r in filteredReceiptDataLst) {
      if (r.receiptBasicInfo!.receiptType == 'Regular') {
        value += double.tryParse(r.lineItemTotalData.receiptTotal) ?? 0;
      } else if (r.receiptBasicInfo!.receiptType == 'Return') {
        value -= double.tryParse(r.lineItemTotalData.receiptTotal) ?? 0;
      }
    }
    return value;
  }

  double getTotalSalesQty() {
    double value = 0;

    for (var r in filteredReceiptDataLst) {
      if (r.receiptBasicInfo!.receiptType == 'Regular') {
        value += double.tryParse(r.lineItemTotalData.totalQty) ?? 0;
      } else if (r.receiptBasicInfo!.receiptType == 'Return') {
        value -= double.tryParse(r.lineItemTotalData.totalQty) ?? 0;
      }
    }
    return value;
  }

  double getTotalPurchase() {
    double value = 0;

    for (var r in filteredVoucherDataLst) {
      if (r.voucherType == 'Regular') {
        value += double.tryParse(r.voucherTotal) ?? 0;
      } else if (r.voucherType == 'Return') {
        value -= double.tryParse(r.voucherTotal) ?? 0;
      }
    }
    return value;
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 1010,
      child: Column(
        children: [
          Container(
            height: 40,
            decoration: const BoxDecoration(
                color: Color(0xff2b2b2b),
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(4), topRight: Radius.circular(4))),
            width: double.maxFinite,
            child: Row(
              children: [
                const SizedBox(
                  width: 14,
                ),
                Text(
                  staticTextTranslate('Dashboard'),
                  style: GoogleFonts.roboto(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xffd4d4d4)),
                ),
                const Expanded(
                    child: SizedBox(
                  width: 5,
                )),
                Container(
                  width: 180,
                  height: 23,
                  decoration: BoxDecoration(
                      color: const Color(0xff9e9e9e),
                      borderRadius: BorderRadius.circular(4)),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: DropdownButton<String>(
                    isExpanded: true,
                    underline: const SizedBox(),
                    value: selectedDashboardStore,
                    items: [
                          DropdownMenuItem<String>(
                            value: 'All Stores',
                            child: Text(
                              staticTextTranslate('All Stores'),
                              style: GoogleFonts.roboto(fontSize: 14),
                            ),
                          )
                        ] +
                        widget.allStoreDataLst.map((StoreData value) {
                          return DropdownMenuItem<String>(
                            value: value.docId,
                            child: Text(
                              value.storeName,
                              style: GoogleFonts.roboto(fontSize: 14),
                            ),
                          );
                        }).toList(),
                    onChanged: (v) {
                      if (v != null) {
                        selectedDashboardStore = v;
                        initData(selectedDashboardStore);
                        setState(() {});
                      }
                    },
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                GestureDetector(
                  onTap: () async {
                    showDialog(
                        context: context,
                        builder: (context) {
                          return Dialog(
                            child: SizedBox(
                              width: 400,
                              height: 380,
                              child: SfDateRangePicker(
                                  initialSelectedRange: PickerDateRange(
                                      rangeStartDate, rangeEndDate),
                                  // initialSelectedDate: ,
                                  initialDisplayDate: rangeStartDate,
                                  onSelectionChanged:
                                      (DateRangePickerSelectionChangedArgs
                                          args) {
                                    if (args.value is PickerDateRange) {
                                      rangeStartDate = args.value.startDate;
                                      rangeEndDate = args.value.endDate;
                                      setState(() {});
                                    }
                                  },
                                  onCancel: () {
                                    Navigator.pop(context);
                                  },
                                  onSubmit: (var p0) {
                                    initData(selectedDashboardStore);
                                    Navigator.pop(context);
                                  },
                                  cancelText: 'CANCEL',
                                  confirmText: 'OK',
                                  showTodayButton: true,
                                  showActionButtons: true,
                                  view: DateRangePickerView.month,
                                  selectionMode:
                                      DateRangePickerSelectionMode.range),
                            ),
                          );
                        });
                  },
                  child: Container(
                    width: 215,
                    height: 23,
                    decoration: BoxDecoration(
                        color: const Color(0xff9e9e9e),
                        borderRadius: BorderRadius.circular(4)),
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    alignment: Alignment.centerLeft,
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            rangeStartDate == getTodayDate()
                                ? staticTextTranslate('Today')
                                : rangeEndDate != null
                                    ? '${DateFormat('MMM dd, yyyy').format(rangeStartDate)} - ${DateFormat('MMM dd, yyyy').format(rangeEndDate!)}'
                                    : DateFormat('MMM dd, yyyy')
                                        .format(rangeStartDate),
                            style: GoogleFonts.roboto(fontSize: 14),
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        const Icon(Icons.arrow_drop_down_sharp)
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 1,
          ),
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 120,
                  decoration: const BoxDecoration(
                      color: Color(0xff2b2b2b),
                      borderRadius:
                          BorderRadius.only(bottomLeft: Radius.circular(4))),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Container(
                          padding: const EdgeInsets.all(5),
                          color: Colors.blue[600],
                          child: const Icon(
                            Iconsax.receipt,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const Expanded(
                          child: SizedBox(
                        height: 10,
                      )),
                      Text(
                        staticTextTranslate("Total Sales"),
                        style: GoogleFonts.roboto(
                            fontSize: 14, color: const Color(0xffd4d4d4)),
                      ),
                      Row(
                        children: [
                          SizedBox(
                              width: 19,
                              height: 19,
                              child: SvgPicture.asset(
                                'assets/sar.svg',
                                color: Colors.white,
                              )),
                          Text(
                            " ${getTotalSales().toStringAsFixed(digit)}",
                            style: GoogleFonts.roboto(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: const Color(0xffd4d4d4),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(
                width: 1,
              ),
              Expanded(
                child: Container(
                  height: 120,
                  decoration: const BoxDecoration(
                    color: Color(0xff2b2b2b),
                  ),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Container(
                          padding: const EdgeInsets.all(5),
                          color: Colors.blue[600],
                          child: const Icon(
                            Iconsax.computing,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const Expanded(
                          child: SizedBox(
                        height: 10,
                      )),
                      Text(
                        staticTextTranslate("Total Qty Sold"),
                        style: GoogleFonts.roboto(
                            fontSize: 14, color: const Color(0xffd4d4d4)),
                      ),
                      Text(
                        getTotalSalesQty().toStringAsFixed(qtydigit),
                        style: GoogleFonts.roboto(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: const Color(0xffd4d4d4),
                        ),
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(
                width: 1,
              ),
              Expanded(
                child: Container(
                  height: 120,
                  decoration: const BoxDecoration(
                      color: Color(0xff2b2b2b),
                      borderRadius:
                          BorderRadius.only(bottomRight: Radius.circular(4))),
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(100),
                        child: Container(
                          padding: const EdgeInsets.all(5),
                          color: Colors.blue[600],
                          child: const Icon(
                            Iconsax.note,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                      ),
                      const Expanded(
                          child: SizedBox(
                        height: 10,
                      )),
                      Text(
                        staticTextTranslate("Total Purchase"),
                        style: GoogleFonts.roboto(
                            fontSize: 14, color: const Color(0xffd4d4d4)),
                      ),
                      Row(
                        children: [
                          SizedBox(
                              width: 19,
                              height: 19,
                              child: SvgPicture.asset(
                                'assets/sar.svg',
                                color: Colors.white,
                              )),
                          Text(
                            " ${getTotalPurchase().toStringAsFixed(digit)}",
                            style: GoogleFonts.roboto(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: const Color(0xffd4d4d4),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
