import 'package:bitpro_hive/home/01_dashboard/weekly_stats/bar_chart.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/string_related/get_today_date.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class WeeklyStats extends StatefulWidget {
  final List<StoreData> allStoreDataLst;
  final List<ReceiptOrQuotationData> allReceiptDataLst;
  const WeeklyStats(
      {super.key,
      required this.allStoreDataLst,
      required this.allReceiptDataLst});

  @override
  State<WeeklyStats> createState() => _WeeklyStatsState();
}

class _WeeklyStatsState extends State<WeeklyStats> {
  //Dashboard selection
  String selectedStoreDocId = 'All Stores';
  String selectedWeek = 'Week';
  late DateTime selectedDatetime;

  late String selectedYear;

  @override
  void initState() {
    selectedDatetime = getTodayDate();
    selectedYear = getTodayDate().year.toString();
    initData();
    super.initState();
  }

  late List<SalesData> chartData;

  initData() {
    filterData();
    setState(() {});
  }

  filterData() {
    //receipt filtering
    List<ReceiptOrQuotationData> filterLst1 = selectedStoreDocId == 'All Stores'
        ? widget.allReceiptDataLst
        : widget.allReceiptDataLst
            .where((e) =>
                e.isReceiptType() &&
                e.receiptBasicInfo!.selectedStoreDocId == selectedStoreDocId)
            .toList();

    if (selectedWeek == 'Week') {
      DateTime now = selectedDatetime;

      int daysOfWeek = now.weekday - 1;
      DateTime firstDay = DateTime(now.year, now.month, now.day - daysOfWeek);

      chartData = [
        SalesData('Mon', getOneDateSalesValue(filterLst1, firstDay)),
        SalesData(
            'Tue',
            getOneDateSalesValue(
                filterLst1, firstDay.add(const Duration(days: 1)))),
        SalesData(
            'Wed',
            getOneDateSalesValue(
                filterLst1, firstDay.add(const Duration(days: 2)))),
        SalesData(
            'Thu',
            getOneDateSalesValue(
                filterLst1, firstDay.add(const Duration(days: 3)))),
        SalesData(
            'Fri',
            getOneDateSalesValue(
                filterLst1, firstDay.add(const Duration(days: 4)))),
        SalesData(
            'Sat',
            getOneDateSalesValue(
                filterLst1, firstDay.add(const Duration(days: 5)))),
        SalesData(
            'Sun',
            getOneDateSalesValue(
                filterLst1, firstDay.add(const Duration(days: 6)))),
      ];
    } else {
      chartData = [
        SalesData('Jan', getOneMonthSalesValue(filterLst1, 1)),
        SalesData('Feb', getOneMonthSalesValue(filterLst1, 2)),
        SalesData('Mar', getOneMonthSalesValue(filterLst1, 3)),
        SalesData('Apr', getOneMonthSalesValue(filterLst1, 4)),
        SalesData('May', getOneMonthSalesValue(filterLst1, 5)),
        SalesData('Jun', getOneMonthSalesValue(filterLst1, 6)),
        SalesData('Jul', getOneMonthSalesValue(filterLst1, 7)),
        SalesData('Aug', getOneMonthSalesValue(filterLst1, 8)),
        SalesData('Sep', getOneMonthSalesValue(filterLst1, 9)),
        SalesData('Oct', getOneMonthSalesValue(filterLst1, 10)),
        SalesData('Nov', getOneMonthSalesValue(filterLst1, 11)),
        SalesData('Dec', getOneMonthSalesValue(filterLst1, 12)),
      ];
    }
  }

  double getOneMonthSalesValue(
      List<ReceiptOrQuotationData> filterLst1, int selectedMonth) {
    List<ReceiptOrQuotationData> lst = filterLst1
        .where((element) =>
            element.createdDate.year == int.parse(selectedYear) &&
            element.createdDate.month == selectedMonth)
        .toList();

    double amt = 0;

    for (var r in lst) {
      if (r.isReceiptType()) {
        if (r.receiptBasicInfo!.receiptType == 'Regular') {
          amt += double.tryParse(r.lineItemTotalData.receiptTotal) ?? 0;
        } else if (r.receiptBasicInfo!.receiptType == 'Return') {
          amt -= double.tryParse(r.lineItemTotalData.receiptTotal) ?? 0;
        }
      }
    }

    return amt;
  }

  double getOneDateSalesValue(
      List<ReceiptOrQuotationData> filterLst1, DateTime currentDate) {
    List<ReceiptOrQuotationData> lst = filterLst1
        .where((element) =>
            element.createdDate.year == currentDate.year &&
            element.createdDate.month == currentDate.month &&
            element.createdDate.day == currentDate.day)
        .toList();

    double amt = 0;

    for (var r in lst) {
      if (r.isReceiptType()) {
        if (r.receiptBasicInfo!.receiptType == 'Regular') {
          amt += double.tryParse(r.lineItemTotalData.receiptTotal) ?? 0;
        } else if (r.receiptBasicInfo!.receiptType == 'Return') {
          amt -= double.tryParse(r.lineItemTotalData.receiptTotal) ?? 0;
        }
      }
    }

    return amt;
  }

  String getSelectedWeekDate() {
    DateTime now = selectedDatetime;

    int daysOfWeek = now.weekday - 1;
    DateTime firstDay = DateTime(now.year, now.month, now.day - daysOfWeek);

    return '${DateFormat('MMM dd, yyyy').format(firstDay)} - ${DateFormat('MMM dd, yyyy').format(firstDay.add(const Duration(days: 6)))}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 300,
      width: 1010,
      decoration: const BoxDecoration(
          color: Color(0xff2b2b2b),
          borderRadius: BorderRadius.all(Radius.circular(4))),
      child: SizedBox(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Row(
              children: [
                const SizedBox(
                  width: 14,
                ),
                Text(
                  selectedWeek == 'Week'
                      ? staticTextTranslate('Weekly Sales')
                      : staticTextTranslate('Monthly Sales'),
                  style: GoogleFonts.roboto(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: const Color(0xffd4d4d4)),
                ),
                const Expanded(
                    child: SizedBox(
                  width: 10,
                )),
                Container(
                  width: 180,
                  height: 23,
                  decoration: BoxDecoration(
                      color: const Color(0xff9e9e9e),
                      borderRadius: BorderRadius.circular(4)),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: DropdownButton<String>(
                    isExpanded: true,
                    underline: const SizedBox(),
                    value: selectedWeek,
                    items: ['Week', 'Month'].map((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          staticTextTranslate(value),
                          style: GoogleFonts.roboto(fontSize: 14),
                        ),
                      );
                    }).toList(),
                    onChanged: (v) {
                      if (v != null) {
                        selectedWeek = v;
                        filterData();

                        setState(() {});
                      }
                    },
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Container(
                  width: 180,
                  height: 23,
                  decoration: BoxDecoration(
                      color: const Color(0xff9e9e9e),
                      borderRadius: BorderRadius.circular(4)),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: DropdownButton<String>(
                    isExpanded: true,
                    underline: const SizedBox(),
                    value: selectedStoreDocId,
                    items: [
                          DropdownMenuItem<String>(
                            value: 'All Stores',
                            child: Text(
                              staticTextTranslate('All Stores'),
                              style: GoogleFonts.roboto(fontSize: 14),
                            ),
                          )
                        ] +
                        widget.allStoreDataLst.map((StoreData value) {
                          return DropdownMenuItem<String>(
                            value: value.docId,
                            child: Text(
                              value.storeName,
                              style: GoogleFonts.roboto(fontSize: 14),
                            ),
                          );
                        }).toList(),
                    onChanged: (v) {
                      if (v != null) {
                        selectedStoreDocId = v;
                        filterData();
                        setState(() {});
                      }
                    },
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Container(
                  width: 240,
                  height: 23,
                  decoration: BoxDecoration(
                      color: const Color(0xff9e9e9e),
                      borderRadius: BorderRadius.circular(4)),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  alignment: Alignment.centerLeft,
                  child: selectedWeek == "Month"
                      ? DropdownButton<String>(
                          isExpanded: true,
                          underline: const SizedBox(),
                          value: selectedYear,
                          items: [
                            for (int i = 0;
                                i <= (DateTime.now().year - 2020);
                                i++)
                              DropdownMenuItem<String>(
                                value: (2020 + i).toString(),
                                child: Text(
                                  (2020 + i).toString(),
                                  style: GoogleFonts.roboto(fontSize: 14),
                                ),
                              )
                          ],
                          onChanged: (v) {
                            if (v != null) {
                              selectedYear = v;

                              filterData();
                              setState(() {});
                            }
                          },
                        )
                      : GestureDetector(
                          onTap: () async {
                            selectedDatetime = (await showDatePicker(
                                    context: context,
                                    firstDate: DateTime(2000),
                                    lastDate: DateTime.now(),
                                    initialDate: selectedDatetime) ??
                                selectedDatetime);
                            filterData();
                            setState(() {});
                          },
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  getSelectedWeekDate(),
                                  style: GoogleFonts.roboto(fontSize: 14),
                                ),
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              const Icon(Icons.arrow_drop_down_sharp)
                            ],
                          ),
                        ),
                ),
                const SizedBox(
                  width: 10,
                ),
              ],
            ),
            SizedBox(height: 260, child: BarChartSample2(chartData: chartData))
          ],
        ),
      ),
    );
  }
}
