import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';

class BarChartSample2 extends StatefulWidget {
  final List<SalesData> chartData;
  const BarChartSample2({super.key, required this.chartData});
  @override
  State<StatefulWidget> createState() => BarChartSample2State();
}

class BarChartSample2State extends State<BarChartSample2> {
  TooltipBehavior? _tooltipBehavior;

  Color borderColor = const Color(0xff434343);
  @override
  void initState() {
    _tooltipBehavior = TooltipBehavior(
        enable: true,
        canShowMarker: true,
        activationMode: ActivationMode.singleTap,
        header: '');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(14),
      child: SfCartesianChart(
          plotAreaBorderWidth: 0,
          isTransposed: true,
          primaryXAxis: CategoryAxis(
            axisLine: const AxisLine(
              color: Colors.white,
            ),
            majorGridLines: const MajorGridLines(
              width: 0,
            ),
            majorTickLines: const MajorTickLines(width: 0),
            axisLabelFormatter: (axisLabelRenderArgs) {
              return ChartAxisLabel(
                  axisLabelRenderArgs.text,
                  const TextStyle(
                      color: Colors.white,
                      fontFamily: 'assets/fonts/new_fonts/Roboto-Regular.ttf'));
            },
          ),
          primaryYAxis: NumericAxis(
              axisLine: const AxisLine(
                color: Colors.white,
              ),
              axisLabelFormatter: (axisLabelRenderArgs) {
                return ChartAxisLabel('', const TextStyle());
              },
              majorGridLines:
                  const MajorGridLines(color: Colors.white, width: 0.2),
              minorTickLines: const MinorTickLines(),
              minorGridLines: const MinorGridLines(),
              majorTickLines: const MajorTickLines(size: 1),
              numberFormat: NumberFormat.compact()),
          tooltipBehavior: _tooltipBehavior,
          series: <CartesianSeries>[
            BarSeries<SalesData, String>(
              dataSource: widget.chartData,
              enableTooltip: true,

              markerSettings: const MarkerSettings(isVisible: false),
              dataLabelMapper: (data, index) => doubleToString(data.sales),
              xValueMapper: (SalesData data, _) => data.week,
              yValueMapper: (SalesData data, _) => data.sales,
              dataLabelSettings: DataLabelSettings(
                  isVisible: true,
                  textStyle: GoogleFonts.roboto(
                      color: const Color.fromARGB(255, 238, 238, 238),
                      fontSize: 13)),
              pointColorMapper: (SalesData data, _) => data.week == 'Sun'
                  ? const Color(0xff00acc1)
                  : data.week == 'Mon'
                      ? const Color(0xffbec931)
                      : data.week == 'Tue'
                          ? const Color(0xff41a046)
                          : data.week == 'Wed'
                              ? const Color(0xff9d6643)
                              : data.week == 'Thu'
                                  ? const Color(0xff9c4343)
                                  : data.week == 'Fri'
                                      ? const Color(0xff42709d)
                                      : data.week == 'Sat'
                                          ? const Color(0xff5c439d)
                                          : null,
              // Width of the bars
              width: 0.6,
              // Spacing between the bars
              // spacing: 0.3
            )
          ]),
    );
  }
}

class SalesData {
  SalesData(this.week, this.sales);

  final String week;
  final double sales;
}
