import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/string_related/get_today_date.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_charts/charts.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

class PaymentMethodPage extends StatefulWidget {
  final List<ReceiptOrQuotationData> allReceiptDataLst;
  const PaymentMethodPage({super.key, required this.allReceiptDataLst});

  @override
  State<PaymentMethodPage> createState() => _PaymentMethodPageState();
}

class _PaymentMethodPageState extends State<PaymentMethodPage> {
  String selectedWeek = 'Week';
  List<ChartData> chartData = [];
  late DateTime rangeStartDate;
  DateTime? rangeEndDate;
  @override
  void initState() {
    super.initState();
    rangeStartDate = getTodayDate();
    initData();
  }

  initData() {
    filterData();
    setState(() {});
  }

  filterData() {
    Map<String, double> allPaymentMethodSalesValueLst =
        getAllPaymentMethodSalesValue();

    double totalSales = 0;
    for (var v in allPaymentMethodSalesValueLst.values) {
      totalSales += v;
    }

    chartData = allPaymentMethodSalesValueLst.keys.map<ChartData>((k) {
      return ChartData(
          k,
          allPaymentMethodSalesValueLst[k] == 0
              ? 0
              : ((allPaymentMethodSalesValueLst[k]! / totalSales) * 100)
                  .roundToDouble(),
          const Color.fromRGBO(9, 0, 136, 1));
    }).toList();
  }

  Map<String, double> getAllPaymentMethodSalesValue() {
    DateTime now = DateTime.now();
    int daysOfWeek = now.weekday - 1;
    DateTime firstDay = DateTime(now.year, now.month, now.day - daysOfWeek);
    DateTime lastDay =
        firstDay.add(const Duration(days: 6, hours: 23, minutes: 59));

    //receipt filtering
    List<ReceiptOrQuotationData> filterLst1 = selectedWeek == 'Week'
        ? widget.allReceiptDataLst
            .where((e) =>
                e.createdDate.compareTo(firstDay) != -1 &&
                e.createdDate.compareTo(lastDay) != 1)
            .toList()
        : selectedWeek == 'Month'
            ? widget.allReceiptDataLst
                .where((e) =>
                    e.createdDate.year == DateTime.now().year &&
                    e.createdDate.month == DateTime.now().month)
                .toList()
            : widget.allReceiptDataLst.where((element) {
                if (rangeEndDate != null) {
                  DateTime d = DateTime(element.createdDate.year,
                      element.createdDate.month, element.createdDate.day);

                  if (d.compareTo(rangeStartDate) != -1 &&
                      d.compareTo(rangeEndDate!) != 1) {
                    return true;
                  }
                  return false;
                }
                return element.createdDate.year == rangeStartDate.year &&
                    element.createdDate.month == rangeStartDate.month &&
                    element.createdDate.day == rangeStartDate.day;
              }).toList();

    Map<String, double> allPaymentMethodSalesValueLst = {
      for (String k in PaymentMethodKey().getAllPaymentMethodLst()) k: 0
    };

    for (var r in filterLst1) {
      if (r.isReceiptType()) {
        for (String k in allPaymentMethodSalesValueLst.keys) {
          double iValue = double.tryParse(r
                  .receiptBasicInfo!.allPaymentMethodAmountsInfo[k]
                  .toString()) ??
              0;
          if (k == 'Cash') {
            iValue = iValue -
                (double.tryParse(
                        r.receiptBasicInfo!.receiptBalance.toString()) ??
                    0);
          }
          allPaymentMethodSalesValueLst[k] =
              r.receiptBasicInfo!.receiptType == 'Regular'
                  ? (allPaymentMethodSalesValueLst[k] ?? 0) + iValue
                  : (allPaymentMethodSalesValueLst[k] ?? 0) - iValue;
        }
      }
    }

    return allPaymentMethodSalesValueLst;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 250,
      decoration: const BoxDecoration(
          color: Color(0xff2b2b2b),
          borderRadius: BorderRadius.all(Radius.circular(4))),
      child: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              const SizedBox(
                width: 14,
              ),
              Text(
                staticTextTranslate('Payment Method'),
                style: GoogleFonts.roboto(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: const Color(0xffd4d4d4)),
              ),
              const Expanded(
                  child: SizedBox(
                width: 10,
              )),
              Container(
                width: 210,
                height: 23,
                decoration: BoxDecoration(
                    color: const Color(0xff9e9e9e),
                    borderRadius: BorderRadius.circular(4)),
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: DropdownButton<String>(
                  isExpanded: true,
                  underline: const SizedBox(),
                  value: selectedWeek,
                  items: ['Week', 'Month', 'Custom Date'].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value != 'Custom Date'
                            ? staticTextTranslate(value)
                            : value == 'Custom Date' &&
                                    selectedWeek != 'Custom Date'
                                ? value
                                : (rangeEndDate != null
                                    ? '${DateFormat('MMM dd, yyyy').format(rangeStartDate)} - ${DateFormat('MMM dd, yyyy').format(rangeEndDate!)}'
                                    : DateFormat('MMM dd, yyyy')
                                        .format(rangeStartDate)),
                        style: GoogleFonts.roboto(fontSize: 14),
                      ),
                    );
                  }).toList(),
                  onChanged: (v) {
                    if (v != null) {
                      selectedWeek = v;
                      if (selectedWeek == 'Custom Date') {
                        showDialog(
                            context: context,
                            builder: (context) {
                              return Dialog(
                                child: SizedBox(
                                  width: 400,
                                  height: 380,
                                  child: SfDateRangePicker(
                                      initialSelectedRange: PickerDateRange(
                                          rangeStartDate, rangeEndDate),
                                      initialDisplayDate: rangeStartDate,
                                      onSelectionChanged:
                                          (DateRangePickerSelectionChangedArgs
                                              args) {
                                        if (args.value is PickerDateRange) {
                                          rangeStartDate = args.value.startDate;
                                          rangeEndDate = args.value.endDate;
                                          setState(() {});
                                        }
                                      },
                                      onCancel: () {
                                        Navigator.pop(context);
                                      },
                                      onSubmit: (var p0) {
                                        filterData();
                                        setState(() {});
                                        Navigator.pop(context);
                                      },
                                      cancelText: 'CANCEL',
                                      confirmText: 'OK',
                                      showTodayButton: true,
                                      showActionButtons: true,
                                      view: DateRangePickerView.month,
                                      selectionMode:
                                          DateRangePickerSelectionMode.range),
                                ),
                              );
                            });
                      } else {
                        filterData();

                        setState(() {});
                      }
                    }
                  },
                ),
              ),
              const SizedBox(
                width: 10,
              ),
            ],
          ),
          const Expanded(
              child: SizedBox(
            height: 10,
          )),
          SizedBox(
            height: 210,
            child: SfCircularChart(
                legend: Legend(
                    position: LegendPosition.auto,
                    isVisible: true,
                    legendItemBuilder:
                        (String name, dynamic series, point, int index) {
                      return SizedBox(
                          height: 15,
                          width: 160,
                          child: Row(children: <Widget>[
                            Container(
                              width: 10,
                              height: 10,
                              decoration: BoxDecoration(
                                  color: !point.isVisible
                                      ? Colors.grey.shade800
                                      : point.color,
                                  borderRadius: BorderRadius.circular(2)),
                            ),
                            const SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$name - ${(getAllPaymentMethodSalesValue()[name] ?? 0).toStringAsFixed(digit)}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 12,
                              ),
                            ),
                          ]));
                    },
                    textStyle: const TextStyle(
                        color: Colors.white,
                        fontFamily: 'assets/fonts/new_fonts/Roboto-Regular.ttf',
                        fontSize: 12,
                        fontWeight: FontWeight.w300)),
                onLegendTapped: (legendTapArgs) {
                  setState(() {});
                },
                series: <CircularSeries>[
                  DoughnutSeries<ChartData, String>(
                      legendIconType: LegendIconType.rectangle,
                      enableTooltip: true,
                      dataSource: chartData,
                      xValueMapper: (ChartData data, _) => data.x,
                      yValueMapper: (ChartData data, _) => data.y,
                      explode: true,
                      dataLabelMapper: (data, index) => '${data.y}%',
                      dataLabelSettings: const DataLabelSettings(
                          isVisible: true,
                          textStyle: TextStyle(
                              color: Colors.white,
                              fontFamily:
                                  'assets/fonts/new_fonts/Roboto-Regular.ttf'),
                          labelPosition: ChartDataLabelPosition.outside),
                      // Explode all the segments
                      explodeAll: true)
                ]),
          ),
          const Expanded(
              child: SizedBox(
            height: 10,
          )),
        ],
      ),
    );
  }
}

class ChartData {
  ChartData(this.x, this.y, this.color);
  final String x;
  final double y;
  final Color color;
}
