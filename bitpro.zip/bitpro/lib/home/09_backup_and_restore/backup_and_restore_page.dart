import 'dart:io';
import 'package:bitpro_hive/services/backup_manager/backup_manager.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:iconsax/iconsax.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../shared/global_variables/font_sizes.dart';
import '../../shared/global_variables/static_text_translate.dart';

class BackupAndRestore extends StatefulWidget {
  const BackupAndRestore({super.key});

  @override
  State<BackupAndRestore> createState() => _BackupAndRestoreState();
}

class _BackupAndRestoreState extends State<BackupAndRestore> {
  bool loading = false;
  @override
  Widget build(BuildContext context) {
    if (loading) return showLoading();
    return Wrap(
      runSpacing: 20,
      children: [
        OnPageButton(
          label: 'Backup',
          width: 150,
          onPressed: () async {
            setState(() {
              loading = true;
            });
            String? selectedDirectory =
                await FilePicker.platform.getDirectoryPath();

            if (selectedDirectory != null) {
              await BackupManager().saveHiveBackupToTheDirPath(
                  selectedDirectory: selectedDirectory, context: context);
            }
            setState(() {
              loading = false;
            });
          },
          icon: Iconsax.cloud4,
        ),
        const SizedBox(
          width: 15,
        ),
        OnPageButton(
          label: 'Restore',
          width: 150,
          onPressed: () async {
            setState(() {
              loading = true;
            });

            final Directory documentsDirectory =
                await getApplicationDocumentsDirectory();
            final customPath =
                Directory('${documentsDirectory.path}/BitproDatabase');

            if (!await customPath.exists()) {
              await customPath.create(recursive: true);
            }

            launchUrl(customPath.uri);

            setState(() {
              loading = false;
            });
          },
          icon: Iconsax.cloud_change,
        ),
        const SizedBox(
          width: 15,
        ),
        OnPageButton(
          label: 'Reset Application',
          width: 200,
          onPressed: () async {
            showResetApplicationDialog();
          },
          icon: Iconsax.rotate_left,
        ),
      ],
    );
  }

  showResetApplicationDialog() {
    return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text(staticTextTranslate('Reset Application?'),
                style: TextStyle(
                  fontSize: getMediumFontSize,
                )),
            content: Text(
                staticTextTranslate(
                    'Please backup before, resetting the application.'),
                style: TextStyle(
                  fontSize: getMediumFontSize,
                )),
            actions: [
              SizedBox(
                height: 42,
                width: 175,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                width: 0.5, color: Colors.grey),
                            borderRadius: BorderRadius.circular(5))),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text(
                      staticTextTranslate('Cancel'),
                      style: TextStyle(
                          fontSize: getMediumFontSize, color: Colors.black),
                    )),
              ),
              SizedBox(
                height: 42,
                width: 175,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5))),
                    onPressed: () async {
                      setState(() {
                        loading = true;
                      });
                      Box box = Hive.box('bitpro_app');
                      await box.clear();

                      Navigator.pop(context);
                      setState(() {
                        loading = false;
                      });
                    },
                    child: Text(
                      staticTextTranslate('Reset'),
                      style: TextStyle(
                          fontSize: getMediumFontSize, color: Colors.white),
                    )),
              ),
            ],
          );
        });
  }
}
