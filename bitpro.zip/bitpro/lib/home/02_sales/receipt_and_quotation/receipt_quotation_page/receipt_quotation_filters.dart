import 'package:bitpro_hive/model/local_models/receipt_filter_data.dart';
import 'package:bitpro_hive/widget/filter_container.dart';
import 'package:bitpro_hive/widget/filter_text_fileds/fiter_textfield.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../../../shared/global_variables/font_sizes.dart';
import '../../../../shared/global_variables/static_text_translate.dart';

class MReceiptQuotationFilterWidget extends StatefulWidget {
  final ReceiptFilterData receiptFilterData;
  final Function refreshFunction;
  final List<StoreData> allStoreDataLst;
  final bool isQuotation;
  const MReceiptQuotationFilterWidget(
      {super.key,
      required this.receiptFilterData,
      required this.refreshFunction,
      required this.allStoreDataLst,
      required this.isQuotation});

  @override
  State<MReceiptQuotationFilterWidget> createState() =>
      _MReceiptQuotationFilterWidgetState();
}

class _MReceiptQuotationFilterWidgetState
    extends State<MReceiptQuotationFilterWidget> {
  TextEditingController receiptIdController = TextEditingController();
  TextEditingController customerNameController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return FilterContainer(fiterFields: [
      FilterTextField(
        onPressed: () {
          receiptIdController.clear();
          widget.receiptFilterData.receiptId = '';

          widget.refreshFunction();
        },
        icon: Icon(
            receiptIdController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: receiptIdController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        controller: receiptIdController,
        hintText: widget.isQuotation ? 'Quotation #' : 'Receipt #',
        onChanged: (val) {
          widget.receiptFilterData.receiptId = val;

          widget.refreshFunction();
        },
      ),
      FilterTextField(
        onPressed: () {
          customerNameController.clear();

          widget.receiptFilterData.customerName = '';
          widget.refreshFunction();
        },
        icon: Icon(
            customerNameController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: customerNameController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        controller: customerNameController,
        hintText: 'Customer',
        onChanged: (val) {
          widget.receiptFilterData.customerName = val;
          widget.refreshFunction();
        },
      ),
      if (widget.isQuotation == false)
        Container(
          width: 200,
          height: 32,
          decoration: BoxDecoration(
              border: Border.all(width: 0.5, color: Colors.grey),
              color: const Color.fromARGB(255, 255, 255, 255),
              borderRadius: BorderRadius.circular(4)),
          padding: const EdgeInsets.only(right: 5, bottom: 3),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                padding: const EdgeInsets.only(top: 2),
                onPressed: () {
                  widget.receiptFilterData.selectedReturnTypeName = '';
                  widget.refreshFunction();
                },
                splashRadius: 1,
                icon: Icon(
                    widget.receiptFilterData.selectedReturnTypeName.isEmpty
                        ? CupertinoIcons.search
                        : Icons.clear,
                    size: 18,
                    color:
                        widget.receiptFilterData.selectedReturnTypeName.isEmpty
                            ? Colors.grey[600]
                            : Colors.black),
              ),
              Flexible(
                  child: Container(
                      width: 180,
                      height: 32,
                      decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 255, 255, 255),
                          borderRadius: BorderRadius.circular(8)),
                      padding: const EdgeInsets.only(right: 10, left: 10),
                      child: DropdownButton<String>(
                        isExpanded: true,
                        value: widget.receiptFilterData.selectedReturnTypeName
                                .isEmpty
                            ? null
                            : widget.receiptFilterData.selectedReturnTypeName,
                        underline: const SizedBox(),
                        hint: Text(
                          staticTextTranslate('Receipt Type'),
                          style: TextStyle(
                            fontSize: getMediumFontSize + 2,
                          ),
                        ),
                        items: <String>['All', 'Regular', 'Return']
                            .map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(
                              staticTextTranslate(value),
                              style: TextStyle(
                                fontSize: getMediumFontSize + 2,
                              ),
                            ),
                          );
                        }).toList(),
                        onChanged: (val) {
                          if (val != null) {
                            widget.receiptFilterData.selectedReturnTypeName =
                                val;
                            widget.refreshFunction();
                          }
                        },
                      ))),
            ],
          ),
        ),
      Container(
        width: 220,
        height: 32,
        decoration: BoxDecoration(
            border: Border.all(width: 0.5, color: Colors.grey),
            color: const Color.fromARGB(255, 255, 255, 255),
            borderRadius: BorderRadius.circular(4)),
        padding: const EdgeInsets.only(right: 3, bottom: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Flexible(
                child: Container(
                    height: 30,
                    decoration: BoxDecoration(
                        color: const Color.fromARGB(255, 255, 255, 255),
                        borderRadius: BorderRadius.circular(8)),
                    padding: const EdgeInsets.only(
                        right: 3, left: 5, top: 5, bottom: 5),
                    child: DropdownButton<String>(
                      isExpanded: true,
                      value: widget.receiptFilterData.selectedStoreDocId,
                      underline: const SizedBox(),
                      hint: Text(
                        staticTextTranslate('Stores'),
                        style: TextStyle(
                          overflow: TextOverflow.ellipsis,
                          fontSize: getMediumFontSize + 1,
                        ),
                      ),
                      items: <String>['All'].map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(
                                staticTextTranslate(value),
                                style: TextStyle(
                                  fontSize: getMediumFontSize + 2,
                                ),
                              ),
                            );
                          }).toList() +
                          widget.allStoreDataLst.map((StoreData value) {
                            return DropdownMenuItem<String>(
                              value: value.docId,
                              child: Text(
                                staticTextTranslate(value.storeName),
                                style: TextStyle(
                                  fontSize: getMediumFontSize + 2,
                                ),
                              ),
                            );
                          }).toList(),
                      onChanged: (val) {
                        if (val != null) {
                          widget.receiptFilterData.selectedStoreDocId = val;
                          widget.refreshFunction();
                        }
                      },
                    ))),
          ],
        ),
      ),
    ]);
  }
}
