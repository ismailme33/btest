import 'package:bitpro_hive/datasourse/receipt_quot_datasource.dart';
import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/receipt_quotation_page/receipt_quotation_filters.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/local_models/receipt_filter_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_customer_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_receipt_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/shared/dialogs/show_register_is_close_dailog.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/receipt_quot_create_edit_page.dart';
import 'package:bitpro_hive/model/customer_data.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import '../../../../shared/custom_top_nav_bar.dart';

class ReceiptAndQuotationPage extends StatefulWidget {
  final EmployeeData userData;
  final bool isQuotation;
  final bool isInvoice;
  const ReceiptAndQuotationPage(
      {Key? key,
      required this.userData,
      this.isQuotation = false,
      this.isInvoice = false})
      : super(key: key);

  @override
  State<ReceiptAndQuotationPage> createState() =>
      _ReceiptAndQuotationPageState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _ReceiptAndQuotationPageState extends State<ReceiptAndQuotationPage> {
  ReceiptQuotationDataSource? dataSource;
  DataGridController dataGridController = DataGridController();
  late final List<BitproGridColumnModel> _bitproGridColumnModel;
  bool loading = true;

  List<ReceiptOrQuotationData> dbReceiptQuotationDataLst = [];

  List<CustomerData> customerDataLst = [];
  List<StoreData> allStoreDataLst = [];

  late ReceiptFilterData receiptFilterData;

  final Color dGvColor = const Color.fromARGB(255, 231, 231, 231);

  @override
  void initState() {
    super.initState();
    _bitproGridColumnModel = getBitproGridData();
    fetchDataFromHive();
  }

  Future<void> resetFilter() async {
    int selectedStoreCode = await HiveStoreDbService().getSelectedStoreCode();
    int index = allStoreDataLst.indexWhere(
        (element) => element.storeCode == selectedStoreCode.toString());

    String selectedStoreFilter = '';
    if (index != -1) {
      selectedStoreFilter = allStoreDataLst.elementAt(index).docId;
    } else {
      selectedStoreFilter = allStoreDataLst.first.docId;
    }

    receiptFilterData = ReceiptFilterData(
        selectedReturnTypeName: '',
        selectedStoreDocId: selectedStoreFilter,
        customerName: '',
        receiptId: '');
  }

  fetchDataFromHive() async {
    allStoreDataLst = await HiveStoreDbService().fetchAllStoresData();
    customerDataLst = await HiveCustomerDbService().fetchAllCustomersData();

    dbReceiptQuotationDataLst = await HiveReceiptDbService()
        .fetchAllReceiptData(isQuotationData: widget.isQuotation);

    await resetFilter();

    dataSource = ReceiptQuotationDataSource(
        isQuotation: widget.isQuotation,
        customerDataLst: customerDataLst,
        dbReceiptData: receiptFilterData.selectedStoreDocId == 'All'
            ? dbReceiptQuotationDataLst
            : dbReceiptQuotationDataLst
                .where((e) => e.isQuotationType()
                    ? e.quotationBasicInfo!.selectedStoreDocId ==
                        receiptFilterData.selectedStoreDocId
                    : e.receiptBasicInfo!.selectedStoreDocId ==
                        receiptFilterData.selectedStoreDocId)
                .toList(),
        allStoreDataLst: allStoreDataLst);
    setState(() {
      loading = false;
    });
  }

  void filterRefreshDataFunction() {
    dataSource = ReceiptQuotationDataSource(
        isQuotation: widget.isQuotation,
        customerDataLst: customerDataLst,
        dbReceiptData: dbReceiptQuotationDataLst.where((e) {
          String selectedCustomerID = '';
          String receiptId = '';
          String receiptType = '';
          String storeId = '';

          if (e.isQuotation && e.quotationBasicInfo != null) {
            selectedCustomerID = e.quotationBasicInfo!.selectedCustomerID;
            receiptId = e.quotationBasicInfo!.quotationNo;
            receiptType = e.quotationBasicInfo!.receiptType;
            storeId = e.quotationBasicInfo!.selectedStoreDocId;
          } else if (!e.isQuotation && e.receiptBasicInfo != null) {
            selectedCustomerID = e.receiptBasicInfo!.selectedCustomerID;
            receiptId = e.receiptBasicInfo!.receiptNo;
            receiptType = e.receiptBasicInfo!.receiptType;
            storeId = e.receiptBasicInfo!.selectedStoreDocId;
          }

          String selectedCustomerName = '';
          int i = customerDataLst
              .indexWhere((e) => e.customerId == selectedCustomerID);
          if (i != -1) {
            selectedCustomerName =
                customerDataLst[i].customerName.toLowerCase();
          }

          return (selectedCustomerName
                      .contains(receiptFilterData.customerName) ||
                  receiptFilterData.customerName.isEmpty) &&
              (receiptId.contains(receiptFilterData.receiptId) ||
                  receiptFilterData.receiptId.isEmpty) &&
              (receiptType == receiptFilterData.selectedReturnTypeName ||
                  receiptFilterData.selectedReturnTypeName.isEmpty) &&
              (storeId == receiptFilterData.selectedStoreDocId ||
                  receiptFilterData.selectedStoreDocId.isEmpty);
        }).toList(),
        allStoreDataLst: allStoreDataLst);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return CustomNavBar(
        pageName: widget.isQuotation
            ? staticTextTranslate('Quotation')
            : staticTextTranslate('Receipt'),
        child: Scaffold(
          backgroundColor: homeBgColor,
          body: SafeArea(
            child: Row(
              children: [
                leftSideBtn(),
                Expanded(
                  child: Card(
                      shape: RoundedRectangleBorder(
                          side:
                              const BorderSide(color: Colors.grey, width: 0.5),
                          borderRadius: BorderRadius.circular(5)),
                      elevation: 0,
                      color: Colors.white,
                      child: Column(
                        children: [
                          if (loading)
                            Expanded(child: showLoading())
                          else ...[
                            //filter
                            MReceiptQuotationFilterWidget(
                                isQuotation: widget.isQuotation,
                                receiptFilterData: receiptFilterData,
                                allStoreDataLst: allStoreDataLst,
                                refreshFunction: filterRefreshDataFunction),
                            BitproGridTable(
                              onChangeRefershFunction: () {
                                setState(() {});
                              },
                              allowSorting: true,
                              dataGridController: dataGridController,
                              source: dataSource!,
                              allowEditing: false,
                              bitproGridColumnModel: _bitproGridColumnModel,
                            ),
                          ]
                        ],
                      )),
                )
              ],
            ),
          ),
        ));
  }

  ReceiptOrQuotationData? getSelectedReceiptData() {
    if (dataGridController.selectedRow != null) {
      var id = '';

      for (var c in dataGridController.selectedRow!.getCells()) {
        if (c.columnName == 'id') {
          id = c.value;
        }
      }

      int index = dbReceiptQuotationDataLst.indexWhere((element) =>
          element.isQuotationType()
              ? element.quotationBasicInfo!.quotationNo == id
              : element.receiptBasicInfo!.receiptNo == id);
      if (index != -1) {
        return dbReceiptQuotationDataLst[index];
      }
    }
    return null;
  }

  Widget leftSideBtn() {
    ReceiptOrQuotationData? selectedReceiptData = getSelectedReceiptData();

    return Container(
      color: const Color.fromARGB(255, 43, 43, 43),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SideMenuButton(
            label: 'Back',
            iconPath: 'assets/icons/back.png',
            buttonFunction: () {
              Navigator.pop(context);
            },
          ),
          SideMenuButton(
            label: 'Create',
            iconPath: 'assets/icons/plus.png',
            buttonFunction: () async {
              if (widget.userData.openRegister == null) {
                showRegisterClosedDialog(context);
              } else {
                bool? res = await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => CreateEditReceiptQuotPage(
                              isInvoice: widget.isInvoice,
                              receiptLength: dbReceiptQuotationDataLst.length,
                              isQuotation: widget.isQuotation,
                              userData: widget.userData,
                              customerDataLst: customerDataLst,
                            )));
                if (res != null && res) {
                  setState(() {
                    loading = true;
                  });
                  fetchDataFromHive();
                }
              }
            },
          ),
          SideMenuButton(
            label: selectedReceiptData != null &&
                    selectedReceiptData.isInvoiceType() &&
                    selectedReceiptData.isInvoiceFinilized() == false
                ? "Edit"
                : 'View',
            iconPath: 'assets/icons/view.png',
            enable: selectedReceiptData != null,
            buttonFunction: () async {
              if (selectedReceiptData != null) {
                bool? res = await Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => CreateEditReceiptQuotPage(
                              isQuotation:
                                  selectedReceiptData.isQuotationType(),
                              isInvoice: selectedReceiptData.isInvoiceType(),
                              receiptLength: dbReceiptQuotationDataLst.length,
                              customerDataLst: customerDataLst,
                              selectedDbReceiptData: selectedReceiptData,
                              viewMode: true,
                              userData: widget.userData,
                            )));
                if (res != null && res) {
                  setState(() {
                    loading = true;
                  });
                  fetchDataFromHive();
                }
              }
            },
          ),
          const SizedBox(
            height: 30,
          ),
          SideMenuButton(
            label: 'Refresh',
            iconPath: 'assets/icons/refresh.png',
            buttonFunction: () async {
              setState(() {
                loading = true;
              });
              await fetchDataFromHive();
            },
          ),
          SideMenuButton(
            label: 'Date Range',
            iconPath: 'assets/icons/date.png',
            buttonFunction: () {
              showDialog(
                  context: context,
                  builder: (context) {
                    return Dialog(
                      child: SizedBox(
                        width: 400,
                        height: 380,
                        child: SfDateRangePicker(
                            onSelectionChanged:
                                (DateRangePickerSelectionChangedArgs args) {
                              if (args.value is PickerDateRange) {
                                receiptFilterData.rangeStartDate =
                                    args.value.startDate;
                                receiptFilterData.rangeEndDate =
                                    args.value.endDate;
                                setState(() {});
                              }
                            },
                            onCancel: () {
                              Navigator.pop(context);
                            },
                            onSubmit: (var p0) {
                              filterRefreshDataFunction();
                              Navigator.pop(context);
                            },
                            cancelText: 'CANCEL',
                            confirmText: 'OK',
                            showTodayButton: false,
                            showActionButtons: true,
                            view: DateRangePickerView.month,
                            selectionMode: DateRangePickerSelectionMode.range),
                      ),
                    );
                  });
            },
          ),
        ],
      ),
    );
  }

  List<BitproGridColumnModel> getBitproGridData() {
    final List<BitproGridColumnModel> bitproGridColumnModel = [
      BitproGridColumnModel(
          columnName: 'serialNumberForStyleColor',
          label: 's.no',
          width: double.nan,
          visible: false),
      BitproGridColumnModel(
          columnName: 'id',
          label: widget.isQuotation
              ? staticTextTranslate('Quote #')
              : staticTextTranslate('Receipt #'),
          width: 150),
      BitproGridColumnModel(
        columnName: 'type',
        label: staticTextTranslate('Type'),
        width: 110,
        visible: !widget.isQuotation,
      ),
      BitproGridColumnModel(
        columnName: 'paymentStatus',
        label: staticTextTranslate('Payment Status'),
        width: 173,
        visible: !widget.isQuotation,
      ),
      BitproGridColumnModel(
        columnName: 'customer',
        label: staticTextTranslate('Customer Name'),
        width: 210,
      ),
      BitproGridColumnModel(
        columnName: 'orgTotal',
        label: staticTextTranslate('Original Total'),
        width: 156,
      ),
      BitproGridColumnModel(
          columnName: 'totalQty',
          label: staticTextTranslate('Total Qty'),
          width: 128),
      BitproGridColumnModel(
        columnName: 'discPer',
        label: staticTextTranslate('Disc %'),
        width: 112,
      ),
      BitproGridColumnModel(
          columnName: 'discVal',
          label: staticTextTranslate('Disc \$'),
          width: 108),
      BitproGridColumnModel(
          columnName: 'taxPer',
          label: staticTextTranslate(staticTextTranslate('Tax %')),
          width: 106),
      BitproGridColumnModel(
          columnName: 'taxVal',
          label: staticTextTranslate('Tax \$'),
          width: 106),
      BitproGridColumnModel(
          columnName: 'store', label: staticTextTranslate('Store'), width: 150),
      BitproGridColumnModel(
          columnName: 'paymentType',
          label: staticTextTranslate('Payment Type'),
          width: 163),
      BitproGridColumnModel(
          columnName: 'total',
          label: widget.isQuotation
              ? staticTextTranslate('Quotation Total')
              : staticTextTranslate('Receipt Total'),
          width: 155),
      BitproGridColumnModel(
          columnName: 'createdDate',
          label: staticTextTranslate('Created Date'),
          width: 160),
      BitproGridColumnModel(
          columnName: 'createdBy',
          label: staticTextTranslate('Created by'),
          width: 143),
    ];
    return bitproGridColumnModel;
  }
}
