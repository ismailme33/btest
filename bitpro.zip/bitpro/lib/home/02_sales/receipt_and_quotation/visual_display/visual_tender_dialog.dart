import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class VisualTenderDialog extends StatefulWidget {
  const VisualTenderDialog({super.key});

  @override
  State<VisualTenderDialog> createState() => _VisualTenderDialogState();
}

class _VisualTenderDialogState extends State<VisualTenderDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: EdgeInsets.all(25),
        height: 550,
        width: 600,
        decoration: BoxDecoration(
          border: Border.all(width: 0.4, color: Colors.grey),
          color: Color(0xFF151515),
        ),
        child: Column(
          children: [
            Text(
              'Select and fulfill appropriate payment methods.',
              style: TextStyle(color: Colors.grey[200], fontSize: 18),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              height: 80,
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Customer: Ismial ibrahim',
                        style: TextStyle(
                          color: Colors.grey[200],
                        ),
                      ),
                      Text(
                        'Address: Jeddah Saudi Arabia',
                        style: TextStyle(
                          color: Colors.grey[200],
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            Expanded(
              child: Container(
                child: Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 35,
                            width: 120,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xFF363439),
                                    shape: RoundedRectangleBorder(
                                        side: BorderSide(
                                          width: 0.3,
                                          color: Colors.white,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(2))),
                                onPressed: () {},
                                child: Text(
                                  'Cash',
                                  style: TextStyle(color: Colors.grey[200]),
                                )),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            height: 35,
                            width: 120,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xFF363439),
                                    shape: RoundedRectangleBorder(
                                        side: BorderSide(
                                          width: 0.3,
                                          color: Colors.white,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(2))),
                                onPressed: () {},
                                child: Text(
                                  'Credit Card',
                                  style: TextStyle(color: Colors.grey[200]),
                                )),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            height: 35,
                            width: 120,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xFF363439),
                                    shape: RoundedRectangleBorder(
                                        side: BorderSide(
                                          width: 0.3,
                                          color: Colors.white,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(2))),
                                onPressed: () {},
                                child: Text(
                                  'Tamara',
                                  style: TextStyle(color: Colors.grey[200]),
                                )),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            height: 35,
                            width: 120,
                            child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xFF363439),
                                    shape: RoundedRectangleBorder(
                                        side: BorderSide(
                                          width: 0.3,
                                          color: Colors.white,
                                        ),
                                        borderRadius:
                                            BorderRadius.circular(2))),
                                onPressed: () {},
                                child: Text(
                                  'Tabby',
                                  style: TextStyle(color: Colors.grey[200]),
                                )),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            height: 250,
                            decoration: BoxDecoration(
                                color: Color(0xFF29282A),
                                border: Border.all(
                                  width: 0.3,
                                  color: Colors.white,
                                )),
                            child: Column(
                              children: [
                                Container(
                                  height: 35,
                                  width: double.maxFinite,
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 7, horizontal: 10),
                                  decoration: const BoxDecoration(
                                    borderRadius: BorderRadius.only(
                                        topLeft: Radius.circular(4),
                                        topRight: Radius.circular(4)),
                                  ),
                                  child: Text(
                                    'Payments',
                                    style: GoogleFonts.roboto(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.grey[200]),
                                  ),
                                ),
                                const SizedBox(
                                  height: 0,
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Container(
                                    width: double.maxFinite,
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 5, horizontal: 10),
                                    decoration: BoxDecoration(
                                        color: Color(0xFF353635),
                                        border: Border.all(
                                          width: 0.3,
                                          color: Colors.white,
                                        ),
                                        borderRadius: BorderRadius.circular(4)),
                                    child: Row(children: [
                                      Container(
                                        decoration: BoxDecoration(
                                          border: Border.all(width: 1),
                                          borderRadius:
                                              BorderRadius.circular(4),
                                          gradient: const LinearGradient(
                                              end: Alignment.bottomCenter,
                                              colors: [
                                                Color.fromARGB(
                                                    255, 207, 39, 39),
                                                Color.fromARGB(
                                                    255, 133, 14, 14),
                                              ],
                                              begin: Alignment.topCenter),
                                        ),
                                        height: 35,
                                        child: ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                              backgroundColor:
                                                  Colors.transparent),
                                          onPressed: () {},
                                          child: const Text('X'),
                                        ),
                                      ),
                                      const SizedBox(
                                        width: 10,
                                      ),
                                      Expanded(
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              'Cash',
                                              style: GoogleFonts.roboto(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w400,
                                                  color: Colors.grey),
                                            ),
                                            Text(
                                              '100.00',
                                              style: GoogleFonts.roboto(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w400,
                                                  color: Colors.grey),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ]),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          SizedBox(
                            width: 180,
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Receipt Total',
                                      style: GoogleFonts.roboto(
                                          color: Colors.grey),
                                    ),
                                    Text(
                                      '100.00',
                                      style: GoogleFonts.roboto(
                                          color: Colors.grey),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Tendered Amount',
                                      style: GoogleFonts.roboto(
                                          color: Colors.grey),
                                    ),
                                    Text(
                                      '100.00',
                                      style: GoogleFonts.roboto(
                                          color: Colors.grey),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Change',
                                      style: GoogleFonts.roboto(
                                          color: Colors.grey),
                                    ),
                                    Text(
                                      '100.00',
                                      style: GoogleFonts.roboto(
                                          color: Colors.grey),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Spacer(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(
                                height: 35,
                                child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                        backgroundColor: Color(0xFFB03726),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(2))),
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                    child: Text(
                                      'Close',
                                      style: TextStyle(color: Colors.grey[200]),
                                    )),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              SizedBox(
                                height: 35,
                                child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                        backgroundColor: Color(0xFF363439),
                                        shape: RoundedRectangleBorder(
                                            side: BorderSide(
                                              width: 0.3,
                                              color: Colors.white,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(2))),
                                    onPressed: () {},
                                    child: Text(
                                      'Save & Print',
                                      style: TextStyle(color: Colors.grey[200]),
                                    )),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
