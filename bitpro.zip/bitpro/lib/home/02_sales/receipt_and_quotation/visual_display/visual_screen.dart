import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/visual_display/visual_tender_dialog.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';

class VisualDisplay extends StatelessWidget {
  const VisualDisplay({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Color(0xFF151515),
        body: Column(
          children: [
            //Top bar
            Container(
              color: Color(0xFF29282A),
              height: 55,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      Image.asset(
                        'assets/icons/bitpro.png',
                        width: 25,
                      ),
                      const SizedBox(
                        width: 5,
                      ),
                      Text(
                        'BitPro',
                        style: GoogleFonts.poppins(
                            fontSize: 25,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      SizedBox(
                        width: 10,
                      ),
                      SizedBox(
                        height: 35,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xFF363439),
                                shape: RoundedRectangleBorder(
                                    side: BorderSide(
                                      width: 0.3,
                                      color: Colors.white,
                                    ),
                                    borderRadius: BorderRadius.circular(2))),
                            onPressed: () {
// shwo dialog for refund

                              showDialog(
                                context: context,
                                builder: (context) => RefundWidget(),
                              );
                            },
                            child: Text(
                              'Refund',
                              style: TextStyle(color: Colors.grey[200]),
                            )),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      SizedBox(
                        height: 35,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xFF363439),
                                shape: RoundedRectangleBorder(
                                    side: BorderSide(
                                      width: 0.3,
                                      color: Colors.white,
                                    ),
                                    borderRadius: BorderRadius.circular(2))),
                            onPressed: () {},
                            child: Text(
                              'Customer',
                              style: TextStyle(color: Colors.grey[200]),
                            )),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      SizedBox(
                        height: 35,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xFF363439),
                                shape: RoundedRectangleBorder(
                                    side: BorderSide(
                                      width: 0.3,
                                      color: Colors.white,
                                    ),
                                    borderRadius: BorderRadius.circular(2))),
                            onPressed: () {},
                            child: Text(
                              'Discount',
                              style: TextStyle(color: Colors.grey[200]),
                            )),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      SizedBox(
                        height: 35,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Color(0xFFB03726),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(2))),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text(
                              'Close',
                              style: TextStyle(color: Colors.grey[200]),
                            )),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                    ],
                  )
                ],
              ),
            ),
            Expanded(
              child: Row(
                children: [
                  // side left bar
                  Container(
                    width: 60,
                    child: Column(
                      children: [
                        Container(
                          height: 2,
                        ),
                        Expanded(
                          child: Container(
                            color: Color(0xFF29282A),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // center portion
                  Expanded(
                    child: Container(
                      padding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                      color: Color(0xFF151515),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Expanded(
                                flex: 2,
                                child: SizedBox(
                                  height: 35,
                                  child: TextField(
                                    style: TextStyle(color: Colors.grey[200]),
                                    decoration: InputDecoration(
                                        hintText: 'Scan or Enter Barcode',
                                        prefixIcon: Icon(
                                          Icons.qr_code,
                                          color: Colors.grey,
                                        ),
                                        contentPadding: EdgeInsets.all(10),
                                        isDense: true,
                                        filled: true,
                                        fillColor: Color(0xFF29282A),
                                        focusedBorder: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(4),
                                            borderSide: BorderSide(
                                                width: 0.7,
                                                color: Colors.blue)),
                                        enabledBorder: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(4),
                                            borderSide: BorderSide(
                                                width: 0.4,
                                                color: Colors.white)),
                                        border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(2),
                                            borderSide:
                                                BorderSide(width: 0.1))),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Expanded(
                                flex: 3,
                                child: SizedBox(
                                  height: 35,
                                  child: TextField(
                                    style: TextStyle(color: Colors.grey[200]),
                                    decoration: InputDecoration(
                                        hintText: 'Search Product',
                                        prefixIcon: Icon(
                                          Icons.search,
                                          color: Colors.grey,
                                        ),
                                        contentPadding: EdgeInsets.all(10),
                                        isDense: true,
                                        filled: true,
                                        fillColor: Color(0xFF29282A),
                                        focusedBorder: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(4),
                                            borderSide: BorderSide(
                                                width: 0.7,
                                                color: Colors.blue)),
                                        enabledBorder: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(4),
                                            borderSide: BorderSide(
                                                width: 0.4,
                                                color: Colors.white)),
                                        border: OutlineInputBorder(
                                            borderRadius:
                                                BorderRadius.circular(2),
                                            borderSide:
                                                BorderSide(width: 0.1))),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Expanded(
                              child: SingleChildScrollView(
                            child: Wrap(
                              runSpacing: 10,
                              runAlignment: WrapAlignment.start,
                              crossAxisAlignment: WrapCrossAlignment.start,
                              alignment: WrapAlignment.start,
                              spacing: 10,
                              children: [
                                Container(
                                    height: 110,
                                    width: 145,
                                    decoration: BoxDecoration(
                                      color: Color(0xFFC9CAEF),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Icon(Iconsax.d_cube_scan5),
                                          Text(
                                            'Computers',
                                            style: GoogleFonts.roboto(
                                                fontWeight: FontWeight.w700),
                                          ),
                                          Spacer(),
                                          Align(
                                            alignment: Alignment.centerRight,
                                            child: Icon(
                                                Icons.arrow_right_alt_outlined,
                                                size: 30,
                                                color: Colors.black),
                                          ),
                                        ],
                                      ),
                                    )),
                                Container(
                                    height: 110,
                                    width: 145,
                                    decoration: BoxDecoration(
                                      color: Color.fromARGB(255, 239, 201, 219),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Icon(Iconsax.d_cube_scan5),
                                          Spacer(),
                                          Text(
                                            'Laptops Tablets and others',
                                            overflow: TextOverflow.ellipsis,
                                            maxLines: 2,
                                            style: GoogleFonts.roboto(
                                                fontWeight: FontWeight.w700),
                                          ),
                                          Spacer(),
                                          Align(
                                            alignment: Alignment.centerRight,
                                            child: Icon(
                                                Icons.arrow_right_alt_outlined,
                                                size: 30,
                                                color: Colors.black),
                                          ),
                                        ],
                                      ),
                                    )),
                                SingleItem(),
                                SingleItem(),
                                SingleItem(),
                                SingleItem(),
                                SingleItem(),
                                SingleItem(),
                                SingleItem(),
                                SingleItem(),
                                SingleItem(),
                                SingleItem(),
                              ],
                            ),
                          )),
                        ],
                      ),
                    ),
                  ),

                  // right side portion
                  Container(
                    width: 400,
                    color: Color(0xFF29282A),
                    child: Column(
                      children: [
                        Container(
                          height: 2,
                          color: Color(0xFF151515),
                        ),
                        Expanded(
                            child: Container(
                          child: const Padding(
                            padding: EdgeInsets.all(15.0),
                            child: SingleChildScrollView(
                              child: Column(
                                children: [
                                  scannedItem(),
                                  SizedBox(
                                    height: 7,
                                  ),
                                  scannedItem(),
                                ],
                              ),
                            ),
                          ),
                        )),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 15.0),
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 15, vertical: 10),
                            decoration: BoxDecoration(
                              color: Color(0xFF353635),
                              borderRadius: BorderRadius.circular(2),
                            ),
                            // height: 112,
                            child: Column(
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Discount (0%)',
                                      style: TextStyle(color: Colors.grey[200]),
                                    ),
                                    Text(
                                      '0.00',
                                      style: TextStyle(color: Colors.grey[200]),
                                    )
                                  ],
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'SubTotal',
                                      style: TextStyle(color: Colors.grey[200]),
                                    ),
                                    Text(
                                      '180.00',
                                      style: TextStyle(color: Colors.grey[200]),
                                    )
                                  ],
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'TAX (15%)',
                                      style: TextStyle(color: Colors.grey[200]),
                                    ),
                                    Text(
                                      '8.00',
                                      style: TextStyle(color: Colors.grey[200]),
                                    )
                                  ],
                                ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Quantity',
                                      style: TextStyle(color: Colors.grey[200]),
                                    ),
                                    Text(
                                      '2',
                                      style: TextStyle(color: Colors.grey[200]),
                                    )
                                  ],
                                ),
                                Divider(
                                  color: Colors.grey,
                                  thickness: 1,
                                  height: 20,
                                  // space from right
                                ),
                                // Row(
                                //   crossAxisAlignment: CrossAxisAlignment.start,
                                //   mainAxisAlignment:
                                //       MainAxisAlignment.spaceBetween,
                                //   children: [
                                //     Text(
                                //       '----------------------------------------------------------',
                                //       style: TextStyle(color: Colors.grey[200]),
                                //     ),
                                //   ],
                                // ),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Total',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.grey[200]),
                                    ),
                                    Text(
                                      '188.00',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                          color: Colors.grey[200]),
                                    )
                                  ],
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: SizedBox(
                                        height: 40,
                                        child: ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                                backgroundColor: Color.fromARGB(
                                                    255, 61, 176, 38),
                                                shape: RoundedRectangleBorder(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            8))),
                                            onPressed: () {},
                                            child: Text(
                                              'Cash',
                                              style: TextStyle(
                                                  color: Colors.grey[200]),
                                            )),
                                      ),
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Expanded(
                                      child: SizedBox(
                                        height: 38,
                                        child: ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                              backgroundColor: Color.fromARGB(
                                                  255, 38, 176, 153),
                                              shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          8))),
                                          onPressed: () {
                                            showDialog(
                                              context: context,
                                              builder: (context) =>
                                                  VisualTenderDialog(),
                                            );
                                          },
                                          child: Text(
                                            '   Tender   ',
                                            style: TextStyle(
                                                color: Colors.grey[200]),
                                          ),
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        )
                        // Padding(
                        //   padding: const EdgeInsets.symmetric(horizontal: 15.0),
                        //   child: Container(
                        //     height: 70,
                        //     color: Color(0xFF29282A),
                        //     child:
                        //   ),
                        // )
                      ],
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class SingleItem extends StatelessWidget {
  const SingleItem({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {},
      child: Container(
          height: 110,
          width: 145,
          decoration: BoxDecoration(
            color: Color(0xFF29282A),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Row(
            children: [
              Container(
                width: 5,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 239, 201, 219),
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(6),
                      bottomLeft: Radius.circular(6)),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        'Lenvo Thinkpad X1 Carbon Gen 10 with 8GB RAM and thi',
                        style: GoogleFonts.roboto(color: Colors.white),
                      ),
                      Spacer(),
                      Text(
                        overflow: TextOverflow.ellipsis,
                        '\$100.00',
                        style: GoogleFonts.roboto(
                            color: Colors.grey[300],
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
              )
            ],
          )),
    );
  }
}

class scannedItem extends StatelessWidget {
  const scannedItem({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
          color: Color(0xFF363439), borderRadius: BorderRadius.circular(6)),
      child: Row(
        children: [
          InkWell(
            onTap: () {},
            child: Icon(
              Icons.cancel,
              color: Colors.white,
            ),
          ),
          SizedBox(
            width: 10,
          ),
          Expanded(
            child: InkWell(
              onTap: () {},
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          SizedBox(
                            width: 230,
                            child: Text(
                              overflow: TextOverflow.ellipsis,
                              '1 x Lenovo Thinkpad X1 Carbon Gen 10',
                              style: GoogleFonts.roboto(color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                      Text(
                        '\$100.00',
                        style: GoogleFonts.roboto(color: Colors.white),
                      )
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        'P.ID: 10001024  |  B: 10001024',
                        style: GoogleFonts.roboto(
                            color: Colors.grey[600], fontSize: 12),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class RefundWidget extends StatelessWidget {
  const RefundWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        padding: EdgeInsets.all(25),
        height: 350,
        width: 500,
        decoration: BoxDecoration(
          border: Border.all(width: 0.4, color: Colors.grey),
          color: Color(0xFF151515),
        ),
        child: Column(
          children: [
            Icon(
              Icons.reset_tv_outlined,
              size: 45,
              color: Colors.grey,
            ),
            SizedBox(
              height: 15,
            ),
            Text(
              'Enter Receipt Number to Complete Refund',
              style: GoogleFonts.montserrat(
                  fontSize: 18,
                  color: Colors.grey[200],
                  fontWeight: FontWeight.w500),
            ),
            SizedBox(
              height: 25,
            ),
            Text(
              'Receipt Number',
              style: GoogleFonts.poppins(
                color: Colors.grey[200],
              ),
            ),
            SizedBox(
              height: 5,
            ),
            SizedBox(
              height: 35,
              width: 300,
              child: TextField(
                decoration: InputDecoration(
                  contentPadding: EdgeInsets.all(5),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey),
                  ),
                  border: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.grey),
                  ),
                ),
              ),
            ),
            Spacer(),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                SizedBox(
                  height: 35,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xFFB03726),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(2))),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        'Close',
                        style: TextStyle(color: Colors.grey[200]),
                      )),
                ),
                SizedBox(
                  width: 10,
                ),
                SizedBox(
                  height: 35,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Color(0xFF363439),
                          shape: RoundedRectangleBorder(
                              side: BorderSide(
                                width: 0.3,
                                color: Colors.white,
                              ),
                              borderRadius: BorderRadius.circular(2))),
                      onPressed: () {},
                      child: Text(
                        'Ok',
                        style: TextStyle(color: Colors.grey[200]),
                      )),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
