import 'package:bitpro_hive/datasourse/receipt_quot_line_item_datasource.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/01_widgets/receipt_header_style_01.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/01_widgets/receipt_header_style_02.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/02_logic/receipt_on_top_funciton.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/01_widgets/get_line_item_from_inv.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/02_logic/receipt_calculation_functions.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/right_side_widget.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/default_settings_data.dart';
import 'package:bitpro_hive/model/settings/receipt_details_data.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_receipt_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_settings_db_service.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/dialogs/show_discount_value_or_percentage_dialog.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/bottom_panel_for_dialog.dart';
import 'package:bitpro_hive/widget/dialogs/balacance_receipt_dialog.dart';
import 'package:bitpro_hive/widget/dialogs/no_item_with_barcode_found_dialog.dart';
import 'package:bitpro_hive/widget/dialogs/receipt_tendor_dialog.dart';
import 'package:bitpro_hive/widget/dialogs/show_import_inventory_dialog.dart';
import 'package:bitpro_hive/widget/dialogs/show_specification_dialog.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:iconsax/iconsax.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:syncfusion_flutter_datagrid_export/export.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' hide Column, Row, Border;
import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/model/customer_data.dart';
import 'package:bitpro_hive/model/inventory_data.dart';
import 'package:bitpro_hive/model/specification_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_merchandise_db_service/inventory_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_promo_code_db_serice.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/shared/custom_top_nav_bar.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import '../../../../model/promo_code_data.dart';
import '../../../../shared/dialogs/discard_changes_dialog.dart';
import '../../../../shared/save_file_and_launch.dart';
import '../../../../shared/templates/tag/print_tag.dart';

class CreateEditReceiptQuotPage extends StatefulWidget {
  final EmployeeData userData;
  final List<CustomerData> customerDataLst;
  bool viewMode;
  final ReceiptOrQuotationData? selectedDbReceiptData;
  final bool isInvoice;
  bool isQuotation;
  int receiptLength;
  CreateEditReceiptQuotPage({
    Key? key,
    required this.userData,
    this.viewMode = false,
    required this.customerDataLst,
    this.selectedDbReceiptData,
    required this.isQuotation,
    required this.receiptLength,
    required this.isInvoice,
  }) : super(key: key);

  @override
  State<CreateEditReceiptQuotPage> createState() =>
      _CreateEditReceiptQuotPageState();
}

class _CreateEditReceiptQuotPageState extends State<CreateEditReceiptQuotPage> {
  late List<BitproGridColumnModel> _bitproGridColumnModel = [];

  final GlobalKey<SfDataGridState> _key = GlobalKey<SfDataGridState>();

  final TextEditingController _scanOrEnterBarcodeTypeAheadController =
      TextEditingController();
  FocusNode scanBarcodeFocusNode = FocusNode();
  final TextEditingController _searchForItemsTypeAheadController =
      TextEditingController();
  final TextEditingController _searchCustomerTypeAheadController =
      TextEditingController();

  DataGridController dataGridController = DataGridController();

  late List<CustomerData> customerDataLst;
  String regularReturnCreditDropDown = 'Regular';

  ///for design 02
  String? selectedPaymentType = 'Cash';

  bool viewMode = false;
  bool reloadDataOnPop = false;

  CustomerData? selectedCustomerData;
  CustomerBranchData? selectedCustomerBranchData;

  late ReceiptQuotLineItemDataSource receiptDataSource;
  List<PromoData> allPromotionDataLst = [];
  List<InventoryData> allInventoryDataLst = [];
  //receipt payment setting fields
  Map<dynamic, dynamic> allPaymentMethodAmountsInfo = {};
  String userMaxDiscount = '';
  String selectedProductImg = '';
  List<StoreData> allStoresData = [];
  late StoreData selectedStoreData;

  //need to check
  String createdBy = '';

  bool isLoading = true;
  bool showSelectCustomerError = false;
  String referenceNo = '';
  SpecificationData? specificationData;

  bool isAdvancePaymentEnabled = false;

  //
  late GeneralSettingsData generalSettingsData;

  double cartDiscountValue = 0;
  double cartDiscountPercentage = 0;

  late TaxSettingsData taxSettingsData;
  late ReceiptSettingData receiptSettingData;
  late ReceiptCalculationFunctions receiptCalculationFunctions;

  DateTime? customCreateDateTime;

  void initBitproGridColumnModel() {
    _bitproGridColumnModel = [
      BitproGridColumnModel(
          columnName: 'serialNumberForStyleColor',
          label: 's.no',
          width: double.nan,
          visible: false),
      BitproGridColumnModel(
          columnName: 'barcode',
          label: 'Barcode',
          width: double.nan,
          visible: false),
      BitproGridColumnModel(
          columnName: 'itemCode',
          label: staticTextTranslate('Item Code'),
          width: 110,
          visible: !widget.isInvoice),
      BitproGridColumnModel(
          columnName: 'productName',
          label: staticTextTranslate('Product Name'),
          width: 250),
      BitproGridColumnModel(
          columnName: 'qty',
          label: staticTextTranslate('Qty'),
          width: 80,
          allowEditing: true),
      BitproGridColumnModel(
          columnName: 'orgPrice',
          label: staticTextTranslate('Org.Price'),
          width: 100),
      BitproGridColumnModel(
          columnName: 'discount_percentage',
          label: staticTextTranslate('Disc %'),
          width: 65,
          allowEditing: true),
      BitproGridColumnModel(
        columnName: 'discount_value',
        label: staticTextTranslate('Disc \$'),
        width: 70,
        visible: false,
      ),
      BitproGridColumnModel(
          columnName: 'discount_value_wt',
          label: staticTextTranslate('Disc \$ WT'),
          width: 105,
          allowEditing: true),
      BitproGridColumnModel(
          columnName: 'priceWT',
          label: staticTextTranslate('Price W/T'),
          width: 120,
          allowEditing: true),
      BitproGridColumnModel(
          columnName: 'total', label: staticTextTranslate('Total'), width: 120),
    ];
  }

  List<LineItemData> getLatestLineItemList() {
    return receiptDataSource.lineItemData;
  }

  getData() async {
    initBitproGridColumnModel();
    taxSettingsData = await HiveSettingsDbService().getTaxSettingsData();
    receiptSettingData = await HiveSettingsDbService().getReceiptSettingsData();
    generalSettingsData =
        await HiveSettingsDbService().getGeneralSettingsData();
    allPromotionDataLst = await HivePromoDbService().fetchPromoData();
    allInventoryDataLst =
        await HiveInventoryDbService().fetchAllInventoryData();
    //updating store data
    allStoresData = await HiveStoreDbService().fetchAllStoresData();

    if (widget.viewMode && widget.selectedDbReceiptData != null) {
      //store init

      int index = allStoresData.indexWhere((element) =>
          element.docId ==
          (widget.selectedDbReceiptData!.isQuotation
              ? widget
                  .selectedDbReceiptData!.quotationBasicInfo!.selectedStoreDocId
              : widget.selectedDbReceiptData!.receiptBasicInfo!
                  .selectedStoreDocId));
      if (index != -1) {
        selectedStoreData = allStoresData.elementAt(index);
      }

      //selected customer
      int cIndex = widget.customerDataLst.indexWhere((element) =>
          element.customerId ==
          (widget.selectedDbReceiptData!.isQuotation
              ? widget
                  .selectedDbReceiptData!.quotationBasicInfo!.selectedCustomerID
              : widget.selectedDbReceiptData!.receiptBasicInfo!
                  .selectedCustomerID));
      if (cIndex != -1) {
        selectedCustomerData = widget.customerDataLst[cIndex];
        _searchCustomerTypeAheadController.text =
            selectedCustomerData!.customerName;

        //finding selected customer branch id
        if (selectedCustomerData!.customerBranchDataLst.isNotEmpty) {
          int cusBranchDocIdIndex = selectedCustomerData!.customerBranchDataLst
              .indexWhere((e) =>
                  e.docId ==
                  (widget.selectedDbReceiptData!.isQuotation
                      ? widget.selectedDbReceiptData!.quotationBasicInfo!
                          .selectedCustomerBranchDocId
                      : widget.selectedDbReceiptData!.receiptBasicInfo!
                          .selectedCustomerBranchDocId));
          if (cusBranchDocIdIndex != -1) {
            selectedCustomerBranchData = selectedCustomerData!
                .customerBranchDataLst[cusBranchDocIdIndex];
          }
        }
      }
      if (widget.selectedDbReceiptData!.receiptBasicInfo != null) {
        //Cart Discount
        cartDiscountPercentage = double.parse(widget
            .selectedDbReceiptData!.receiptBasicInfo!.cartDiscountPercentage);
        cartDiscountValue = double.parse(
            widget.selectedDbReceiptData!.receiptBasicInfo!.cartDiscountValue);
        //payment method
        allPaymentMethodAmountsInfo = widget.selectedDbReceiptData!
            .receiptBasicInfo!.allPaymentMethodAmountsInfo;
        //other
        isAdvancePaymentEnabled = widget
            .selectedDbReceiptData!.receiptBasicInfo!.isAdvancePaymentEnabled;
        regularReturnCreditDropDown =
            widget.selectedDbReceiptData!.receiptBasicInfo!.receiptType;
        referenceNo =
            widget.selectedDbReceiptData!.receiptBasicInfo!.referenceNo;
        specificationData =
            widget.selectedDbReceiptData!.receiptBasicInfo!.specificationInfo;
      } else if (widget.selectedDbReceiptData!.quotationBasicInfo != null) {
        //Cart Discount
        cartDiscountPercentage = double.parse(widget
            .selectedDbReceiptData!.quotationBasicInfo!.cartDiscountPercentage);
        cartDiscountValue = double.parse(widget
            .selectedDbReceiptData!.quotationBasicInfo!.cartDiscountValue);

        regularReturnCreditDropDown =
            widget.selectedDbReceiptData!.quotationBasicInfo!.receiptType;
        referenceNo =
            widget.selectedDbReceiptData!.quotationBasicInfo!.referenceNo;
        specificationData =
            widget.selectedDbReceiptData!.quotationBasicInfo!.specificationInfo;
        // selectedPaymentType = widget.selectedDbReceiptData!.receiptBasicInfo!
        //     .invoiceData!.selectedPaymentType;
      }
    } else {
      //getting default selected store
      selectedStoreData = await HiveStoreDbService().getSelectedStoreData();
    }

    //other fields init
    customerDataLst = widget.customerDataLst;
    createdBy = widget.userData.empBasicInfoData.username;
    userMaxDiscount =
        widget.userData.empWorkAndRolesData.discountPercentage ?? '';
    receiptDataSource = ReceiptQuotLineItemDataSource(
        dataGridController: dataGridController,
        receiptLineItemData:
            widget.viewMode ? widget.selectedDbReceiptData!.lineItemsData : [],
        maxDiscount:
            widget.userData.empWorkAndRolesData.discountPercentage ?? '',
        context: context,
        taxSettingsData: taxSettingsData);

    viewMode = widget.viewMode;

    if (widget.isInvoice &&
        widget.viewMode &&
        widget.selectedDbReceiptData != null &&
        widget.selectedDbReceiptData!.isInvoiceFinilized() == false) {
      viewMode = false;
      widget.viewMode = false;
    }
    setState(() {
      isLoading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    getData();

    dataGridController.addListener(() {
      setState(() {});
    });
    WidgetsBinding.instance
        .addPostFrameCallback((_) => scanBarcodeFocusNode.requestFocus());
  }

  void updatedDataSourceWithNewItem(LineItemData newItem) {
    List<LineItemData> selectedLocalReceiptData = getLatestLineItemList();
    selectedLocalReceiptData.add(newItem);

    receiptDataSource = ReceiptQuotLineItemDataSource(
        dataGridController: dataGridController,
        receiptLineItemData: selectedLocalReceiptData,
        maxDiscount: userMaxDiscount,
        context: context,
        taxSettingsData: taxSettingsData);
    setState(() {});
  }

  Future<void> _shortcutKeyOnTap(String name) async {
    if (name == 'openTendor') {
      await showReceiptTenderDialog(
          context: context,
          viewMode: viewMode,
          lineItemList: getLatestLineItemList(),
          selectedDbReceiptData: widget.selectedDbReceiptData,
          receiptCalculationFunctions: receiptCalculationFunctions,
          allPaymentMethodAmountsInfo: allPaymentMethodAmountsInfo,
          cartDiscountPercentage: cartDiscountPercentage,
          cartDiscountValue: cartDiscountValue,
          isAdvancePaymentEnabled: isAdvancePaymentEnabled,
          receiptSettingData: receiptSettingData,
          taxSettingsData: taxSettingsData,
          printAndUploadOnTap: receiptOnTapBtn);
    } else if (name == 'printUpdatedOnTap' && !viewMode) {
      await receiptOnTapBtn(printAndSave: true);
    } else if (name == 'updatedOnTap' && !viewMode) {
      await receiptOnTapBtn(saveOnly: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) return showLoading(withScaffold: true);
    receiptCalculationFunctions = ReceiptCalculationFunctions(
        taxPer: taxSettingsData.taxPercentage,
        selectedLocalReceiptData: getLatestLineItemList(),
        cartDiscountValueWt: cartDiscountValue,
        cartDiscountPercentage: cartDiscountPercentage);

    return CustomNavBar(
      pageName: widget.isInvoice
          ? "Invoice"
          : widget.isQuotation
              ? staticTextTranslate('Quotation')
              : staticTextTranslate('Receipt'),
      child: Shortcuts(
        shortcuts: <LogicalKeySet, Intent>{
          LogicalKeySet(LogicalKeyboardKey.f8):
              const ReceiptCallbackShortcutsIntent(name: 'openTendor'),
          LogicalKeySet(LogicalKeyboardKey.f12):
              const ReceiptCallbackShortcutsIntent(name: 'printUpdatedOnTap'),
          LogicalKeySet(LogicalKeyboardKey.f11):
              const ReceiptCallbackShortcutsIntent(name: 'updatedOnTap'),
        },
        child: Actions(
          actions: <Type, Action<Intent>>{
            ReceiptCallbackShortcutsIntent:
                CallbackAction<ReceiptCallbackShortcutsIntent>(
                    onInvoke: (ReceiptCallbackShortcutsIntent intent) =>
                        _shortcutKeyOnTap(intent.name)),
          },
          child: Scaffold(
            backgroundColor: homeBgColor,
            body: Container(
              color: Colors.white,
              child: Row(
                children: [
                  leftSideWidget(),
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width > 1250
                                ? MediaQuery.of(context).size.width - 455
                                : 700,
                            height: MediaQuery.of(context).size.height - 80,
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Container(
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(width: 0.5),
                                      borderRadius: BorderRadius.circular(4)),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      receiptHeaderWidget(),
                                      Container(
                                        height: 0.5,
                                        color: Colors.black,
                                      ),
                                      BitproGridTable(
                                        sfDataGridKey: _key,
                                        onChangeRefershFunction: () {
                                          setState(() {});
                                        },
                                        // onChangeSelectedRowIndex: (i) {
                                        // try {
                                        //   String itemCode =
                                        //       getLatestLineItemList()[i]
                                        //           .itemCode;

                                        //   int index = allInventoryDataLst
                                        //       .indexWhere((e) =>
                                        //           e.itemCode == itemCode);
                                        //   selectedProductImg =
                                        //       allInventoryDataLst[index]
                                        //           .productImg;
                                        // setState(() {});
                                        // } catch (e) {}
                                        // },
                                        dataGridController: dataGridController,
                                        source: receiptDataSource,
                                        allowEditing: !viewMode,
                                        bitproGridColumnModel:
                                            _bitproGridColumnModel,
                                      ),
                                    ],
                                  )),
                            ),
                          ),
                          rightSideWidget()
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> receiptOnTapBtn({
    bool printOnly = false,
    bool printAndSave = false,
    bool saveOnly = false,
    bool isFinialized = false,
  }) async {
    setState(() {
      isLoading = true;
    });

    ReceiptOrQuotationData? receiptOrQuotationData =
        await ReceiptOnTopFunciton(context: context)
            .getReceiptQuoationModelData(
                selectedCustomerBranchData: selectedCustomerBranchData,
                customCreatedDate: customCreateDateTime,
                isFinialized: isFinialized,
                isInvoice: widget.isInvoice,
                selectedPaymentType: selectedPaymentType,
                isAdvancePaymentEnabled: isAdvancePaymentEnabled,
                isQuotation: widget.isQuotation,
                receiptLength: widget.receiptLength,
                cartDiscountValue: cartDiscountValue,
                cartDiscountPercentage: cartDiscountPercentage,
                selectedStoreData: selectedStoreData,
                referenceNo: referenceNo,
                createdBy: createdBy,
                specificationData: specificationData,
                selectedDbReceiptData: widget.selectedDbReceiptData,
                selectedCustomerData: selectedCustomerData,
                selectedLineItem: getLatestLineItemList(),
                receiptCalculationFunctions: receiptCalculationFunctions,
                allPaymentMethodAmountsInfo: allPaymentMethodAmountsInfo,
                regularReturnCreditDropDown: regularReturnCreditDropDown);

    if (receiptOrQuotationData != null) {
      String tenderAmount = receiptCalculationFunctions
          .calculateTenderedAmount(allPaymentMethodAmountsInfo);
      String receiptTotal = receiptCalculationFunctions.receiptTotal;
      String changeAmount = regularReturnCreditDropDown == 'Regular'
          ? receiptCalculationFunctions
              .calculateBalanceAmount(allPaymentMethodAmountsInfo)
          : receiptTotal;

      bool showChangeWindow = regularReturnCreditDropDown == 'Credit'
          ? false
          : true; // cash != '0' ? true : false;

      if (printOnly || printAndSave) {
        await ReceiptOnTopFunciton(context: context).printReceiptQuotation(
            receiptOrQuotationData: receiptOrQuotationData,
            isQuotation: widget.isQuotation,
            selectedCustomerData: selectedCustomerData,
            tenderAmount: tenderAmount,
            changeAmount: changeAmount);
      }

      if (printAndSave || saveOnly) {
        reloadDataOnPop = true;
        await HiveReceiptDbService().addEditReceipt(
          dbReceiptData: receiptOrQuotationData,
          allInventoryDataLst: allInventoryDataLst,
          updateInventoryQty: widget.isInvoice ? false : true,
        );
        resetDataFunction();

        if (showChangeWindow &&
            widget.isQuotation == false &&
            widget.isInvoice == false) {
          await changeWindowDialog(
              subtotal: receiptTotal,
              tendered: tenderAmount,
              change: changeAmount,
              viewMode: widget.viewMode,
              context: context);
        }
      }
      if (printOnly) {
        Navigator.pop(context);
      }
    }
    setState(() {
      isLoading = false;
    });
  }

  resetDataFunction() {
    //resetting data
    customCreateDateTime = null;
    widget.receiptLength = widget.receiptLength + 1;
    scanBarcodeFocusNode.requestFocus();
    selectedCustomerData = null;
    _searchCustomerTypeAheadController.clear();
    allPaymentMethodAmountsInfo = {};
    cartDiscountPercentage = 0;
    cartDiscountValue = 0;
    isAdvancePaymentEnabled = false;
    receiptDataSource = ReceiptQuotLineItemDataSource(
        context: context,
        dataGridController: dataGridController,
        maxDiscount: userMaxDiscount,
        receiptLineItemData: [],
        taxSettingsData: taxSettingsData);
    referenceNo = '';
    regularReturnCreditDropDown = 'Regular';
  }

  Widget receiptHeaderWidget() {
    if (widget.isInvoice) {
      return IgnorePointer(
        ignoring: viewMode,
        child: ReceiptHeaderStyle02(
          allStoresData: allStoresData,
          selectedStoreData: selectedStoreData,
          onChangePaymentType: (String p0) {
            setState(() {
              selectedPaymentType = p0;
            });
          },
          onChangeReceptType: (p0) {
            setState(() {
              regularReturnCreditDropDown = p0;
            });
          },
          onChangedSelectedStore:
              viewMode && widget.selectedDbReceiptData != null
                  ? null
                  : (val) {
                      setState(() {
                        int index = allStoresData
                            .indexWhere((element) => element.docId == val);
                        if (index != -1) {
                          selectedStoreData = allStoresData.elementAt(index);
                          setState(() {});
                        }
                      });
                    },
          selectedPaymentType: selectedPaymentType,
          selectedReceiptType: regularReturnCreditDropDown,
          taxSettingsData: taxSettingsData,
          onAdd: (lineItemData) {
            updatedDataSourceWithNewItem(lineItemData);

            setState(() {});
          },
        ),
      );
    }
    return ReceiptHeaderStyle01(
        viewMode: viewMode,
        onNewItemCreatedFunction: () async {
          //refreshing inventory data
          allInventoryDataLst =
              await HiveInventoryDbService().fetchAllInventoryData();
          setState(() {});
        },
        showCustomCreateDate: receiptSettingData.showCustomCrateDate,
        receiptSettingData: receiptSettingData,
        userData: widget.userData,
        taxSettingsData: taxSettingsData,
        updatedDataSourceWithNewItem: updatedDataSourceWithNewItem,
        selectedProductImg: selectedProductImg,
        allStoresData: allStoresData,
        regularReturnCreditDropDown: regularReturnCreditDropDown,
        scanOrEnterBarcodeTypeAheadController:
            _scanOrEnterBarcodeTypeAheadController,
        searchForItemsTypeAheadController: _searchForItemsTypeAheadController,
        allInventoryDataLst: allInventoryDataLst,
        scanBarcodeFocusNode: scanBarcodeFocusNode,
        customDateTime: customCreateDateTime,
        onChangeCustomCreateDate: (p0) {
          setState(() {
            customCreateDateTime = p0;
          });
        },
        onFieldSubmittedScanOrEnterBarcode: (val) async {
          List res = allInventoryDataLst
              .where((e) =>
                  e.barcode.toLowerCase() == val.toLowerCase() ||
                  e.itemCode.toLowerCase() == val.toLowerCase())
              .toList();
          if (res.isNotEmpty) {
            InventoryData inv = res.first;

            // addSearcheSubmittedInvData(inv);
            LineItemData? lineItemData = await getLineItemFromInventory(
                selectedInventoryData: inv,
                receiptSettingData: receiptSettingData,
                context: context,
                taxPercentage: taxSettingsData.taxPercentage);
            if (lineItemData != null) {
              updatedDataSourceWithNewItem(lineItemData);
            }
            _scanOrEnterBarcodeTypeAheadController.clear();
          } else {
            _scanOrEnterBarcodeTypeAheadController.clear();

            showNoItemWithBarcodeFoundDialog(context, val);
          }
          scanBarcodeFocusNode.requestFocus();
          setState(() {});
        },
        onChangedReceiptType:
            widget.viewMode && widget.selectedDbReceiptData != null
                ? null
                : (val) {
                    setState(() {
                      showSelectCustomerError = false;
                      regularReturnCreditDropDown = val ?? 'Regular';
                    });
                  },
        onChangedSelectedStore: viewMode && widget.selectedDbReceiptData != null
            ? null
            : (val) {
                setState(() {
                  int index = allStoresData
                      .indexWhere((element) => element.docId == val);
                  if (index != -1) {
                    selectedStoreData = allStoresData.elementAt(index);
                    setState(() {});
                  }
                });
              },
        selectedStoreData: selectedStoreData);
  }

  Widget leftSideWidget() {
    return Container(
      color: const Color.fromARGB(255, 43, 43, 43),
      child: Column(
        children: [
          SideMenuButton(
            label: 'Back',
            iconPath: 'assets/icons/back.png',
            buttonFunction: () async {
              if (viewMode) {
                Navigator.pop(context);
              } else {
                showDiscardChangesDialog(context,
                    receiptOrQuotation: reloadDataOnPop);
              }
            },
          ),
          if (!viewMode)
            SideMenuButton(
              label: 'Remove Item',
              iconPath: 'assets/icons/remove.png',
              enable: dataGridController.selectedIndex != -1,
              buttonFunction: () async {
                if (dataGridController.selectedIndex != -1) {
                  List<LineItemData> lineItemLst = getLatestLineItemList();
                  lineItemLst.removeAt(dataGridController.selectedIndex);

                  dataGridController.selectedRow = null;

                  receiptDataSource = ReceiptQuotLineItemDataSource(
                      dataGridController: dataGridController,
                      receiptLineItemData: lineItemLst,
                      maxDiscount: userMaxDiscount,
                      context: context,
                      taxSettingsData: taxSettingsData);
                  setState(() {});
                  scanBarcodeFocusNode.requestFocus();
                }
              },
            ),
          if (widget.isQuotation == false && widget.isInvoice == false) ...[
            const SizedBox(
              height: 30,
            ),
            SideMenuButton(
              label: 'Exports',
              iconPath: 'assets/icons/export.png',
              buttonFunction: () async {
                setState(() {
                  isLoading = true;
                });
                final Workbook workbook =
                    _key.currentState!.exportToExcelWorkbook();
                final List<int> bytes = workbook.saveAsStream();
                workbook.dispose();
                await saveAndLaunchFile(bytes, fileExtension: 'xlsx', context);
                setState(() {
                  isLoading = false;
                });
              },
            ),
            if (!viewMode)
              SideMenuButton(
                label: 'Import Items',
                iconPath: 'assets/icons/import.png',
                buttonFunction: () async {
                  showReceiptCreateImportDialog(
                      allInventoryDataLst: allInventoryDataLst,
                      context: context);
                },
              )
          ],
          if (viewMode)
            SideMenuButton(
              label: 'Print',
              iconPath: 'assets/icons/print.png',
              buttonFunction: () async {
                receiptOnTapBtn(printOnly: true);
              },
            ),
          if (widget.isQuotation == false) ...[
            if (widget.isInvoice == false)
              SideMenuButton(
                  label: 'Print Tag',
                  enable: dataGridController.selectedRow != null,
                  iconPath: 'assets/icons/tag.png',
                  buttonFunction: () async {
                    if (dataGridController.selectedRow != null) {
                      String selectedBarcodeValue = '';
                      for (var c
                          in dataGridController.selectedRow!.getCells()) {
                        if (c.columnName == 'barcode') {
                          selectedBarcodeValue = c.value;
                        }
                      }

                      List<PrintTagData> allPrintTagDataLst =
                          getLatestLineItemList().map((e) {
                        int ohQty = -1;
                        String priceWT = '';
                        for (InventoryData inv in allInventoryDataLst) {
                          if (inv.barcode == e.barcode) {
                            ohQty = int.tryParse(inv.ohQtyForDifferentStores[
                                    selectedStoreData.docId]) ??
                                0;
                            priceWT = inv.priceWT;
                          }
                        }
                        return PrintTagData(
                            storeName: selectedStoreData.storeName,
                            barcodeValue: e.barcode,
                            docQty: double.tryParse(e.qty) ?? 0,
                            itemCode: e.itemCode,
                            productName: e.productName,
                            onHandQty: ohQty,
                            priceWt: priceWT);
                      }).toList();
                      int i = allPrintTagDataLst.indexWhere((element) =>
                          element.barcodeValue == selectedBarcodeValue);
                      PrintTagData selectedPrintTagData =
                          allPrintTagDataLst.elementAt(i);
                      buildTagPrint(
                          context: context,
                          allPrintTagDataLst: allPrintTagDataLst,
                          selectedPrintTagData: selectedPrintTagData);
                    }
                  }),
            const SizedBox(
              height: 10,
            ),
            SideMenuButton(
              label: 'Reference no',
              iconPath: 'assets/icons/reference.png',
              buttonFunction: () async {
                String ref = referenceNo;
                showDialog(
                    context: context,
                    builder: (context) {
                      return StatefulBuilder(builder: (context, setState2) {
                        return Dialog(
                          child: SizedBox(
                            height: 220,
                            width: 380,
                            child: Column(
                              children: [
                                BlackTopPanelForDialogWindow(
                                    label: 'Reference Number'),
                                Expanded(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      SizedBox(
                                        width: 250,
                                        child: TextFormField(
                                            autofocus: true,
                                            initialValue: referenceNo,
                                            enabled: !viewMode,
                                            style:
                                                const TextStyle(fontSize: 16),
                                            decoration: const InputDecoration(
                                                isDense: true,
                                                hintText: 'Reference No.',
                                                contentPadding:
                                                    EdgeInsets.symmetric(
                                                        vertical: 10,
                                                        horizontal: 15),
                                                border: OutlineInputBorder()),
                                            onChanged: (val) {
                                              if (val.isNotEmpty) {
                                                setState(() {
                                                  ref = val;
                                                });
                                                setState2(() {});
                                              }
                                            }),
                                      ),
                                    ],
                                  ),
                                ),
                                Align(
                                    alignment: Alignment.bottomCenter,
                                    child: BottomPanelForDialog(buttons: [
                                      OnPageGreyButton(
                                        label: 'Cancel',
                                        width: 130,
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      OnPageButton(
                                        label: 'Save',
                                        onPressed: () {
                                          Navigator.pop(context);
                                          referenceNo = ref;
                                          setState(() {});
                                          setState2(() {});
                                        },
                                        icon: Iconsax.save_add,
                                        width: 130,
                                      ),
                                    ])),
                              ],
                            ),
                          ),
                        );
                      });
                    });
              },
            ),
            if (widget.isInvoice == false)
              SideMenuButton(
                label: staticTextTranslate('Specification'),
                iconPath: 'assets/icons/reference.png',
                buttonFunction: () async {
                  var res = await showSpecificationDialog(
                      context: context,
                      specificationData: specificationData,
                      viewMode: viewMode);
                  if (res != null) {
                    specificationData = res;
                    setState(() {});
                  }
                },
              ),
            if (generalSettingsData.showOverallDiscountInReceiptCreate)
              SideMenuButton(
                label: 'Cart Discount',
                iconPath: 'assets/icons/discount.png',
                buttonFunction: () async {
                  double rTotal = 0;
                  // //calculating total
                  for (LineItemData v in getLatestLineItemList()) {
                    double d = 0;
                    d = double.tryParse(v.totalWt) ?? 0;
                    rTotal += d;
                  }

                  if (rTotal == 0) {
                    showToast('Receipt total is 0, please add items.', context);
                  } else {
                    var res = await showDiscountValueOrPercentageEnterDialog(
                        showOverallDiscountPerTabInReceiptCreate:
                            generalSettingsData
                                .showOverallDiscountInReceiptCreate,
                        context: context,
                        viewOnly: viewMode,
                        discountPer: cartDiscountPercentage.toString(),
                        discountValue: doubleToString(cartDiscountValue));

                    if (res != null && viewMode == false) {
                      double lDisVal = double.tryParse(res['disVal']) ?? 0;
                      double lDisPer = double.tryParse(res['disPer']) ?? 0;

                      if (res['selectedTabIndex'] == 0) {
                        //disvalue is selected and calculate discount percentage
                        // Discount% = (Discount/Listed Price) ×100
                        lDisPer = (lDisVal / rTotal) * 100;
                      } else {
                        //disper is selected and calcualte discount value
                        // (X/100) * Y
                        lDisVal = (lDisPer / 100) * rTotal;
                      }

                      cartDiscountPercentage = lDisPer;
                      cartDiscountValue = lDisVal;

                      setState(() {});
                    }
                  }
                },
              ),
          ]
        ],
      ),
    );
  }

  Widget rightSideWidget() {
    return ReceiptQuotRightSideWidget(
      selectCustomerBranch: selectedCustomerBranchData,
      onTapSelectCustomerBranch: (CustomerBranchData val) {
        setState(() {
          selectedCustomerBranchData = val;
        });
      },
      viewMode: viewMode,
      isInvoice: widget.isInvoice,
      selectedDbReceiptData: widget.selectedDbReceiptData,
      isQuotation: widget.isQuotation,
      customerDataLst: customerDataLst,
      selectedCustomerData: selectedCustomerData,
      userData: widget.userData,
      showSelectCustomerError: showSelectCustomerError,
      onChangeSelectedCustomerData: (CustomerData? val) {
        selectedCustomerData = val;

        selectedCustomerBranchData = null;

        _searchCustomerTypeAheadController.text =
            val == null ? '' : val.customerName;
        showSelectCustomerError = false;

        setState(() {});
      },
      updatedCustomerDataList: (List<CustomerData> val) {
        customerDataLst = val;
        setState(() {});
      },
      searchCustomerTypeAheadController: _searchCustomerTypeAheadController,
      regularReturnCreditDropDown: regularReturnCreditDropDown,
      receiptTotalQty: receiptCalculationFunctions.receiptTotalQty,
      receiptDisPer: receiptCalculationFunctions.receiptDiscountPer,
      receiptDisValue: receiptCalculationFunctions.receiptDiscountValueWt,
      receiptTaxPer: receiptCalculationFunctions.receiptTaxPer,
      receiptTaxValue: receiptCalculationFunctions.receiptTaxValue,
      receiptTotal: receiptCalculationFunctions.receiptTotal,
      receiptTotalBeforeTAx: receiptCalculationFunctions.receiptTotalBeforeTax,
      onTapMainBtn2: widget.selectedDbReceiptData != null &&
              widget.selectedDbReceiptData!.isInvoiceType() &&
              widget.selectedDbReceiptData!.isInvoiceFinilized() == true
          ? null
          : () async {
              await receiptOnTapBtn(isFinialized: true, printAndSave: true);
            },
      onTapMainBtn: widget.selectedDbReceiptData != null &&
              widget.selectedDbReceiptData!.isInvoiceType() &&
              widget.selectedDbReceiptData!.isInvoiceFinilized() == true
          ? null
          : () async {
              if (widget.isInvoice) {
                await receiptOnTapBtn(isFinialized: false, printAndSave: true);
              } else if (widget.isQuotation) {
                if (widget.viewMode == false) {
                  setState(() {
                    isLoading = true;
                  });
                  await _shortcutKeyOnTap('printUpdatedOnTap');
                  setState(() {
                    isLoading = false;
                  });
                  Navigator.pop(context, true);
                }
              } else {
                if (regularReturnCreditDropDown == 'Credit') {
                  if (selectedCustomerData == null) {
                    showToast('Please select a customer', context);
                    setState(() {
                      showSelectCustomerError = true;
                    });
                  } else {
                    await _shortcutKeyOnTap('printUpdatedOnTap');
                  }
                } else {
                  await _shortcutKeyOnTap('openTendor');
                }
              }
            },
    );
  }
}

class BoxForSpecification extends StatelessWidget {
  String hintText = '';
  String? initialValue;
  Function(String)? onChange;
  bool readOnly;

  BoxForSpecification({
    required this.hintText,
    this.initialValue,
    this.onChange,
    this.readOnly = true,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 140,
      child: TextFormField(
        onChanged: onChange,
        initialValue: initialValue,
        readOnly: readOnly,
        style: const TextStyle(fontSize: 17, color: Colors.black),
        decoration: InputDecoration(
          enabledBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.zero,
            borderSide: BorderSide(width: 1, color: Colors.grey),
          ),
          isDense: true,
          hintText: hintText,
          hintStyle: TextStyle(color: Colors.black, fontSize: 16),
          contentPadding:
              const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
          border: const OutlineInputBorder(borderRadius: BorderRadius.zero),
        ),
      ),
    );
  }
}

class ReceiptCallbackShortcutsIntent extends Intent {
  const ReceiptCallbackShortcutsIntent({required this.name});

  final String name;
}
