import 'dart:io';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/01_widgets/get_line_item_from_inv.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/settings/receipt_details_data.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:iconsax/iconsax.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/01_widgets/selectInventoryItemPage.dart';
import 'package:bitpro_hive/model/inventory_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:intl/intl.dart';

class ReceiptHeaderStyle01 extends StatefulWidget {
  final bool viewMode;
  final EmployeeData userData;
  final TaxSettingsData taxSettingsData;
  final String selectedProductImg;
  final List<StoreData> allStoresData;
  final StoreData selectedStoreData;
  final String regularReturnCreditDropDown;
  final TextEditingController scanOrEnterBarcodeTypeAheadController;
  final TextEditingController searchForItemsTypeAheadController;
  final List<InventoryData> allInventoryDataLst;
  final FocusNode scanBarcodeFocusNode;
  final ReceiptSettingData receiptSettingData;
  final DateTime? customDateTime;
  final Function(LineItemData) updatedDataSourceWithNewItem;
  final Function(String?)? onChangedSelectedStore;
  final void Function(String?)? onChangedReceiptType;
  final Function(String)? onFieldSubmittedScanOrEnterBarcode;
  final Function(DateTime?) onChangeCustomCreateDate;
  final Function? onNewItemCreatedFunction;
  final bool showCustomCreateDate;
  const ReceiptHeaderStyle01(
      {super.key,
      required this.viewMode,
      required this.userData,
      required this.taxSettingsData,
      required this.updatedDataSourceWithNewItem,
      required this.selectedProductImg,
      required this.allStoresData,
      required this.onChangedSelectedStore,
      required this.selectedStoreData,
      this.onChangedReceiptType,
      required this.regularReturnCreditDropDown,
      required this.searchForItemsTypeAheadController,
      required this.scanOrEnterBarcodeTypeAheadController,
      required this.allInventoryDataLst,
      this.onFieldSubmittedScanOrEnterBarcode,
      this.onNewItemCreatedFunction,
      required this.scanBarcodeFocusNode,
      required this.receiptSettingData,
      required this.onChangeCustomCreateDate,
      required this.customDateTime,
      required this.showCustomCreateDate});

  @override
  State<ReceiptHeaderStyle01> createState() => _ReceiptHeaderStyle01State();
}

class _ReceiptHeaderStyle01State extends State<ReceiptHeaderStyle01> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.grey,
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(4), topRight: Radius.circular(4)),
      ),
      width: double.maxFinite,
      // height: 120,
      constraints: BoxConstraints(minHeight: 120),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 10,
          vertical: 5,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      filters(),
                      const SizedBox(
                        width: 10,
                      ),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(4),
                          gradient: const LinearGradient(
                              end: Alignment.bottomCenter,
                              colors: [
                                Color.fromARGB(255, 12, 65, 114),
                                Color.fromARGB(255, 12, 65, 114),
                              ],
                              begin: Alignment.topCenter),
                        ),
                        height: 35,
                        width: 35,
                        margin: const EdgeInsets.only(top: 0),
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              elevation: 0,
                              padding: const EdgeInsets.all(0),
                              backgroundColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ),
                            onPressed: () async {
                              if (widget.viewMode == false) {
                                List<InventoryData> selectedInventoryDataLst =
                                    await showDialog(
                                  context: context,
                                  builder: (context) {
                                    return Dialog(
                                      child: SelectInventoryItemPage(
                                        onNewItemCreatedFunction:
                                            widget.onNewItemCreatedFunction,
                                        userData: widget.userData,
                                      ),
                                    );
                                  },
                                );

                                for (var inv in selectedInventoryDataLst) {
                                  LineItemData? res =
                                      await getLineItemFromInventory(
                                          receiptSettingData:
                                              widget.receiptSettingData,
                                          selectedInventoryData: inv,
                                          context: context,
                                          taxPercentage: widget
                                              .taxSettingsData.taxPercentage);
                                  if (res != null) {
                                    widget.updatedDataSourceWithNewItem(res);
                                  }
                                }
                              }
                            },
                            child: const Icon(
                              Iconsax.d_cube_scan,
                              size: 19,
                              color: Colors.white,
                            )),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Wrap(
                    runSpacing: 10,
                    children: [
                      Container(
                          width: 220,
                          height: 35,
                          // margin: const EdgeInsets.only(top: 10, bottom: 10),
                          decoration: BoxDecoration(
                              border:
                                  Border.all(color: Colors.black, width: 0.5),
                              color: const Color.fromARGB(255, 255, 255, 255),
                              borderRadius: BorderRadius.circular(4)),
                          padding: const EdgeInsets.only(right: 10, left: 10),
                          child: DropdownButton<String>(
                            isExpanded: true,
                            value: widget.regularReturnCreditDropDown,
                            underline: const SizedBox(),
                            items: <String>['Regular', 'Return', 'Credit']
                                .map((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(staticTextTranslate(value),
                                    style: TextStyle(
                                        fontSize: getMediumFontSize + 2)),
                              );
                            }).toList(),
                            onChanged: widget.onChangedReceiptType,
                          )),
                      const SizedBox(
                        width: 10,
                      ),
                      Container(
                          width: 220,
                          height: 35,
                          // margin: const EdgeInsets.only(top: 10, bottom: 10),
                          decoration: BoxDecoration(
                              border:
                                  Border.all(color: Colors.black, width: 0.5),
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(4)),
                          padding: const EdgeInsets.only(right: 10, left: 10),
                          child: DropdownButton<String>(
                              isExpanded: true,
                              value: widget.selectedStoreData.docId,
                              underline: const SizedBox(),
                              items:
                                  widget.allStoresData.map((StoreData value) {
                                return DropdownMenuItem<String>(
                                  value: value.docId,
                                  child: Text(
                                      overflow: TextOverflow.ellipsis,
                                      staticTextTranslate(value.storeName),
                                      style: TextStyle(
                                          fontSize: getMediumFontSize)),
                                );
                              }).toList(),
                              onChanged: widget.onChangedSelectedStore)),
                      if (widget.showCustomCreateDate) ...[
                        const SizedBox(
                          width: 10,
                        ),
                        GestureDetector(
                          onTap: () async {
                            DateTime? res = await showDatePicker(
                                context: context,
                                firstDate: DateTime(1900),
                                lastDate: DateTime(5000));

                            if (res != null) {
                              widget.onChangeCustomCreateDate(res);
                            }
                          },
                          child: Container(
                              width: 220,
                              height: 35,
                              // margin: const EdgeInsets.only(top: 10, bottom: 10),
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Colors.black, width: 0.5),
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(4)),
                              padding:
                                  const EdgeInsets.only(right: 10, left: 10),
                              alignment: Alignment.centerLeft,
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      widget.customDateTime != null
                                          ? DateFormat('dd/MM/yyyy')
                                              .format(widget.customDateTime!)
                                          : 'Custom Created Date',
                                      style: TextStyle(
                                          fontSize: getMediumFontSize + 2,
                                          color: widget.customDateTime != null
                                              ? Colors.black
                                              : Colors.grey[700]),
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: widget.customDateTime == null
                                        ? null
                                        : () {
                                            if (widget.customDateTime != null) {
                                              widget.onChangeCustomCreateDate(
                                                  null);
                                            }
                                          },
                                    child: Icon(
                                        widget.customDateTime == null
                                            ? Icons.calendar_month
                                            : Icons.cancel,
                                        size: 20,
                                        color: Colors.grey[700]),
                                  )
                                ],
                              )),
                        )
                      ]
                    ],
                  )
                ],
              ),
            ),
            SizedBox(
                width: 120,
                height: 120,
                child: Card(
                    shape: RoundedRectangleBorder(
                        side: const BorderSide(width: 0.5, color: Colors.black),
                        borderRadius: BorderRadius.circular(4)),
                    elevation: 0,
                    color: Colors.white,
                    child: widget.selectedProductImg.isNotEmpty
                        ? ClipRRect(
                            borderRadius: BorderRadius.circular(4),
                            child: Image.file(
                              File(widget.selectedProductImg),
                              // fit: BoxFit.cover,
                            ),
                          )
                        : const Icon(
                            Icons.image,
                            size: 40,
                            color: Color.fromARGB(255, 196, 196, 196),
                          ))),
          ],
        ),
      ),
    );
  }

  filters() {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0),
      child: Row(
        children: [
          Container(
            width: 220,
            height: 35,
            decoration: BoxDecoration(
                border: Border.all(color: Colors.black, width: 0.5),
                color: const Color.fromARGB(255, 255, 255, 255),
                borderRadius: BorderRadius.circular(4)),
            padding: const EdgeInsets.only(right: 0, bottom: 3),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  padding: const EdgeInsets.only(top: 3),
                  onPressed: () {
                    widget.scanOrEnterBarcodeTypeAheadController.clear();

                    setState(() {});
                  },
                  splashRadius: 1,
                  icon:
                      widget.scanOrEnterBarcodeTypeAheadController.text.isEmpty
                          ? const Icon(Iconsax.scan_barcode, size: 19)
                          : Icon(Icons.clear,
                              size: 19,
                              color: widget
                                      .scanOrEnterBarcodeTypeAheadController
                                      .text
                                      .isEmpty
                                  ? Colors.grey[900]
                                  : Colors.black),
                ),
                Flexible(
                    child: TextFormField(
                        enabled: !widget.viewMode,
                        focusNode: widget.scanBarcodeFocusNode,
                        controller:
                            widget.scanOrEnterBarcodeTypeAheadController,
                        onChanged: (val) {
                          setState(() {});
                        },
                        decoration: InputDecoration(
                          hintText:
                              staticTextTranslate('Scan or enter barcode'),
                          hintStyle: TextStyle(color: Colors.grey[800]),
                          contentPadding:
                              const EdgeInsets.only(bottom: 13, right: 5),
                          border: InputBorder.none,
                        ),
                        onFieldSubmitted:
                            widget.onFieldSubmittedScanOrEnterBarcode)),
              ],
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          Container(
            width: 220,
            height: 35,
            decoration: BoxDecoration(
                border: Border.all(color: Colors.black, width: 0.5),
                color: Colors.white,
                borderRadius: BorderRadius.circular(4)),
            padding: const EdgeInsets.only(right: 10, bottom: 3),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  padding: const EdgeInsets.only(top: 3),
                  onPressed: () {
                    widget.searchForItemsTypeAheadController.clear();

                    setState(() {});
                  },
                  splashRadius: 1,
                  icon: Icon(
                      widget.searchForItemsTypeAheadController.text.isEmpty
                          ? CupertinoIcons.search
                          : Icons.clear,
                      size: 18,
                      color:
                          widget.searchForItemsTypeAheadController.text.isEmpty
                              ? Colors.grey[900]
                              : Colors.black),
                ),
                if (widget.viewMode)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        staticTextTranslate('Search For Items'),
                        style: TextStyle(
                            fontSize: getMediumFontSize + 2,
                            color: Colors.grey[900]),
                      ),
                    ),
                  ),
                if (!widget.viewMode)
                  Flexible(
                    child: TypeAheadFormField(
                      enabled: !widget.viewMode,
                      textFieldConfiguration: TextFieldConfiguration(
                        controller: widget.searchForItemsTypeAheadController,
                        decoration: InputDecoration(
                          hintText: staticTextTranslate('Search for Items'),
                          hintStyle: TextStyle(color: Colors.grey[700]),
                          contentPadding:
                              const EdgeInsets.only(bottom: 13, right: 5),
                          border: InputBorder.none,
                        ),
                      ),
                      noItemsFoundBuilder: (context) {
                        return Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Text(staticTextTranslate('No Items Found!'),
                              style: TextStyle(fontSize: getMediumFontSize)),
                        );
                      },
                      suggestionsCallback: (pattern) {
                        return widget.allInventoryDataLst
                            .where((e) =>
                                e.productName
                                    .toLowerCase()
                                    .contains(pattern.toLowerCase()) ||
                                e.barcode
                                    .toLowerCase()
                                    .contains(pattern.toLowerCase()))
                            .toList();
                      },
                      itemBuilder: (context, InventoryData suggestion) {
                        return ListTile(
                          title: Text(suggestion.productName,
                              style: TextStyle(fontSize: getMediumFontSize)),
                          subtitle: Text(
                              '${suggestion.barcode} - ${suggestion.itemCode}',
                              style: TextStyle(fontSize: getMediumFontSize)),
                        );
                      },
                      transitionBuilder: (context, suggestionsBox, controller) {
                        return suggestionsBox;
                      },
                      onSuggestionSelected: (InventoryData inv) async {
                        // addSearcheSubmittedInvData(inv);
                        LineItemData? res = await getLineItemFromInventory(
                            selectedInventoryData: inv,
                            receiptSettingData: widget.receiptSettingData,
                            context: context,
                            taxPercentage:
                                widget.taxSettingsData.taxPercentage);
                        if (res != null) {
                          widget.updatedDataSourceWithNewItem(res);
                        }
                        widget.searchForItemsTypeAheadController.clear();
                      },
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
