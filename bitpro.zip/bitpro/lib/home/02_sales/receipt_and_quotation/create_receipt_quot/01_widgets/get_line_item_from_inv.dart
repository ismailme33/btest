import 'package:bitpro_hive/model/inventory_data.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/settings/receipt_details_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/dialogs/show_product_price_enter_dialog.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:flutter/material.dart';

Future<LineItemData?> getLineItemFromInventory(
    {required InventoryData selectedInventoryData,
    required BuildContext context,
    required ReceiptSettingData receiptSettingData,
    required double taxPercentage}) async {
  String orgPriceWT = selectedInventoryData.priceWT;
  String orgPrice = selectedInventoryData.price;

  if (selectedInventoryData.productPriceCanChange) {
    var res = await showProductPriceEnterDialog(
        receiptSettingData: receiptSettingData,
        context: context,
        productPrice: orgPrice,
        productPriceWt: orgPriceWT);

    if (res != null) {
      if (res['selectedTabIndex'] == 0) {
        orgPrice = res['price'];
        orgPriceWT = calculatePriceWt(orgPrice, taxPercentage);
      } else {
        orgPriceWT = res['priceWt'];
        orgPrice = calculatePrice(orgPriceWT, taxPercentage);
      }
    } else {
      return null;
    }
  }
  if (orgPriceWT != '0') {
    return LineItemData(
      unitName: selectedInventoryData.unit,
      productName: selectedInventoryData.productName,
      barcode: selectedInventoryData.barcode,
      itemCode: selectedInventoryData.itemCode,
      cost: selectedInventoryData.cost,
      qty: '1',
      orgPrice: orgPrice,
      orgPriceWt: orgPriceWT,
      //
      price: orgPrice,
      priceWt: orgPriceWT,
      discountValue: '0',
      discountPercentage: '0',
      total: orgPrice,
      totalWt: orgPriceWT,
      discountPercentageWt: '0',
      discountValueWt: '0',
    );
  } else {
    showToast('Item has a 0 priceWt', context);
  }
  return null;
}

String calculatePriceWt(String price, double taxPercentage) {
  if (price.isEmpty) return '0';

  double p = double.parse(price);
  double total = p * (1 + (taxPercentage / 100));

  return total.toStringAsFixed(digit);
}

String calculatePrice(String priceWt, double taxPercentage) {
  if (priceWt.isEmpty) return '0';

  double p = double.parse(priceWt);
  double taxAmount = p - (p / (1 + (taxPercentage / 100)));

  return taxAmount.toStringAsFixed(digit);
}
