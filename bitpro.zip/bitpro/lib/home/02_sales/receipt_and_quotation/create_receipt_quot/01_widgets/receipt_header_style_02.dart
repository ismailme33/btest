import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';

class ReceiptHeaderStyle02 extends StatefulWidget {
  final TaxSettingsData taxSettingsData;
  final Function(LineItemData) onAdd;
  final String? selectedReceiptType;
  final String? selectedPaymentType;
  final Function(String) onChangeReceptType;
  final Function(String) onChangePaymentType;
  final List<StoreData> allStoresData;
  final StoreData selectedStoreData;
  final Function(String?)? onChangedSelectedStore;
  const ReceiptHeaderStyle02(
      {super.key,
      required this.taxSettingsData,
      required this.onAdd,
      required this.selectedReceiptType,
      required this.selectedPaymentType,
      required this.onChangeReceptType,
      required this.onChangePaymentType,
      required this.allStoresData,
      required this.selectedStoreData,
      this.onChangedSelectedStore});

  @override
  State<ReceiptHeaderStyle02> createState() => _ReceiptHeaderStyle02State();
}

class _ReceiptHeaderStyle02State extends State<ReceiptHeaderStyle02> {
  final List<String> itmes = ['Regular', 'Credit Note'];
  final List<String> payments = ['Cash', 'Credit Card', 'Credit'];

  var formKey = GlobalKey<FormState>();

  InputDecoration inputDecoration = InputDecoration(
    fillColor: Colors.white,
    filled: true,
    errorMaxLines: 3,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(4),
      borderSide: BorderSide(
        color: Colors.grey,
        width: 0.5,
      ),
    ),
  );

  TextEditingController nameController = TextEditingController();
  TextEditingController quantityController = TextEditingController();
  TextEditingController priceController = TextEditingController();
  TextEditingController priceWtController = TextEditingController();
  TextEditingController totalController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: const BoxDecoration(
          color: Colors.grey,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(4), topRight: Radius.circular(4)),
        ),
        width: double.maxFinite,
        // height: 120,
        child: Form(
          key: formKey,
          child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
                vertical: 0,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 180,
                        height: 30,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(width: 0.5),
                            borderRadius: BorderRadius.circular(4)),
                        child: DropdownButton<String>(
                          underline: SizedBox(),
                          style: TextStyle(color: Colors.black),
                          isExpanded: true,
                          padding: EdgeInsets.all(4),
                          value: widget.selectedReceiptType,
                          items: itmes.map((String item) {
                            return DropdownMenuItem<String>(
                              value: item,
                              child: Text(item),
                            );
                          }).toList(),
                          onChanged: (value) {
                            if (value != null) {
                              widget.onChangeReceptType(value);
                              setState(() {});
                            }
                          },
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Container(
                        width: 190,
                        height: 30,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(width: 0.5),
                            borderRadius: BorderRadius.circular(4)),
                        child: DropdownButton<String>(
                          hint: Text('Payment Mode'),
                          underline: SizedBox(),
                          style: TextStyle(color: Colors.black),
                          isExpanded: true,
                          padding: EdgeInsets.all(4),
                          value: widget.selectedPaymentType,
                          items: payments.map((String item) {
                            return DropdownMenuItem<String>(
                              value: item,
                              child: Text(item),
                            );
                          }).toList(),
                          onChanged: (value) {
                            if (value != null) {
                              widget.onChangePaymentType(value);
                              setState(() {});
                            }
                          },
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      Container(
                          width: 270,
                          height: 30,
                          margin: const EdgeInsets.only(top: 10, bottom: 10),
                          decoration: BoxDecoration(
                              border:
                                  Border.all(color: Colors.black, width: 0.5),
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(4)),
                          padding: const EdgeInsets.only(right: 10, left: 10),
                          child: DropdownButton<String>(
                              padding: EdgeInsets.symmetric(vertical: 3),
                              isExpanded: true,
                              value: widget.selectedStoreData.docId,
                              underline: const SizedBox(),
                              items:
                                  widget.allStoresData.map((StoreData value) {
                                return DropdownMenuItem<String>(
                                  value: value.docId,
                                  child: Text(
                                      staticTextTranslate(value.storeName),
                                      style: TextStyle(
                                          fontSize: getMediumFontSize + 1)),
                                );
                              }).toList(),
                              onChanged: widget.onChangedSelectedStore))
                    ],
                  ),
                  Wrap(
                    alignment: WrapAlignment.start,
                    crossAxisAlignment: WrapCrossAlignment.start,
                    children: [
                      SizedBox(
                        width: 300,
                        child: TextFormField(
                          controller: nameController,

                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            }
                            return null;
                          },
                          decoration: inputDecoration.copyWith(
                            hintText: 'Enter Product or Service Discription',

                            contentPadding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 8), // Adjust padding
                            isCollapsed:
                                true, // Ensures the TextFormField respects the padding
                          ),
                          style: TextStyle(fontSize: 16), // Adjust font size
                          onChanged: (value) {
                            setState(() {});
                          },
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      SizedBox(
                        width: 70,
                        child: TextFormField(
                          controller: quantityController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            } else if (double.tryParse(value) == null) {
                              return 'Please enter valid number';
                            } else if (double.parse(value) == 0 ||
                                double.parse(value).isNegative) {
                              return 'Quantity can\'t be 0 or less than 0';
                            }
                            return null;
                          },
                          decoration: inputDecoration.copyWith(
                            hintText: 'Qty',

                            contentPadding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 8), // Adjust padding
                            isCollapsed:
                                true, // Ensures the TextFormField respects the padding
                          ),
                          style: TextStyle(fontSize: 16), // Adjust font size
                          onChanged: (value) {
                            setState(() {
                              if (double.tryParse(value.toString()) != null) {
                                _calculateTotalFromPriceWt(
                                    priceWtController.text);
                              }
                            });
                          },
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      SizedBox(
                        width: 100,
                        child: TextFormField(
                          controller: priceController,

                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            } else if (double.tryParse(value) == null) {
                              return 'Please enter valid number';
                            } else if (double.parse(value) == 0 ||
                                double.parse(value).isNegative) {
                              return 'Price can\'t be 0 or less than 0';
                            }
                            return null;
                          },
                          decoration: inputDecoration.copyWith(
                            hintText: 'Price',

                            contentPadding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 8), // Adjust padding
                            isCollapsed:
                                true, // Ensures the TextFormField respects the padding
                          ),
                          style: TextStyle(fontSize: 16), // Adjust font size
                          onChanged: (value) {
                            setState(() {
                              if (double.tryParse(value.toString()) != null) {
                                _calculatePriceWtFromPrice(value,
                                    widget.taxSettingsData.taxPercentage);
                              }
                            });
                          },
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      SizedBox(
                        width: 100,
                        child: TextFormField(
                          controller: priceWtController,

                          validator: (value) {
                            if (value!.isEmpty) {
                              return 'Please enter some text';
                            } else if (double.tryParse(value) == null) {
                              return 'Please enter valid number';
                            } else if (double.parse(value) == 0 ||
                                double.parse(value).isNegative) {
                              return 'Price WT can\'t be 0 or less than 0';
                            }
                            return null;
                          },
                          decoration: inputDecoration.copyWith(
                            hintText: 'Price WT',

                            contentPadding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 8), // Adjust padding
                            isCollapsed:
                                true, // Ensures the TextFormField respects the padding
                          ),
                          style: TextStyle(fontSize: 16), // Adjust font size
                          onChanged: (value) {
                            setState(() {
                              if (double.tryParse(value) != null) {
                                _calculatePriceFromPriceWt(value,
                                    widget.taxSettingsData.taxPercentage);
                              }
                            });
                          },
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      SizedBox(
                        width: 60,
                        child: TextFormField(
                          controller: totalController,

                          readOnly: true,

                          decoration: inputDecoration.copyWith(
                            hintText: 'Total',

                            contentPadding: EdgeInsets.symmetric(
                                vertical: 8, horizontal: 8), // Adjust padding
                            isCollapsed:
                                true, // Ensures the TextFormField respects the padding
                          ),
                          style: TextStyle(fontSize: 16), // Adjust font size
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      SizedBox(
                        height: 30,
                        width: 70,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                minimumSize: Size(100, 40),
                                backgroundColor: darkBlueColor),
                            onPressed: () {
                              if (formKey.currentState!.validate()) {
                                widget.onAdd(LineItemData(
                                  unitName: '',
                                  productName: nameController.text,
                                  qty: quantityController.text,
                                  price: priceController.text,
                                  priceWt: priceWtController.text,
                                  total: totalController.text,
                                  barcode: '',
                                  cost: '',
                                  discountPercentage: '0',
                                  discountPercentageWt: '0',
                                  discountValue: '0',
                                  discountValueWt: '0',
                                  itemCode: '',
                                  orgPrice: priceController.text,
                                  orgPriceWt: priceWtController.text,
                                  totalWt: totalController.text,
                                ));

                                nameController.clear();
                                quantityController.clear();
                                priceController.clear();
                                priceWtController.clear();
                                totalController.clear();
                                setState(() {});
                              }
                            },
                            child: Text('Add')),
                      )
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  )
                ],
              )),
        ));
  }

  void _calculatePriceWtFromPrice(String price, double taxPercentage) {
    if (price.isEmpty) return;

    double p = double.parse(price);

    priceWtController.text = doubleToString((p * (1 + (taxPercentage / 100))));
    _calculateTotalFromPriceWt(priceWtController.text);
  }

  void _calculatePriceFromPriceWt(String priceWt, double taxPercentage) {
    if (priceWt.isEmpty) return;

    double p = double.parse(priceWt);

    priceController.text =
        doubleToString(p - (p / (1 + (100 / taxPercentage))));
    _calculateTotalFromPriceWt(priceWt);
  }

  void _calculateTotalFromPriceWt(String priceWt) {
    if (priceWt.isEmpty || quantityController.text.isEmpty) return;

    double p = double.parse(priceWt);

    totalController.text =
        doubleToString(p * double.parse(quantityController.text));
  }
}
