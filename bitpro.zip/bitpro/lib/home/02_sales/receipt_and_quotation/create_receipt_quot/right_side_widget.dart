import 'package:bitpro_hive/home/02_sales/customer/customer_create/customer_create_page.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_customer_db_service.dart';
import 'package:bitpro_hive/widget/string_related/get_id_number.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import 'package:bitpro_hive/model/customer_data.dart';
import '../../../../shared/global_variables/font_sizes.dart';
import '../../../../shared/global_variables/static_text_translate.dart';

class ReceiptQuotRightSideWidget extends StatefulWidget {
  final bool viewMode;
  final bool isQuotation;
  final bool isInvoice;

  final ReceiptOrQuotationData? selectedDbReceiptData;
  final List<CustomerData> customerDataLst;
  final CustomerData? selectedCustomerData;
  final Function(CustomerData?) onChangeSelectedCustomerData;
  final Function(List<CustomerData>) updatedCustomerDataList;
  final EmployeeData userData;
  final bool showSelectCustomerError;
  final TextEditingController searchCustomerTypeAheadController;
  //
  final CustomerBranchData? selectCustomerBranch;
  final String regularReturnCreditDropDown;
  final String receiptTotalQty;
  final String receiptDisPer;
  final String receiptDisValue;
  final String receiptTotalBeforeTAx;
  final String receiptTaxPer;
  final String receiptTaxValue;
  final String receiptTotal;
  final Function(CustomerBranchData) onTapSelectCustomerBranch;
  final Function()? onTapMainBtn;
  final Function()? onTapMainBtn2;
  const ReceiptQuotRightSideWidget(
      {super.key,
      required this.onTapSelectCustomerBranch,
      required this.selectCustomerBranch,
      required this.isInvoice,
      required this.onTapMainBtn2,
      required this.viewMode,
      required this.customerDataLst,
      required this.selectedCustomerData,
      required this.onChangeSelectedCustomerData,
      required this.updatedCustomerDataList,
      required this.userData,
      required this.regularReturnCreditDropDown,
      required this.receiptTotalQty,
      required this.receiptDisPer,
      required this.receiptDisValue,
      required this.receiptTotalBeforeTAx,
      required this.receiptTaxPer,
      required this.receiptTaxValue,
      required this.receiptTotal,
      required this.onTapMainBtn,
      required this.showSelectCustomerError,
      required this.searchCustomerTypeAheadController,
      required this.isQuotation,
      this.selectedDbReceiptData});

  @override
  State<ReceiptQuotRightSideWidget> createState() =>
      _ReceiptQuotRightSideWidgetState();
}

class _ReceiptQuotRightSideWidgetState
    extends State<ReceiptQuotRightSideWidget> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 275,
      height: MediaQuery.of(context).size.height - 85,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 5),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(width: 0.3),
                borderRadius: BorderRadius.circular(4),
                color: const Color(0xffE2E2E2),
              ),
              child: Column(
                children: [
                  Container(
                    height: 35,
                    width: double.maxFinite,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(4),
                            topRight: Radius.circular(4)),
                        gradient: LinearGradient(
                            end: Alignment.bottomCenter,
                            colors: [
                              Color.fromARGB(255, 51, 51, 51),
                              Color.fromARGB(255, 51, 51, 51),
                            ],
                            begin: Alignment.topCenter)),
                    child: Row(
                      children: [
                        Text(
                          staticTextTranslate('Customer Details'),
                          style: GoogleFonts.roboto(
                              fontSize: 16,
                              fontWeight: FontWeight.w400,
                              color: Colors.white),
                        )
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Flexible(
                              child: SizedBox(
                                height: 35,
                                child: widget.viewMode
                                    ? Container(
                                        width: double.maxFinite,
                                        decoration: BoxDecoration(
                                            border:
                                                Border.all(color: Colors.grey),
                                            borderRadius:
                                                BorderRadius.circular(2)),
                                        child: Row(
                                          children: [
                                            const SizedBox(width: 10),
                                            Flexible(
                                                child: Text(
                                                    widget
                                                        .searchCustomerTypeAheadController
                                                        .text,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: TextStyle(
                                                        fontSize:
                                                            getMediumFontSize))),
                                          ],
                                        ),
                                      )
                                    : TypeAheadFormField(
                                        getImmediateSuggestions: false,
                                        textFieldConfiguration:
                                            TextFieldConfiguration(
                                          style: GoogleFonts.roboto(
                                              color: const Color.fromARGB(
                                                  255, 0, 0, 0),
                                              fontSize: getMediumFontSize + 2),
                                          controller: widget
                                              .searchCustomerTypeAheadController,
                                          decoration: InputDecoration(
                                            fillColor: Colors.white,
                                            filled: true,
                                            suffixIcon: widget
                                                        .selectedCustomerData !=
                                                    null
                                                ? GestureDetector(
                                                    onTap: () {
                                                      widget
                                                          .onChangeSelectedCustomerData(
                                                              null);
                                                    },
                                                    child: Container(
                                                        color:
                                                            Colors.transparent,
                                                        width: 20,
                                                        child: Icon(
                                                          Icons.cancel,
                                                        )),
                                                  )
                                                : SizedBox(),
                                            hintText: staticTextTranslate(
                                                'Search customer'),
                                            hintStyle: GoogleFonts.roboto(
                                                color: Colors.grey[600],
                                                fontSize:
                                                    getMediumFontSize + 2),
                                            contentPadding:
                                                const EdgeInsets.only(
                                                    left: 10,
                                                    right: 5,
                                                    bottom: 3),
                                            border: const OutlineInputBorder(),
                                          ),
                                        ),
                                        noItemsFoundBuilder: (context) {
                                          return Padding(
                                            padding: const EdgeInsets.all(10.0),
                                            child: Text(
                                                staticTextTranslate(
                                                    'No Items Found!'),
                                                style: TextStyle(
                                                    fontSize:
                                                        getMediumFontSize)),
                                          );
                                        },
                                        suggestionsCallback: (pattern) {
                                          return widget.customerDataLst
                                              .where(
                                                (e) =>
                                                    e.customerName
                                                        .toLowerCase()
                                                        .contains(pattern
                                                            .toLowerCase()) ||
                                                    e.phone1
                                                        .toLowerCase()
                                                        .contains(
                                                          pattern.toLowerCase(),
                                                        ),
                                              )
                                              .toList();
                                        },
                                        itemBuilder:
                                            (context, CustomerData suggestion) {
                                          return ListTile(
                                            // subtitle: Text(suggestion.phone1),
                                            title: Text(
                                              suggestion.customerName,
                                              style: TextStyle(
                                                  fontSize: getMediumFontSize),
                                            ),
                                          );
                                        },
                                        transitionBuilder: (context,
                                            suggestionsBox, controller) {
                                          return suggestionsBox;
                                        },
                                        onSuggestionSelected: (CustomerData e) {
                                          widget
                                              .onChangeSelectedCustomerData(e);
                                        },
                                      ),
                              ),
                            ),
                            if (widget.viewMode == false)
                              const SizedBox(
                                width: 10,
                              ),
                            if (widget.viewMode == false)
                              Container(
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(4),
                                    gradient: const LinearGradient(
                                        end: Alignment.bottomCenter,
                                        colors: [
                                          Color.fromARGB(255, 12, 65, 114),
                                          Color.fromARGB(255, 12, 65, 114),
                                        ],
                                        begin: Alignment.topCenter)),
                                height: 35,
                                width: 35,
                                child: ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      elevation: 0,
                                      padding: const EdgeInsets.all(0),
                                      backgroundColor: Colors.transparent,
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                        4,
                                      )),
                                    ),
                                    onPressed: () async {
                                      showAddCustomerDialog();
                                      setState(() {});
                                    },
                                    child: const Icon(
                                      Iconsax.add_circle,
                                      size: 19,
                                    )),
                              ),
                          ],
                        ),
                        if (widget.showSelectCustomerError)
                          Padding(
                            padding: const EdgeInsets.only(top: 10, left: 8.0),
                            child: Text(
                              staticTextTranslate('Please select a customer'),
                              style: GoogleFonts.roboto(
                                fontSize: 12,
                                color: Colors.red.shade800,
                              ),
                            ),
                          ),
                        const SizedBox(
                          height: 10,
                        ),
                        Text(
                          staticTextTranslate('Name') +
                              ' : ${widget.selectedCustomerData != null ? widget.selectedCustomerData!.customerName : ''}',
                          style: GoogleFonts.roboto(
                              fontSize: getMediumFontSize + 1,
                              fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Text(
                          staticTextTranslate('Phone') +
                              ' : ${widget.selectedCustomerData != null ? widget.selectedCustomerData!.phone1 : ''}',
                          style: GoogleFonts.roboto(
                              fontSize: getMediumFontSize + 1,
                              fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Text(
                          staticTextTranslate('Address') +
                              ' : ${widget.selectedCustomerData != null ? widget.selectedCustomerData!.address1 : ''}',
                          style: GoogleFonts.roboto(
                              fontSize: getMediumFontSize + 1,
                              fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(
                          height: 5,
                        ),
                        Row(
                          children: [
                            Text(
                              staticTextTranslate('Branch') +
                                  ' : ${widget.selectedCustomerData != null ? widget.selectedCustomerData!.customerBranchDataLst.isEmpty ? "No branch found" : '' : ''}',
                              style: GoogleFonts.roboto(
                                  fontSize: getMediumFontSize + 1,
                                  fontWeight: FontWeight.w500),
                            ),
                            if (widget.selectedCustomerData != null &&
                                widget.selectedCustomerData!
                                    .customerBranchDataLst.isNotEmpty)
                              Expanded(
                                child: DropdownButton<CustomerBranchData>(
                                  hint: Text("Select"),
                                  isExpanded: true,
                                  value: widget.selectCustomerBranch,
                                  style: GoogleFonts.roboto(
                                      fontSize: getMediumFontSize + 1,
                                      color: Colors.black,
                                      fontWeight: FontWeight.w500),
                                  items: widget.selectedCustomerData!
                                      .customerBranchDataLst
                                      .map((CustomerBranchData value) {
                                    return DropdownMenuItem<CustomerBranchData>(
                                      value: value,
                                      child: Text(value.branchName),
                                    );
                                  }).toList(),
                                  onChanged: widget.viewMode
                                      ? null
                                      : (val) {
                                          if (val != null) {
                                            widget
                                                .onTapSelectCustomerBranch(val);
                                            setState(() {});
                                          }
                                        },
                                ),
                              )
                          ],
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          Expanded(
            child: Container(
              width: double.maxFinite,
              decoration: BoxDecoration(
                border: Border.all(width: 0.5),
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [],
              ),
            ),
          ),
          const SizedBox(
            height: 5,
          ),
          totalWidget()
        ],
      ),
    );
  }

  showAddCustomerDialog() async {
    String newCustomerId = await getIdNumber(widget.customerDataLst.length + 1);
    CustomerData? customerData = await showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: CustomerCreateEditPage(
              newCustomerId: newCustomerId,
              hideCustomTab: true,
              userData: widget.userData,
              customerDataLst: widget.customerDataLst),
        );
      },
    );
    widget.onChangeSelectedCustomerData(customerData);
    widget.updatedCustomerDataList(
        await HiveCustomerDbService().fetchAllCustomersData());
    setState(() {});
  }

  Widget totalWidget() {
    return Container(
      decoration: BoxDecoration(
          color: Color(0xffE2E2E2),
          border: Border.all(width: 0.5),
          borderRadius: BorderRadius.circular(4)),
      width: 300,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          height: 35,
          width: double.maxFinite,
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(4), topRight: Radius.circular(4)),
            gradient: LinearGradient(
                end: Alignment.bottomCenter,
                colors: [
                  Color.fromARGB(255, 51, 51, 51),
                  Color.fromARGB(255, 51, 51, 51),
                ],
                begin: Alignment.topCenter),
          ),
          child: Row(
            children: [
              Text(
                staticTextTranslate('Totals'),
                style: GoogleFonts.roboto(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Colors.white),
              )
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    staticTextTranslate('Total Qty'),
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(
                    height: 0,
                  ),
                  Text(
                    widget.receiptTotalQty,
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    staticTextTranslate('Discount %'),
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                  Text(
                    widget.receiptDisPer,
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    staticTextTranslate('Discount \$'),
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(
                    height: 0,
                  ),
                  Text(
                    widget.receiptDisValue,
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    staticTextTranslate('Total before Tax'),
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(
                    height: 0,
                  ),
                  Text(
                    widget.receiptTotalBeforeTAx,
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    '${staticTextTranslate("Tax")} (${widget.receiptTaxPer}%)',
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(
                    height: 0,
                  ),
                  Text(
                    widget.receiptTaxValue,
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 1,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
              const SizedBox(
                height: 5,
              ),
              Text(
                staticTextTranslate(
                    '---------------------------------------------------'),
                style: GoogleFonts.roboto(
                    fontSize: getMediumFontSize + 1,
                    fontWeight: FontWeight.w500),
              ),
              const SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    staticTextTranslate('TOTAL'),
                    style: GoogleFonts.roboto(
                        fontSize: getMediumFontSize + 3,
                        fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 6,
                  ),
                  Row(
                    children: [
                      SizedBox(
                          width: 16,
                          height: 16,
                          child: SvgPicture.asset(
                            'assets/sar.svg',
                          )),
                      SizedBox(width: 5),
                      Text(
                        widget.regularReturnCreditDropDown != 'Return'
                            ? widget.receiptTotal
                            : '-${widget.receiptTotal}',
                        style: GoogleFonts.roboto(
                            fontSize: getExtraLargeFontSize + 3,
                            color:
                                widget.regularReturnCreditDropDown != 'Return'
                                    ? Colors.black
                                    : Colors.red[800],
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  )
                ],
              ),
              const SizedBox(
                height: 10,
              ),
              Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    gradient: widget.onTapMainBtn2 == null
                        ? null
                        : LinearGradient(
                            end: Alignment.bottomCenter,
                            colors: [
                              Color.fromARGB(255, 12, 65, 114),
                              Color.fromARGB(255, 12, 65, 114),
                            ],
                            begin: Alignment.topCenter)),
                height: 38,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        elevation: 0,
                        backgroundColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4))),
                    onPressed: widget.onTapMainBtn,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          widget.isQuotation ? Icons.print : Iconsax.money_2,
                          size: 20,
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text(
                            staticTextTranslate(widget.isInvoice
                                ? 'Draft'
                                : widget.isQuotation
                                    ? 'Save & Print'
                                    : widget.regularReturnCreditDropDown ==
                                            'Credit'
                                        ? "Print & Upate"
                                        : 'Tender'),
                            style: TextStyle(fontSize: getMediumFontSize)),
                      ],
                    )),
              ),
              if (widget.isInvoice)
                Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(4),
                      gradient: widget.onTapMainBtn2 == null
                          ? null
                          : LinearGradient(
                              end: Alignment.bottomCenter,
                              colors: [
                                Color.fromARGB(255, 12, 65, 114),
                                Color.fromARGB(255, 12, 65, 114),
                              ],
                              begin: Alignment.topCenter)),
                  margin: const EdgeInsets.only(top: 5),
                  height: 38,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          elevation: 0,
                          backgroundColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(4))),
                      onPressed: widget.onTapMainBtn2,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Iconsax.money_2,
                            size: 20,
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          Text(staticTextTranslate('Finilized'),
                              style: TextStyle(fontSize: getMediumFontSize)),
                        ],
                      )),
                ),
            ],
          ),
        )
      ]),
    );
  }
}
