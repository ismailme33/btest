// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';

class ReceiptCalculationFunctions {
  //
  double _orgPriceWtTotal = 0;
  double _totalWtTotal = 0;
  double _totalTotal = 0;
  double _dis$WtTotal = 0;

  //important value
  double _totalQty = 0;
  double _discountPer = 0;
  double _discountValueWt = 0;
  double _totalBeforeTax = 0;
  double _taxValue = 0;
  double _receiptTotal = 0;
  double _receiptTaxPer = 0;

  String get receiptTotalQty => _totalQty.toStringAsFixed(2);
  String get receiptDiscountPer => doubleToString(_discountPer);
  String get receiptDiscountValueWt => _discountValueWt.toStringAsFixed(2);
  String get receiptTotal => _receiptTotal.toStringAsFixed(2);
  String get receiptTotalBeforeTax => _totalBeforeTax.toStringAsFixed(2);
  String get receiptTaxPer => doubleToString(_receiptTaxPer);
  String get receiptTaxValue => _taxValue.toStringAsFixed(2);

  ReceiptCalculationFunctions(
      {required List<LineItemData> selectedLocalReceiptData,
      required double cartDiscountValueWt,
      required double cartDiscountPercentage,
      required double taxPer}) {
    _receiptTaxPer = taxPer;
    for (LineItemData v in selectedLocalReceiptData) {
      _totalQty += double.tryParse(v.qty) ?? 0;
      _orgPriceWtTotal +=
          (double.tryParse(v.orgPriceWt) ?? 0) * (double.tryParse(v.qty) ?? 0);
      _totalWtTotal += double.tryParse(v.totalWt) ?? 0;
      _totalTotal += double.tryParse(v.total) ?? 0;
      _dis$WtTotal += double.tryParse(v.discountValueWt) ?? 0;
    }
    if (cartDiscountPercentage != 0 && cartDiscountValueWt != 0) {
      //we have cart discount
      // double cartDiscountWt = cartDiscountValueWt;
      _receiptTotal = _totalWtTotal - cartDiscountValueWt;

      _discountValueWt = _dis$WtTotal + cartDiscountValueWt;
      if (_discountValueWt != 0) {
        _discountPer =
            _calculateDiscountPercentage(_orgPriceWtTotal, _receiptTotal);
      }
      _totalBeforeTax = _calculateVAT(
          taxPercentage: taxPer, grossPrice: _receiptTotal, getNetPrice: true);
      _taxValue = _calculateVAT(
          taxPercentage: taxPer, grossPrice: _receiptTotal, getNetPrice: false);
    } else {
      //we don't have cart discount

      _discountValueWt = _dis$WtTotal;
      if (_discountValueWt != 0) {
        _discountPer =
            _calculateDiscountPercentage(_orgPriceWtTotal, _totalWtTotal);
      }
      _totalBeforeTax = _totalTotal;
      _taxValue = _totalWtTotal - _totalTotal;
      _receiptTotal = _totalWtTotal;
    }
  }

  //for tendor
  String calculateDueAmount(allPaymentMethodAmountsInfo) {
    double t = _receiptTotal;

    double tenderedAmt =
        double.parse(calculateTenderedAmount(allPaymentMethodAmountsInfo));

    if (tenderedAmt < t) {
      return doubleToString(t - tenderedAmt);
    } else {
      return '0';
    }
  }

  String calculateTenderedAmount(allPaymentMethodAmountsInfo) {
    double amt = 0;

    for (var v in allPaymentMethodAmountsInfo.values) {
      amt += double.tryParse(v.toString()) ?? 0;
    }

    return amt == 0 ? '0' : doubleToString(amt);
  }

  String calculateBalanceAmount(allPaymentMethodAmountsInfo) {
    double totalAmt = _receiptTotal;
    double tenderedAmt =
        double.parse(calculateTenderedAmount(allPaymentMethodAmountsInfo));

    if (tenderedAmt > totalAmt) {
      return doubleToString(tenderedAmt - totalAmt);
    } else {
      return '0';
    }
  }

  //helper function
  double _calculateDiscountPercentage(
      double priceBeforeDiscount, double priceAfterDiscount) {
    if (priceBeforeDiscount == 0 || priceAfterDiscount == 0) {
      return 0;
    }

    double discount = priceBeforeDiscount - priceAfterDiscount;
    return (discount / priceBeforeDiscount) * 100;
  }

  //helper function
  double _calculateVAT(
      {required double taxPercentage,
      required double grossPrice,
      bool getNetPrice = false}) {
    if (taxPercentage == 0 || grossPrice == 0) {
      return 0;
    }

    // Calculate the VAT amount
    double taxAmount = grossPrice * (taxPercentage / (100 + taxPercentage));

    // Calculate the net price (gross price - tax amount)
    double netPrice = grossPrice - taxAmount;

    // Print the results
    if (getNetPrice) {
      return netPrice;
    } else {
      return taxAmount;
    }
  }
}
