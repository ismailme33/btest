import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/02_logic/receipt_calculation_functions.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_item_total_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/templates/quotation_templates/print_quotation.dart';
import 'package:bitpro_hive/shared/templates/receipt_templates/print_receipt.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:bitpro_hive/model/customer_data.dart';
import 'package:bitpro_hive/model/specification_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/string_related/get_id_number.dart';

class ReceiptOnTopFunciton {
  final BuildContext context;

  ReceiptOnTopFunciton({required this.context});

  Future<void> printReceiptQuotation({
    required ReceiptOrQuotationData receiptOrQuotationData,
    required bool isQuotation,
    required CustomerData? selectedCustomerData,
    required String tenderAmount,
    required String changeAmount,
  }) async {
    if (isQuotation) {
      await printQuotation(
          context, receiptOrQuotationData, selectedCustomerData);
    } else {
      await printReceipt(
          context,
          receiptOrQuotationData,
          receiptOrQuotationData.lineItemTotalData.totalTaxValue,
          selectedCustomerData,
          tenderAmount,
          changeAmount);
    }
  }

  Future<ReceiptOrQuotationData?> getReceiptQuoationModelData({
    required bool isAdvancePaymentEnabled,
    required bool isQuotation,
    required bool isInvoice,
    required int receiptLength,
    required double cartDiscountValue,
    required double cartDiscountPercentage,
    required StoreData selectedStoreData,
    required String referenceNo,
    required String createdBy,
    required SpecificationData? specificationData,
    required ReceiptOrQuotationData? selectedDbReceiptData,
    required CustomerData? selectedCustomerData,
    required List<LineItemData> selectedLineItem,
    required ReceiptCalculationFunctions receiptCalculationFunctions,
    required Map<dynamic, dynamic> allPaymentMethodAmountsInfo,
    required String regularReturnCreditDropDown,
    required String? selectedPaymentType,
    required DateTime? customCreatedDate,
    required CustomerBranchData? selectedCustomerBranchData,
    //invoice related
    required bool isFinialized,
  }) async {
    if ((isAdvancePaymentEnabled || selectedPaymentType == 'Credit') &&
        selectedCustomerData == null) {
      showToast('Please select a costomer.', context);
      return null;
    }

    if (isInvoice && selectedPaymentType != null) {
      allPaymentMethodAmountsInfo[selectedPaymentType] =
          receiptCalculationFunctions.receiptTotal;
    }

    LineItemTotalData lineItemTotalData = LineItemTotalData(
        totalQty: receiptCalculationFunctions.receiptTotalQty,
        totalDiscountPercentage: receiptCalculationFunctions.receiptDiscountPer,
        totalDiscountValue: receiptCalculationFunctions.receiptDiscountValueWt,
        totalBeforeTax: receiptCalculationFunctions.receiptTotalBeforeTax,
        totalTaxValue: receiptCalculationFunctions.receiptTaxValue,
        totalTaxPercentage: receiptCalculationFunctions.receiptTaxPer,
        receiptTotal: receiptCalculationFunctions.receiptTotal);

    if (selectedLineItem.isNotEmpty &&
        ((double.parse(receiptCalculationFunctions
                        .calculateDueAmount(allPaymentMethodAmountsInfo)) ==
                    0 ||
                regularReturnCreditDropDown == 'Credit' ||
                (isAdvancePaymentEnabled && selectedCustomerData != null)) ||
            isQuotation)) {
      ReceiptOrQuotationData dbReceiptData;

      //ading new receipt
      if (regularReturnCreditDropDown == 'Credit') {
        allPaymentMethodAmountsInfo = {
          PaymentMethodKey().credit: receiptCalculationFunctions.receiptTotal
        };
      }

      ReceiptBasicInfo? receiptBasicInfo;
      QuotationBasicInfo? quotationBasicInfo;

      String newId = selectedDbReceiptData != null
          ? isQuotation
              ? selectedDbReceiptData.quotationBasicInfo!.quotationNo
              : selectedDbReceiptData.receiptBasicInfo!.receiptNo
          : await getIdNumber(receiptLength + 1);

      String docId = selectedDbReceiptData != null
          ? selectedDbReceiptData.docId
          : getRandomString(20);

      if (isQuotation == false) {
        // isInvoice
        InvoiceData? invoiceData = isInvoice && selectedPaymentType != null
            ? InvoiceData(
                selectedPaymentType: selectedPaymentType,
                isFinialized: isFinialized)
            : null;

        receiptBasicInfo = ReceiptBasicInfo(
          invoiceData: invoiceData,
          selectedCustomerBranchDocId: selectedCustomerBranchData == null
              ? ''
              : selectedCustomerBranchData.docId,
          receiptNo: newId,
          selectedCustomerID: selectedCustomerData == null
              ? ''
              : selectedCustomerData.customerId,
          cartDiscountPercentage: doubleToString(cartDiscountPercentage),
          cartDiscountValue: doubleToString(cartDiscountValue),
          selectedStoreDocId: selectedStoreData.docId,
          receiptType: regularReturnCreditDropDown == 'Credit'
              ? 'Regular'
              : regularReturnCreditDropDown,
          referenceNo: referenceNo,
          specificationInfo: specificationData,
          isAdvancePaymentEnabled: isAdvancePaymentEnabled,
          receiptDue: receiptCalculationFunctions
              .calculateDueAmount(allPaymentMethodAmountsInfo),
          receiptBalance: receiptCalculationFunctions
              .calculateBalanceAmount(allPaymentMethodAmountsInfo),
          allPaymentMethodAmountsInfo: allPaymentMethodAmountsInfo,
        );
      } else {
        quotationBasicInfo = QuotationBasicInfo(
          quotationNo: newId,
          selectedCustomerBranchDocId: selectedCustomerBranchData == null
              ? ''
              : selectedCustomerBranchData.docId,
          selectedCustomerID: selectedCustomerData == null
              ? ''
              : selectedCustomerData.customerId,
          cartDiscountPercentage: doubleToString(cartDiscountPercentage),
          cartDiscountValue: doubleToString(cartDiscountValue),
          selectedStoreDocId: selectedStoreData.docId,
          receiptType: regularReturnCreditDropDown == 'Credit'
              ? 'Regular'
              : regularReturnCreditDropDown,
          referenceNo: referenceNo,
          specificationInfo: specificationData,
        );
      }
      DateTime createdDate = selectedDbReceiptData != null
          ? selectedDbReceiptData.createdDate
          : DateTime.now();

      if (selectedDbReceiptData == null && customCreatedDate != null) {
        var d1 = DateTime.now();
        createdDate = DateTime(customCreatedDate.year, customCreatedDate.month,
            customCreatedDate.day, d1.hour, d1.minute, d1.second);
      }
      dbReceiptData = ReceiptOrQuotationData(
        isQuotation: isQuotation,
        lineItemTotalData: lineItemTotalData,
        lineItemsData: selectedLineItem,
        quotationBasicInfo: quotationBasicInfo,
        receiptBasicInfo: receiptBasicInfo,
        createdBy: createdBy,
        docId: docId,
        createdDate: createdDate,
      );

      return dbReceiptData;
    }
    return null;
  }
}
