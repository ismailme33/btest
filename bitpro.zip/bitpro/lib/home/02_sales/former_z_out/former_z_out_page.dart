import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_former_z_out_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:bitpro_hive/widget/filter_container.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/shared/custom_top_nav_bar.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import '../../../model/former_z_out_data.dart';
import '../../../shared/global_variables/font_sizes.dart';
import '../../../shared/global_variables/static_text_translate.dart';

class FormerZOutPage extends StatefulWidget {
  final EmployeeData userData;

  const FormerZOutPage({Key? key, required this.userData}) : super(key: key);

  @override
  State<FormerZOutPage> createState() => _FormerZOutPageState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _FormerZOutPageState extends State<FormerZOutPage> {
  final List<BitproGridColumnModel> _bitproGridColumnModel = [
    BitproGridColumnModel(
      columnName: 'serialNumberForStyleColor',
      label: 'serialNumberForStyleColor',
      width: 140.0,
      visible: false,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'zout#',
      label: staticTextTranslate('Z out #'),
      width: 120.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'total',
      label: staticTextTranslate('Total'),
      width: 120.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'cashier_name',
      label: staticTextTranslate('Cashier Name'),
      width: 140.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'store_name',
      label: staticTextTranslate('Store'),
      width: 120.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'over/short',
      label: staticTextTranslate('Over / Short'),
      width: 180.0,
      allowEditing: false,
    ),
  ];
  FormerZoutDataSource? customerDataSource;
  DataGridController dataGridController = DataGridController();
  DateTime? rangeStartDate;
  DateTime? rangeEndDate;
  bool loading = true;
  var customerIdController = TextEditingController();
  var customerNameController = TextEditingController();
  var customerPhoneController = TextEditingController();

  List<FormerZOutData> formerZoutDataLst = [];
  List<StoreData> storeDataLst = [];
  @override
  void initState() {
    super.initState();
    hiveFetchData();
  }

  commonInit() async {
    formerZoutDataLst
        .sort(((a, b) => b.formerZoutNo.compareTo(a.formerZoutNo)));
    customerDataSource ??= FormerZoutDataSource(
        formerZOutData: formerZoutDataLst, storeDataLst: storeDataLst);
    setState(() {
      loading = false;
    });
  }

  hiveFetchData() async {
    formerZoutDataLst =
        await HiveFormerZOutDbService().fetchAllFormerZoutData();
    storeDataLst = await HiveStoreDbService().fetchAllStoresData();

    await commonInit();
  }

  // fbFetchData() async {
  //   formerZoutDataLst =
  //       await HiveFormerZOutDbService().fetchAllFormerZoutData();

  //   await commonInit();
  // }

  filterAccordingSelectedDate() {
    List<FormerZOutData> filteredEmployeesDataLst = [];
    if (rangeStartDate != null && rangeEndDate != null) {
      for (var ug in formerZoutDataLst) {
        DateTime tmp = DateTime(DateTime.parse(ug.openDate).year,
            DateTime.parse(ug.openDate).month, DateTime.parse(ug.openDate).day);
        if (tmp.compareTo(rangeStartDate!) != -1 &&
            (tmp.compareTo(rangeEndDate!) != 1)) {
          filteredEmployeesDataLst.add(ug);
        }
      }
    } else if (rangeStartDate != null) {
      var res = formerZoutDataLst.where((e) =>
          DateTime.parse(e.openDate).day == rangeStartDate!.day &&
          DateTime.parse(e.openDate).month == rangeStartDate!.month &&
          DateTime.parse(e.openDate).year == rangeStartDate!.year);

      filteredEmployeesDataLst = res.toList();
    }

    customerDataSource = FormerZoutDataSource(
        formerZOutData: filteredEmployeesDataLst, storeDataLst: storeDataLst);
    rangeStartDate = null;
    rangeEndDate = null;
    setState(() {});
  }

  searchById(String id) {
    List<FormerZOutData> filteredVendorDataLst = [];
    if (id.isEmpty) {
      customerDataSource = FormerZoutDataSource(
          formerZOutData: formerZoutDataLst, storeDataLst: storeDataLst);
      setState(() {});
      return;
    }

    for (var v in formerZoutDataLst) {
      if (v.formerZoutNo.toLowerCase().contains(id.toLowerCase())) {
        filteredVendorDataLst.add(v);
      }
    }
    customerDataSource = FormerZoutDataSource(
        formerZOutData: filteredVendorDataLst, storeDataLst: storeDataLst);
    setState(() {});
  }

  searchByCustomerName(String val) {
    List<FormerZOutData> filteredVendorDataLst = [];
    if (val.isEmpty) {
      customerDataSource = FormerZoutDataSource(
          formerZOutData: formerZoutDataLst, storeDataLst: storeDataLst);
      setState(() {});
      return;
    }

    for (var v in formerZoutDataLst) {
      if (v.cashierName.toLowerCase().contains(val.toLowerCase())) {
        filteredVendorDataLst.add(v);
      }
    }
    customerDataSource = FormerZoutDataSource(
        formerZOutData: filteredVendorDataLst, storeDataLst: storeDataLst);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return CustomNavBar(
      pageName: 'Former ZOut',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Container(
            color: homeBgColor,
            child: Row(
              children: [
                Container(
                  color: const Color.fromARGB(255, 43, 43, 43),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SideMenuButton(
                        label: 'Back',
                        iconPath: 'assets/icons/back.png',
                        buttonFunction: () {
                          Navigator.pop(context);
                        },
                      ),
                      SideMenuButton(
                        label: 'Refresh',
                        iconPath: 'assets/icons/refresh.png',
                        buttonFunction: () async {
                          setState(() {
                            loading = true;
                          });
                          await hiveFetchData();
                        },
                      ),
                      const SizedBox(
                        height: 30,
                      ),
                      SideMenuButton(
                        label: 'Date Range',
                        iconPath: 'assets/icons/date.png',
                        buttonFunction: () {
                          showDialog(
                              context: context,
                              builder: (context) {
                                return Dialog(
                                  child: SizedBox(
                                    width: 400,
                                    height: 380,
                                    child: SfDateRangePicker(
                                        onSelectionChanged:
                                            (DateRangePickerSelectionChangedArgs
                                                args) {
                                          if (args.value is PickerDateRange) {
                                            rangeStartDate =
                                                args.value.startDate;
                                            rangeEndDate = args.value.endDate;
                                            setState(() {});
                                          }
                                        },
                                        onCancel: () {
                                          Navigator.pop(context);
                                        },
                                        onSubmit: (var p0) {
                                          filterAccordingSelectedDate();
                                          Navigator.pop(context);
                                        },
                                        cancelText: 'CANCEL',
                                        confirmText: 'OK',
                                        showTodayButton: false,
                                        showActionButtons: true,
                                        view: DateRangePickerView.month,
                                        selectionMode:
                                            DateRangePickerSelectionMode.range),
                                  ),
                                );
                              });
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Card(
                      shape: RoundedRectangleBorder(
                          side:
                              const BorderSide(width: 0.5, color: Colors.grey),
                          borderRadius: BorderRadius.circular(4)),
                      elevation: 0,
                      color: Colors.white,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          //filter
                          filterWidget(),

                          if (loading)
                            Expanded(
                              child: Center(
                                child: showLoading(),
                              ),
                            ),
                          if (!loading)
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 600,
                                    margin: const EdgeInsets.all(6),
                                    decoration: BoxDecoration(
                                        border: Border.all(width: 0.3)),
                                    height: MediaQuery.of(context).size.height -
                                        155,
                                    child: BitproGridTable(
                                      width: 600,
                                      onChangeRefershFunction: () {
                                        setState(() {});
                                      },
                                      dataGridController: dataGridController,
                                      source: customerDataSource!,
                                      allowEditing: false,
                                      allowSorting: true,
                                      allowFiltering: true,
                                      bitproGridColumnModel:
                                          _bitproGridColumnModel,
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  if (dataGridController.selectedIndex != -1)
                                    detailsScreen()
                                ],
                              ),
                            )
                        ],
                      )),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  filterWidget() {
    return FilterContainer(fiterFields: [
      Container(
        width: 230,
        height: 32,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.5),
            color: const Color.fromARGB(255, 255, 255, 255),
            borderRadius: BorderRadius.circular(5)),
        padding: const EdgeInsets.only(right: 10, bottom: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              padding: const EdgeInsets.only(top: 3),
              onPressed: () {
                customerIdController.clear();

                customerDataSource = FormerZoutDataSource(
                    formerZOutData: formerZoutDataLst,
                    storeDataLst: storeDataLst);
                setState(() {});
              },
              splashRadius: 1,
              icon: Icon(
                  customerIdController.text.isEmpty
                      ? CupertinoIcons.search
                      : Icons.clear,
                  size: 18,
                  color: customerIdController.text.isEmpty
                      ? Colors.grey[600]
                      : Colors.black),
            ),
            Flexible(
              child: TextField(
                controller: customerIdController,
                decoration: InputDecoration(
                  hintText: staticTextTranslate('Zout#'),
                  hintStyle: TextStyle(color: Colors.grey[600]),
                  contentPadding: const EdgeInsets.only(bottom: 15, right: 5),
                  border: InputBorder.none,
                ),
                onChanged: (val) {
                  searchById(val);
                },
              ),
            ),
          ],
        ),
      ),
      const SizedBox(
        width: 0,
      ),
      Container(
        width: 230,
        height: 30,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.5),
            color: const Color.fromARGB(255, 255, 255, 255),
            borderRadius: BorderRadius.circular(5)),
        padding: const EdgeInsets.only(right: 10, bottom: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              padding: const EdgeInsets.only(top: 3),
              onPressed: () {
                customerNameController.clear();

                customerDataSource = FormerZoutDataSource(
                    formerZOutData: formerZoutDataLst,
                    storeDataLst: storeDataLst);
                setState(() {});
              },
              splashRadius: 1,
              icon: Icon(
                  customerNameController.text.isEmpty
                      ? CupertinoIcons.search
                      : Icons.clear,
                  size: 18,
                  color: customerNameController.text.isEmpty
                      ? Colors.grey[600]
                      : Colors.black),
            ),
            Flexible(
              child: TextField(
                  controller: customerNameController,
                  onChanged: (val) {
                    searchByCustomerName(val);
                  },
                  decoration: InputDecoration(
                    hintText: staticTextTranslate('Cashier'),
                    hintStyle: TextStyle(color: Colors.grey[600]),
                    contentPadding: const EdgeInsets.only(bottom: 13, right: 5),
                    border: InputBorder.none,
                  )),
            ),
          ],
        ),
      ),
    ]);
  }

  detailsScreen() {
    List<DataGridCell> cells = dataGridController.selectedRow!.getCells();
    int i = cells.indexWhere((e) => e.columnName == 'zout#');
    FormerZOutData? formerZOutData;
    if (i != -1) {
      String zoutd = cells.elementAt(i).value;
      int j = formerZoutDataLst
          .indexWhere((element) => element.formerZoutNo == zoutd);
      if (j != -1) {
        formerZOutData = formerZoutDataLst.elementAt(j);
      }
    }
    if (formerZOutData == null) return const SizedBox();

    return Container(
        width: 500,
        decoration: BoxDecoration(
            border: Border.all(color: Colors.grey, width: 0.5),
            color: Colors.white,
            borderRadius: BorderRadius.circular(4)),
        height: MediaQuery.of(context).size.height - 170,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Column(
          children: [
            Row(
              children: [
                Text(
                  staticTextTranslate('Z-Out#: '),
                  style: GoogleFonts.roboto(
                      fontSize: getMediumFontSize + 5,
                      fontWeight: FontWeight.bold),
                ),
                const SizedBox(
                  height: 0,
                ),
                Text(
                  formerZOutData.formerZoutNo,
                  style: GoogleFonts.roboto(
                      fontSize: getMediumFontSize + 5,
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(
              height: 20,
            ),
            Expanded(
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(staticTextTranslate('Total Over / Short'),
                          style: TextStyle(
                            fontSize: getMediumFontSize - 1,
                          )),
                      Text(
                        formerZOutData.overShort,
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(staticTextTranslate('Opened Date'),
                          style: TextStyle(
                            fontSize: getMediumFontSize - 1,
                          )),
                      const SizedBox(
                        height: 0,
                      ),
                      Text(
                        DateFormat('dd MMM, yyyy h:mm a')
                            .format(DateTime.parse(formerZOutData.openDate)),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(staticTextTranslate('Closed Date'),
                          style: TextStyle(
                            fontSize: getMediumFontSize - 1,
                          )),
                      Text(
                        DateFormat(
                          'dd MMM, yyyy h:mm a',
                        ).format(
                          DateTime.parse(formerZOutData.closeDate),
                        ),
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(staticTextTranslate('Cashier Name'),
                          style: TextStyle(
                            fontSize: getMediumFontSize - 1,
                          )),
                      Text(
                        formerZOutData.cashierName,
                        style: TextStyle(
                          fontSize: getMediumFontSize,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    width: 50,
                    child: Center(
                      child: Container(
                        width: 1,
                        height: double.infinity,
                        color: const Color.fromARGB(255, 151, 151, 151),
                      ),
                    ),
                  ),
                  SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        for (var k
                            in formerZOutData.allPaymentMethodsTotals.keys)
                          if (k != PaymentMethodKey().cash &&
                              k != PaymentMethodKey().creditCard)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                    // PaymentMethodKey().getTextName(k)
                                    k + ' Total',
                                    style: TextStyle(
                                      fontSize: getMediumFontSize - 1,
                                    )),
                                Text(
                                    formerZOutData.allPaymentMethodsTotals[k] ==
                                            null
                                        ? '0'
                                        : doubleToString(formerZOutData
                                                .allPaymentMethodsTotals[k] ??
                                            ''),
                                    style: TextStyle(
                                        fontSize: getMediumFontSize,
                                        fontWeight: FontWeight.w600)),
                                SizedBox(
                                  height: 10,
                                ),
                              ],
                            ),
                        const SizedBox(
                          height: 0,
                        ),
                        Text(staticTextTranslate('Credit Card Total On System'),
                            style: TextStyle(
                              fontSize: getMediumFontSize - 1,
                            )),
                        Text(
                          formerZOutData.creditCardTotalInSystem,
                          style: TextStyle(
                            fontSize: getMediumFontSize,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Text(staticTextTranslate('Credit Card Total'),
                            style: TextStyle(
                              fontSize: getMediumFontSize - 1,
                            )),
                        const SizedBox(
                          height: 0,
                        ),
                        Text(
                          formerZOutData.allPaymentMethodsTotals[
                                  PaymentMethodKey().creditCard]
                              .toString(),
                          style: TextStyle(
                            fontSize: getMediumFontSize,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        Text(staticTextTranslate('Total N/C Difference'),
                            style: TextStyle(
                              fontSize: getMediumFontSize - 1,
                            )),
                        Text(
                          formerZOutData.totalNCDifferences,
                          style: TextStyle(
                            fontSize: getMediumFontSize,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        SizedBox(
                          height: 20,
                          child: Center(
                            child: Container(
                              height: 1,
                              color: Colors.grey,
                              width: 200,
                            ),
                          ),
                        ),
                        Text(staticTextTranslate('Total Cash On System'),
                            style: TextStyle(
                              fontSize: getMediumFontSize - 1,
                            )),
                        Text(
                          formerZOutData.totalCashOnSystem,
                          style: TextStyle(
                            fontSize: getMediumFontSize,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Text(staticTextTranslate('Total Cash Entered'),
                            style: TextStyle(
                              fontSize: getMediumFontSize - 1,
                            )),
                        Text(
                          formerZOutData.totalCashEntered,
                          style: TextStyle(
                            fontSize: getMediumFontSize,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Text(staticTextTranslate('Total Cash Difference'),
                            style: TextStyle(
                              fontSize: getMediumFontSize - 1,
                            )),
                        Text(
                          formerZOutData.overShort,
                          style: TextStyle(
                            fontSize: getMediumFontSize,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ],
        ));
  }
}

class FormerZoutDataSource extends DataGridSource {
  FormerZoutDataSource(
      {required List<FormerZOutData> formerZOutData,
      required List<StoreData> storeDataLst}) {
    _employeeData = formerZOutData.map<DataGridRow>((e) {
      String storeName = '';

      int i =
          storeDataLst.indexWhere((ele) => ele.docId == e.selectedStoreDocId);
      if (i != -1) {
        storeName = storeDataLst.elementAt(i).storeName;
      }
      return DataGridRow(cells: [
        DataGridCell<int>(
            columnName: 'serialNumberForStyleColor',
            value: formerZOutData.indexOf(e) + 1),
        DataGridCell<String>(columnName: 'zout#', value: e.formerZoutNo),
        DataGridCell<String>(columnName: 'total', value: e.total),
        DataGridCell<String>(columnName: 'cashier_name', value: e.cashierName),
        DataGridCell<String>(columnName: 'store_name', value: storeName),
        DataGridCell<String>(columnName: 'over/short', value: e.overShort),
      ]);
    }).toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        color: row.getCells()[0].value.isEven
            ? const Color.fromARGB(255, 246, 247, 255)
            : Colors.white,
        cells: row.getCells().map<Widget>((e) {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(1.0),
            child: Text(
              e.value.toString(),
              style: GoogleFonts.roboto(
                  fontSize: getMediumFontSize, fontWeight: FontWeight.w500),
            ),
          );
        }).toList());
  }
}
