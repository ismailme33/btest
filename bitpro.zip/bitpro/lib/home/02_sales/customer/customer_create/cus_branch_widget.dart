import 'package:bitpro_hive/model/customer_data.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/onpage_panel.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';

class CusomerBranchWidget extends StatefulWidget {
  final List<CustomerBranchData> customerBranchData;
  final bool hideCustomTab;
  final Function(CustomerBranchData) addCustomerBranchData;
  final Function(CustomerBranchData) updateCustomerBranchData;
  final Function(String) deleteCustomerBranchData;
  const CusomerBranchWidget(
      {super.key,
      required this.updateCustomerBranchData,
      required this.addCustomerBranchData,
      required this.deleteCustomerBranchData,
      required this.customerBranchData,
      required this.hideCustomTab});

  @override
  State<CusomerBranchWidget> createState() => _CusomerBranchWidgetState();
}

class _CusomerBranchWidgetState extends State<CusomerBranchWidget> {
  final List<BitproGridColumnModel> _bitproGridColumnModel = [
    BitproGridColumnModel(
      columnName: 'serialNumberForStyleColor',
      label: 'serialNumberForStyleColor',
      width: 100.0, // Default width since not explicitly set
      visible: false,
      allowEditing: false,
    ),
    BitproGridColumnModel(
        columnName: 'docId',
        label: staticTextTranslate('docid'),
        width: 150,
        allowEditing: false,
        visible: false),
    BitproGridColumnModel(
      columnName: 'b_name',
      label: staticTextTranslate('Branch Name'),
      width: 150,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'b_address',
      label: staticTextTranslate('Branch Address'),
      width: 250.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'b_phone',
      label: staticTextTranslate('Branch Phone'),
      width: 170.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'phone',
      label: staticTextTranslate('Phone'),
      width: 150.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'carrier',
      label: staticTextTranslate('Carrier'),
      width: 143.0,
      allowEditing: false,
    ),
  ];
  CustomerBranchDataSource? customerBranchDataSource;
  DataGridController dataGridController = DataGridController();

  bool isLoading = false;

  @override
  void initState() {
    initData();
    super.initState();
  }

  initData() {
    customerBranchDataSource =
        CustomerBranchDataSource(customerBranchData: widget.customerBranchData);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.sizeOf(context).width *
        (widget.hideCustomTab ? 0.488 : 0.519);
    double height = MediaQuery.sizeOf(context).height;
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: width,
        decoration: BoxDecoration(
            border: Border.all(width: 0.3),
            color: const Color(0xffE2E2E2),
            borderRadius: BorderRadius.circular(3)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 35,
              padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(4), topRight: Radius.circular(4)),
                gradient: LinearGradient(
                    end: Alignment.bottomCenter,
                    colors: [
                      Color.fromARGB(255, 51, 51, 51),
                      Color.fromARGB(255, 51, 51, 51),
                      //Color.fromARGB(255, 0, 0, 0),
                    ],
                    begin: Alignment.topCenter),
              ),
              child: Row(
                children: [
                  Text(
                    staticTextTranslate('Branch'),
                    style: GoogleFonts.roboto(
                        fontSize: 16,
                        fontWeight: FontWeight.w400,
                        color: Colors.white),
                  )
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            actionButton(height),
            SizedBox(
              height: 10,
            ),
            if (isLoading)
              Expanded(child: showLoading())
            else
              BitproGridTable(
                onChangeRefershFunction: () {
                  setState(() {});
                },
                showCheckBoxAlso: true,
                dataGridController: dataGridController,
                source: customerBranchDataSource!,
                allowEditing: false,
                allowSorting: true,
                bitproGridColumnModel: _bitproGridColumnModel,
              ),
          ],
        ),
      ),
    );
  }

  Future<CustomerBranchData?> customerBranchDialog({
    required double height,
    required String title,
    bool viewOnly = false,
    CustomerBranchData? customerBranchData,
  }) async {
    return await showDialog(
        context: context,
        builder: (context) {
          String branchName = '';
          String branchAddress = '';
          String branchPhone = '';
          String phone = '';
          String carrier = '';

          if (customerBranchData != null) {
            branchName = customerBranchData.branchName;
            branchAddress = customerBranchData.branchAddress;
            branchPhone = customerBranchData.branchPhone;
            phone = customerBranchData.phone;
            carrier = customerBranchData.carrier;
          }

          return StatefulBuilder(builder: (context, setState) {
            return Dialog(
                child: SizedBox(
              height: height * 0.6,
              child: OnPagePanel(
                  widht: 410,
                  columnForTextField: Column(
                    children: [
                      BTextField(
                        textFieldReadOnly: viewOnly,
                        redStarEnabled: true,
                        label: 'Branch Name',
                        initialValue: branchName,
                        validator: ((value) {
                          if (value!.isEmpty) {
                            return staticTextTranslate('Enter branch name');
                          }
                          return null;
                        }),
                        onChanged: (val) => setState(() {
                          branchName = val;
                        }),
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                      ),
                      BTextField(
                        textFieldReadOnly: viewOnly,
                        label: 'Branch Address',
                        initialValue: branchAddress,
                        onChanged: (val) => setState(() {
                          branchAddress = val;
                        }),
                      ),
                      BTextField(
                        textFieldReadOnly: viewOnly,
                        label: 'Branch Phone',
                        initialValue: branchPhone,
                        onChanged: (val) => setState(() {
                          branchPhone = val;
                        }),
                      ),
                      BTextField(
                        textFieldReadOnly: viewOnly,
                        label: 'Phone',
                        initialValue: phone,
                        onChanged: (val) => setState(() {
                          phone = val;
                        }),
                      ),
                      BTextField(
                        textFieldReadOnly: viewOnly,
                        label: 'Carrier',
                        initialValue: carrier,
                        onChanged: (val) => setState(() {
                          carrier = val;
                        }),
                      ),
                    ],
                  ),
                  rowForButton: viewOnly
                      ? SizedBox()
                      : Row(
                          children: [
                            OnPageButton(
                              icon: Iconsax.archive,
                              label: 'Save',
                              onPressed: () {
                                Navigator.pop(
                                    context,
                                    CustomerBranchData(
                                        docId: customerBranchData != null
                                            ? customerBranchData.docId
                                            : getRandomString(12),
                                        branchName: branchName,
                                        branchAddress: branchAddress,
                                        branchPhone: branchPhone,
                                        phone: phone,
                                        carrier: carrier));
                              },
                            ),
                          ],
                        ),
                  topLabel: title),
            ));
          });
        });
  }

  Widget actionButton(double height) {
    return Row(
      children: [
        SizedBox(
          width: 10,
        ),
        SizedBox(
          width: 70,
          child: ElevatedButton(
            onPressed: dataGridController.selectedRow == null
                ? null
                : () async {
                    var docId = '';

                    for (var c in dataGridController.selectedRow!.getCells()) {
                      if (c.columnName == 'docId') {
                        docId = c.value;
                      }
                    }

                    int index = widget.customerBranchData
                        .indexWhere((e) => e.docId == docId);
                    if (index != -1) {
                      await customerBranchDialog(
                          height: height,
                          viewOnly: true,
                          title: 'View Branch Details',
                          customerBranchData: widget.customerBranchData[index]);
                    }
                  },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
            child: Icon(
              Iconsax.eye,
              size: 20,
            ),
          ),
        ),
        SizedBox(
          width: 10,
        ),
        SizedBox(
          width: 70,
          child: ElevatedButton(
            onPressed: dataGridController.selectedRow == null
                ? null
                : () async {
                    var docId = '';

                    for (var c in dataGridController.selectedRow!.getCells()) {
                      if (c.columnName == 'docId') {
                        docId = c.value;
                      }
                    }

                    int index = widget.customerBranchData
                        .indexWhere((e) => e.docId == docId);
                    if (index != -1) {
                      bool? res = await deleteBranchConfirmationDialog();

                      if (res != null && res) {
                        widget.deleteCustomerBranchData(
                            widget.customerBranchData[index].docId);
                        customerBranchDataSource = CustomerBranchDataSource(
                            customerBranchData: widget.customerBranchData);
                      }
                    }
                  },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
            child: Icon(
              Icons.cancel,
              size: 18,
            ),
          ),
        ),
        SizedBox(
          width: 10,
        ),
        SizedBox(
          width: 70,
          child: ElevatedButton(
            onPressed: dataGridController.selectedRow == null
                ? null
                : () async {
                    var docId = '';

                    for (var c in dataGridController.selectedRow!.getCells()) {
                      if (c.columnName == 'docId') {
                        docId = c.value;
                      }
                    }

                    int index = widget.customerBranchData
                        .indexWhere((e) => e.docId == docId);
                    if (index != -1) {
                      CustomerBranchData? res = await customerBranchDialog(
                          height: height,
                          title: 'Edit Branch Details',
                          customerBranchData: widget.customerBranchData[index]);
                      if (res != null) {
                        widget.updateCustomerBranchData(res!);
                        customerBranchDataSource = CustomerBranchDataSource(
                            customerBranchData: widget.customerBranchData);
                      }
                    }
                  },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
            child: Icon(
              Icons.edit,
              size: 18,
            ),
          ),
        ),
        SizedBox(
          width: 10,
        ),
        SizedBox(
          width: 70,
          child: ElevatedButton(
            onPressed: () async {
              CustomerBranchData? res = await customerBranchDialog(
                  height: height, title: 'Add Branch Details');
              if (res != null) {
                widget.addCustomerBranchData(res);
                customerBranchDataSource = CustomerBranchDataSource(
                    customerBranchData: widget.customerBranchData);
                setState(() {});
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.black),
            child: Icon(
              Icons.add,
              size: 18,
            ),
          ),
        )
      ],
    );
  }

  Future<bool?> deleteBranchConfirmationDialog() async {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context2) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
                side: const BorderSide(width: 0.2, color: Colors.grey)),
            title: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Icon(
                  Iconsax.danger,
                  size: 20,
                ),
                const SizedBox(
                  width: 15,
                ),
                Text(staticTextTranslate('Delete'),
                    style: TextStyle(
                      fontSize: getMediumFontSize + 5,
                    )),
              ],
            ),
            content: Text(
                staticTextTranslate(
                    'Are you sure you want to delete this branch?'),
                style: TextStyle(
                  fontSize: getMediumFontSize,
                )),
            actions: [
              SizedBox(
                height: 42,
                width: 173,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        side: const BorderSide(width: 0.1, color: Colors.grey),
                        backgroundColor: Colors.grey[100],
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4))),
                    onPressed: () {
                      Navigator.pop(context2);
                    },
                    child: Text(staticTextTranslate('Cancel'),
                        style: TextStyle(
                            fontSize: getMediumFontSize, color: Colors.black))),
              ),
              SizedBox(
                height: 42,
                width: 173,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      side: const BorderSide(width: 0.1, color: Colors.grey),
                      backgroundColor: Colors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    onPressed: () async {
                      Navigator.pop(context2, true);
                    },
                    child: Text(
                      staticTextTranslate('Delete'),
                      style: TextStyle(
                        fontSize: getMediumFontSize,
                        color: Colors.white,
                      ),
                    )),
              ),
            ],
          );
        });
  }
}

class CustomerBranchDataSource extends DataGridSource {
  CustomerBranchDataSource(
      {required List<CustomerBranchData> customerBranchData}) {
    _employeeData = customerBranchData
        .map<DataGridRow>((e) => DataGridRow(cells: [
              DataGridCell<int>(
                  columnName: 'serialNumberForStyleColor',
                  value: customerBranchData.indexOf(e) + 1),
              DataGridCell<String>(columnName: 'docId', value: e.docId),
              DataGridCell<String>(columnName: 'b_name', value: e.branchName),
              DataGridCell<String>(
                  columnName: 'b_address', value: e.branchAddress),
              DataGridCell<String>(columnName: 'b_phone', value: e.branchPhone),
              DataGridCell<String>(columnName: 'phone', value: e.phone),
              DataGridCell<String>(columnName: 'carrier', value: e.carrier),
            ]))
        .toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        color: row.getCells()[0].value.isEven
            ? const Color(0xffF1F1F1)
            : Colors.white,
        cells: row.getCells().map<Widget>((e) {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(1.0),
            child: Text(
              e.value.toString(),
              style: GoogleFonts.roboto(
                  fontSize: getMediumFontSize, fontWeight: FontWeight.w500),
            ),
          );
        }).toList());
  }
}
