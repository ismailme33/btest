import 'package:bitpro_hive/home/02_sales/customer/customer_create/cus_branch_widget.dart';
import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_customer_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/onpage_panel.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:bitpro_hive/model/customer_data.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/custom_top_nav_bar.dart';
import 'package:bitpro_hive/shared/dialogs/discard_changes_dialog.dart';
import 'package:bitpro_hive/shared/loading.dart';
import '../../../../shared/global_variables/static_text_translate.dart';

class CustomerCreateEditPage extends StatefulWidget {
  final EmployeeData userData;
  final bool edit;
  final CustomerData? selectedRowData;
  final List<CustomerData> customerDataLst;
  final bool hideCustomTab;
  final String newCustomerId;
  const CustomerCreateEditPage(
      {super.key,
      required this.userData,
      this.edit = false,
      this.selectedRowData,
      this.hideCustomTab = false,
      required this.customerDataLst,
      required this.newCustomerId});

  @override
  State<CustomerCreateEditPage> createState() => _CustomerCreateEditPageState();
}

class _CustomerCreateEditPageState extends State<CustomerCreateEditPage> {
  String? customerId;
  String? customerName;

  String? address1;
  String? address2;
  String? phone1;
  String? phone2;
  String? email;
  String? openingBalance = '0';
  String? vatNumber;
  String? companyName;

  String? street;
  String? area;
  String? country;
  String? city;
  String? buildingNumber;
  String? postCode;
  String? additionalNumber;
  String? shortAddress;
  String? crNumber;

  bool loading = false;
  List<CustomerBranchData> customerBranchData = [];

  @override
  void initState() {
    super.initState();
    if (widget.edit && widget.selectedRowData != null) {
      customerId = widget.selectedRowData!.customerId;
      customerName = widget.selectedRowData!.customerName;

      address1 = widget.selectedRowData!.address1;
      address2 = widget.selectedRowData!.address2;
      phone1 = widget.selectedRowData!.phone1;
      phone2 = widget.selectedRowData!.phone2;
      email = widget.selectedRowData!.email;
      vatNumber = widget.selectedRowData!.vatNo;
      companyName = widget.selectedRowData!.companyName;
      openingBalance = widget.selectedRowData!.openingBalance;
      customerBranchData = widget.selectedRowData!.customerBranchDataLst;
      cColor = Colors.green;
      cIcon = Icons.done;

      street = widget.selectedRowData!.street;
      area = widget.selectedRowData!.area;
      country = widget.selectedRowData!.country;
      city = widget.selectedRowData!.city;
      buildingNumber = widget.selectedRowData!.buildingNumber;
      postCode = widget.selectedRowData!.postCode;
      additionalNumber = widget.selectedRowData!.additionalNumber;
      shortAddress = widget.selectedRowData!.shortAddress;
      crNumber = widget.selectedRowData!.crNumber;
    } else {
      customerId = widget.newCustomerId;
    }
  }

  Color cColor = Colors.red;
  IconData cIcon = Icons.warning;

  @override
  Widget build(BuildContext context) {
    if (widget.hideCustomTab) {
      return childBody();
    }

    return CustomNavBar(pageName: 'Customer', child: childBody());
  }

  childBody() {
    return Scaffold(
      backgroundColor: homeBgColor,
      body: SafeArea(
        child: Container(
          color: homeBgColor,
          child: Row(
            children: [
              Container(
                color: const Color.fromARGB(255, 43, 43, 43),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SideMenuButton(
                      label: 'Back',
                      iconPath: 'assets/icons/back.png',
                      buttonFunction: () {
                        showDiscardChangesDialog(context);
                      },
                    ),
                    SideMenuButton(
                        label: 'Save',
                        iconPath: 'assets/icons/save.png',
                        buttonFunction: () => onTapSaveButton())
                  ],
                ),
              ),
              const SizedBox(
                width: 0,
              ),
              Expanded(
                child: loading
                    ? showLoading()
                    : SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            OnPagePanel(
                                widht: 410,
                                columnForTextField: SingleChildScrollView(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      BTextField(
                                        textFieldReadOnly: true,
                                        label: 'Customer Id',
                                        initialValue: customerId,
                                        validator: ((value) {
                                          if (value!.isEmpty) {
                                            return staticTextTranslate(
                                                'Enter customer id');
                                          } else if ((widget.edit &&
                                                  widget.selectedRowData!
                                                          .customerId !=
                                                      value) ||
                                              !widget.edit) {
                                            if (widget.customerDataLst
                                                .where((e) =>
                                                    e.customerId == value)
                                                .isNotEmpty) {
                                              return staticTextTranslate(
                                                  'ID is already in use');
                                            }
                                          }
                                          return null;
                                        }),
                                        onChanged: (val) => setState(() {
                                          customerId = val;
                                        }),
                                        autovalidateMode:
                                            AutovalidateMode.onUserInteraction,
                                      ),
                                      BTextField(
                                        keyboardType: TextInputType.multiline,
                                        textFieldHeight: null,
                                        redStarEnabled: true,
                                        label: 'Customer Name',
                                        initialValue: customerName,
                                        onChanged: (val) => setState(() {
                                          if (val.isEmpty) {
                                            cColor = Colors.red;
                                            cIcon = Icons.warning;
                                          } else {
                                            cColor = Colors.green;
                                            cIcon = Icons.done;
                                          }
                                          customerName = val;
                                        }),
                                      ),
                                      BTextField(
                                        prefixIcon: Icons.email,
                                        label: 'Email',
                                        initialValue: email,
                                        onChanged: (val) => setState(() {
                                          email = val;
                                        }),
                                      ),
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          BTextField(
                                            fieldWidth: 175,
                                            label: 'TIN Number',
                                            bottomTxt:
                                                'Tax Identification Number',
                                            initialValue: vatNumber,
                                            onChanged: (val) => setState(() {
                                              vatNumber = val;
                                            }),
                                          ),
                                          SizedBox(
                                            width: 10,
                                          ),
                                          BTextField(
                                            fieldWidth: 175,
                                            label: 'CR Number',
                                            initialValue: crNumber,
                                            onChanged: (val) => setState(() {
                                              crNumber = val;
                                            }),
                                            bottomTxt:
                                                'Commercial Registration',
                                          ),
                                        ],
                                      ),
                                      // BTextField(
                                      //   label: 'Company Name',
                                      //   initialValue: companyName,
                                      //   onChanged: (val) => setState(() {
                                      //     companyName = val;
                                      //   }),
                                      // ),
                                      BTextField(
                                        prefixIcon: Icons.money,
                                        fieldWidth: 175,
                                        label: 'Opening balance',
                                        initialValue: openingBalance,
                                        onChanged: (val) => setState(() {
                                          openingBalance = val;
                                        }),
                                        validator: (val) {
                                          if (val != null &&
                                              double.tryParse(val) == null) {
                                            return staticTextTranslate(
                                                'Enter a valid number');
                                          }
                                          return null;
                                        },
                                        autovalidateMode:
                                            AutovalidateMode.onUserInteraction,
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      BTextField(
                                        keyboardType: TextInputType.multiline,
                                        textFieldHeight: null,
                                        prefixIcon: Icons.location_city,
                                        label: 'Address 1',
                                        initialValue: address1,
                                        onChanged: (val) => setState(() {
                                          address1 = val;
                                        }),
                                      ),
                                      BTextField(
                                        keyboardType: TextInputType.multiline,
                                        textFieldHeight: null,
                                        prefixIcon: Icons.location_city,
                                        label: 'Address 2',
                                        initialValue: address2,
                                        onChanged: (val) => setState(() {
                                          address2 = val;
                                        }),
                                      ),
                                      Row(
                                        children: [
                                          BTextField(
                                            prefixIcon: Icons.phone,
                                            fieldWidth: 175,
                                            label: 'Phone 01',
                                            initialValue: phone1,
                                            onChanged: (val) => setState(() {
                                              phone1 = val;
                                            }),
                                          ),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          BTextField(
                                            prefixIcon: Icons.phone,
                                            fieldWidth: 175,
                                            label: 'Phone 02',
                                            initialValue: phone2,
                                            onChanged: (val) => setState(() {
                                              phone2 = val;
                                            }),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          BTextField(
                                            prefixIcon: Icons.flag,
                                            fieldWidth: 175,
                                            label: 'Country',
                                            initialValue: country,
                                            onChanged: (val) => setState(() {
                                              country = val;
                                            }),
                                          ),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          BTextField(
                                            prefixIcon: Icons.location_on,
                                            fieldWidth: 175,
                                            label: 'City',
                                            initialValue: city,
                                            onChanged: (val) => setState(() {
                                              city = val;
                                            }),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          BTextField(
                                            fieldWidth: 175,
                                            label: 'Street',
                                            initialValue: street,
                                            onChanged: (val) => setState(() {
                                              street = val;
                                            }),
                                          ),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          BTextField(
                                            fieldWidth: 175,
                                            label: 'Area',
                                            initialValue: area,
                                            onChanged: (val) => setState(() {
                                              area = val;
                                            }),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          BTextField(
                                            prefixIcon: Icons.house,
                                            fieldWidth: 175,
                                            label: 'Building Number',
                                            initialValue: buildingNumber,
                                            onChanged: (val) => setState(() {
                                              buildingNumber = val;
                                            }),
                                          ),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          BTextField(
                                            fieldWidth: 175,
                                            label: 'Post Code',
                                            initialValue: postCode,
                                            onChanged: (val) => setState(() {
                                              postCode = val;
                                            }),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          BTextField(
                                            fieldWidth: 175,
                                            label: 'Additional Number',
                                            initialValue: additionalNumber,
                                            onChanged: (val) => setState(() {
                                              additionalNumber = val;
                                            }),
                                          ),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          BTextField(
                                            fieldWidth: 175,
                                            label: 'Short Address',
                                            initialValue: shortAddress,
                                            onChanged: (val) => setState(() {
                                              shortAddress = val;
                                            }),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(
                                        height: 5,
                                      ),
                                    ],
                                  ),
                                ),
                                rowForButton: Row(
                                  children: [
                                    OnPageButton(
                                      icon: Iconsax.archive,
                                      label: 'Save',
                                      onPressed: () => onTapSaveButton(),
                                    ),
                                  ],
                                ),
                                topLabel: 'Customer Details'),
                            CusomerBranchWidget(
                              hideCustomTab: widget.hideCustomTab,
                              customerBranchData: customerBranchData,
                              addCustomerBranchData: (CustomerBranchData d) {
                                customerBranchData.add(d);
                                setState(() {});
                              },
                              updateCustomerBranchData: (CustomerBranchData d) {
                                int index = customerBranchData
                                    .indexWhere((e) => e.docId == d.docId);
                                if (index != -1) {
                                  customerBranchData[index] = d;
                                  setState(() {});
                                }
                              },
                              deleteCustomerBranchData: (String docId) {
                                int index = customerBranchData
                                    .indexWhere((e) => e.docId == docId);
                                if (index != -1) {
                                  customerBranchData.removeAt(index);
                                  setState(() {});
                                }
                              },
                            )
                          ],
                        ),
                      ),
              )
            ],
          ),
        ),
      ),
    );
  }

  onTapSaveButton() async {
    if (customerName != null && customerName!.isNotEmpty) {
      setState(() {
        loading = true;
      });

      StoreData selectedStoreData =
          await HiveStoreDbService().getSelectedStoreData();

      CustomerData customerData = CustomerData(
          customerBranchDataLst: customerBranchData,
          selectedStoreDocId: selectedStoreData.docId,
          docId: widget.edit && widget.selectedRowData != null
              ? widget.selectedRowData!.docId
              : getRandomString(20),
          createdDate: widget.edit && widget.selectedRowData != null
              ? widget.selectedRowData!.createdDate
              : DateTime.now(),
          address1: address1 ?? '',
          address2: address2 ?? '',
          companyName: companyName ?? '',
          createdBy: widget.userData.empBasicInfoData.username,
          customerId: customerId ?? '',
          customerName: customerName ?? '',
          email: email ?? '',
          phone1: phone1 ?? '',
          phone2: phone2 ?? '',
          vatNo: vatNumber ?? '',
          openingBalance: openingBalance ?? '0',
          fbModifiedDate:
              widget.edit ? widget.selectedRowData!.fbModifiedDate : null,
          fbUploadedDate:
              widget.edit ? widget.selectedRowData!.fbUploadedDate : null,
          additionalNumber: additionalNumber ?? '',
          area: area ?? '',
          buildingNumber: buildingNumber ?? '',
          city: city ?? '',
          country: country ?? '',
          postCode: postCode ?? '',
          shortAddress: shortAddress ?? '',
          crNumber: crNumber ?? '',
          street: street ?? '');

      await HiveCustomerDbService().addEditCustomerData(customerData);

      Navigator.pop(context, customerData);
    }
  }
}
