import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';

class SideMenuButton extends StatelessWidget {
  final String iconPath;
  final String label;
  final Function() buttonFunction;
  final bool enable;
  const SideMenuButton(
      {super.key,
      this.enable = true,
      required this.label,
      required this.iconPath,
      required this.buttonFunction});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      width: 170,
      child: TextButton(
        style: TextButton.styleFrom(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
        onPressed: buttonFunction,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              foregroundDecoration: enable == false
                  ? const BoxDecoration(
                      color: Colors.grey,
                      backgroundBlendMode: BlendMode.saturation,
                    )
                  : null,
              child: Image.asset(
                iconPath,
                width: 20,
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            Text(staticTextTranslate(label),
                style: TextStyle(
                    fontSize: getMediumFontSize,
                    color: enable == false
                        ? Colors.grey
                        : const Color.fromARGB(255, 255, 255, 255))),
          ],
        ),
      ),
    );
  }
}
