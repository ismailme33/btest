import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_customer_db_service.dart';
import 'package:bitpro_hive/widget/filter_container.dart';
import 'package:bitpro_hive/widget/filter_text_fileds/fiter_textfield.dart';
import 'package:bitpro_hive/widget/string_related/get_id_number.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/home/02_sales/customer/customer_create/customer_create_page.dart';
import 'package:bitpro_hive/home/02_sales/customer/customer_payment/customer_payment_page.dart';
import 'package:bitpro_hive/shared/custom_top_nav_bar.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';
import '../../../model/customer_data.dart';
import '../../../shared/global_variables/font_sizes.dart';
import '../../../shared/global_variables/static_text_translate.dart';

class CustomerPage extends StatefulWidget {
  final EmployeeData userData;

  const CustomerPage({Key? key, required this.userData}) : super(key: key);

  @override
  State<CustomerPage> createState() => _CustomerPageState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _CustomerPageState extends State<CustomerPage> {
  final List<BitproGridColumnModel> _bitproGridColumnModel = [
    BitproGridColumnModel(
      columnName: 'serialNumberForStyleColor',
      label: 'serialNumberForStyleColor',
      width: 100.0, // Default width since not explicitly set
      visible: false,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'id',
      label: staticTextTranslate('Customer Id'),
      width: 150,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'name',
      label: staticTextTranslate('Customer Name'),
      width: 250.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'vat no',
      label: staticTextTranslate('VAT Number'),
      width: 170.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'company',
      label: staticTextTranslate('Company'),
      width: 150.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'phone1',
      label: staticTextTranslate('Phone 01'),
      width: 143.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'created date',
      label: staticTextTranslate('Created Date'),
      width: 169.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'created by',
      label: staticTextTranslate('Created by'),
      width: 139.0,
      allowEditing: false,
    ),
  ];
  CustomerDataSource? customerDataSource;
  DataGridController dataGridController = DataGridController();
  DateTime? rangeStartDate;
  DateTime? rangeEndDate;
  bool loading = true;
  var customerIdController = TextEditingController();
  var customerNameController = TextEditingController();
  var customerPhoneController = TextEditingController();
  var customerPhone1Controller = TextEditingController();

  List<CustomerData> customerDataLst = [];
  @override
  void initState() {
    super.initState();
    hiveFetchData();
  }

  commonInit() async {
    customerDataLst.sort((b, a) => a.createdDate.compareTo(b.createdDate));
    customerDataSource = CustomerDataSource(customerData: customerDataLst);
    setState(() {
      loading = false;
    });
  }

  hiveFetchData() async {
    customerDataLst = await HiveCustomerDbService().fetchAllCustomersData();
    await commonInit();
  }

  fbFetchData() async {
    customerDataLst = await HiveCustomerDbService().fetchAllCustomersData();
    await commonInit();
  }

  filterAccordingSelectedDate() {
    List<CustomerData> filteredEmployeesDataLst = [];
    if (rangeStartDate != null && rangeEndDate != null) {
      for (var ug in customerDataLst) {
        DateTime tmp = DateTime(
            ug.createdDate.year, ug.createdDate.month, ug.createdDate.day);
        if (tmp.compareTo(rangeStartDate!) != -1 &&
            (tmp.compareTo(rangeEndDate!) != 1)) {
          filteredEmployeesDataLst.add(ug);
        }
      }
    } else if (rangeStartDate != null) {
      var res = customerDataLst.where((e) =>
          e.createdDate.day == rangeStartDate!.day &&
          e.createdDate.month == rangeStartDate!.month &&
          e.createdDate.year == rangeStartDate!.year);

      filteredEmployeesDataLst = res.toList();
    }

    customerDataSource =
        CustomerDataSource(customerData: filteredEmployeesDataLst);
    rangeStartDate = null;
    rangeEndDate = null;
    setState(() {});
  }

  searchById(String id) {
    List<CustomerData> filteredVendorDataLst = [];
    if (id.isEmpty) {
      customerDataSource = CustomerDataSource(customerData: customerDataLst);
      setState(() {});
      return;
    }

    for (var v in customerDataLst) {
      if (v.customerId.toLowerCase().contains(id.toLowerCase())) {
        filteredVendorDataLst.add(v);
      }
    }
    customerDataSource =
        CustomerDataSource(customerData: filteredVendorDataLst);
    setState(() {});
  }

  searchByCustomerName(String val) {
    List<CustomerData> filteredVendorDataLst = [];
    if (val.isEmpty) {
      customerDataSource = CustomerDataSource(customerData: customerDataLst);
      setState(() {});
      return;
    }

    for (var v in customerDataLst) {
      if (v.customerName.toLowerCase().contains(val.toLowerCase())) {
        filteredVendorDataLst.add(v);
      }
    }
    customerDataSource =
        CustomerDataSource(customerData: filteredVendorDataLst);
    setState(() {});
  }

  searchByCustomerPhone(String val) {
    List<CustomerData> filteredVendorDataLst = [];
    if (val.isEmpty) {
      customerDataSource = CustomerDataSource(customerData: customerDataLst);
      setState(() {});
      return;
    }

    for (var v in customerDataLst) {
      if (v.phone1.toLowerCase().contains(val.toLowerCase())) {
        filteredVendorDataLst.add(v);
      }
    }
    customerDataSource =
        CustomerDataSource(customerData: filteredVendorDataLst);
    setState(() {});
  }

  searchByCompanyName(String name) {
    List<CustomerData> filteredVendorDataLst = [];
    if (name.isEmpty) {
      customerDataSource = CustomerDataSource(customerData: customerDataLst);
      setState(() {});
      return;
    }

    for (var v in customerDataLst) {
      if (v.companyName.toLowerCase().contains(name.toLowerCase())) {
        filteredVendorDataLst.add(v);
      }
    }
    customerDataSource =
        CustomerDataSource(customerData: filteredVendorDataLst);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return CustomNavBar(
      pageName: 'Coustomer',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Container(
            color: homeBgColor,
            child: Container(
              color: homeBgColor,
              child: Row(
                children: [
                  Container(
                    color: const Color.fromARGB(255, 43, 43, 43),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 0,
                        ),
                        SideMenuButton(
                          label: 'Back',
                          iconPath: 'assets/icons/back.png',
                          buttonFunction: () {
                            Navigator.pop(context);
                          },
                        ),
                        SideMenuButton(
                          label: 'Create',
                          iconPath: 'assets/icons/plus.png',
                          buttonFunction: () async {
                            String newCustomerId =
                                await getIdNumber(customerDataLst.length + 1);
                            CustomerData? res = await Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        CustomerCreateEditPage(
                                          customerDataLst: customerDataLst,
                                          userData: widget.userData,
                                          newCustomerId: newCustomerId,
                                        )));
                            if (res != null) {
                              setState(() {
                                loading = true;
                              });
                              fbFetchData();
                            }
                          },
                        ),
                        SideMenuButton(
                          label: 'Edit',
                          iconPath: 'assets/icons/edit.png',
                          enable: dataGridController.selectedRow != null,
                          buttonFunction: () async {
                            if (dataGridController.selectedRow != null) {
                              var id = '';

                              for (var c in dataGridController.selectedRow!
                                  .getCells()) {
                                if (c.columnName == 'id') {
                                  id = c.value;
                                }
                              }

                              CustomerData? res = await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          CustomerCreateEditPage(
                                            newCustomerId: id,
                                            customerDataLst: customerDataLst,
                                            userData: widget.userData,
                                            edit: true,
                                            selectedRowData: customerDataLst
                                                .where(
                                                    (e) => e.customerId == id)
                                                .first,
                                          )));
                              if (res != null) {
                                setState(() {
                                  loading = true;
                                });
                                fbFetchData();
                              }
                            }
                          },
                        ),
                        const SizedBox(
                          height: 30,
                        ),
                        SideMenuButton(
                          label: 'Refresh',
                          iconPath: 'assets/icons/refresh.png',
                          buttonFunction: () async {
                            setState(() {
                              loading = true;
                            });
                            await fbFetchData();
                          },
                        ),
                        SideMenuButton(
                          label: 'Date Range',
                          iconPath: 'assets/icons/date.png',
                          buttonFunction: () {
                            showDialog(
                                context: context,
                                builder: (context) {
                                  return Dialog(
                                    child: SizedBox(
                                      width: 400,
                                      height: 380,
                                      child: SfDateRangePicker(
                                          onSelectionChanged:
                                              (DateRangePickerSelectionChangedArgs
                                                  args) {
                                            if (args.value is PickerDateRange) {
                                              rangeStartDate =
                                                  args.value.startDate;
                                              rangeEndDate = args.value.endDate;
                                              setState(() {});
                                            }
                                          },
                                          onCancel: () {
                                            Navigator.pop(context);
                                          },
                                          onSubmit: (var p0) {
                                            filterAccordingSelectedDate();
                                            Navigator.pop(context);
                                          },
                                          cancelText: 'CANCEL',
                                          confirmText: 'OK',
                                          showTodayButton: false,
                                          showActionButtons: true,
                                          view: DateRangePickerView.month,
                                          selectionMode:
                                              DateRangePickerSelectionMode
                                                  .range),
                                    ),
                                  );
                                });
                          },
                        ),
                        SideMenuButton(
                          label: 'Customer Payment',
                          iconPath: 'assets/icons/back.png',
                          enable: dataGridController.selectedRow != null,
                          buttonFunction: () {
                            if (dataGridController.selectedRow != null) {
                              var id = '';

                              for (var c in dataGridController.selectedRow!
                                  .getCells()) {
                                if (c.columnName == 'id') {
                                  id = c.value;
                                }
                              }
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => CustomerPaymentPage(
                                            userData: widget.userData,
                                            customerDataLst: customerDataLst,
                                            selectedCustomerData:
                                                customerDataLst
                                                    .where((e) =>
                                                        e.customerId == id)
                                                    .first,
                                          )));
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(
                    width: 0,
                  ),
                  Expanded(
                    child: Card(
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                width: 0.5, color: Colors.grey),
                            borderRadius: BorderRadius.circular(5)),
                        elevation: 0,
                        color: Colors.white,
                        child: Column(
                          children: [
                            //filters
                            filterWidget(),
                            if (loading) Expanded(child: showLoading()),
                            if (!loading)
                              BitproGridTable(
                                onChangeRefershFunction: () {
                                  setState(() {});
                                },
                                dataGridController: dataGridController,
                                source: customerDataSource!,
                                allowEditing: false,
                                allowSorting: true,
                                bitproGridColumnModel: _bitproGridColumnModel,
                              ),
                          ],
                        )),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  filterWidget() {
    return FilterContainer(fiterFields: [
      FilterTextField(
        onPressed: () {
          customerIdController.clear();

          customerDataSource =
              CustomerDataSource(customerData: customerDataLst);
          setState(() {});
        },
        icon: Icon(
            customerIdController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: customerIdController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        controller: customerIdController,
        hintText: 'Customer Id',
        onChanged: (val) {
          searchById(val);
        },
      ),
      FilterTextField(
        icon: Icon(
            customerNameController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: customerNameController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        hintText: 'Customer Name',
        onPressed: () {
          customerNameController.clear();

          customerDataSource =
              CustomerDataSource(customerData: customerDataLst);
          setState(() {});
        },
        onChanged: (val) {
          searchByCustomerName(val);
        },
      ),
      FilterTextField(
        onPressed: () {
          customerPhone1Controller.clear();

          customerDataSource =
              CustomerDataSource(customerData: customerDataLst);
          setState(() {});
        },
        icon: Icon(
            customerPhone1Controller.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 18,
            color: customerPhone1Controller.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        controller: customerPhone1Controller,
        hintText: 'Customer Phone',
        onChanged: (val) {
          searchByCustomerPhone(val);
        },
      ),
      FilterTextField(
        icon: Icon(
            customerPhoneController.text.isEmpty
                ? CupertinoIcons.search
                : Icons.clear,
            size: 20,
            color: customerPhoneController.text.isEmpty
                ? Colors.grey[600]
                : Colors.black),
        onPressed: () {
          customerPhoneController.clear();

          customerDataSource =
              CustomerDataSource(customerData: customerDataLst);
          setState(() {});
        },
        onChanged: (val) {
          searchByCompanyName(val);
        },
        hintText: 'Company',
        controller: customerPhoneController,
      ),
    ]);
  }
}

class CustomerDataSource extends DataGridSource {
  CustomerDataSource({required List<CustomerData> customerData}) {
    _employeeData = customerData
        .map<DataGridRow>((e) => DataGridRow(cells: [
              DataGridCell<int>(
                  columnName: 'serialNumberForStyleColor',
                  value: customerData.indexOf(e) + 1),
              DataGridCell<String>(columnName: 'id', value: e.customerId),
              DataGridCell<String>(columnName: 'name', value: e.customerName),
              DataGridCell<String>(columnName: 'vat no', value: e.vatNo),
              DataGridCell<String>(columnName: 'company', value: e.companyName),
              DataGridCell<String>(columnName: 'phone1', value: e.phone1),
              DataGridCell<String>(
                  columnName: 'created date',
                  value: DateFormat.yMd().add_jm().format(e.createdDate)),
              DataGridCell<String>(
                  columnName: 'created by', value: e.createdBy),
            ]))
        .toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        color: row.getCells()[0].value.isEven
            ? const Color(0xffF1F1F1)
            : Colors.white,
        cells: row.getCells().map<Widget>((e) {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.all(1.0),
            child: Text(
              e.value.toString(),
              style: GoogleFonts.roboto(
                  fontSize: getMediumFontSize, fontWeight: FontWeight.w500),
            ),
          );
        }).toList());
  }
}
