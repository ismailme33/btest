import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/visual_display/visual_screen.dart';
import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/shared/calcuation_functions/double_to_string.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/home/02_sales/customer/customer_page.dart';
import 'package:bitpro_hive/home/02_sales/former_z_out/former_z_out_page.dart';
import 'package:bitpro_hive/home/02_sales/promotion/promo_code_page.dart';
import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/receipt_quotation_page/receipt_and_quotation_page.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/former_z_out_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/model/user_group_data.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_former_z_out_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_sales_db_service/hive_register_db_service.dart';
import 'package:bitpro_hive/services/hive/hive_settings/hive_store_db_service.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:bitpro_hive/shared/toast.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/string_related/get_id_number.dart';
import 'package:bitpro_hive/widget/string_related/get_random_string.dart';
import '../../shared/global_variables/font_sizes.dart';
import '../../shared/global_variables/static_text_translate.dart';

class SalesPage extends StatefulWidget {
  final EmployeeData userData;
  final UserGroupData currentUserRole;

  const SalesPage({
    Key? key,
    required this.userData,
    required this.currentUserRole,
  }) : super(key: key);

  @override
  State<SalesPage> createState() => _SalesPageState();
}

class _SalesPageState extends State<SalesPage> {
  final List<BitproGridColumnModel> _bitproGridColumnModel1 = [
    BitproGridColumnModel(
      columnName: 'type',
      label: staticTextTranslate('Type'),
      width: double.nan,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'amount_on_system',
      label: staticTextTranslate('Amount on system'),
      width: double.nan,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'entered_amount',
      label: staticTextTranslate('Entered Amount'),
      width: double.nan,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'over_short',
      label: staticTextTranslate('Over / Short'),
      width: double.nan,
      allowEditing: false,
    ),
  ];

  final List<BitproGridColumnModel> _bitproGridColumnModel2 = [
    BitproGridColumnModel(
      columnName: 'type',
      label: staticTextTranslate('Type'),
      width: double.nan,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'amount',
      label: staticTextTranslate('Amount'),
      width: double.nan,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'reference',
      label: staticTextTranslate('Reference #'),
      width: double.nan,
      allowEditing: false,
    ),
  ];

  DataGridController dataGridController = DataGridController();
  DataGridController dataGridController2 = DataGridController();
  var formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        if (widget.currentUserRole.receipt)
          OnPageButton(
            label: 'Receipt',
            icon: Iconsax.receipt,
            iconSize: 20,
            width: 150,
            onPressed: () async {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          ReceiptAndQuotationPage(userData: widget.userData)));
            },
          ),
        // if (widget.currentUserRole.receipt)
        //   OnPageButton(
        //     label: 'Invoice',
        //     icon: Iconsax.receipt,
        //     iconSize: 20,
        //     width: 150,
        //     onPressed: () async {
        //       Navigator.push(
        //           context,
        //           MaterialPageRoute(
        //               builder: (context) => ReceiptAndQuotationPage(
        //                     userData: widget.userData,
        //                     isInvoice: true,
        //                   )));
        //     },
        //   ),
        if (widget.currentUserRole.customers)
          OnPageButton(
            label: 'Customer',
            icon: Iconsax.people,
            iconSize: 20,
            width: 150,
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => CustomerPage(
                            userData: widget.userData,
                          )));
            },
          ),
        if (widget.currentUserRole.registers)
          OnPageButton(
            label: 'Register',
            icon: Iconsax.keyboard_open,
            iconSize: 20,
            width: 165,
            onPressed: () {
              mainRegisterDialog();
            },
          ),
        if (widget.currentUserRole.formerZout)
          OnPageButton(
            label: 'Former Z out',
            icon: Iconsax.book,
            iconSize: 20,
            width: 170,
            onPressed: () async {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => FormerZOutPage(
                            userData: widget.userData,
                          )));
            },
          ),
        if (widget.currentUserRole.promotion)
          OnPageButton(
            label: 'Promotion',
            icon: Iconsax.discount_circle,
            iconSize: 20,
            width: 150,
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => PromoCodePage()));
            },
          ),
        if (widget.currentUserRole.promotion)
          OnPageButton(
            label: 'Quotation',
            icon: Iconsax.menu_board,
            iconSize: 20,
            width: 150,
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => ReceiptAndQuotationPage(
                            userData: widget.userData,
                            isQuotation: true,
                          )));
              // Navigator.push(
              //     context,
              //     MaterialPageRoute(
              //         builder: (context) => QuotationPage(
              //               userData: widget.userData,
              //               // isQuotation: true,
              //             )));
            },
          ),
        if (widget.currentUserRole.promotion)
          OnPageButton(
            label: 'Touch screen',
            icon: Iconsax.screenmirroring,
            iconSize: 20,
            width: 170,
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => VisualDisplay()));
            },
          ),
      ],
    );
  }

  openRegisterDialog() {
    bool dialogLoading = false;
    showDialog(
        context: context,
        builder: (context) => StatefulBuilder(builder: (context, setState2) {
              return Dialog(
                backgroundColor: homeBgColor,
                child: SizedBox(
                    height: 400,
                    width: 600,
                    child: dialogLoading
                        ? showLoading()
                        : Column(children: [
                            Container(
                              width: double.maxFinite,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 5),
                              decoration: const BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(4),
                                      topRight: Radius.circular(4)),
                                  gradient: LinearGradient(
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Color.fromARGB(255, 66, 66, 66),
                                        Color.fromARGB(255, 0, 0, 0),
                                      ],
                                      begin: Alignment.topCenter)),
                              child: Text(
                                staticTextTranslate('Open Register'),
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: getMediumFontSize + 5,
                                ),
                              ),
                            ),
                            Expanded(
                                child: SizedBox(
                              width: 600,
                              child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8.0, horizontal: 15),
                                      child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Text(
                                              staticTextTranslate(
                                                  'All Sales transactions will be counted till the closing of this register.'),
                                              style: GoogleFonts.roboto(
                                                fontSize: getMediumFontSize,
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 0,
                                            ),
                                            Text(
                                              staticTextTranslate(
                                                  'Click Open Register to Open a Register'),
                                              style: GoogleFonts.roboto(
                                                fontSize: getMediumFontSize,
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 35,
                                            ),
                                            Row(
                                              children: [
                                                SizedBox(
                                                  width: 150,
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        staticTextTranslate(
                                                            'Cashier :'),
                                                        style: GoogleFonts.roboto(
                                                            fontSize:
                                                                getMediumFontSize +
                                                                    2,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500),
                                                      ),
                                                      const SizedBox(
                                                        height: 10,
                                                      ),
                                                      Text(
                                                        staticTextTranslate(
                                                            'Date / Time :'),
                                                        style: GoogleFonts.roboto(
                                                            fontSize:
                                                                getMediumFontSize +
                                                                    2,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      widget
                                                          .userData
                                                          .empBasicInfoData
                                                          .username,
                                                      style: GoogleFonts.roboto(
                                                          fontSize:
                                                              getMediumFontSize +
                                                                  2,
                                                          fontWeight:
                                                              FontWeight.w500),
                                                    ),
                                                    const SizedBox(
                                                      height: 10,
                                                    ),
                                                    Text(
                                                      style: GoogleFonts.roboto(
                                                          fontSize:
                                                              getMediumFontSize +
                                                                  2,
                                                          fontWeight:
                                                              FontWeight.w500),
                                                      DateFormat(
                                                              'dd-MM-yyyy hh:mm a')
                                                          .format(
                                                              DateTime.now()),
                                                    ),
                                                  ],
                                                )
                                              ],
                                            )
                                          ]))),
                            )),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                width: 800,
                                decoration: const BoxDecoration(
                                    color: Color(0xffdddfe8),
                                    borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(6),
                                        bottomRight: Radius.circular(6))),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    OnPageGreyButton(
                                      label: 'Cancel',
                                      onPressed: () {
                                        Navigator.pop(context);
                                      },
                                    ),
                                    const SizedBox(width: 10),
                                    OnPageButton(
                                      label: 'Finish',
                                      icon: Iconsax.folder_open,
                                      onPressed: () async {
                                        setState2(() {
                                          dialogLoading = true;
                                        });
                                        await HiveRegisterDbService(
                                                context: context)
                                            .openRegister(widget.userData);
                                        showToast(
                                            'Register Opened Successfully',
                                            context);
                                        setState2(() {
                                          dialogLoading = false;
                                        });
                                        Navigator.pop(context);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            )
                          ])),
              );
            }));
  }

  String calculateCreditCardTotalInSytem(List<ReceiptOrQuotationData> lst) {
    double t = 0;
    for (var l in lst) {
      if (l.isReceiptType()) {
        t += double.tryParse(l.receiptBasicInfo!.allPaymentMethodAmountsInfo[
                    PaymentMethodKey().creditCard] ??
                '') ??
            0;
      }
    }
    return doubleToString(t);
  }

  String calculateCashTotalInSystem(List<ReceiptOrQuotationData> lst) {
    double t = 0;
    for (var l in lst) {
      if (l.isReceiptType()) {
        var a = double.tryParse(l.receiptBasicInfo!
                    .allPaymentMethodAmountsInfo[PaymentMethodKey().cash] ??
                '0') ??
            0;
        var b = double.tryParse(l.receiptBasicInfo!.receiptBalance) ?? 0;

        t += a - b;
      }
    }
    return doubleToString(t);
  }

  c3Screen(List<ReceiptOrQuotationData> receiptDataLst, String enterCashTotal) {
    bool loading = false;

    Map<String, double> allPaymentMethodsTotals = {
      for (var k in PaymentMethodKey().getAllPaymentMethodLst()) k: 0
    };

    for (var r in receiptDataLst) {
      if (r.isReceiptType()) {
        for (var k in r.receiptBasicInfo!.allPaymentMethodAmountsInfo.keys) {
          if (allPaymentMethodsTotals.containsKey(k)) {
            allPaymentMethodsTotals[k] = allPaymentMethodsTotals[k]! +
                (double.tryParse(
                        r.receiptBasicInfo!.allPaymentMethodAmountsInfo[k]) ??
                    0);
          }
        }
      }
    }
    showDialog(
        barrierDismissible: false,
        context: context,
        builder: (context) => StatefulBuilder(builder: (context, setState2) {
              return Dialog(
                backgroundColor: homeBgColor,
                child: SizedBox(
                    height: 450,
                    width: 600,
                    child: loading
                        ? showLoading()
                        : Column(children: [
                            Container(
                              // height: 55,
                              width: double.maxFinite,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 10),
                              decoration: const BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(4),
                                      topRight: Radius.circular(4)),
                                  gradient: LinearGradient(
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Color.fromARGB(255, 66, 66, 66),
                                        Color.fromARGB(255, 0, 0, 0),
                                      ],
                                      begin: Alignment.topCenter)),
                              child: Text(
                                staticTextTranslate('Register Closing'),
                                style: GoogleFonts.roboto(
                                  color: Colors.white,
                                  fontSize: getMediumFontSize + 5,
                                ),
                              ),
                            ),
                            Expanded(
                                child: SizedBox(
                              width: 600,
                              child: Padding(
                                  padding: const EdgeInsets.all(3.0),
                                  child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 15.0, horizontal: 15),
                                      child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            Text(
                                              staticTextTranslate('Totals'),
                                              style: GoogleFonts.roboto(
                                                fontSize: getMediumFontSize + 2,
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 10,
                                            ),
                                            BitproGridTable(
                                              fillAll: true,
                                              dataGridController:
                                                  dataGridController,
                                              source: CloseRegisterScreenB(
                                                  allPaymentMethodsTotals:
                                                      allPaymentMethodsTotals,
                                                  enterCashTotal:
                                                      enterCashTotal),
                                              allowEditing: false,
                                              allowSorting: true,
                                              bitproGridColumnModel:
                                                  _bitproGridColumnModel1,
                                              onChangeRefershFunction: () {
                                                setState(() {});
                                              },
                                            ),
                                            const SizedBox(
                                              height: 15,
                                            ),
                                            Text(
                                              staticTextTranslate(
                                                  'Total Over / Short'),
                                              style: GoogleFonts.roboto(
                                                fontSize: getMediumFontSize + 1,
                                              ),
                                            ),
                                            const SizedBox(
                                              height: 5,
                                            ),
                                            Container(
                                              width: 230,
                                              height: 30,
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  border: Border.all(
                                                      color: Colors.grey),
                                                  borderRadius:
                                                      BorderRadius.circular(3)),
                                              padding: const EdgeInsets.only(
                                                right: 10,
                                                left: 10,
                                              ),
                                              child: TextFormField(
                                                  initialValue: doubleToString(double
                                                          .parse(
                                                              enterCashTotal) -
                                                      double.parse(
                                                          calculateCashTotalInSystem(
                                                              receiptDataLst))),
                                                  onChanged: (val) {},
                                                  decoration:
                                                      const InputDecoration(
                                                    contentPadding:
                                                        EdgeInsets.only(
                                                            bottom: 22,
                                                            right: 5),
                                                    border: InputBorder.none,
                                                  )),
                                            )
                                          ]))),
                            )),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                width: 800,
                                decoration: const BoxDecoration(
                                    color: Color(0xffdddfe8),
                                    borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(4),
                                        bottomRight: Radius.circular(4))),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    OnPageButton(
                                      label: 'Back',
                                      icon: Iconsax.previous,
                                      onPressed: () {
                                        Navigator.pop(context);
                                      },
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    OnPageButton(
                                      label: 'Finish',
                                      onPressed: () async {
                                        setState(() {
                                          loading = true;
                                        });
                                        setState2(() {});
                                        String docId = getRandomString(20);
                                        List<FormerZOutData> resLst =
                                            await HiveFormerZOutDbService()
                                                .fetchAllFormerZoutData();
                                        String newFormerZoutNo =
                                            await getIdNumber(
                                                resLst.length + 1);

                                        StoreData storeData =
                                            await HiveStoreDbService()
                                                .getSelectedStoreData();

                                        DateTime registerClosingDate =
                                            DateTime.now();

                                        double total = 0;

                                        for (var v
                                            in allPaymentMethodsTotals.values) {
                                          total += v;
                                        }

                                        double overShort =
                                            double.parse(enterCashTotal) -
                                                (allPaymentMethodsTotals[
                                                        PaymentMethodKey()
                                                            .cash] ??
                                                    0);

                                        await HiveFormerZOutDbService()
                                            .addFormerZOutReceipt(
                                                FormerZOutData(
                                          docId: docId,
                                          selectedStoreDocId: storeData.docId,
                                          formerZoutNo: newFormerZoutNo,
                                          cashierName: widget.userData
                                              .empBasicInfoData.username,

                                          total: doubleToString(total),
                                          overShort: doubleToString(overShort),

                                          totalCashOnSystem:
                                              calculateCashTotalInSystem(
                                                  receiptDataLst),
                                          creditCardTotalInSystem:
                                              calculateCreditCardTotalInSytem(
                                                  receiptDataLst),

                                          totalCashEntered: enterCashTotal,

                                          openDate: widget.userData.openRegister
                                              .toString(),
                                          closeDate:
                                              registerClosingDate.toString(),

                                          allPaymentMethodsTotals:
                                              allPaymentMethodsTotals,

                                          //not used
                                          totalCashDifferences: '0',
                                          totalNCDifferences: '0',
                                        ));

                                        await HiveRegisterDbService(
                                                context: context)
                                            .closeRegister(widget.userData);

                                        showToast(
                                            'Register Closed Successfully',
                                            context);

                                        Navigator.pop(context);
                                        Navigator.pop(context);
                                      },
                                      icon: Iconsax.pen_add,
                                    ),
                                  ],
                                ),
                              ),
                            )
                          ])),
              );
            }));
  }

  closeRegisterDialog() async {
    int dialogNo = 1;
    String enterCashTotal = '';

    // ignore: use_build_context_synchronously
    showDialog(
        context: context,
        builder: (context) => StatefulBuilder(builder: (context, setState2) {
              if (dialogNo == 2) {
                return FutureBuilder<List<ReceiptOrQuotationData>>(
                    future: HiveRegisterDbService(context: context)
                        .closeRegisterData(
                            widget.userData.empBasicInfoData.username,
                            widget.userData.openRegister!),
                    builder: (context, sp) {
                      List<ReceiptOrQuotationData> receiptDataLst = [];

                      if (sp.hasData) {
                        receiptDataLst = sp.data ?? [];
                      }

                      Map<String, double> nonCurrencyPaymentMethodsTotals = {
                        for (var k in PaymentMethodKey()
                            .getNonCurrencyPaymentMethodLst())
                          k: 0
                      };

                      for (var r in receiptDataLst) {
                        if (r.isReceiptType()) {
                          for (var k in r.receiptBasicInfo!
                              .allPaymentMethodAmountsInfo.keys) {
                            if (nonCurrencyPaymentMethodsTotals
                                .containsKey(k)) {
                              nonCurrencyPaymentMethodsTotals[k] =
                                  nonCurrencyPaymentMethodsTotals[k]! +
                                      (double.tryParse(r.receiptBasicInfo!
                                                  .allPaymentMethodAmountsInfo[
                                              k]) ??
                                          0);
                            }
                          }
                        }
                      }

                      double nonCurrencyTotal = 0;
                      for (var v in nonCurrencyPaymentMethodsTotals.values) {
                        nonCurrencyTotal += v;
                      }

                      return Dialog(
                          backgroundColor: homeBgColor,
                          child: SizedBox(
                              height: 400,
                              width: 600,
                              child: sp.hasData == false
                                  ? showLoading()
                                  : Column(children: [
                                      Container(
                                        // height: 55,
                                        width: double.maxFinite,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 18, vertical: 10),
                                        decoration: const BoxDecoration(
                                            borderRadius: BorderRadius.only(
                                                topLeft: Radius.circular(4),
                                                topRight: Radius.circular(4)),
                                            gradient: LinearGradient(
                                                end: Alignment.bottomCenter,
                                                colors: [
                                                  Color.fromARGB(
                                                      255, 66, 66, 66),
                                                  Color.fromARGB(255, 0, 0, 0),
                                                ],
                                                begin: Alignment.topCenter)),
                                        child: Text(
                                          staticTextTranslate(
                                              'Register Closing'),
                                          style: GoogleFonts.roboto(
                                            color: Colors.white,
                                            fontSize: getMediumFontSize + 5,
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                          child: SizedBox(
                                        width: 600,
                                        child: Padding(
                                            padding: const EdgeInsets.all(4.0),
                                            child: Padding(
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        vertical: 15.0,
                                                        horizontal: 15),
                                                child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      const SizedBox(
                                                        height: 10,
                                                      ),
                                                      Text(
                                                        staticTextTranslate(
                                                            'Non Currency'),
                                                        style: GoogleFonts.roboto(
                                                            fontSize:
                                                                getMediumFontSize +
                                                                    2,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w400),
                                                      ),
                                                      const SizedBox(
                                                        height: 10,
                                                      ),
                                                      BitproGridTable(
                                                        onChangeRefershFunction:
                                                            () {
                                                          setState(() {});
                                                        },
                                                        fillAll: true,
                                                        dataGridController:
                                                            dataGridController,
                                                        source: CloseRegisterScreenA(
                                                            nonCurrencyPaymentMethodsTotals:
                                                                nonCurrencyPaymentMethodsTotals),
                                                        allowEditing: false,
                                                        allowSorting: true,
                                                        bitproGridColumnModel:
                                                            _bitproGridColumnModel2,
                                                      ),
                                                      const SizedBox(
                                                        height: 15,
                                                      ),
                                                      Text(
                                                        staticTextTranslate(
                                                          'Non Currency Total',
                                                        ),
                                                        style: GoogleFonts.roboto(
                                                            fontSize:
                                                                getMediumFontSize,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w500),
                                                      ),
                                                      const SizedBox(
                                                        height: 5,
                                                      ),
                                                      Container(
                                                        width: 230,
                                                        height: 30,
                                                        decoration: BoxDecoration(
                                                            color: Colors.white,
                                                            border: Border.all(
                                                                color: Colors
                                                                    .grey),
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        3)),
                                                        padding:
                                                            const EdgeInsets
                                                                .only(
                                                          right: 3,
                                                          left: 3,
                                                        ),
                                                        child: TextFormField(
                                                            style: const TextStyle(
                                                                fontSize: 16,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w400),
                                                            readOnly: true,
                                                            initialValue:
                                                                doubleToString(
                                                                    nonCurrencyTotal),
                                                            onChanged: (val) {},
                                                            decoration:
                                                                const InputDecoration(
                                                              contentPadding:
                                                                  EdgeInsets.only(
                                                                      bottom:
                                                                          22,
                                                                      right: 5),
                                                              border:
                                                                  InputBorder
                                                                      .none,
                                                            )),
                                                      )
                                                    ]))),
                                      )),
                                      Align(
                                        alignment: Alignment.bottomCenter,
                                        child: Container(
                                          width: 800,
                                          decoration: const BoxDecoration(
                                              color: Color(0xffdddfe8),
                                              borderRadius: BorderRadius.only(
                                                  bottomLeft:
                                                      Radius.circular(6),
                                                  bottomRight:
                                                      Radius.circular(6))),
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 5, vertical: 10),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              OnPageButton(
                                                label: 'Back',
                                                icon: Icons.skip_previous,
                                                onPressed: () {
                                                  setState(() {
                                                    dialogNo = 1;
                                                  });
                                                  setState2(() {});
                                                },
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              OnPageButton(
                                                label: 'Next',
                                                icon: Iconsax.next,
                                                onPressed: () async {
                                                  c3Screen(receiptDataLst,
                                                      enterCashTotal);
                                                },
                                              ),
                                            ],
                                          ),
                                        ),
                                      )
                                    ])));
                    });
              } else {
                return Dialog(
                  backgroundColor: homeBgColor,
                  child: SizedBox(
                      height: 400,
                      width: 600,
                      child: Form(
                        key: formKey,
                        child: Column(children: [
                          Container(
                            // height: 55,
                            width: double.maxFinite,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 10),
                            decoration: const BoxDecoration(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(4),
                                    topRight: Radius.circular(4)),
                                gradient: LinearGradient(
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color.fromARGB(255, 66, 66, 66),
                                      Color.fromARGB(255, 0, 0, 0),
                                    ],
                                    begin: Alignment.topCenter)),
                            child: Text(
                              staticTextTranslate('Register Closing'),
                              style: GoogleFonts.roboto(
                                color: Colors.white,
                                fontSize: getMediumFontSize + 5,
                              ),
                            ),
                          ),
                          Expanded(
                              child: SizedBox(
                            width: 600,
                            child: Padding(
                                padding: const EdgeInsets.all(4.0),
                                child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 15.0, horizontal: 15),
                                    child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          // Text(
                                          //   staticTextTranslate(
                                          //       'Register Closing'),
                                          //   style: TextStyle(
                                          //       fontSize: getLargeFontSize + 5,
                                          //       fontWeight: FontWeight.w500),
                                          // ),
                                          const SizedBox(
                                            height: 0,
                                          ),
                                          Text(
                                              staticTextTranslate(
                                                  'Enter the Closing totals to finish the Register Closing'),
                                              style: GoogleFonts.roboto(
                                                fontSize: getMediumFontSize,
                                              )),
                                          const SizedBox(
                                            height: 25,
                                          ),
                                          Text(
                                              staticTextTranslate(
                                                  'Enter cash total'),
                                              style: GoogleFonts.roboto(
                                                fontWeight: FontWeight.w500,
                                                fontSize: getMediumFontSize,
                                              )),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          SizedBox(
                                            width: 230,
                                            // height: 35,
                                            child: TextFormField(
                                                autofocus: true,
                                                style: GoogleFonts.roboto(
                                                  fontSize: 16,
                                                  height: 1,
                                                ),
                                                autovalidateMode:
                                                    AutovalidateMode
                                                        .onUserInteraction,
                                                initialValue: enterCashTotal,
                                                validator: (val) {
                                                  if (val!.isEmpty) {
                                                    return staticTextTranslate(
                                                        'Enter cash total');
                                                  } else if (double.tryParse(
                                                          val) ==
                                                      null) {
                                                    return staticTextTranslate(
                                                        'Enter a valid value');
                                                  }
                                                  return null;
                                                },
                                                onChanged: (val) {
                                                  setState(() {
                                                    enterCashTotal = val;
                                                  });
                                                  setState2(() {});
                                                },
                                                decoration: InputDecoration(
                                                  isDense: true,
                                                  contentPadding:
                                                      const EdgeInsets.all(12),
                                                  border: OutlineInputBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              3)),
                                                )),
                                          ),
                                        ]))),
                          )),
                          Align(
                            alignment: Alignment.bottomCenter,
                            child: Container(
                              width: 800,
                              decoration: const BoxDecoration(
                                  color: Color(0xffdddfe8),
                                  borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(6),
                                      bottomRight: Radius.circular(6))),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  OnPageGreyButton(
                                    label: 'Cancel',
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                  ),
                                  const SizedBox(width: 10),
                                  OnPageButton(
                                    label: 'Next',
                                    icon: Iconsax.next,
                                    onPressed: () async {
                                      if (formKey.currentState!.validate()) {
                                        setState(() {
                                          dialogNo = 2;
                                        });
                                        setState2(() {});
                                      }
                                    },
                                  )
                                ],
                              ),
                            ),
                          )
                        ]),
                      )),
                );
              }
            }));
  }

  mainRegisterDialog() {
    showDialog(
        context: context,
        builder: (context) => StatefulBuilder(builder: (context, setState2) {
              return Dialog(
                backgroundColor: homeBgColor,
                child: SizedBox(
                    height: 400,
                    width: 600,
                    child: Column(children: [
                      Container(
                        // height: 55,
                        width: double.maxFinite,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 18, vertical: 10),
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(4),
                                topRight: Radius.circular(4)),
                            gradient: LinearGradient(
                                end: Alignment.bottomCenter,
                                colors: [
                                  Color.fromARGB(255, 66, 66, 66),
                                  Color.fromARGB(255, 0, 0, 0),
                                ],
                                begin: Alignment.topCenter)),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text(
                              staticTextTranslate('Register Open / Close'),
                              style: GoogleFonts.roboto(
                                  color: Colors.white,
                                  fontSize: getMediumFontSize + 5),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                          child: SizedBox(
                        width: 600,
                        child: Padding(
                            padding: const EdgeInsets.only(top: 15.0, left: 5),
                            child: Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8.0, horizontal: 15),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      // const SizedBox(
                                      //   height: 5,
                                      // ),
                                      // Text(
                                      //   staticTextTranslate(
                                      //       'Register Open / Close'),
                                      //   style: TextStyle(
                                      //       fontSize: getLargeFontSize + 5,
                                      //       fontWeight: FontWeight.w500),
                                      // ),
                                      const SizedBox(
                                        height: 10,
                                      ),
                                      Text(
                                        staticTextTranslate(
                                            'All Sales transactions will be counted till closing this register.'),
                                        style: GoogleFonts.roboto(
                                          fontSize: getMediumFontSize + 1,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 0,
                                      ),
                                      Text(
                                        staticTextTranslate(
                                            'Click Open Register to Start making Sales. If Register is Open.'),
                                        style: GoogleFonts.roboto(
                                          fontSize: getMediumFontSize + 1,
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 0,
                                      ),
                                      Text(
                                        staticTextTranslate(
                                            'Click Close Register to Complete.'),
                                        style: GoogleFonts.roboto(
                                          fontSize: getMediumFontSize + 1,
                                        ),
                                      ),
                                      const Expanded(
                                        child: SizedBox(
                                          height: 10,
                                        ),
                                      ),

                                      Row(
                                        children: [
                                          OnPageButton(
                                            label: 'Open Register',
                                            icon: Iconsax.folder_open,
                                            backgroundColor:
                                                widget.userData.openRegister ==
                                                        null
                                                    ? Colors.transparent
                                                    : Colors.grey,
                                            onPressed: () {
                                              if (widget
                                                      .userData.openRegister ==
                                                  null) {
                                                Navigator.pop(context);
                                                openRegisterDialog();
                                              }
                                            },
                                          ),
                                          const SizedBox(
                                            width: 10,
                                          ),
                                          OnPageButton(
                                            label: 'Close Register',
                                            icon: Iconsax.pen_close,
                                            backgroundColor:
                                                widget.userData.openRegister ==
                                                        null
                                                    ? Colors.grey
                                                    : Colors.transparent,
                                            onPressed: () {
                                              if (widget
                                                      .userData.openRegister !=
                                                  null) {
                                                Navigator.pop(context);
                                                closeRegisterDialog();
                                              }
                                            },
                                          )
                                        ],
                                      ),
                                      const SizedBox(
                                        height: 25,
                                      ),
                                    ]))),
                      )),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          width: 800,
                          decoration: const BoxDecoration(
                              color: Color(0xffdddfe8),
                              borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(4),
                                  bottomRight: Radius.circular(4))),
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              OnPageGreyButton(
                                label: 'Close',
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                              )
                            ],
                          ),
                        ),
                      )
                    ])),
              );
            }));
  }
}

class CloseRegisterScreenA extends DataGridSource {
  CloseRegisterScreenA(
      {required Map<String, double> nonCurrencyPaymentMethodsTotals}) {
    _employeeData = nonCurrencyPaymentMethodsTotals.keys
        .map<DataGridRow>((e) => DataGridRow(cells: [
              DataGridCell<String>(
                  columnName: 'type', value: PaymentMethodKey().getTextName(e)),
              DataGridCell<String>(
                  columnName: 'amount',
                  value: nonCurrencyPaymentMethodsTotals[e].toString()),
              const DataGridCell<String>(columnName: 'reference', value: '0'),
            ]))
        .toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        cells: row.getCells().map<Widget>((e) {
      return Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.all(1.0),
        child: Text(
          e.value.toString(),
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: Colors.black,
              fontWeight: FontWeight.w400),
        ),
      );
    }).toList());
  }
}

class CloseRegisterScreenB extends DataGridSource {
  CloseRegisterScreenB(
      {required Map<String, double> allPaymentMethodsTotals,
      required String enterCashTotal}) {
    _employeeData = allPaymentMethodsTotals.keys
        .map((k) => DataGridRow(cells: [
              DataGridCell<String>(columnName: 'type', value: k),
              DataGridCell<String>(
                  columnName: 'amount_on_system',
                  value: doubleToString(allPaymentMethodsTotals[k] ?? 0)),
              DataGridCell<String>(
                  columnName: 'entered_amount',
                  value: k == PaymentMethodKey().cash ? enterCashTotal : '0'),
              DataGridCell<String>(
                  columnName: 'over_short',
                  value: k == PaymentMethodKey().cash
                      ? doubleToString(double.parse(enterCashTotal) -
                          (allPaymentMethodsTotals[k] ?? 0))
                      : '0'),
            ]))
        .toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        cells: row.getCells().map<Widget>((e) {
      return Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.all(1.0),
        child: Text(
          e.value.toString(),
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: e.columnName == 'over_short' &&
                      !double.parse(e.value).isNegative &&
                      e.value != '0'
                  ? Colors.green
                  : e.columnName == 'over_short' &&
                          double.parse(e.value).isNegative
                      ? Colors.red
                      : Colors.black,
              fontWeight: FontWeight.w400),
        ),
      );
    }).toList());
  }
}
