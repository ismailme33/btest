import 'package:bitpro_hive/accounting/journal_new.dart';
import 'package:bitpro_hive/accounting/payment_voucher_new.dart';
import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/hrms/ta_devices_create.dart';
import 'package:bitpro_hive/widget/filter_container.dart';
import 'package:bitpro_hive/widget/filter_text_fileds/fiter_textfield.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:bitpro_hive/model/department_data.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import '../../../shared/custom_top_nav_bar.dart';
import '../../../shared/global_variables/font_sizes.dart';

class PaymentVoucherList extends StatefulWidget {
  const PaymentVoucherList({
    super.key,
  });

  @override
  State<PaymentVoucherList> createState() => _PaymentVoucherListState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _PaymentVoucherListState extends State<PaymentVoucherList> {
  final List<BitproGridColumnModel> _bitproGridColumnModel = [
    BitproGridColumnModel(
      columnName: 'ID',
      label: 'Journal #',
      width: 200.0, // Default width since not explicitly set
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'status',
      label: 'Description',
      width: 200.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'Name',
      label: 'Date',
      width: 200.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'ipaddress',
      label: 'Reference',
      width: 200.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'port',
      label: 'Amount',
      width: 200.0, // Default width
      allowEditing: false,
    ),
    BitproGridColumnModel(
      visible: false,
      columnName: 'devicelocation',
      label: 'Device Location',
      width: 100.0, // Default width
      allowEditing: false,
    ),
  ];
  DataGridController dataGridController = DataGridController();

  DateTime? rangeEndDate;

  final departmentIdFilterController = TextEditingController();
  final departmentNameFilterController = TextEditingController();
  bool loading = true;
  List<DepartmentData> allDepartmentDataLst = [];
  final EmployeeDataSource _employeeDataSource = EmployeeDataSource();

  @override
  Widget build(BuildContext context) {
    return CustomNavBar(
      pageName: 'Payment Voucher',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Row(
            children: [
              Container(
                color: const Color.fromARGB(255, 43, 43, 43),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SideMenuButton(
                      label: 'Back',
                      iconPath: 'assets/icons/back.png',
                      buttonFunction: () {
                        Navigator.pop(context);
                      },
                    ),
                    SideMenuButton(
                        label: 'New',
                        iconPath: 'assets/icons/plus.png',
                        buttonFunction: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => PaymentVoucherNew(),
                              ));
                        }),
                    SideMenuButton(
                        label: 'Edit',
                        enable: dataGridController.selectedRow != null,
                        iconPath: 'assets/icons/edit.png',
                        buttonFunction: () {}),
                    const SizedBox(
                      height: 30,
                    ),
                    SideMenuButton(
                        label: 'Delete',
                        iconPath: 'assets/icons/cancel.png',
                        buttonFunction: () {}),
                    SideMenuButton(
                        label: 'Connect',
                        iconPath: 'assets/icons/date.png',
                        buttonFunction: () {}),
                    SideMenuButton(
                        label: 'Retrive Data',
                        iconPath: 'assets/icons/cancel.png',
                        buttonFunction: () {}),
                  ],
                ),
              ),
              Expanded(
                child: Card(
                    shape: RoundedRectangleBorder(
                        side: const BorderSide(width: 0.5, color: Colors.grey),
                        borderRadius: BorderRadius.circular(4)),
                    elevation: 0,
                    color: Colors.white,
                    child: Column(
                      children: [
                        FilterContainer(fiterFields: [filterWidget()]),
                        BitproGridTable(
                          dataGridController: dataGridController,
                          source: _employeeDataSource,
                          allowEditing: false,
                          onChangeRefershFunction: () {
                            setState(() {});
                          },
                          allowSorting: true,
                          bitproGridColumnModel: _bitproGridColumnModel,
                        ),
                      ],
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }

  filterWidget() {
    return FilterContainer(fiterFields: [
      FilterTextField(
          icon: Icon(
              departmentIdFilterController.text.isEmpty
                  ? CupertinoIcons.search
                  : Icons.clear,
              size: 18,
              color: departmentIdFilterController.text.isEmpty
                  ? Colors.grey[600]
                  : Colors.black),
          onChanged: (j) {},
          onPressed: () {},
          controller: departmentIdFilterController,
          hintText: 'Device Name'),
      FilterTextField(
          icon: Icon(
              departmentIdFilterController.text.isEmpty
                  ? CupertinoIcons.search
                  : Icons.clear,
              size: 18,
              color: departmentIdFilterController.text.isEmpty
                  ? Colors.grey[600]
                  : Colors.black),
          onChanged: (j) {},
          onPressed: () {},
          controller: departmentIdFilterController,
          hintText: 'IP Address'),
      FilterTextField(
          icon: Icon(
              departmentIdFilterController.text.isEmpty
                  ? CupertinoIcons.search
                  : Icons.clear,
              size: 18,
              color: departmentIdFilterController.text.isEmpty
                  ? Colors.grey[600]
                  : Colors.black),
          onChanged: (j) {},
          onPressed: () {},
          controller: departmentIdFilterController,
          hintText: 'Device Location'),
    ]);
  }
}

class Employee {
  Employee(this.id, this.status, this.name, this.ipaddress, this.port,
      this.devicelocation);

  final int id;
  final String status;
  final String name;
  final String ipaddress;
  final String devicelocation;
  final double port;
}

class EmployeeDataSource extends DataGridSource {
  // Dummy data list with only one entry
  final List<Employee> employees = [
    Employee(10001, 'Rent Paid for Branch 1', '15 - Feb - 2025 12:29PM', 'NA',
        2500.00, 'Jeddah')
  ];

  // Holds DataGridRow collection
  @override
  List<DataGridRow> get rows => employees.map<DataGridRow>((e) {
        return DataGridRow(cells: [
          DataGridCell<int>(columnName: 'ID', value: e.id),
          DataGridCell<String>(
            columnName: 'status',
            value: e.status,
          ),
          DataGridCell<String>(columnName: 'Name', value: e.name),
          DataGridCell<String>(columnName: 'ipaddress', value: e.ipaddress),
          DataGridCell<double>(columnName: 'port', value: e.port),
          DataGridCell<String>(
              columnName: ' final String devicelocation',
              value: e.devicelocation),
        ]);
      }).toList();

  // Mapping cell data to widgets for display
  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        cells: row.getCells().map<Widget>((cell) {
      return Container(
        color: row.getCells()[0].value.isEven
            ? const Color(0xffF1F1F1)
            : Colors.white,
        alignment: Alignment.center,
        padding: EdgeInsets.all(3.0),
        child: Text(
          cell.value.toString(),
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: Colors.black,
              fontWeight: FontWeight.w400),
        ),
      );
    }).toList());
  }
}
