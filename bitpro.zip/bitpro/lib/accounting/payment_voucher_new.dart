import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/material.dart';
import 'package:bitpro_hive/model/department_data.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import '../../../shared/custom_top_nav_bar.dart';

class PaymentVoucherNew extends StatefulWidget {
  const PaymentVoucherNew({
    super.key,
  });

  @override
  State<PaymentVoucherNew> createState() => _TaDevicesCreateState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _TaDevicesCreateState extends State<PaymentVoucherNew> {
  DataGridController dataGridController = DataGridController();

  DateTime? rangeEndDate;

  final departmentIdFilterController = TextEditingController();
  final departmentNameFilterController = TextEditingController();
  bool loading = true;
  List<DepartmentData> allDepartmentDataLst = [];

  @override
  Widget build(BuildContext context) {
    bool isChecked = true;
    return CustomNavBar(
      pageName: 'Daily Journal',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Row(
            children: [
              Container(
                color: const Color.fromARGB(255, 43, 43, 43),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SideMenuButton(
                      label: 'Back',
                      iconPath: 'assets/icons/back.png',
                      buttonFunction: () {
                        Navigator.pop(context);
                      },
                    ),
                    SideMenuButton(
                        label: 'Save',
                        iconPath: 'assets/icons/save.png',
                        buttonFunction: () {}),
                  ],
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Column(
                    children: [
                      Container(
                        width: double.infinity,
                        height: 30,
                        decoration: BoxDecoration(
                          border: Border.all(width: 0.3),
                          color: Color.fromARGB(255, 51, 51, 51),
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(4),
                              topRight: Radius.circular(4)),
                        ),
                        child: Center(
                          child: Row(
                            children: [
                              SizedBox(
                                width: 5,
                              ),
                              Text(' Journal Entry Details',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontWeight: FontWeight.w400)),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          border: Border.all(width: 0.3),
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(4),
                              bottomRight: Radius.circular(4)),
                          color: Colors.grey[300],
                        ),
                        child: Row(
                          children: [
                            SizedBox(
                              width: 340,
                              child: Column(
                                children: [
                                  BTextField(
                                    label: 'Pay to',
                                    onChanged: (input) {},
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  BTextField(
                                    label: 'Description',
                                    onChanged: (input) {},
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  BTextField(
                                    label: 'Payment by',
                                    onChanged: (input) {},
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 100,
                            ),
                            SizedBox(
                              width: 350,
                              child: Column(
                                children: [
                                  BTextField(
                                    label: 'Date',
                                    onChanged: (input) {},
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  BTextField(
                                    label: 'Journal#',
                                    onChanged: (input) {},
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  BTextField(
                                    label: 'Voucher Total',
                                    onChanged: (input) {},
                                  )
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Expanded(
                        child: Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 10, vertical: 8),
                            decoration: BoxDecoration(
                              border: Border.all(width: 0.3),
                              borderRadius: BorderRadius.circular(4),
                              color: Colors.grey[300],
                            ),
                            child: Column(
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                        width: 40,
                                        child: Text(
                                          ' LN',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                    SizedBox(
                                        width: 100,
                                        child: Text(
                                          ' A/C Num.',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                    SizedBox(
                                        width: 100,
                                        child: Text(
                                          ' Sub A/C',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                    SizedBox(
                                        width: 250,
                                        child: Text(
                                          ' A/C Name',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                    SizedBox(
                                        width: 280,
                                        child: Text(
                                          ' Description',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                    SizedBox(
                                        width: 80,
                                        child: Text(
                                          ' Currency',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                    SizedBox(
                                        width: 100,
                                        child: Text(
                                          ' Debit',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                    SizedBox(
                                        width: 100,
                                        child: Text(
                                          ' Credit',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold),
                                        )),
                                  ],
                                ),
                                SizedBox(
                                  height: 3,
                                ),
                                Expanded(
                                  child: Column(
                                    children: [
                                      Expanded(
                                        child: Container(
                                          color: Colors.grey[400],
                                          child: SingleChildScrollView(
                                            child: Column(
                                              children: [
                                                lineItem(),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.only(top: 10),
                                        child: Row(
                                          children: [
                                            SizedBox(
                                              width: 750,
                                            ),
                                            SizedBox(
                                                width: 100,
                                                height: 25,
                                                child: TextField(
                                                  style: GoogleFonts.roboto(
                                                      fontSize: 14),
                                                  decoration: InputDecoration(
                                                      fillColor: Colors.white,
                                                      filled: true,
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 4,
                                                              vertical: 0),
                                                      border: OutlineInputBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(2),
                                                          borderSide:
                                                              BorderSide(
                                                                  width: 0.5,
                                                                  color: Colors
                                                                      .black))),
                                                )),
                                            SizedBox(
                                              width: 100,
                                              height: 25,
                                              child: TextField(
                                                style: GoogleFonts.roboto(
                                                    fontSize: 14),
                                                decoration: InputDecoration(
                                                    fillColor: Colors.white,
                                                    filled: true,
                                                    contentPadding:
                                                        EdgeInsets.symmetric(
                                                            horizontal: 4,
                                                            vertical: 0),
                                                    border: OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(2),
                                                        borderSide: BorderSide(
                                                            width: 0.5,
                                                            color:
                                                                Colors.black))),
                                              ),
                                            ),
                                            SizedBox(
                                                width: 100,
                                                height: 25,
                                                child: TextField(
                                                  style: GoogleFonts.roboto(
                                                      fontSize: 14),
                                                  decoration: InputDecoration(
                                                      fillColor: Colors.white,
                                                      filled: true,
                                                      contentPadding:
                                                          EdgeInsets.symmetric(
                                                              horizontal: 4,
                                                              vertical: 0),
                                                      border: OutlineInputBorder(
                                                          borderRadius:
                                                              BorderRadius
                                                                  .circular(2),
                                                          borderSide:
                                                              BorderSide(
                                                                  width: 0.5,
                                                                  color: Colors
                                                                      .black))),
                                                )),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ],
                            )),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Container(
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          border: Border.all(width: 0.3),
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(4),
                              bottomRight: Radius.circular(4)),
                          color: Colors.grey[300],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 300,
                              child: Column(
                                children: [
                                  BTextField(
                                    fieldWidth: 200,
                                    label: 'Created by',
                                    onChanged: (input) {},
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  BTextField(
                                    fieldWidth: 200,
                                    label: 'Created Date',
                                    onChanged: (input) {},
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: 60,
                            ),
                            SizedBox(
                              width: 300,
                              child: Column(
                                children: [
                                  BTextField(
                                    fieldWidth: 200,
                                    label: 'Workstation',
                                    onChanged: (input) {},
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class lineItem extends StatelessWidget {
  const lineItem({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
            width: 40,
            height: 25,
            child: TextField(
              style: GoogleFonts.roboto(fontSize: 14),
              decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2),
                      borderSide: BorderSide(color: Colors.black))),
            )),
        SizedBox(
            width: 100,
            height: 25,
            child: TextField(
              style: GoogleFonts.roboto(fontSize: 14),
              decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2),
                      borderSide: BorderSide(color: Colors.black))),
            )),
        SizedBox(
            width: 100,
            height: 25,
            child: TextField(
              style: GoogleFonts.roboto(fontSize: 14),
              decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2),
                      borderSide: BorderSide(color: Colors.black))),
            )),
        SizedBox(
            width: 250,
            height: 25,
            child: TextField(
              style: GoogleFonts.roboto(fontSize: 14),
              decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2),
                      borderSide: BorderSide(color: Colors.black))),
            )),
        SizedBox(
            width: 280,
            height: 25,
            child: TextField(
              style: GoogleFonts.roboto(fontSize: 14),
              decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2),
                      borderSide: BorderSide(color: Colors.black))),
            )),
        SizedBox(
            width: 80,
            height: 25,
            child: TextField(
              style: GoogleFonts.roboto(fontSize: 14),
              decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2),
                      borderSide: BorderSide(width: 0.3, color: Colors.black))),
            )),
        SizedBox(
            width: 100,
            height: 25,
            child: TextField(
              style: GoogleFonts.roboto(fontSize: 14),
              decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2),
                      borderSide: BorderSide(width: 0.5, color: Colors.black))),
            )),
        SizedBox(
            width: 100,
            height: 25,
            child: TextField(
              style: GoogleFonts.roboto(fontSize: 14),
              decoration: InputDecoration(
                  fillColor: Colors.white,
                  filled: true,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(2),
                      borderSide: BorderSide(width: 0.5, color: Colors.black))),
            )),
      ],
    );
  }
}
