import 'package:bitpro_hive/accounting/journal_list.dart';
import 'package:bitpro_hive/accounting/payment_voucher_list.dart';
import 'package:bitpro_hive/accounting/receitp_voucher_list.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';

class AccountingPage extends StatelessWidget {
  const AccountingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 5,
        ),
        Text(
          'Paymets',
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: Colors.black,
              fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 5,
        ),
        Container(
          height: 0.5,
          color: Colors.black,
        ),
        SizedBox(
          height: 15,
        ),
        Wrap(
          spacing: 15,
          runSpacing: 15,
          children: [
            OnPageButton(
              label: 'Receipt Voucher',
              width: 200,
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ReceitpVoucherList(),
                    ));
              },
              icon: Icons.receipt,
            ),
            OnPageButton(
              label: 'Payment Voucher',
              width: 200,
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => PaymentVoucherList(),
                    ));
              },
              icon: Icons.note,
            ),
            OnPageButton(
              label: 'Customers',
              width: 160,
              onPressed: () {},
              icon: Iconsax.people,
            ),
            OnPageButton(
              label: 'Vendors',
              width: 150,
              onPressed: () {},
              icon: Icons.factory,
            ),
          ],
        ),
        SizedBox(
          height: 30,
        ),
        Text(
          'General Ledgers and Payrolls',
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: Colors.black,
              fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 5,
        ),
        Container(
          height: 0.5,
          color: Colors.black,
        ),
        SizedBox(
          height: 15,
        ),
        Wrap(
          spacing: 15,
          runSpacing: 15,
          children: [
            OnPageButton(
              label: 'Journal Entries',
              width: 200,
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => JournalList(),
                    ));
              },
              icon: Iconsax.book,
            ),
            // OnPageButton(
            //   label: 'Expense Record',
            //   width: 190,
            //   onPressed: () {},
            //   icon: Iconsax.d_square,
            // ),
            OnPageButton(
              label: 'Salary Processing',
              width: 200,
              onPressed: () {},
              icon: Iconsax.dollar_circle,
            ),
            OnPageButton(
              label: 'Reports',
              width: 200,
              onPressed: () {},
              icon: Icons.analytics,
            ),
          ],
        ),
        SizedBox(
          height: 30,
        ),
        Text(
          'Assets Tracking',
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: Colors.black,
              fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 5,
        ),
        Container(
          height: 0.5,
          color: Colors.black,
        ),
        SizedBox(
          height: 15,
        ),
        Wrap(
          spacing: 15,
          runSpacing: 15,
          children: [
            OnPageButton(
              label: 'General & IT Assets',
              width: 220,
              onPressed: () {},
              icon: Icons.device_hub,
            ),
            OnPageButton(
              label: 'Assets Asignment',
              width: 200,
              onPressed: () {},
              icon: Iconsax.category,
            ),
          ],
        ),
      ],
    );
  }
}
