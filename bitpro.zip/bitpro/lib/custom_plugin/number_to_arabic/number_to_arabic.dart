class NumberToArabicWords {
  static const Map<int, String> _units = {
    0: 'صفر',
    1: 'واحد',
    2: 'اثنان',
    3: 'ثلاثة',
    4: 'أربعة',
    5: 'خمسة',
    6: 'ستة',
    7: 'سبعة',
    8: 'ثمانية',
    9: 'تسعة',
  };

  static const Map<int, String> _tens = {
    10: 'عشرة',
    11: 'أحد عشر',
    12: 'اثنا عشر',
    13: 'ثلاثة عشر',
    14: 'أربعة عشر',
    15: 'خمسة عشر',
    16: 'ستة عشر',
    17: 'سبعة عشر',
    18: 'ثمانية عشر',
    19: 'تسعة عشر',
    20: 'عشرون',
    30: 'ثلاثون',
    40: 'أربعون',
    50: 'خمسون',
    60: 'ستون',
    70: 'سبعون',
    80: 'ثمانون',
    90: 'تسعون',
  };

  static const Map<int, String> _scales = {
    100: 'مائة',
    1000: 'ألف',
    1000000: 'مليون',
    1000000000: 'بليون',
    1000000000000: 'تريليون',
  };

  static String convert(double number, {bool isCurrency = false}) {
    // Handle zero case
    if (number == 0) {
      return 'صفر' + (isCurrency ? ' درهم فقط' : '');
    }

    // Split integer and decimal parts
    int integerPart = number.toInt();
    int decimalPart =
        ((number - integerPart) * 100).round(); // For two decimal places (Fils)

    String result = '';

    // Convert integer part
    if (integerPart > 0) {
      result += _convertInteger(integerPart) + (isCurrency ? ' درهم' : '');
    }

    // Convert decimal part
    if (decimalPart > 0) {
      if (result.isNotEmpty) {
        result += ' فاصلة ';
      }
      result +=
          _convertInteger(decimalPart) + (isCurrency ? ' فلس' : ' جزء من مائة');
    }

    // Append "فقط" for currency
    if (isCurrency && result.isNotEmpty) {
      result += ' فقط';
    }

    return result;
  }

  static String _convertInteger(int number) {
    if (number == 0) return '';

    String result = '';

    // Handle all scales (trillions, billions, millions, thousands, hundreds)
    for (var scale in _scales.keys.toList().reversed) {
      if (number >= scale) {
        int count = number ~/ scale;
        result += _convertInteger(count) + ' ' + _getScaleName(scale, count);
        number %= scale;
        if (number > 0) result += ' و';
      }
    }

    // Handle tens and units
    if (number > 0) {
      if (_tens.containsKey(number)) {
        result += _tens[number]!;
      } else if (number < 10) {
        result += _units[number]!;
      } else {
        int tens = (number ~/ 10) * 10;
        int units = number % 10;
        result += _tens[tens]!;
        if (units > 0) {
          result += ' و' + _units[units]!;
        }
      }
    }

    return result.trim();
  }

  static String _getScaleName(int scale, int count) {
    if (scale == 1000000000000) {
      // Trillion
      if (count == 1) return 'تريليون';
      if (count == 2) return 'تريليونان';
      if (count >= 3 && count <= 10) return 'تريليونات';
      return 'تريليون';
    } else if (scale == 1000000000) {
      // Billion
      if (count == 1) return 'بليون';
      if (count == 2) return 'بليونان';
      if (count >= 3 && count <= 10) return 'بلايين';
      return 'بليون';
    } else if (scale == 1000006) {
      // Million
      if (count == 1) return 'مليون';
      if (count == 2) return 'مليونان';
      if (count >= 3 && count <= 10) return 'ملايين';
      return 'مليون';
    } else if (scale == 1000) {
      // Thousand
      if (count == 1) return 'ألف';
      if (count == 2) return 'ألفان';
      if (count >= 3 && count <= 10) return 'آلاف';
      return 'ألف';
    } else if (scale == 100) {
      // Hundred
      if (count == 1) return 'مائة';
      if (count == 2) return 'مائتان';
      if (count >= 3 && count <= 10) return 'مئات';
      return 'مائة';
    }
    return _scales[scale]!;
  }
}
