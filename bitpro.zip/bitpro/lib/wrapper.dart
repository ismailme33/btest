import 'dart:io';
import 'package:bitpro_hive/home/license_module/license_module.dart';
import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/model/settings/license_setting_data.dart';
import 'package:bitpro_hive/shared/loading.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:bitpro_hive/auth/login_page.dart';
import 'package:bitpro_hive/home/home_page.dart';

class Wrapper extends StatefulWidget {
  const Wrapper({Key? key}) : super(key: key);

  @override
  State<Wrapper> createState() => _WrapperState();
}

class _WrapperState extends State<Wrapper> {
  var box = Hive.box('bitpro_app');

  //
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
  late WindowsDeviceInfo windowsDeviceInfo;
  bool isLoadingDeviceInfo = true;
  @override
  void initState() {
    if (Platform.isWindows) loadWindowsDeviceInfo();
    super.initState();
  }

  bool connectionChecked = true;

  // Future<bool> initializeDbConnection() async {
  // if (globalMySqlConnection != null) {
  //   try {
  //     await getMySqlConnection(context);
  //   } catch (e) {
  //     return false;
  //   }
  // }
  // return true;
  // }

  loadWindowsDeviceInfo() async {
    windowsDeviceInfo = await deviceInfo.windowsInfo;
    isLoadingDeviceInfo = false;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    // return EditablePersonPage();
    return ValueListenableBuilder<Box>(
        valueListenable: Hive.box('bitpro_app').listenable(),
        builder: (context, box, widget) {
          // box.clear();

          var res = box.get('license_data');

          LicenseSettingData? licenseData;
          if (res != null) {
            licenseData = LicenseSettingData.fromMap(res);
          }

          if (Platform.isWindows) {
            if (licenseData == null ||
                licenseData.key.isEmpty ||
                licenseData.auth.isEmpty) {
              return const LicenseModule();
            } else {
              //check license Expiry Date

              DateTime licenseExpiryDate = licenseData.expiry_date;

              if (licenseExpiryDate.compareTo(DateTime.now()) == -1) {
                return LicenseModule(
                  licenseExpiredDate: licenseExpiryDate,
                );
              }

              if (isLoadingDeviceInfo) {
                return showLoading();
              } else if (windowsDeviceInfo.productId !=
                  licenseData.windownsProductId) {
                //checking for windowsProductId for licence
                return LicenseModule(
                    licenseExpiredDate: licenseExpiryDate,
                    showDifferentDeviceKey: true);
              }
            }
          }

          bool? loggedIn = box.get('is_user_logged_in');
          Map? ud = box.get('user_data');

          if (loggedIn == null || loggedIn == false || ud == null) {
            return LoginPage(
              licenseExpiryDate: Platform.isWindows
                  ? licenseData!.expiry_date
                  : DateTime.now().add(const Duration(days: 20)),
            );
          }

          return HomePage(
            userData: EmployeeData.fromMap(ud),
          );
        });
  }
}
