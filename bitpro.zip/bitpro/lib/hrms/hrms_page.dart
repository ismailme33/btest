import 'package:bitpro_hive/hrms/shift_shedule.dart';
import 'package:bitpro_hive/hrms/ta_devices.dart';
import 'package:bitpro_hive/hrms/time_tables_view.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';

class HrmsPage extends StatelessWidget {
  const HrmsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          height: 5,
        ),
        Text(
          staticTextTranslate('Employees'),
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: Colors.black,
              fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 5,
        ),
        Container(
          height: 0.5,
          color: Colors.black,
        ),
        SizedBox(
          height: 15,
        ),
        Wrap(
          spacing: 15,
          runSpacing: 15,
          children: [
            OnPageButton(
              label: staticTextTranslate('Dashboard'),
              width: 170,
              onPressed: () {},
              icon: Icons.space_dashboard,
            ),
            OnPageButton(
              label: staticTextTranslate('Employees'),
              width: 170,
              onPressed: () {},
              icon: Iconsax.d_square,
            ),
            OnPageButton(
              label: staticTextTranslate('Employee Setup'),
              width: 190,
              onPressed: () {},
              icon: Iconsax.d_square,
            ),
          ],
        ),
        SizedBox(
          height: 30,
        ),
        Text(
          staticTextTranslate('Time & Attendance'),
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: Colors.black,
              fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 5,
        ),
        Container(
          height: 0.5,
          color: Colors.black,
        ),
        SizedBox(
          height: 15,
        ),
        Wrap(
          spacing: 15,
          runSpacing: 15,
          children: [
            OnPageButton(
              label: staticTextTranslate('Time Tracking'),
              width: 175,
              onPressed: () {},
              icon: Iconsax.timer,
            ),
            OnPageButton(
              label: staticTextTranslate('Absence & Leaves'),
              width: 205,
              onPressed: () {},
              icon: Icons.leave_bags_at_home_outlined,
            ),
            OnPageButton(
              label: staticTextTranslate('TA Devices'),
              width: 170,
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TaDevices(),
                    ));
              },
              icon: Icons.fingerprint,
            ),
            OnPageButton(
              label: staticTextTranslate('Time Tables'),
              width: 170,
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TimeTablesView(),
                    ));
              },
              icon: Icons.date_range,
            ),
            OnPageButton(
              label: staticTextTranslate('Shift Schedule'),
              width: 179,
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ShiftShedule(),
                    ));
              },
              icon: Icons.rotate_90_degrees_ccw,
            ),
            OnPageButton(
              label: staticTextTranslate('Employee Schedule'),
              width: 211,
              onPressed: () {},
              icon: Icons.schedule,
            ),
            OnPageButton(
              label: staticTextTranslate('Shifts'),
              width: 140,
              onPressed: () {},
              icon: Iconsax.d_square,
            ),
            OnPageButton(
              label: staticTextTranslate('Travel'),
              width: 150,
              onPressed: () {},
              icon: Iconsax.airplane,
            ),
          ],
        ),
        SizedBox(
          height: 30,
        ),
        Text(
          'Payroll & Others',
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: Colors.black,
              fontWeight: FontWeight.w500),
        ),
        SizedBox(
          height: 5,
        ),
        Container(
          height: 0.5,
          color: Colors.black,
        ),
        SizedBox(
          height: 15,
        ),
        Wrap(
          spacing: 15,
          runSpacing: 15,
          children: [
            OnPageButton(
              label: staticTextTranslate('Salary Processing'),
              width: 199,
              onPressed: () {},
              icon: Icons.monetization_on,
            ),
            OnPageButton(
              label: staticTextTranslate('Cases/Requests'),
              width: 195,
              onPressed: () {},
              icon: Icons.cases,
            ),
            OnPageButton(
              label: staticTextTranslate('Certificates'),
              width: 165,
              onPressed: () {},
              icon: Icons.book,
            ),
            OnPageButton(
              label: staticTextTranslate('ID Card Printing'),
              width: 200,
              onPressed: () {},
              icon: Icons.card_membership,
            ),
          ],
        ),
      ],
    );
  }
}
