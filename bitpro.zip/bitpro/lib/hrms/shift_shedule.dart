import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/widget/bitpro_grid_table.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/material.dart';
import 'package:bitpro_hive/model/department_data.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import '../../../shared/custom_top_nav_bar.dart';
import '../../../shared/global_variables/font_sizes.dart';

class ShiftShedule extends StatefulWidget {
  const ShiftShedule({
    super.key,
  });

  @override
  State<ShiftShedule> createState() => _ShiftSheduleState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _ShiftSheduleState extends State<ShiftShedule> {
  final List<BitproGridColumnModel> _bitproGridColumnModel = [
    BitproGridColumnModel(
      columnName: 'ID',
      label: 'Device ID',
      width: 150.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'status',
      label: 'Status',
      width: 150.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'Name',
      label: 'Device Name',
      width: 150.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'ipaddress',
      label: 'IP Address',
      width: 150.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'port',
      label: 'Port',
      width: 150.0,
      allowEditing: false,
    ),
    BitproGridColumnModel(
      columnName: 'devicelocation',
      label: 'Device Location',
      width:
          100.0, // Default width since minimumWidth not explicitly set for this column
      allowEditing: false,
    ),
  ];
  DataGridController dataGridController = DataGridController();

  DateTime? rangeEndDate;

  final departmentIdFilterController = TextEditingController();
  final departmentNameFilterController = TextEditingController();
  bool loading = true;
  List<DepartmentData> allDepartmentDataLst = [];
  final EmployeeDataSource _employeeDataSource = EmployeeDataSource();

  final List<String> days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  final List<int> times = List.generate(25, (index) => index); // 0 to 24
  final double width = 22;
  final double heigt = 20;

  @override
  Widget build(BuildContext context) {
    return CustomNavBar(
      pageName: 'Shift Schedule',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Row(
            children: [
              Container(
                color: const Color.fromARGB(255, 43, 43, 43),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SideMenuButton(
                      label: 'Back',
                      iconPath: 'assets/icons/back.png',
                      buttonFunction: () {
                        Navigator.pop(context);
                      },
                    ),
                    SideMenuButton(
                        label: 'Save',
                        iconPath: 'assets/icons/save.png',
                        buttonFunction: () {}),
                  ],
                ),
              ),
              Expanded(
                child: Card(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4)),
                    elevation: 0,
                    color: Colors.white,
                    child: Row(
                      children: [
                        Expanded(
                            flex: 4,
                            child: Container(
                              decoration: BoxDecoration(
                                  border: Border.all(width: 0.4),
                                  borderRadius: BorderRadius.circular(3)),
                              child: Column(
                                children: [
                                  BlackTopPanelForDialogWindow(
                                      fontSize: 18, height: 3, label: 'Shifts'),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  BitproGridTable(
                                    onChangeRefershFunction: () {
                                      setState(() {});
                                    },
                                    dataGridController: dataGridController,
                                    source: _employeeDataSource,
                                    allowEditing: false,
                                    allowSorting: true,
                                    bitproGridColumnModel:
                                        _bitproGridColumnModel,
                                  ),
                                ],
                              ),
                            )),
                        SizedBox(
                          width: 10,
                        ),
                        Expanded(
                            flex: 6,
                            child: Container(
                              decoration:
                                  BoxDecoration(border: Border.all(width: 0.3)),
                              child: Expanded(
                                child: Column(
                                  children: [
                                    BlackTopPanelForDialogWindow(
                                        fontSize: 18,
                                        height: 3,
                                        label: 'Shift Time Period'),

                                    // Time row at the top
                                    Container(
                                      padding: EdgeInsets.all(10),
                                      width: double.infinity,
                                      child: SingleChildScrollView(
                                        scrollDirection: Axis.horizontal,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.start,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding:
                                                  EdgeInsets.only(bottom: 10),
                                              child: Column(
                                                children: [
                                                  OnPageButton(
                                                      label: 'Add Time',
                                                      onPressed: () {})
                                                ],
                                              ),
                                            ),
                                            Row(
                                              children: [
                                                Container(
                                                  width: 60,
                                                  height: heigt,
                                                  decoration: BoxDecoration(
                                                      color: Colors.grey[300],
                                                      border: Border.all(
                                                          width: 0.4)),
                                                  alignment: Alignment.center,
                                                  child: Text("Time"),
                                                ),
                                                ...times.map((time) =>
                                                    Container(
                                                      width: width,
                                                      height: heigt,
                                                      alignment:
                                                          Alignment.center,
                                                      decoration: BoxDecoration(
                                                          color:
                                                              Colors.grey[300],
                                                          border: Border.all(
                                                              width: 0.4)),
                                                      child:
                                                          Text(time.toString()),
                                                    )),
                                              ],
                                            ),
                                            // Rows for each day with shift cells
                                            ...days.map((day) {
                                              return Row(
                                                children: [
                                                  // Day name in the first column
                                                  Container(
                                                    width: 60,
                                                    height: heigt,
                                                    alignment: Alignment.center,
                                                    decoration: BoxDecoration(
                                                      color: Colors.blue[100],
                                                      border: Border.all(
                                                          width: 0.4),
                                                    ),
                                                    child: Text(day),
                                                  ),
                                                  // Shift cells for each hour
                                                  ...times.map((_) => Container(
                                                        width: width,
                                                        height: heigt,
                                                        alignment:
                                                            Alignment.center,
                                                        decoration:
                                                            BoxDecoration(
                                                          border: Border.all(
                                                              width: 0.4),
                                                          color: Colors.white,
                                                        ),
                                                      )),
                                                ],
                                              );
                                            }),
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            )),
                      ],
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }
}

class Employee {
  Employee(this.id, this.status, this.name, this.ipaddress, this.port,
      this.devicelocation);

  final int id;
  final String status;
  final String name;
  final String ipaddress;
  final String devicelocation;
  final double port;
}

class EmployeeDataSource extends DataGridSource {
  // Dummy data list with only one entry
  final List<Employee> employees = [
    Employee(1, 'Connceted', 'Device 1', '192.168.1.1', 4321, 'Jeddah')
  ];

  // Holds DataGridRow collection
  @override
  List<DataGridRow> get rows => employees.map<DataGridRow>((e) {
        return DataGridRow(cells: [
          DataGridCell<int>(columnName: 'ID', value: e.id),
          DataGridCell<String>(
            columnName: 'status',
            value: e.status,
          ),
          DataGridCell<String>(columnName: 'Name', value: e.name),
          DataGridCell<String>(columnName: 'ipaddress', value: e.ipaddress),
          DataGridCell<double>(columnName: 'port', value: e.port),
          DataGridCell<String>(
              columnName: ' final String devicelocation',
              value: e.devicelocation),
        ]);
      }).toList();

  // Mapping cell data to widgets for display
  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        cells: row.getCells().map<Widget>((cell) {
      return Container(
        color: row.getCells()[0].value.isEven
            ? const Color(0xffF1F1F1)
            : Colors.white,
        alignment: Alignment.center,
        padding: EdgeInsets.all(3.0),
        child: Text(
          cell.value.toString(),
          style: GoogleFonts.roboto(
              fontSize: getMediumFontSize + 1,
              color: Colors.black,
              fontWeight: FontWeight.w400),
        ),
      );
    }).toList());
  }
}
