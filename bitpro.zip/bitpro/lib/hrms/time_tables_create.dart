import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/onpage_panel.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:bitpro_hive/model/department_data.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import '../../../shared/custom_top_nav_bar.dart';

class TimeTablesCreate extends StatefulWidget {
  const TimeTablesCreate({
    super.key,
  });

  @override
  State<TimeTablesCreate> createState() => _TimeTablesCreateState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _TimeTablesCreateState extends State<TimeTablesCreate> {
  DataGridController dataGridController = DataGridController();

  DateTime? rangeEndDate;

  final departmentIdFilterController = TextEditingController();
  final departmentNameFilterController = TextEditingController();
  bool loading = true;
  List<DepartmentData> allDepartmentDataLst = [];

  @override
  Widget build(BuildContext context) {
    bool isChecked = false;
    return CustomNavBar(
      pageName: 'Time Tables',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Row(
            children: [
              Container(
                color: const Color.fromARGB(255, 43, 43, 43),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SideMenuButton(
                      label: 'Back',
                      iconPath: 'assets/icons/back.png',
                      buttonFunction: () {
                        Navigator.pop(context);
                      },
                    ),
                    SideMenuButton(
                        label: 'Save',
                        iconPath: 'assets/icons/save.png',
                        buttonFunction: () {}),
                  ],
                ),
              ),
              Expanded(
                child: Card(
                    shape: RoundedRectangleBorder(
                        side: const BorderSide(width: 0.5, color: Colors.grey),
                        borderRadius: BorderRadius.circular(4)),
                    elevation: 0,
                    color: Colors.white,
                    child: Row(
                      children: [
                        OnPagePanel(
                            widht: 450,
                            columnForTextField: Column(
                              children: [
                                BTextField(
                                    label: 'Timetable Name', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'On Duty Time', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Off Duty Time', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Late Time (Mins)',
                                    onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Early Time (Mins)',
                                    onChanged: (j) {}),
                                SizedBox(
                                  height: 20,
                                ),
                                BTextField(
                                    label: 'Beginning in', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Ending in', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Beginning Out', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Ending Out', onChanged: (j) {}),
                                SizedBox(
                                  height: 20,
                                ),
                                BTextField(
                                    label: 'Count as Workday',
                                    onChanged: (j) {}),
                                SizedBox(
                                  height: 15,
                                ),
                                Row(
                                  children: [
                                    Container(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Checkbox(
                                            value: isChecked,
                                            onChanged: (bool? value) {
                                              setState(() {
                                                isChecked = value ?? false;
                                              });
                                            },
                                            activeColor: Colors.green,
                                            checkColor: Colors
                                                .white, // Color of the checkmark
                                          ),
                                          Text('Must Checkin'),
                                        ],
                                      ),
                                    ),
                                    SizedBox(
                                      width: 10,
                                    ),
                                    Container(
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        children: [
                                          Checkbox(
                                            value: isChecked,
                                            onChanged: (bool? value) {
                                              setState(() {
                                                isChecked = value ?? false;
                                              });
                                            },
                                            activeColor: Colors.green,
                                            checkColor: Colors
                                                .white, // Color of the checkmark
                                          ),
                                          Text('Must Checkout'),
                                        ],
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                            rowForButton: Row(
                              children: [
                                OnPageButton(label: 'Save', onPressed: () {})
                              ],
                            ),
                            topLabel: 'Time Table Details')
                      ],
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }
}
