import 'package:bitpro_hive/home/02_sales/customer/sideMenuButton.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:bitpro_hive/widget/onpage_panel.dart';
import 'package:bitpro_hive/widget/top_bar.dart';
import 'package:flutter/material.dart';
import 'package:bitpro_hive/model/department_data.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import '../../../shared/custom_top_nav_bar.dart';

class TaDevicesCreate extends StatefulWidget {
  const TaDevicesCreate({
    super.key,
  });

  @override
  State<TaDevicesCreate> createState() => _TaDevicesCreateState();
}

var selectedDataGirdListerner = ValueNotifier<DataGridRow?>(null);

class _TaDevicesCreateState extends State<TaDevicesCreate> {
  DataGridController dataGridController = DataGridController();

  DateTime? rangeEndDate;

  final departmentIdFilterController = TextEditingController();
  final departmentNameFilterController = TextEditingController();
  bool loading = true;
  List<DepartmentData> allDepartmentDataLst = [];

  @override
  Widget build(BuildContext context) {
    bool isChecked = true;
    return CustomNavBar(
      pageName: 'Time Attendance Device',
      child: Scaffold(
        backgroundColor: homeBgColor,
        body: SafeArea(
          child: Row(
            children: [
              Container(
                color: const Color.fromARGB(255, 43, 43, 43),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SideMenuButton(
                      label: 'Back',
                      iconPath: 'assets/icons/back.png',
                      buttonFunction: () {
                        Navigator.pop(context);
                      },
                    ),
                    SideMenuButton(
                        label: 'Save',
                        iconPath: 'assets/icons/save.png',
                        buttonFunction: () {}),
                  ],
                ),
              ),
              Expanded(
                child: Card(
                    shape: RoundedRectangleBorder(
                        side: const BorderSide(width: 0.5, color: Colors.grey),
                        borderRadius: BorderRadius.circular(4)),
                    elevation: 0,
                    color: Colors.white,
                    child: Row(
                      children: [
                        OnPagePanel(
                            widht: 450,
                            columnForTextField: Column(
                              children: [
                                BTextField(
                                    label: 'Device Name', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'IP / Host Name', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Port Number', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Username', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Password', onChanged: (j) {}),
                                SizedBox(
                                  height: 20,
                                ),
                                BTextField(
                                    label: 'Device Location',
                                    onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                BTextField(
                                    label: 'Sub Location', onChanged: (j) {}),
                                SizedBox(
                                  height: 5,
                                ),
                                SizedBox(
                                  height: 15,
                                ),
                                Row(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Checkbox(
                                          value: isChecked,
                                          onChanged: (bool? value) {
                                            setState(() {
                                              isChecked = value ?? false;
                                            });
                                          },
                                          activeColor: Colors.green,
                                          checkColor: Colors
                                              .white, // Color of the checkmark
                                        ),
                                        Text('Active'),
                                        SizedBox(
                                          width: 15,
                                        ),
                                        TextButton(
                                            onPressed: () {},
                                            child: Text('Test Connection'))
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(
                                  height: 15,
                                ),
                                SizedBox(
                                  height: 100,
                                  child: TextField(
                                    maxLines: 100,
                                    decoration: InputDecoration(
                                        hintText: 'Connection test Status...',
                                        filled: true,
                                        fillColor: Colors.white,
                                        border: OutlineInputBorder()),
                                  ),
                                ),
                              ],
                            ),
                            rowForButton: Row(
                              children: [
                                OnPageButton(label: 'Save', onPressed: () {})
                              ],
                            ),
                            topLabel: 'Time Attendance Device Details')
                      ],
                    )),
              )
            ],
          ),
        ),
      ),
    );
  }
}
