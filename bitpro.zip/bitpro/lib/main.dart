import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/services/hive/hive_user_db_service.dart';
import 'package:bitpro_hive/wrapper.dart';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:path_provider/path_provider.dart';
import 'package:bitpro_hive/shared/custom_top_nav_bar.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:hotkey_manager/hotkey_manager.dart';
import 'package:bitsdojo_window/bitsdojo_window.dart';
import 'dart:io';

bool logout = true;
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // For hot reload, `unregisterAll()` needs to be called.
  await hotKeyManager.unregisterAll();

  /// ensure printer profile is loaded
  // await CapabilityProfile.ensureProfileLoaded();
  // Get Documents directory and initialize Hive in a custom path within it
  final Directory documentsDirectory = await getApplicationDocumentsDirectory();
  final customPath = Directory('${documentsDirectory.path}/BitproDatabase');

  if (!await customPath.exists()) {
    await customPath.create(recursive: true);
  }

  // Initialize Hive with the custom path
  Hive.init(customPath.path);
  await Hive.openBox('bitpro_app');

  // //automatic logout
  if (logout) {
    var box = Hive.box('bitpro_app');
    Map? ud = box.get('user_data');
    if (ud != null) {
      await HiveUserDbService()
          .logoutUser(EmployeeData.fromMap(ud).empBasicInfoData.username);
    }
    //   Box box = Hive.box('bitpro_app');
    //   await box.put('is_user_logged_in', false);
    //   await box.put(
    //       'last_user_username', widget.userData.empBasicInfoData.username);
    //   logout = false;
  }

  runApp(const MyApp(
    setFullScreen: true,
  ));
  doWhenWindowReady(() {
    final win = appWindow;
    win.alignment = Alignment.center;
    win.title = "Bitpro";
    win.show();
    win.maximize();
  });
}

class MyApp extends StatefulWidget {
  final bool setFullScreen;
  const MyApp({Key? key, this.setFullScreen = false}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();

    var box = Hive.box('bitpro_app');
    String language = box.get('Selected Language') ?? 'English';
    if (language == 'English') {
      engSelectedLanguage = true;
    } else {
      engSelectedLanguage = false;
    }

    // store timer for fetching and updating
    if (box.get('fbFetchAndUpdateTimerInMin') == null) {
      box.put('fbFetchAndUpdateTimerInMin', 15);
    }

    if (widget.setFullScreen) setFullScreen();
  }

  setFullScreen() async {
    // await DesktopWindow.setFullScreen(true);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Bitpro',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
            scrollbarTheme: ScrollbarThemeData(
                crossAxisMargin: 2.0,
                mainAxisMargin: 2.0,
                thickness: MaterialStateProperty.all(7),
                radius: const Radius.circular(8),
                thumbColor: MaterialStateProperty.all(Colors.grey[700]),
                interactive: true,
                trackVisibility: MaterialStateProperty.all(true),
                trackColor: MaterialStateProperty.all(Colors.grey[300]),
                thumbVisibility: MaterialStateProperty.all(true)),
            bottomNavigationBarTheme: const BottomNavigationBarThemeData(
              backgroundColor: Colors.white,
              selectedItemColor: Color.fromARGB(255, 59, 6, 80),
              unselectedItemColor: Color.fromARGB(255, 39, 39, 39),
            ),
            useMaterial3: false,
            primarySwatch: Colors.blueGrey,
            fontFamily: 'Cisco'),
        home: CustomNavBar(pageName: '', child: const Wrapper()),
        builder: (context, child) {
          return Directionality(
              textDirection:
                  engSelectedLanguage ? TextDirection.ltr : TextDirection.rtl,
              child: child!);
        });
  }
}
