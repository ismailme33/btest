import 'dart:io';
import 'dart:ui';
import 'package:bitpro_hive/services/hive/hive_user_db_service.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
import '../shared/global_variables/font_sizes.dart';
import '../shared/loading.dart';
import '../shared/global_variables/static_text_translate.dart';
import '../shared/toast.dart';

class LoginPage extends StatefulWidget {
  final DateTime licenseExpiryDate;
  const LoginPage({super.key, required this.licenseExpiryDate});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String? username;
  String? password;
  var formKey = GlobalKey<FormState>();
  bool loading = false;
  bool obscurePassword = true;

  TextEditingController usernameController = TextEditingController();
  @override
  void initState() {
    initData();
    super.initState();
  }

  initData() async {
    Box box = Hive.box('bitpro_app');
    var data = await box.get('last_user_username');
    print(data);
    if (data != null) {
      setState(() {
        username = data;
        usernameController.text = data;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Shortcuts(
      shortcuts: <LogicalKeySet, Intent>{
        LogicalKeySet(LogicalKeyboardKey.enter):
            const LoginCallbackShortcutsIntent(name: 'onEnter'),
      },
      child: Actions(
        actions: <Type, Action<Intent>>{
          LoginCallbackShortcutsIntent:
              CallbackAction<LoginCallbackShortcutsIntent>(
                  onInvoke: (LoginCallbackShortcutsIntent intent) =>
                      onTapLogin()),
        },
        child: Scaffold(
          backgroundColor: Colors.white,
          body: Center(
            child: loading
                ? showLoading()
                : Stack(alignment: Alignment.center, children: [
                    Container(
                      width: double.infinity,
                      foregroundDecoration: const BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage('assets/bck.jpg'),
                            fit: BoxFit.cover,
                            opacity: 100),
                      ),
                      color: const Color.fromARGB(255, 201, 201, 201),
                    ),
                    Container(
                      width: 418,
                      height: 510,
                      color: Colors.transparent,
                      //we use Stack(); because we want the effects be on top of each other,
                      //  just like layer in photoshop.
                      child: Stack(
                        children: [
                          //blur effect ==> the third layer of stack
                          BackdropFilter(
                            filter: ImageFilter.blur(
                              //sigmaX is the Horizontal blur
                              sigmaX: 5.0,
                              //sigmaY is the Vertical blur
                              sigmaY: 5.0,
                            ),
                            //we use this container to scale up the blur effect to fit its
                            //  parent, without this container the blur effect doesn't appear.
                            child: Container(),
                          ),
                          //gradient effect ==> the second layer of stack
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: Colors.white.withOpacity(0.13)),
                              gradient: LinearGradient(
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                  colors: [
                                    //begin color
                                    Colors.white.withOpacity(0.2),
                                    //end color
                                    Colors.white.withOpacity(0.9),
                                  ]),
                            ),
                          ),
                          //child ==> the first/top layer of stack
                          Center(
                            child: Padding(
                              padding: const EdgeInsets.all(31.0),
                              child: Form(
                                key: formKey,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      staticTextTranslate('Login to Bitpro'),
                                      style: GoogleFonts.cairo(
                                          fontSize: getExtraLargeFontSize + 5,
                                          fontWeight: FontWeight.bold,
                                          color:
                                              Color.fromARGB(255, 1, 29, 43)),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    SizedBox(
                                      width: 300,
                                      child: Column(
                                        children: [
                                          SizedBox(
                                            height: 35,
                                            child: TextFormField(
                                              controller: usernameController,
                                              style: GoogleFonts.roboto(
                                                  height: 1.5,
                                                  fontSize: 18,
                                                  color: Colors.black),
                                              validator: (value) => value!
                                                      .isEmpty
                                                  ? staticTextTranslate(
                                                      'Please enter your username')
                                                  : null,
                                              decoration: InputDecoration(
                                                  contentPadding:
                                                      EdgeInsets.all(5),
                                                  fillColor: Colors.grey[400],
                                                  filled: true,
                                                  hintStyle: GoogleFonts.roboto(
                                                      fontSize: 16,
                                                      color: Colors.grey[700]),
                                                  hintText: staticTextTranslate(
                                                    'Username',
                                                  ),
                                                  border:
                                                      const OutlineInputBorder(),
                                                  focusedBorder:
                                                      const OutlineInputBorder(
                                                          borderSide:
                                                              BorderSide(
                                                            width: 1,
                                                            color:
                                                                Color.fromARGB(
                                                                    255,
                                                                    19,
                                                                    101,
                                                                    148),
                                                          ),
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius.circular(
                                                                      2))),
                                                  enabledBorder:
                                                      const OutlineInputBorder(
                                                          borderRadius:
                                                              BorderRadius.all(
                                                                  Radius
                                                                      .circular(
                                                                          2)),
                                                          borderSide: BorderSide(
                                                              width: 0.6,
                                                              color: Colors
                                                                  .black))),
                                              onChanged: (val) {
                                                setState(() {
                                                  username = val;
                                                });
                                              },
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          SizedBox(
                                            height: 35,
                                            child: TextFormField(
                                              // focusNode: _focusNode,
                                              style: GoogleFonts.roboto(
                                                  fontSize: 16,
                                                  color: Colors.black),
                                              obscureText: obscurePassword,
                                              validator: (value) => value!
                                                      .isEmpty
                                                  ? staticTextTranslate(
                                                      'Please enter your password')
                                                  : null,
                                              decoration: InputDecoration(
                                                  contentPadding:
                                                      EdgeInsets.all(5),
                                                  fillColor: Colors.grey[400],
                                                  filled: true,
                                                  hintStyle: GoogleFonts.roboto(
                                                      fontSize: 16,
                                                      color: Colors.grey[700]),
                                                  focusedBorder: const OutlineInputBorder(
                                                      borderRadius: BorderRadius.all(
                                                          Radius.circular(2)),
                                                      borderSide: BorderSide(
                                                          width: 1,
                                                          color: Color.fromARGB(
                                                              255, 19, 101, 148))),
                                                  enabledBorder: const OutlineInputBorder(
                                                      borderRadius: BorderRadius.all(
                                                          Radius.circular(2)),
                                                      borderSide: BorderSide(
                                                          width: 0.6,
                                                          color: Colors.black)),
                                                  suffixIcon: IconButton(
                                                      splashRadius: 1,
                                                      onPressed: () {
                                                        setState(() {
                                                          obscurePassword =
                                                              !obscurePassword;
                                                        });
                                                      },
                                                      icon: obscurePassword
                                                          ? const Icon(
                                                              Iconsax.eye,
                                                              size: 18,
                                                            )
                                                          : const Icon(
                                                              Iconsax.eye_slash,
                                                              size: 18,
                                                            )),
                                                  hintText: staticTextTranslate(
                                                      'Password'),
                                                  border: const OutlineInputBorder()),
                                              onChanged: (val) {
                                                setState(() {
                                                  password = val;
                                                });
                                              },
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 20,
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              OnPageGreyButton(
                                                width: 145,
                                                icon: Iconsax.close_circle,
                                                label: 'Close',
                                                iconColor: Colors.black,
                                                onPressed: () {
                                                  exit(0);
                                                },
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              OnPageButton(
                                                  width: 145,
                                                  label: 'Login',
                                                  onPressed: () async {
                                                    onTapLogin();
                                                  },
                                                  icon: Iconsax.login),
                                            ],
                                          ),
                                          const SizedBox(
                                            height: 30,
                                          ),
                                          Text(
                                            maxLines: 2,
                                            staticTextTranslate(
                                                'Bitpro is a trademark of Bitpro International, Bitpro Global Software Ltd.'),
                                            textAlign: TextAlign.center,
                                            style: GoogleFonts.cairo(
                                              fontSize: getMediumFontSize + 2,
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          Icon(
                                            Iconsax.message,
                                            size: 20,
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                            staticTextTranslate(
                                                """www.bitproglobal.com | support@bitproglobal.com"""),
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              fontSize: getMediumFontSize,
                                            ),
                                          ),
                                          Text(
                                            staticTextTranslate('Version 1.5'),
                                            textAlign: TextAlign.center,
                                            style: GoogleFonts.roboto(
                                              fontSize: getMediumFontSize,
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                            staticTextTranslate(
                                                'Licensed Up to: ${DateFormat('MM-dd-yyyy').format(widget.licenseExpiryDate)}'),
                                            textAlign: TextAlign.center,
                                            style: GoogleFonts.roboto(
                                                fontSize: getMediumFontSize,
                                                color: const Color.fromARGB(
                                                    255, 34, 82, 105)),
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ]),
          ),
        ),
      ),
    );
  }

  onTapLogin() async {
    if (formKey.currentState!.validate()) {
      setState(() {
        loading = true;
      });
      var userData = await HiveUserDbService().login(username!, password!);

      if (userData != null) {
        var box = Hive.box('bitpro_app');
        await box.put('user_data', userData.toMap());
        box.put('is_user_logged_in', true);
      } else {
        showToast(
            staticTextTranslate('Enter the correct username and password.'),
            context);
      }
      setState(() {
        loading = false;
      });
    }
  }
}

class LoginCallbackShortcutsIntent extends Intent {
  const LoginCallbackShortcutsIntent({required this.name});

  final String name;
}
