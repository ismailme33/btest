// import 'dart:io';

// import 'package:bitpro_hive/services/mysql/get_mysql_connection.dart';
// import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
// import 'package:desktop_window/desktop_window.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:hive/hive.dart';

// import '../main.dart';
// import '../shared/loading.dart';

// class SelectMySqlDB extends StatefulWidget {
//   const SelectMySqlDB({super.key});

//   @override
//   State<SelectMySqlDB> createState() => _SelectMySqlDBState();
// }

// class _SelectMySqlDBState extends State<SelectMySqlDB> {
//   String? hostUrl = 'localhost';
//   int? port = 3306;
//   String? user = 'root';
//   String? password;
//   var formKey = GlobalKey<FormState>();
//   bool loading = false;
//   @override
//   void initState() {
//     setWindowSize();
//     clearHive();
//     super.initState();
//   }

//   clearHive() {
//     var box = Hive.box('bitpro_app');
//     box.clear();
//   }

//   setWindowSize() async {
//     await DesktopWindow.setFullScreen(true);
//     await DesktopWindow.setMinWindowSize(const Size(550, 650));
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Shortcuts(
//       shortcuts: <LogicalKeySet, Intent>{
//         LogicalKeySet(LogicalKeyboardKey.enter):
//             const LoginCallbackShortcutsIntent(name: 'onEnter'),
//       },
//       child: Actions(
//         actions: <Type, Action<Intent>>{
//           LoginCallbackShortcutsIntent:
//               CallbackAction<LoginCallbackShortcutsIntent>(
//                   onInvoke: (LoginCallbackShortcutsIntent intent) {
//             if (formKey.currentState!.validate()) {
//               onEnterLogin();
//             }
//           }),
//         },
//         child: Scaffold(
//           backgroundColor: Colors.white,
//           body: Center(
//             child: loading
//                 ? showLoading()
//                 : Stack(alignment: Alignment.center, children: [
//                     Container(
//                       width: double.infinity,
//                       foregroundDecoration: const BoxDecoration(
//                         image: DecorationImage(
//                             image: AssetImage('assets/bcc.jpg'),
//                             fit: BoxFit.cover,
//                             opacity: 50),
//                       ),
//                       color: const Color.fromARGB(255, 201, 201, 201),
//                     ),
//                     Container(
//                       width: 400,
//                       height: 580,
//                       padding: const EdgeInsets.all(30),
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(8),
//                         color: const Color.fromARGB(255, 223, 223, 223)
//                             .withOpacity(0.85),
//                         boxShadow: [
//                           BoxShadow(
//                             color: const Color.fromARGB(255, 15, 15, 15)
//                                 .withOpacity(0.5),
//                             spreadRadius: 5,
//                             blurRadius: 7,
//                             offset: const Offset(
//                                 0, 6), // changes position of shadow
//                           ),
//                         ],
//                       ),
//                       child: SizedBox(
//                         width: 300,
//                         child: Form(
//                           key: formKey,
//                           child: Column(
//                             mainAxisAlignment: MainAxisAlignment.center,
//                             crossAxisAlignment: CrossAxisAlignment.center,
//                             children: [
//                               Text(
//                                 staticTextTranslate('Database Initialization'),
//                                 style: const TextStyle(
//                                     fontSize: 26, fontWeight: FontWeight.w600),
//                               ),
//                               const SizedBox(
//                                 height: 20,
//                               ),
//                               TextFormField(
//                                 initialValue: hostUrl,
//                                 validator: (value) => value!.isEmpty
//                                     ? staticTextTranslate(
//                                         'Please enter the host url')
//                                     : null,
//                                 decoration: InputDecoration(
//                                     alignLabelWithHint: true,
//                                     labelText: staticTextTranslate('Host Url'),
//                                     border: const OutlineInputBorder()),
//                                 onChanged: (val) {
//                                   setState(() {
//                                     hostUrl = val;
//                                   });
//                                 },
//                               ),
//                               const SizedBox(
//                                 height: 20,
//                               ),
//                               TextFormField(
//                                 initialValue: port.toString(),
//                                 validator: (value) => value!.isEmpty
//                                     ? staticTextTranslate(
//                                         'Please enter the port')
//                                     : null,
//                                 decoration: InputDecoration(
//                                     alignLabelWithHint: true,
//                                     labelText: staticTextTranslate('Port'),
//                                     border: const OutlineInputBorder()),
//                                 onChanged: (val) {
//                                   setState(() {
//                                     port = int.parse(val);
//                                   });
//                                 },
//                               ),
//                               const SizedBox(
//                                 height: 20,
//                               ),
//                               TextFormField(
//                                 initialValue: user,
//                                 validator: (value) => value!.isEmpty
//                                     ? staticTextTranslate(
//                                         'Please enter the user')
//                                     : null,
//                                 decoration: InputDecoration(
//                                     alignLabelWithHint: true,
//                                     labelText: staticTextTranslate('User'),
//                                     border: const OutlineInputBorder()),
//                                 onChanged: (val) {
//                                   setState(() {
//                                     user = val;
//                                   });
//                                 },
//                               ),
//                               const SizedBox(
//                                 height: 20,
//                               ),
//                               TextFormField(
//                                 initialValue: password,
//                                 decoration: InputDecoration(
//                                     alignLabelWithHint: true,
//                                     labelText: staticTextTranslate('Password'),
//                                     border: const OutlineInputBorder()),
//                                 onChanged: (val) {
//                                   setState(() {
//                                     password = val;
//                                   });
//                                 },
//                               ),
//                               const SizedBox(
//                                 height: 20,
//                               ),
//                               Row(
//                                 mainAxisAlignment: MainAxisAlignment.end,
//                                 children: [
//                                   SizedBox(
//                                     height: 45,
//                                     width: 163,
//                                     child: ElevatedButton(
//                                         style: ElevatedButton.styleFrom(
//                                             backgroundColor: Colors.white),
//                                         onPressed: () {
//                                           exit(0);
//                                         },
//                                         child: Row(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.center,
//                                           children: [
//                                             Icon(Icons.cancel,
//                                                 color: Colors.black),
//                                             const SizedBox(
//                                               width: 10,
//                                             ),
//                                             Text(
//                                               staticTextTranslate('Cancel'),
//                                               style: TextStyle(
//                                                   color: Colors.black),
//                                             ),
//                                           ],
//                                         )),
//                                   ),
//                                   const SizedBox(
//                                     width: 10,
//                                   ),
//                                   SizedBox(
//                                     height: 45,
//                                     width: 165,
//                                     child: ElevatedButton(
//                                         style: ElevatedButton.styleFrom(),
//                                         onPressed: () async {
//                                           if (formKey.currentState!
//                                               .validate()) {
//                                             onEnterLogin();
//                                           }
//                                         },
//                                         child: Row(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.center,
//                                           children: [
//                                             const Icon(
//                                                 Icons.developer_board_sharp),
//                                             const SizedBox(
//                                               width: 10,
//                                             ),
//                                             Text(staticTextTranslate(
//                                                 'Continue')),
//                                           ],
//                                         )),
//                                   ),
//                                 ],
//                               ),
//                               const SizedBox(
//                                 height: 30,
//                               ),
//                             ],
//                           ),
//                         ),
//                       ),
//                     ),
//                   ]),
//           ),
//         ),
//       ),
//     );
//   }

//   onEnterLogin() async {
//     setState(() {
//       loading = true;
//     });

//     int status = await checkMySqlDBExits(
//         host: hostUrl!,
//         password: password,
//         port: port!,
//         user: user!,
//         context:
//             context); // 1 = connected, 2 = Database not found, 3 = other errors
//     if (status == 2) {
//       // ignore: use_build_context_synchronously
//       showDialog(
//           barrierDismissible: false,
//           context: context,
//           builder: (context) => AlertDialog(
//                 title: const Text('Database not found'),
//                 content: const Text(
//                     'Do you want to create the database "$mySqlDbName" on the server?'),
//                 actions: [
//                   SizedBox(
//                       height: 45,
//                       width: 165,
//                       child: ElevatedButton(
//                         style: ElevatedButton.styleFrom(
//                             backgroundColor: Colors.grey),
//                         onPressed: () async {
//                           setState(() {
//                             loading = false;
//                           });
//                           Navigator.pop(context);
//                         },
//                         child: Text(staticTextTranslate('No')),
//                       )),
//                   SizedBox(
//                       height: 45,
//                       width: 165,
//                       child: ElevatedButton(
//                         onPressed: () async {
//                           await createDatabase(
//                               host: hostUrl!,
//                               password: password,
//                               port: port!,
//                               user: user!);
//                           onEnterLogin();
//                           Navigator.pop(context);
//                         },
//                         child: Text(staticTextTranslate('Yes')),
//                       )),
//                 ],
//               ));
//     } else {
//       setState(() {
//         loading = false;
//       });
//       Navigator.of(context).pushAndRemoveUntil(
//           MaterialPageRoute(
//               builder: (context) => MyApp(
//                     setFullScreen: false,
//                   )),
//           (Route<dynamic> route) => false);
//     }
//   }
// }

// class LoginCallbackShortcutsIntent extends Intent {
//   const LoginCallbackShortcutsIntent({required this.name});

//   final String name;
// }
