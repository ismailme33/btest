import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/shared/dialogs/discount_overlimt_dialog.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:syncfusion_flutter_datagrid/datagrid.dart';

class ReceiptQuotLineItemDataSource extends DataGridSource {
  ReceiptQuotLineItemDataSource(
      {required List<LineItemData> receiptLineItemData,
      required String maxDiscount,
      required context,
      required TaxSettingsData taxSettingsData,
      required DataGridController dataGridController}) {
    _taxSettingsData = taxSettingsData;
    _lineItemData = receiptLineItemData;
    _userMaxDiscountPer = double.tryParse(maxDiscount) ?? 0;
    _context = context;

    _dataGridRows = _lineItemData
        .map<DataGridRow>((LineItemData lineItemData) =>
            getDataGridRow(lineItemData, _lineItemData.indexOf(lineItemData)))
        .toList();
    _dataGridController = dataGridController;
    notifyListeners();
  }

  /// Get datagrid row of the dealer.
  DataGridRow getDataGridRow(
    LineItemData lineItemData,
    snum,
  ) {
    return DataGridRow(cells: <DataGridCell>[
      DataGridCell<int>(columnName: 'serialNumberForStyleColor', value: snum),
      DataGridCell<String>(columnName: 'barcode', value: lineItemData.barcode),
      DataGridCell<String>(
          columnName: 'itemCode', value: lineItemData.itemCode),
      DataGridCell<String>(
          columnName: 'productName', value: lineItemData.productName),
      DataGridCell<String>(columnName: 'qty', value: lineItemData.qty),
      DataGridCell<String>(
          columnName: 'orgPrice',
          value: double.parse(lineItemData.orgPriceWt).toStringAsFixed(digit)),
      DataGridCell<String>(
          columnName: 'discount_percentage',
          value: double.parse(lineItemData.discountPercentage)
              .toStringAsFixed(digit)),
      DataGridCell<String>(
          columnName: 'discount_value',
          value:
              double.parse(lineItemData.discountValue).toStringAsFixed(digit)),
      DataGridCell<String>(
          columnName: 'discount_value_wt',
          value: double.parse(lineItemData.discountValueWt)
              .toStringAsFixed(digit)),
      DataGridCell<String>(
          columnName: 'priceWT',
          value: double.parse(lineItemData.priceWt).toStringAsFixed(digit)),
      DataGridCell<String>(columnName: 'total', value: lineItemData.totalWt),
    ]);
  }

  @override
  List<DataGridRow> get rows => _dataGridRows;
  List<LineItemData> get lineItemData => _lineItemData;

  late BuildContext _context;
  late List<DataGridRow> _dataGridRows;
  late double _userMaxDiscountPer;

  late TaxSettingsData _taxSettingsData;

  late List<LineItemData> _lineItemData;
  late DataGridController _dataGridController;
  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    return DataGridRowAdapter(
        color: row.getCells()[0].value.isEven
            ? Colors.white
            : const Color(0xffF1F1F1),
        cells: row.getCells().map<Widget>((e) {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 2.0, vertical: 1),
            child: Text(
              overflow: TextOverflow.ellipsis,
              e.value.toString(),
              style:
                  GoogleFonts.roboto(fontSize: 14, fontWeight: FontWeight.w500),
            ),
          );
        }).toList());
  }

  dynamic newCellValue;

  /// Help to control the editable text in [TextField] widget.
  TextEditingController editingController = TextEditingController();

  @override
  Widget? buildEditWidget(DataGridRow dataGridRow,
      RowColumnIndex rowColumnIndex, GridColumn column, CellSubmit submitCell) {
    // Text going to display on editable widget
    final String displayText = dataGridRow
            .getCells()
            .firstWhere((DataGridCell dataGridCell) =>
                dataGridCell.columnName == column.columnName)
            .value
            ?.toString() ??
        '';

    newCellValue = null;

    editingController.text = displayText;
    editingController.selection = TextSelection(
        baseOffset: 0, extentOffset: editingController.value.text.length);
    return Container(
      padding: const EdgeInsets.all(8.0),
      // alignment: isNumericType ? Alignment.centerRight : Alignment.centerLeft,
      child: TextField(
        autofocus: true,
        controller: editingController,
        // textAlign: isNumericType ? TextAlign.right : TextAlign.left,
        decoration: const InputDecoration(
            contentPadding: EdgeInsets.fromLTRB(0, 0, 0, 16.0),
            border: InputBorder.none),
        // keyboardType: isNumericType ? TextInputType.number : TextInputType.text,
        onChanged: (String value) {
          if (value.isNotEmpty) {
            // if (isNumericType) {
            //   newCellValue = double.parse(value);
            // } else {
            newCellValue = value;
            // }
          } else {
            newCellValue = null;
          }
        },
        onSubmitted: (String value) {
          // In Mobile Platform.
          // Call [CellSubmit] callback to fire the canSubmitCell and
          // onCellSubmit to commit the new value in single place.
          submitCell();
        },
      ),
    );
  }

  @override
  Future<void> onCellSubmit(
    DataGridRow dataGridRow,
    RowColumnIndex rowColumnIndex,
    GridColumn column,
  ) async {
    final dynamic oldValue = dataGridRow
            .getCells()
            .firstWhere((DataGridCell dataGridCell) =>
                dataGridCell.columnName == column.columnName)
            .value ??
        '';

    final int dataRowIndex = _dataGridRows.indexOf(dataGridRow);

    if (newCellValue == null ||
        oldValue == newCellValue ||
        double.tryParse(newCellValue) == null ||
        double.parse(newCellValue).isNegative == true) {
      return;
    }

    //if qty is changed
    if (column.columnName == 'qty' && double.parse(newCellValue) != 0) {
      double newQty = double.parse(newCellValue);

      _lineItemData[dataRowIndex]
          .updateQuantity(newQty, _taxSettingsData.taxPercentage);
    }
    //if discount percentage is changed
    else if (column.columnName == 'discount_percentage') {
      double newDisPer = double.parse(newCellValue);

      if (newDisPer > _userMaxDiscountPer) {
        showDiscountOverLimitDialog(_context, _userMaxDiscountPer);
      } else {
        _lineItemData[dataRowIndex].updateDiscountPercentage(
            newDisPer, _taxSettingsData.taxPercentage);
      }
    }

    // if discount value wt is changed
    else if (column.columnName == 'discount_value_wt') {
      double newDiscountWtValue = double.parse(newCellValue);

      final LineItemData item = LineItemData(
          unitName: _lineItemData[dataRowIndex].unitName,
          cost: _lineItemData[dataRowIndex].cost,
          productName: _lineItemData[dataRowIndex].productName,
          qty: _lineItemData[dataRowIndex].qty,
          orgPrice: _lineItemData[dataRowIndex].orgPrice,
          orgPriceWt: _lineItemData[dataRowIndex].orgPriceWt,
          discountPercentage: _lineItemData[dataRowIndex].discountPercentage,
          discountPercentageWt:
              _lineItemData[dataRowIndex].discountPercentageWt,
          discountValue: _lineItemData[dataRowIndex].discountValue,
          discountValueWt: _lineItemData[dataRowIndex].discountValueWt,
          price: _lineItemData[dataRowIndex].price,
          priceWt: _lineItemData[dataRowIndex].priceWt,
          total: _lineItemData[dataRowIndex].total,
          totalWt: _lineItemData[dataRowIndex].totalWt,
          barcode: _lineItemData[dataRowIndex].barcode,
          itemCode: _lineItemData[dataRowIndex].itemCode);

      item.updateDiscountWtValue(
        newDiscountWtValue: newDiscountWtValue,
        taxPer: _taxSettingsData.taxPercentage,
      );

      if ((double.tryParse(item.discountPercentage) ?? 0) >
          _userMaxDiscountPer) {
        showDiscountOverLimitDialog(_context, _userMaxDiscountPer);
      } else {
        _lineItemData[dataRowIndex].updateDiscountWtValue(
            newDiscountWtValue: newDiscountWtValue,
            taxPer: _taxSettingsData.taxPercentage);
      }
    } else if (column.columnName == 'priceWT' &&
        double.parse(newCellValue) != 0) {
      double newPriceWt = double.parse(newCellValue);
      final LineItemData item = LineItemData(
          unitName: _lineItemData[dataRowIndex].unitName,
          cost: _lineItemData[dataRowIndex].cost,
          productName: _lineItemData[dataRowIndex].productName,
          qty: _lineItemData[dataRowIndex].qty,
          orgPrice: _lineItemData[dataRowIndex].orgPrice,
          orgPriceWt: _lineItemData[dataRowIndex].orgPriceWt,
          discountPercentage: _lineItemData[dataRowIndex].discountPercentage,
          discountPercentageWt:
              _lineItemData[dataRowIndex].discountPercentageWt,
          discountValue: _lineItemData[dataRowIndex].discountValue,
          discountValueWt: _lineItemData[dataRowIndex].discountValueWt,
          price: _lineItemData[dataRowIndex].price,
          priceWt: _lineItemData[dataRowIndex].priceWt,
          total: _lineItemData[dataRowIndex].total,
          totalWt: _lineItemData[dataRowIndex].totalWt,
          barcode: _lineItemData[dataRowIndex].barcode,
          itemCode: _lineItemData[dataRowIndex].itemCode);

      item.updatePriceWithTax(
        newPriceWithTax: newPriceWt,
        taxPer: _taxSettingsData.taxPercentage,
      );

      if ((double.tryParse(item.discountPercentage) ?? 0) >
          _userMaxDiscountPer) {
        showDiscountOverLimitDialog(_context, _userMaxDiscountPer);
      } else {
        _lineItemData[dataRowIndex].updatePriceWithTax(
          newPriceWithTax: newPriceWt,
          taxPer: _taxSettingsData.taxPercentage,
        );
      }
    }

    //updating quantity
    _dataGridRows[dataRowIndex].getCells()[4] = DataGridCell<String>(
        columnName: 'qty', value: _lineItemData[dataRowIndex].qty);

    //updating discount percentage
    _dataGridRows[dataRowIndex].getCells()[6] = DataGridCell<String>(
        columnName: 'discount_percentage',
        value: _lineItemData[dataRowIndex].discountPercentage);

    //updating discount value
    _dataGridRows[dataRowIndex].getCells()[7] = DataGridCell<String>(
        columnName: 'discount_value',
        value: _lineItemData[dataRowIndex].discountValue);

    //updating discount value
    _dataGridRows[dataRowIndex].getCells()[8] = DataGridCell<String>(
        columnName: 'discount_value_wt',
        value: _lineItemData[dataRowIndex].discountValueWt);

    //updating price wt
    _dataGridRows[dataRowIndex].getCells()[9] = DataGridCell<String>(
        columnName: 'priceWT', value: _lineItemData[dataRowIndex].priceWt);

    //updating total
    _dataGridRows[dataRowIndex].getCells()[10] = DataGridCell<String>(
        columnName: 'total', value: _lineItemData[dataRowIndex].totalWt);
    // To reset the new cell value after successfully updated to DataGridRow
    //and underlying mode.
    newCellValue = null;

    notifyListeners();
    _dataGridController.notifyListeners();

    // print(LineItemData.  _lineItemData.);

    var l = _lineItemData[dataRowIndex];
    print("""{
      'productName': ${l.productName},
      'qty': ${l.qty},
      'orgPrice': ${l.orgPrice},
      'orgPriceWt': ${l.orgPriceWt},
      'discountPercentage': ${l.discountPercentage},
      'discountPercentageWt': ${l.discountPercentageWt},
      'discountValue': ${l.discountValue},
      'discountValueWt': ${l.discountValueWt},
      'price': ${l.price},
      'priceWt': ${l.priceWt},
      'total': ${l.total},
      'totalWt': ${l.totalWt},
      'barcode': ${l.barcode},
      'itemCode': ${l.itemCode},
      'cost': ${l.cost},
    }""");
  }
}
