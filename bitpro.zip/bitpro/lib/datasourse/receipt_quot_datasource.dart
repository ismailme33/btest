import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/store_data.dart';
import 'package:bitpro_hive/widget/string_related/get_payment_type.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:bitpro_hive/model/customer_data.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import '../../../../shared/global_variables/font_sizes.dart';

class ReceiptQuotationDataSource extends DataGridSource {
  ReceiptQuotationDataSource(
      {required List<ReceiptOrQuotationData> dbReceiptData,
      required List<CustomerData> customerDataLst,
      required bool isQuotation,
      required List<StoreData> allStoreDataLst}) {
    _employeeData = dbReceiptData.map<DataGridRow>((e) {
      String id = '';
      String receiptType = '';
      String paymentStatus = '';
      String customer = '';
      String orgTotal = '';
      String totalQty = '';
      String totalDiscountPercentage = '';
      String totalDiscountValue = '';
      String totalTaxPercentage = '';
      String totalTaxValue = '';
      String store = 'Store not found';
      String paymentType = '';
      String total = '';
      String createdDate = '';
      String createdBy = '';

      id = isQuotation
          ? e.quotationBasicInfo!.quotationNo
          : e.receiptBasicInfo!.receiptNo;
      receiptType = isQuotation ? '' : e.receiptBasicInfo!.receiptType;
      paymentStatus = isQuotation
          ? ''
          : e.receiptBasicInfo!.invoiceData != null
              ? e.receiptBasicInfo!.invoiceData!.isFinialized
                  ? 'Finalized'
                  : 'Draft'
              : e.receiptBasicInfo!.isAdvancePaymentEnabled &&
                      (double.tryParse(e.receiptBasicInfo!.receiptDue) ?? 0) !=
                          0
                  ? 'Due'
                  : "Compeleted";

      int i = customerDataLst.indexWhere((element) =>
          element.customerId ==
          (isQuotation
              ? e.quotationBasicInfo!.selectedCustomerID
              : e.receiptBasicInfo!.selectedCustomerID));
      if (i != -1) {
        customer = customerDataLst[i].customerName;
      }

      orgTotal = e.lineItemTotalData.receiptTotal;
      totalQty = e.lineItemTotalData.totalQty;
      totalDiscountPercentage = e.lineItemTotalData.totalDiscountPercentage;
      totalDiscountValue = e.lineItemTotalData.totalDiscountValue;
      totalTaxPercentage = e.lineItemTotalData.totalTaxPercentage;
      totalTaxValue = e.lineItemTotalData.totalTaxValue;

      int j = allStoreDataLst.indexWhere((s) =>
          s.docId ==
          (isQuotation
              ? e.quotationBasicInfo!.selectedStoreDocId
              : e.receiptBasicInfo!.selectedStoreDocId));
      if (j != -1) {
        store = allStoreDataLst[j].storeName;
      }

      paymentType = isQuotation ? '' : getReceiptPaymentType(e);
      total = e.lineItemTotalData.receiptTotal;
      createdDate = DateFormat.yMd().add_jm().format(e.createdDate);
      createdBy = e.createdBy;

      return DataGridRow(cells: [
        DataGridCell<int>(
            columnName: 'serialNumberForStyleColor',
            value: dbReceiptData.indexOf(e) + 1),
        DataGridCell<String>(columnName: 'id', value: id),
        DataGridCell<String>(columnName: 'type', value: receiptType),
        DataGridCell<String>(columnName: 'paymentStatus', value: paymentStatus),
        DataGridCell<String>(columnName: 'customer', value: customer),
        DataGridCell<String>(
            columnName: 'orgTotal',
            value: double.parse(orgTotal).toStringAsFixed(digit)),
        DataGridCell<String>(
            columnName: 'totalQty',
            value: double.parse(totalQty).toStringAsFixed(qtydigit)),
        DataGridCell<String>(
            columnName: 'discPer',
            value: double.parse(totalDiscountPercentage).toStringAsFixed(2)),
        DataGridCell<String>(
            columnName: 'discVal',
            value: double.parse(totalDiscountValue).toStringAsFixed(digit)),
        DataGridCell<String>(
            columnName: 'taxPer',
            value: double.parse(totalTaxPercentage).toStringAsFixed(digit)),
        DataGridCell<String>(
            columnName: 'taxVal',
            value: double.parse(totalTaxValue).toStringAsFixed(digit)),
        DataGridCell<String>(columnName: 'store', value: store),
        DataGridCell<String>(columnName: 'paymentType', value: paymentType),
        DataGridCell<String>(
            columnName: 'total',
            value: double.parse(total).toStringAsFixed(digit)),
        DataGridCell<String>(columnName: 'createdDate', value: createdDate),
        DataGridCell<String>(columnName: 'createdBy', value: createdBy),
      ]);
    }).toList();
  }

  List<DataGridRow> _employeeData = [];

  @override
  List<DataGridRow> get rows => _employeeData;

  @override
  DataGridRowAdapter buildRow(DataGridRow row) {
    bool isReturnReceipt = false;

    if (row.getCells().indexWhere((e) =>
            e.columnName == 'type' &&
            (e.value == 'Return' || e.value == 'Credit Note')) !=
        -1) {
      isReturnReceipt = true;
    }
    return DataGridRowAdapter(
        color: row.getCells()[0].value.isEven
            ? const Color(0xffF1F1F1)
            : Colors.white,
        cells: row.getCells().map<Widget>((e) {
          return Container(
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 3),
            child: Text(
              overflow: TextOverflow.ellipsis,
              e.value.toString(),
              style: GoogleFonts.roboto(
                  fontSize: getMediumFontSize,
                  color: isReturnReceipt ? Colors.red[700] : Colors.black,
                  fontWeight: FontWeight.w500),
            ),
          );
        }).toList());
  }
}
