// import 'package:bitpro_hive/auth/db_initialization_page.dart';
// import 'package:bitpro_hive/services/mysql/employees_service.dart';
// import 'package:bitpro_hive/services/mysql/fetching_and_updating/fetching_fb_data.dart';
// import 'package:bitpro_hive/services/mysql/fetching_and_updating/updating_fb_data.dart';
// import 'package:bitpro_hive/services/mysql/get_mysql_connection.dart';
// import 'package:bitpro_hive/services/mysql/merchandise_service/department.dart';
// import 'package:bitpro_hive/services/mysql/merchandise_service/inventory.dart';
// import 'package:bitpro_hive/services/mysql/merchandise_service/merchandise_vendors_payments.dart';
// import 'package:bitpro_hive/services/mysql/merchandise_service/vendor.dart';
// import 'package:bitpro_hive/services/mysql/sales_service/customer.dart';
// import 'package:bitpro_hive/services/mysql/sales_service/customer_payment.dart';
// import 'package:bitpro_hive/services/mysql/sales_service/former_z_out_db_service.dart';
// import 'package:bitpro_hive/services/mysql/sales_service/promo_code.dart';
// import 'package:bitpro_hive/services/mysql/sales_service/quotation_mysql_db_service.dart';
// import 'package:bitpro_hive/services/mysql/sales_service/receipt.dart';
// import 'package:bitpro_hive/services/mysql/settings_service/mysql_settings.dart';
// import 'package:bitpro_hive/services/mysql/settings_service/mysql_store_db_service.dart';
// import 'package:bitpro_hive/services/mysql/user_group_service.dart';
// import 'package:bitpro_hive/services/mysql/voucher_service/voucher.dart';
// import 'package:bitpro_hive/shared/custom_top_nav_bar.dart';
// import 'package:bitpro_hive/shared/dialogs/adding_changing_db/db_has_data_dialog.dart';
// import 'package:bitpro_hive/shared/dialogs/adding_changing_db/db_is_empty_dialog.dart';
// import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
// import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
// import 'package:bitpro_hive/shared/loading.dart';
// import 'package:bitpro_hive/shared/toast.dart';
// import 'package:bitpro_hive/widget/onpage_panel.dart';
// import 'package:bitpro_hive/wrapper.dart';
// import 'package:desktop_window/desktop_window.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:hive/hive.dart';
// import 'package:mysql1/mysql1.dart';

// class MySqlBackendSetupPage extends StatefulWidget {
//   final bool isChangeOrMergingDatabase;
//   const MySqlBackendSetupPage({
//     super.key,
//     this.isChangeOrMergingDatabase = false,
//   });

//   @override
//   State<MySqlBackendSetupPage> createState() => _MySqlBackendSetupPageState();
// }

// class _MySqlBackendSetupPageState extends State<MySqlBackendSetupPage> {
//   String hostUrl = 'localhost';
//   String port = '3306';
//   String user = 'root';
//   String? password;

//   var formKey = GlobalKey<FormState>();

//   bool isLoading = false;
//   String errMsg = '';

//   @override
//   void initState() {
//     setWindowSize();
//     super.initState();
//   }

//   setWindowSize() async {
//     await DesktopWindow.setMinWindowSize(const Size(550, 650));
//   }

//   @override
//   Widget build(BuildContext context) {
//     return customTopNavBar(Scaffold(
//         backgroundColor: Colors.grey[300],
//         body: isLoading
//             ? showLoading()
//             : SafeArea(
//                 child: Form(
//                 key: formKey,
//                 child: Center(
//                   child: SizedBox(
//                       width: 450,
//                       height: 460,
//                       child: Center(
//                         child: SizedBox(
//                           child: OnPagePanel(
//                               columnForTextField: Column(
//                                 children: [
//                                   TextFormField(
//                                     autovalidateMode:
//                                         AutovalidateMode.onUserInteraction,
//                                     decoration: const InputDecoration(
//                                         focusedBorder: OutlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: Color.fromARGB(
//                                                     255, 13, 82, 139))),
//                                         contentPadding: EdgeInsets.symmetric(
//                                             vertical: 13, horizontal: 8),
//                                         isDense: true,
//                                         fillColor: Colors.white,
//                                         filled: true,
//                                         alignLabelWithHint: true,
//                                         labelText: 'Host Url',
//                                         border: OutlineInputBorder(
//                                             borderSide:
//                                                 BorderSide(width: 0.3))),
//                                     validator: (value) =>
//                                         value == null || value.isEmpty
//                                             ? 'Please enter host url'
//                                             : null,
//                                     initialValue: hostUrl,
//                                     onChanged: (val) {
//                                       setState(() {
//                                         hostUrl = val.trim();
//                                       });
//                                     },
//                                   ),
//                                   const SizedBox(
//                                     height: 15,
//                                   ),
//                                   TextFormField(
//                                     autovalidateMode:
//                                         AutovalidateMode.onUserInteraction,
//                                     decoration: const InputDecoration(
//                                         focusedBorder: OutlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: Color.fromARGB(
//                                                     255, 13, 82, 139))),
//                                         contentPadding: EdgeInsets.symmetric(
//                                             vertical: 13, horizontal: 8),
//                                         isDense: true,
//                                         fillColor: Colors.white,
//                                         filled: true,
//                                         alignLabelWithHint: true,
//                                         labelText: 'Port',
//                                         border: OutlineInputBorder()),
//                                     validator: (value) =>
//                                         value == null || value.isEmpty
//                                             ? "Please enter port"
//                                             : int.tryParse(value) == null
//                                                 ? "Please enter a valid number"
//                                                 : null,
//                                     initialValue: port,
//                                     onChanged: (val) {
//                                       setState(() {
//                                         port = val.trim();
//                                       });
//                                     },
//                                   ),
//                                   const SizedBox(
//                                     height: 15,
//                                   ),
//                                   TextFormField(
//                                     autovalidateMode:
//                                         AutovalidateMode.onUserInteraction,
//                                     decoration: const InputDecoration(
//                                         focusedBorder: OutlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: Color.fromARGB(
//                                                     255, 13, 82, 139))),
//                                         contentPadding: EdgeInsets.symmetric(
//                                             vertical: 13, horizontal: 8),
//                                         isDense: true,
//                                         fillColor: Colors.white,
//                                         filled: true,
//                                         alignLabelWithHint: true,
//                                         labelText: 'User',
//                                         border: OutlineInputBorder()),
//                                     validator: (value) =>
//                                         value == null || value.isEmpty
//                                             ? "Please enter user"
//                                             : null,
//                                     initialValue: user,
//                                     onChanged: (val) {
//                                       setState(() {
//                                         user = val;
//                                       });
//                                     },
//                                   ),
//                                   const SizedBox(
//                                     height: 15,
//                                   ),
//                                   TextFormField(
//                                     decoration: const InputDecoration(
//                                         focusedBorder: OutlineInputBorder(
//                                             borderSide: BorderSide(
//                                                 color: Color.fromARGB(
//                                                     255, 13, 82, 139))),
//                                         contentPadding: EdgeInsets.symmetric(
//                                             vertical: 13, horizontal: 8),
//                                         isDense: true,
//                                         fillColor: Colors.white,
//                                         filled: true,
//                                         alignLabelWithHint: true,
//                                         labelText: 'Password',
//                                         border: OutlineInputBorder()),
//                                     onChanged: (val) {
//                                       setState(() {
//                                         password = val;
//                                       });
//                                     },
//                                   ),
//                                   const SizedBox(
//                                     height: 10,
//                                   ),
//                                   Text(
//                                     errMsg,
//                                     textAlign: TextAlign.center,
//                                     style: TextStyle(
//                                         color: Colors.red.shade800,
//                                         fontSize: 16),
//                                   )
//                                 ],
//                               ),
//                               rowForButton: Row(
//                                 children: [
//                                   Container(
//                                     decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(4),
//                                         gradient: const LinearGradient(
//                                             end: Alignment.bottomCenter,
//                                             colors: [
//                                               Color(0xff092F53),
//                                               Color(0xff284F70),
//                                             ],
//                                             begin: Alignment.topCenter)),
//                                     height: 45,
//                                     width: 163,
//                                     child: ElevatedButton(
//                                         style: ElevatedButton.styleFrom(
//                                           backgroundColor: Colors.transparent,
//                                         ),
//                                         onPressed: () async {
//                                           if (widget
//                                               .isChangeOrMergingDatabase) {
//                                             Navigator.pop(context);
//                                           } else {
//                                             setState(() {
//                                               isLoading = true;
//                                             });
//                                             var box = Hive.box('bitpro_app');

//                                             await box.put('Server_Data', {
//                                               'setupSkipped': true,
//                                               'mysqlSetupDone': false,
//                                               'workstationSetupDone': false,
//                                               //
//                                               'hostUrl': '',
//                                               'port': 0,
//                                               'user': '',
//                                               'password': ''
//                                             });
//                                             // Navigator.pushReplacement(
//                                             //     context,
//                                             //     MaterialPageRoute(
//                                             //         builder: (context) =>
//                                             //             const Wrapper()));
//                                             // setState(() {
//                                             //   isLoading = false;
//                                             // });
//                                           }
//                                         },
//                                         child: Row(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.center,
//                                           children: [
//                                             Icon(
//                                               widget.isChangeOrMergingDatabase
//                                                   ? Icons
//                                                       .navigate_before_outlined
//                                                   : Icons
//                                                       .navigate_next_outlined,
//                                               color: Colors.white,
//                                             ),
//                                             const SizedBox(
//                                               width: 10,
//                                             ),
//                                             Text(
//                                                 staticTextTranslate(widget
//                                                         .isChangeOrMergingDatabase
//                                                     ? 'Back'
//                                                     : 'Skip'),
//                                                 style: TextStyle(
//                                                   fontSize: getMediumFontSize,
//                                                 )),
//                                           ],
//                                         )),
//                                   ),
//                                   const SizedBox(
//                                     width: 10,
//                                   ),
//                                   Container(
//                                     decoration: BoxDecoration(
//                                         borderRadius: BorderRadius.circular(4),
//                                         gradient: const LinearGradient(
//                                             end: Alignment.bottomCenter,
//                                             colors: [
//                                               Color(0xff092F53),
//                                               Color(0xff284F70),
//                                             ],
//                                             begin: Alignment.topCenter)),
//                                     height: 45,
//                                     width: 165,
//                                     child: ElevatedButton(
//                                         onPressed: () async {
//                                           onTapSumbit();
//                                         },
//                                         style: ElevatedButton.styleFrom(
//                                             backgroundColor: hostUrl.isEmpty
//                                                 ? Colors.grey[400]
//                                                 : Colors.transparent),
//                                         child: Row(
//                                           mainAxisAlignment:
//                                               MainAxisAlignment.center,
//                                           children: [
//                                             const Icon(Icons.done),
//                                             const SizedBox(
//                                               width: 10,
//                                             ),
//                                             Text('Submit',
//                                                 style: TextStyle(
//                                                   fontSize: getMediumFontSize,
//                                                 )),
//                                           ],
//                                         )),
//                                   ),
//                                 ],
//                               ),
//                               topLabel: "Birpro FireBase Setup"),
//                         ),
//                       )),
//                 ),
//               ))));
//   }

//   onTapSumbit() async {
//     bool canCallApi = true;

//     if (formKey.currentState!.validate()) {
//       if (canCallApi) {
//         setState(() {
//           isLoading = true;
//         });

//         Box box = Hive.box('bitpro_app');

//         await box.put('Server_Data', {
//           'host': hostUrl,
//           'port': int.parse(port),
//           'user': user,
//           'password': password,
//           'mysqlSetupDone': false,
//           'setupSkipped': false,
//           'workstationSetupDone': false
//         });

//         int status = await checkMySqlDBExits(
//             host: hostUrl,
//             password: password,
//             port: int.parse(port),
//             user: user,
//             context:
//                 context); // 1 = connected, 2 = Database not found, 3 = other errors
//         print('status');
//         print(status);
//         if (status == 2) {
//           // ignore: use_build_context_synchronously
//           await showDialog(
//               barrierDismissible: false,
//               context: context,
//               builder: (context) => AlertDialog(
//                     title: const Text('Database not found'),
//                     content: const Text(
//                         'Do you want to create the database "$mySqlDbName" on the server?'),
//                     actions: [
//                       SizedBox(
//                           height: 45,
//                           width: 165,
//                           child: ElevatedButton(
//                             style: ElevatedButton.styleFrom(
//                                 backgroundColor: Colors.grey),
//                             onPressed: () async {
//                               setState(() {
//                                 isLoading = false;
//                               });
//                               Navigator.pop(context);
//                             },
//                             child: Text(staticTextTranslate('No')),
//                           )),
//                       SizedBox(
//                           height: 45,
//                           width: 165,
//                           child: ElevatedButton(
//                             onPressed: () async {
//                               await createDatabase(
//                                 host: hostUrl,
//                                 password: password,
//                                 port: int.parse(port),
//                                 user: user,
//                               );

//                               onEnterLogin();
//                               Navigator.pop(context);
//                             },
//                             child: Text(staticTextTranslate('Yes')),
//                           )),
//                     ],
//                   ));
//         } else if (status == 1) {
//           await onEnterLogin();
//         } else {
//           setState(() {
//             isLoading = false;
//           });
//         }
//       }
//     }
//   }

//   onEnterLogin() async {
//     Box box = Hive.box('bitpro_app');
//     //checking that mysql server info is correct and if it has data or it's empty
//     MySqlConnection connection = await getMySqlConnection(context);
//     bool res1 =
//         await MySqlStoreDbService(context: context, connection: connection)
//             .getUpdatedAndNewStoreData('', checkingHasData: true);
//     bool res2 =
//         await MySqlUserGroupDbService(context: context, connection: connection)
//             .getUpdatedAndNewUserGroupsData('', checkingHasData: true);
//     bool res3 =
//         await MySqlEmployeesDbService(context: context, connection: connection)
//             .getUpdatedAndNewUserData('', checkingHasData: true);
//     await connection.close();
//     if (res1 == false || res2 == false || res3 == false) {
//       if (widget.isChangeOrMergingDatabase) {
//         String msg1 = "Store, User_Group and Users data table is required.";
//         if (res1 == false) {
//           msg1 += "\n - Store table is empty.";
//         }
//         if (res2 == false) {
//           msg1 += "\n - User_Group table is empty.";
//         }
//         if (res3 == false) {
//           msg1 += "\n - Users data table is empty.";
//         }

//         msg1 +=
//             "\n\nDo you want to upload your Local Database into Mysql Database?";

//         bool yn = await showDbIsEmptyDialog(context, msg1);
//         if (yn) {
//           //yes, upload hive data in fb
//           showToast("updating hive data in Sever", context);
//           //first remove all data from db
//           await dropAllTables();
//           await UpdatingMysqlDataService(context: context)
//               .udpatingHiveDataInFirebase(uploadAllHiveDataInFb: true);
//           await box.put('Server_Data', {
//             'host': hostUrl,
//             'port': int.parse(port),
//             'user': user,
//             'password': password,
//             'setupSkipped': false,
//             'mysqlSetupDone': true,
//             'workstationSetupDone': true
//           });
//           Navigator.pushReplacement(context,
//               MaterialPageRoute(builder: (context) => const Wrapper()));
//         }
//       } else {
//         String msg1 = "Store, User_Group and Users data table is required.";
//         if (res1 == false) {
//           msg1 += "\n - Store table is empty.";
//         }
//         if (res2 == false) {
//           msg1 += "\n - User_Group table is empty.";
//         }
//         if (res3 == false) {
//           msg1 += "\n - Users data table is empty.";
//         }

//         msg1 +=
//             "\n\nNo Data Found in Mysql Database & Local Database, you need to skip the backend connection or try with new server.";

//         await showDbIsEmptyDialog(context, msg1, showOkButton: true);
//       }
//     } else {
//       //
//       bool yn = await showDbHasDataDialog(context,
//           showMergeOption: widget.isChangeOrMergingDatabase);
//       if (yn) {
//         //yes, fetch data fron fb to hive
//         showToast("updating hive data in Sever", context);
//         print('updating data');
//         await FetchingMysqlDataService(context: context).fetchData();
//         print('done updating data');
//         await box.put('Server_Data', {
//           'host': hostUrl,
//           'port': int.parse(port),
//           'user': user,
//           'password': password,
//           'setupSkipped': false,
//           'mysqlSetupDone': true,
//           'workstationSetupDone': false
//         });
//         Navigator.pushReplacement(
//             context, MaterialPageRoute(builder: (context) => const Wrapper()));
//       }
//     }
//     setState(() {
//       isLoading = false;
//     });
//   }

//   dropAllTables() async {
//     MySqlConnection connection = await getMySqlConnection(context);

//     await MySqlUserGroupDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating users data into hive
//     await MySqlEmployeesDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //Voucher

//     //fetching and updating Purchase Voucher data into hive
//     await MySqlVoucherDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //Setting
//     //fetching and updating store data into hive
//     await MySqlStoreDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating settings data into hive
//     await MySqlSettingDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //Sales
//     //fetching and updating dbReceipt data into hive
//     await MySqlReceiptDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating dbQuotation data into hive
//     await MySqlQuotationDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating promotion data into hive
//     await MySqlPromoDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating formerZOut data into hive
//     await MySqlFormerZOutDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating customer payment data into hive
//     await MySqlCustomerPaymentDbService(
//             context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating sales customer data into hive
//     await MySqlCustomerDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //Merchandise

//     //fetching and updating vendorPayment data into hive
//     await MySqlVendorPaymentDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating vendor data into hive
//     await MySqlVendorDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating inventory data into hive
//     await MySqlInventoryDbService(context: context, connection: connection)
//         .dropTableData(connection);

//     //fetching and updating merchandise department data into hive
//     await MySqlDepartmentDbService(context: context, connection: connection)
//         .dropTableData(connection);
//     await connection.close();
//   }
// }
