import 'package:hive/hive.dart';

Future<bool> checkIsSetupSkipped() async {
  var box = Hive.box('bitpro_app');
  var serverData = box.get('server_data');
  if (serverData != null && serverData['setupSkipped'] == true) {
    return true;
  }
  return false;
}
