import 'package:bitpro_hive/model/employee_data.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hive/hive.dart';

//This page is used in Select Inventory only
class TopBar extends StatefulWidget {
  final String pageName;
  const TopBar({super.key, this.pageName = ''});

  @override
  State<TopBar> createState() => _TopBarState();
}

class _TopBarState extends State<TopBar> {
  String fullName = '';
  String designation = '';

  @override
  void initState() {
    initData();
    super.initState();
  }

  initData() {
    var box = Hive.box('bitpro_app');
    Map? ud = box.get('user_data');

    if (ud != null) {
      EmployeeData u = EmployeeData.fromMap(ud);

      fullName =
          '${u.empBasicInfoData.firstName} ${u.empBasicInfoData.lastName}';
      designation = u.empWorkAndRolesData.position ?? '';
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return
        // Column(
        //   children: [
        Container(
      height: 49.5,
      width: double.maxFinite,
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
      decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(0), topRight: Radius.circular(0)),
          gradient: LinearGradient(
              end: Alignment.bottomCenter,
              colors: [
                Color.fromARGB(255, 37, 37, 37),
                Color.fromARGB(255, 37, 37, 37),
              ],
              begin: Alignment.topCenter)),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(
                width: 5,
              ),
              Image.asset(
                'assets/icons/bitpro.png',
                width: 23,
              ),
              const SizedBox(
                width: 5,
              ),
              Text(
                'BitPro',
                style: GoogleFonts.lato(
                    fontSize: 22,
                    fontWeight: FontWeight.w600,
                    color: Colors.white),
              ),
              const SizedBox(
                width: 65,
              ),
              Text(
                staticTextTranslate(widget.pageName),
                style: GoogleFonts.roboto(
                    fontSize: 20,
                    fontWeight: FontWeight.w400,
                    color: Colors.white),
              ),
            ],
          ),
          SizedBox(
            height: 35,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  height: 27,
                  width: 27,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(100),
                      color: Colors.white),
                  child: Icon(
                    Icons.person,
                    size: 20,
                    color: Colors.grey[600],
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      fullName,
                      style: GoogleFonts.roboto(
                          fontSize: getMediumFontSize - 1, color: Colors.white),
                    ),
                    Text(
                      designation,
                      style: GoogleFonts.roboto(
                          fontSize: getMediumFontSize - 4, color: Colors.white),
                    )
                  ],
                )
              ],
            ),
          )
        ],
      ),
    );
    //     Container(
    //       height: 0.5,
    //       color: Colors.white,
    //     )
    //   ],
    // );
  }
}
