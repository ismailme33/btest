import 'package:flutter/material.dart';

class BottomPanelForDialog extends StatelessWidget {
  final List<Widget> buttons;

  const BottomPanelForDialog({required this.buttons, super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color.fromARGB(255, 198, 198, 198),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(6),
          bottomRight: Radius.circular(6),
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      child: Row(mainAxisAlignment: MainAxisAlignment.end, children: buttons),
    );
  }
}
