import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/receipt_quot_create_edit_page.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/bottom_panel_for_dialog.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';
import 'package:bitpro_hive/model/specification_data.dart';

Future<SpecificationData?> showSpecificationDialog(
    {required BuildContext context,
    required bool viewMode,
    required SpecificationData? specificationData}) async {
  return await showDialog<SpecificationData?>(
    context: context,
    builder: (context) {
      SpecificationData spData = specificationData ??
          SpecificationData(
            sphRight: '',
            sphLeft: '',
            cylRight: '',
            cylLeft: '',
            axisRight: '',
            axisLeft: '',
            ipd: '',
            add: '',
          );
      return StatefulBuilder(builder: (context, setState2) {
        return Dialog(
          child: SizedBox(
            height: 350,
            width: 500,
            child: Column(
              children: [
                BlackTopPanelForDialogWindow(label: 'Specification'),
                Spacer(),
                SizedBox(
                  width: 350,
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 70,
                            height: 34.8,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              height: 34.8,
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                              ),
                              child: Center(child: Text('R')),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              height: 34.8,
                              decoration: BoxDecoration(
                                border: Border.all(color: Colors.grey),
                              ),
                              child: Center(child: Text('L')),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            width: 70,
                            height: 34.8,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                            ),
                            child: const Center(
                              child: Text(
                                'SPH',
                                style: TextStyle(fontSize: 16),
                              ),
                            ),
                          ),
                          BoxForSpecification(
                            readOnly: viewMode,
                            hintText: '',
                            initialValue: spData.sphRight,
                            onChange: (val) {
                              setState2(() {
                                spData.sphRight = val;
                              });
                            },
                          ),
                          BoxForSpecification(
                            initialValue: spData.sphLeft,
                            readOnly: viewMode,
                            onChange: (val) {
                              setState2(() {
                                spData.sphLeft = val;
                              });
                            },
                            hintText: '',
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          SizedBox(
                            width: 70,
                            child: BoxForSpecification(hintText: 'CYL'),
                          ),
                          BoxForSpecification(
                            hintText: '',
                            initialValue: spData.cylRight,
                            readOnly: viewMode,
                            onChange: (val) {
                              setState2(() {
                                spData.cylRight = val;
                              });
                            },
                          ),
                          BoxForSpecification(
                            hintText: '',
                            readOnly: viewMode,
                            initialValue: spData.cylLeft,
                            onChange: (val) {
                              setState2(() {
                                spData.cylLeft = val;
                              });
                            },
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            width: 70,
                            height: 34.8,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                            ),
                            child: const Center(
                              child: Text(
                                'AXIS',
                                style: TextStyle(fontSize: 16),
                              ),
                            ),
                          ),
                          BoxForSpecification(
                            hintText: '',
                            readOnly: viewMode,
                            initialValue: spData.axisRight,
                            onChange: (val) {
                              setState2(() {
                                spData.axisRight = val;
                              });
                            },
                          ),
                          BoxForSpecification(
                            hintText: '',
                            readOnly: viewMode,
                            initialValue: spData.axisLeft,
                            onChange: (val) {
                              setState2(() {
                                spData.axisLeft = val;
                              });
                            },
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            width: 70,
                            height: 34.8,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                            ),
                            child: const Center(
                              child: Text(
                                'IPD',
                                style: TextStyle(fontSize: 16),
                              ),
                            ),
                          ),
                          Expanded(
                            child: BoxForSpecification(
                              hintText: '',
                              readOnly: viewMode,
                              initialValue: spData.ipd,
                              onChange: (val) {
                                setState2(() {
                                  spData.ipd = val;
                                });
                              },
                            ),
                          ),
                          Container(
                            width: 70,
                            height: 34.8,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey),
                            ),
                            child: const Center(
                              child: Text(
                                'ADD',
                                style: TextStyle(fontSize: 16),
                              ),
                            ),
                          ),
                          Expanded(
                            child: BoxForSpecification(
                              hintText: '',
                              readOnly: viewMode,
                              initialValue: spData.add,
                              onChange: (val) {
                                setState2(() {
                                  spData.add = val;
                                });
                              },
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                const Spacer(),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: BottomPanelForDialog(
                    buttons: [
                      Spacer(),
                      if (viewMode == false)
                        const SizedBox(
                          width: 10,
                        ),
                      OnPageGreyButton(
                        label: 'Cancel',
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      OnPageButton(
                        label: 'Save',
                        onPressed: () {
                          // specificationData = spData;
                          // setState2(() {});

                          Navigator.pop(context, spData);
                        },
                        icon: Iconsax.save_add5,
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        );
      });
    },
  );
}
