import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/02_logic/receipt_calculation_functions.dart';
import 'package:bitpro_hive/model/receipt/line_item_data.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/model/settings/receipt_details_data.dart';
import 'package:bitpro_hive/model/settings/tax_settings.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:bitpro_hive/widget/dialogs/tendor_amount_dialog.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import '../../../../shared/global_variables/font_sizes.dart';
import '../../../../shared/global_variables/static_text_translate.dart';

showReceiptTenderDialog(
    {required BuildContext context,
    required bool viewMode,
    required bool isAdvancePaymentEnabled,
    required ReceiptSettingData receiptSettingData,
    required List<LineItemData> lineItemList,
    required ReceiptOrQuotationData? selectedDbReceiptData,
    required Map<dynamic, dynamic> allPaymentMethodAmountsInfo,
    required TaxSettingsData taxSettingsData,
    required double cartDiscountValue,
    required double cartDiscountPercentage,
    required ReceiptCalculationFunctions receiptCalculationFunctions,
    required Function({bool printOnly, bool printAndSave, bool saveOnly})
        printAndUploadOnTap}) {
  showDialog(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context2, setState2) {
            bool callFuntion = false;
            if (lineItemList.isNotEmpty) {
              if (viewMode) {
                if (selectedDbReceiptData!
                            .receiptBasicInfo!.isAdvancePaymentEnabled ==
                        true &&
                    (double.tryParse(selectedDbReceiptData
                                .receiptBasicInfo!.receiptDue) ??
                            0) !=
                        0) {
                  //second time paying
                  callFuntion = double.parse(receiptCalculationFunctions
                          .calculateDueAmount(allPaymentMethodAmountsInfo)) ==
                      0;
                  if (callFuntion == false) {
                    // showToast("Transaction payment is due", context);
                  }
                }
              } else {
                if (isAdvancePaymentEnabled) {
                  callFuntion = true;
                } else {
                  callFuntion = double.parse(receiptCalculationFunctions
                          .calculateDueAmount(allPaymentMethodAmountsInfo)) ==
                      0;
                  if (callFuntion == false) {
                    // showToast("Transaction payment is due", context);
                  }
                }
              }
            }

            return Dialog(
              backgroundColor: homeBgColor,
              child: SizedBox(
                  height: 650,
                  width: 810,
                  child: Column(children: [
                    Container(
                      height: 50,
                      width: double.maxFinite,
                      padding: const EdgeInsets.all(15),
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(3),
                            topRight: Radius.circular(3)),
                        gradient: LinearGradient(
                            end: Alignment.bottomCenter,
                            colors: [
                              Color.fromARGB(255, 37, 37, 37),
                              Color.fromARGB(255, 37, 37, 37),
                            ],
                            begin: Alignment.topCenter),
                      ),
                      child: Text(
                        staticTextTranslate('Tender Transaction'),
                        style: GoogleFonts.roboto(
                            fontSize: 18,
                            fontWeight: FontWeight.w400,
                            color: Colors.white),
                      ),
                    ),
                    SizedBox(
                      height: 368,
                      child: Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Row(
                          children: [
                            Column(
                              children: [
                                Container(
                                  //height: 50,
                                  padding: const EdgeInsets.all(10),
                                  width: 240,
                                  decoration: BoxDecoration(
                                    border: Border.all(width: 0.4),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Text(
                                    'Take Due: ${receiptCalculationFunctions.calculateDueAmount(allPaymentMethodAmountsInfo)}',
                                    style: GoogleFonts.roboto(
                                      fontWeight: FontWeight.w500,
                                      fontSize: 18,
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                Container(
                                  width: 240,
                                  decoration: BoxDecoration(
                                    border: Border.all(width: 0.4),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: receiptSettingData
                                            .paymentTypeList.keys
                                            .map((e) => _tendorPaymentMethodButton(
                                                key: e,
                                                dueAmount:
                                                    receiptCalculationFunctions
                                                        .calculateDueAmount(
                                                            allPaymentMethodAmountsInfo),
                                                setState2: setState2,
                                                allPaymentMethodAmountsInfo:
                                                    allPaymentMethodAmountsInfo,
                                                context: context2,
                                                isAdvancePaymentEnabled:
                                                    isAdvancePaymentEnabled,
                                                receiptSettingData:
                                                    receiptSettingData,
                                                selectedDbReceiptData:
                                                    selectedDbReceiptData,
                                                viewMode: viewMode))
                                            .toList()),
                                  ),
                                ),
                                SizedBox(
                                  height: 10,
                                ),
                                if (receiptSettingData
                                    .inTenderUseAdvancePayment)
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: Row(
                                      children: [
                                        Checkbox(
                                            activeColor: darkBlueColor,
                                            side: const BorderSide(width: 0.7),
                                            shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(3)),
                                            value: isAdvancePaymentEnabled,
                                            onChanged: (val) {
                                              if (viewMode == false) {
                                                setState2(() {
                                                  isAdvancePaymentEnabled =
                                                      val!;
                                                });
                                              }
                                            }),
                                        InkWell(
                                          onTap: () {
                                            if (viewMode == false) {
                                              setState2(() {
                                                isAdvancePaymentEnabled =
                                                    !isAdvancePaymentEnabled;
                                              });
                                            }
                                          },
                                          child: Text(
                                              staticTextTranslate(
                                                  '  Advance Payment'),
                                              style: TextStyle(
                                                fontSize: getMediumFontSize,
                                              )),
                                        ),
                                      ],
                                    ),
                                  ),
                              ],
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                            Expanded(
                                child: Column(
                              children: [
                                Container(
                                  height: 336,
                                  decoration: BoxDecoration(
                                    color: const Color(0xffE2E2E2),
                                    border: Border.all(width: 0.4),
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  child: Column(children: [
                                    Container(
                                      height: 35,
                                      width: double.maxFinite,
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 7, horizontal: 10),
                                      decoration: const BoxDecoration(
                                        borderRadius: BorderRadius.only(
                                            topLeft: Radius.circular(4),
                                            topRight: Radius.circular(4)),
                                        gradient: LinearGradient(
                                            end: Alignment.bottomCenter,
                                            colors: [
                                              Color.fromARGB(255, 51, 51, 51),
                                              Color.fromARGB(255, 51, 51, 51),
                                            ],
                                            begin: Alignment.topCenter),
                                      ),
                                      child: Text(
                                        staticTextTranslate('Payments'),
                                        style: GoogleFonts.roboto(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w400,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 5,
                                    ),
                                    for (var infoKey
                                        in allPaymentMethodAmountsInfo.keys)
                                      Padding(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 8.0, vertical: 2.5),
                                        child: Container(
                                          width: double.maxFinite,
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 5, horizontal: 10),
                                          decoration: BoxDecoration(
                                              color: Colors.white,
                                              border: Border.all(width: 0.4),
                                              borderRadius:
                                                  BorderRadius.circular(4)),
                                          child: Row(children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                border: Border.all(width: 0),
                                                borderRadius:
                                                    BorderRadius.circular(4),
                                                gradient: const LinearGradient(
                                                    end: Alignment.bottomCenter,
                                                    colors: [
                                                      Color.fromARGB(
                                                          255, 207, 39, 39),
                                                      Color.fromARGB(
                                                          255, 207, 39, 39),
                                                    ],
                                                    begin: Alignment.topCenter),
                                              ),
                                              height: 32,
                                              child: ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                    elevation: 0,
                                                    backgroundColor:
                                                        Colors.transparent),
                                                onPressed: () {
                                                  if (viewMode == false ||
                                                      (isAdvancePaymentEnabled &&
                                                          selectedDbReceiptData!
                                                                  .receiptBasicInfo!
                                                                  .receiptDue !=
                                                              '0')) {
                                                    allPaymentMethodAmountsInfo
                                                        .remove(infoKey);
                                                    setState2(() {});
                                                  }
                                                },
                                                child: const Text('X'),
                                              ),
                                            ),
                                            const SizedBox(
                                              width: 10,
                                            ),
                                            Expanded(
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceBetween,
                                                children: [
                                                  Text(
                                                    infoKey,
                                                    style: GoogleFonts.roboto(
                                                        fontSize: 16,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: const Color
                                                            .fromARGB(
                                                            255, 0, 0, 0)),
                                                  ),
                                                  Text(
                                                    allPaymentMethodAmountsInfo[
                                                        infoKey],
                                                    style: GoogleFonts.roboto(
                                                        fontSize: 16,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        color: const Color
                                                            .fromARGB(
                                                            255, 0, 0, 0)),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ]),
                                        ),
                                      ),
                                  ]),
                                )
                              ],
                            )),
                          ],
                        ),
                      ),
                    ),
                    Expanded(
                      child: SizedBox(
                        width: double.maxFinite,
                        child: Padding(
                          padding: const EdgeInsets.all(15),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              SizedBox(
                                width: 350,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      staticTextTranslate("Invoice Total"),
                                      style: GoogleFonts.roboto(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Container(
                                        height: 30,
                                        width: 150,
                                        alignment: Alignment.centerLeft,
                                        padding: const EdgeInsets.all(5),
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: Colors.black,
                                                width: 0.6),
                                            borderRadius:
                                                BorderRadius.circular(3)),
                                        child: Text(
                                          ReceiptCalculationFunctions(
                                                  taxPer: taxSettingsData
                                                      .taxPercentage,
                                                  cartDiscountPercentage:
                                                      cartDiscountPercentage,
                                                  cartDiscountValueWt:
                                                      cartDiscountValue,
                                                  selectedLocalReceiptData:
                                                      lineItemList
                                                          .map<LineItemData>(
                                                              (e) => e)
                                                          .toList())
                                              .receiptTotal,
                                          style: GoogleFonts.roboto(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600),
                                        ))
                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              SizedBox(
                                width: 350,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      staticTextTranslate("Tendered Amount"),
                                      style: GoogleFonts.roboto(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Container(
                                        height: 30,
                                        width: 150,
                                        alignment: Alignment.centerLeft,
                                        padding: const EdgeInsets.all(5),
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: Colors.black,
                                                width: 0.6),
                                            borderRadius:
                                                BorderRadius.circular(3)),
                                        child: Text(
                                          ReceiptCalculationFunctions(
                                                  taxPer: taxSettingsData
                                                      .taxPercentage,
                                                  cartDiscountPercentage:
                                                      cartDiscountPercentage,
                                                  cartDiscountValueWt:
                                                      cartDiscountValue,
                                                  selectedLocalReceiptData:
                                                      lineItemList
                                                          .map<LineItemData>(
                                                              (e) => e)
                                                          .toList())
                                              .calculateTenderedAmount(
                                                  allPaymentMethodAmountsInfo),
                                          style: GoogleFonts.roboto(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600),
                                        ))
                                  ],
                                ),
                              ),
                              const SizedBox(
                                height: 10,
                              ),
                              SizedBox(
                                width: 350,
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      staticTextTranslate("Balance"),
                                      style: GoogleFonts.roboto(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w600),
                                    ),
                                    const SizedBox(
                                      width: 10,
                                    ),
                                    Container(
                                        height: 30,
                                        width: 150,
                                        alignment: Alignment.centerLeft,
                                        padding: const EdgeInsets.all(5),
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            border: Border.all(
                                                color: Colors.black,
                                                width: 0.6),
                                            borderRadius:
                                                BorderRadius.circular(3)),
                                        child: Text(
                                          receiptCalculationFunctions
                                              .calculateBalanceAmount(
                                                  allPaymentMethodAmountsInfo),
                                          style: GoogleFonts.roboto(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w600),
                                        ))
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Container(
                      height: 62,
                      width: double.maxFinite,
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 10),
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(0),
                            topRight: Radius.circular(0)),
                        gradient: LinearGradient(
                            end: Alignment.bottomCenter,
                            colors: [
                              Colors.grey,
                              Colors.grey,
                            ],
                            begin: Alignment.topCenter),
                      ),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '',
                              style: GoogleFonts.roboto(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.white),
                            ),
                            Row(children: [
                              OnPageGreyButton(
                                label: 'Cancel',
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              OnPageButton(
                                label: 'Print',
                                onPressed: () {
                                  printAndUploadOnTap(printOnly: true);
                                },
                                backgroundColor: !callFuntion
                                    ? Colors.grey.shade800
                                    : Colors.transparent,
                                imageIcon: 'assets/icons/pdf.png',
                                imageIconWidth: 25,
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              // const SizedBox(
                              //   width: 10,
                              // ),
                              // OnPageButton(
                              //   label: 'Save & ',
                              //   onPressed: () {},
                              //   backgroundColor: !callFuntion
                              //       ? Colors.grey.shade800
                              //       : Colors.transparent,
                              //   icon: Icons.email_rounded,
                              // ),
                              // const SizedBox(
                              //   width: 10,
                              // ),
                              // OnPageButton(
                              //   label: 'Save &',
                              //   onPressed: () {},
                              //   backgroundColor: !callFuntion
                              //       ? Colors.grey.shade800
                              //       : Colors.transparent,
                              //   imageIcon: 'assets/icons/whatsapp.png',
                              //   imageIconWidth: 25,
                              // ),
                              // const SizedBox(
                              //   width: 10,
                              // ),
                              OnPageButton(
                                label: 'Save',
                                onPressed: () {
                                  if (callFuntion) {
                                    Navigator.pop(context);
                                    printAndUploadOnTap(saveOnly: true);
                                  }
                                },
                                backgroundColor: !callFuntion
                                    ? Colors.grey.shade800
                                    : Colors.transparent,
                              ),
                              const SizedBox(
                                width: 10,
                              ),
                              OnPageButton(
                                label: 'Save & Print',
                                icon: Icons.print,
                                onPressed: () {
                                  if (callFuntion) {
                                    Navigator.pop(context);
                                    printAndUploadOnTap(printAndSave: true);
                                  }
                                },
                                backgroundColor: !callFuntion
                                    ? Colors.grey.shade800
                                    : Colors.transparent,
                              )
                            ])
                          ]),
                    ),
                  ])),
            );
          }));
}

Widget _tendorPaymentMethodButton({
  required String key,
  required String dueAmount,
  required setState2,
  required ReceiptSettingData receiptSettingData,
  required bool viewMode,
  required bool isAdvancePaymentEnabled,
  required ReceiptOrQuotationData? selectedDbReceiptData,
  required BuildContext context,
  required Map<dynamic, dynamic> allPaymentMethodAmountsInfo,
}) {
  if (key == PaymentMethodKey().cash &&
      receiptSettingData.paymentTypeList[key] != 0) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      child: OnPageButton(
        label: 'Cash',
        onPressed: () async {
          if (viewMode == false ||
              (isAdvancePaymentEnabled &&
                  selectedDbReceiptData!.receiptBasicInfo!.receiptDue != '0')) {
            String? amount = await showTendorAmountDialog(context,
                dueAmount: dueAmount,
                paymentMathodKey: key,
                previousAmt: allPaymentMethodAmountsInfo[key] ?? '0');
            if (amount != null && amount.isNotEmpty && amount != '0') {
              allPaymentMethodAmountsInfo[key] = amount;
            }
            setState2(() {});
          }
        },
      ),
    );
  } else if (key == PaymentMethodKey().creditCard &&
      receiptSettingData.paymentTypeList[key] != 0) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 5),
      child: OnPageButton(
        label: 'Credit Card',
        onPressed: () async {
          if (viewMode == false ||
              (isAdvancePaymentEnabled &&
                  selectedDbReceiptData!.receiptBasicInfo!.receiptDue != '0')) {
            String? amount = await showTendorAmountDialog(context,
                dueAmount: dueAmount,
                paymentMathodKey: key,
                previousAmt: allPaymentMethodAmountsInfo[key] ?? '0');
            if (amount != null && amount.isNotEmpty && amount != '0') {
              allPaymentMethodAmountsInfo[key] = amount;
            }
            setState2(() {});
          }
        },
      ),
    );
  } else if (key == PaymentMethodKey().tamara &&
      receiptSettingData.paymentTypeList[key] != 0) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          gradient: const LinearGradient(
              end: Alignment.bottomLeft,
              colors: [
                Color.fromARGB(255, 211, 164, 8),
                Color.fromARGB(255, 124, 27, 116),
              ],
              begin: Alignment.topCenter)),
      height: 38,
      width: 220,
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              elevation: 0,
              backgroundColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4))),
          onPressed: () async {
            if (viewMode == false ||
                (isAdvancePaymentEnabled &&
                    selectedDbReceiptData!.receiptBasicInfo!.receiptDue !=
                        '0')) {
              String? amount = await showTendorAmountDialog(context,
                  dueAmount: dueAmount,
                  paymentMathodKey: key,
                  previousAmt: allPaymentMethodAmountsInfo[key] ?? '0');
              if (amount != null && amount.isNotEmpty && amount != '0') {
                allPaymentMethodAmountsInfo[key] = amount;
              }
              setState2(() {});
            }
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/icons/tamara.png',
                width: 120,
              )
            ],
          )),
    );
  } else if (key == PaymentMethodKey().tabby &&
      receiptSettingData.paymentTypeList[key] != 0) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          gradient: const LinearGradient(
              end: Alignment.bottomCenter,
              colors: [
                Color.fromARGB(255, 30, 199, 171),
                Color.fromARGB(255, 30, 199, 171),
              ],
              begin: Alignment.topCenter)),
      height: 38,
      width: 220,
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              elevation: 0,
              backgroundColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(4))),
          onPressed: () async {
            if (viewMode == false ||
                (isAdvancePaymentEnabled &&
                    selectedDbReceiptData!.receiptBasicInfo!.receiptDue !=
                        '0')) {
              String? amount = await showTendorAmountDialog(context,
                  dueAmount: dueAmount,
                  paymentMathodKey: key,
                  previousAmt: allPaymentMethodAmountsInfo[key] ?? '0');
              if (amount != null && amount.isNotEmpty && amount != '0') {
                allPaymentMethodAmountsInfo[key] = amount;
              }
              setState2(() {});
            }
          },
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/icons/tabby.png',
                width: 75,
              )
            ],
          )),
    );
  }
  return SizedBox();
}
