import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/receipt_quot_create_edit_page.dart';
import 'package:bitpro_hive/model/receipt/receipt_data.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phone_form_field/phone_form_field.dart';

Future<String?> showTamaraPaymentDialog(context,
    {required ReceiptOrQuotationData dbReceiptData}) async {
  PhoneController controller = PhoneController(
      initialValue: const PhoneNumber(isoCode: IsoCode.AE, nsn: ''));
  TextEditingController emailTextEditingController = TextEditingController();
  late PhoneNumber phoneNumber;
  //= PhoneNumber(isoCode: IsoCode.AE, nsn: '42929929');
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  await showDialog(
      // barrierDismissible: false,
      context: context,
      builder: (context) {
        bool sendingCheckoutSms = false;
        bool checkingForCheckoutStatus = false;
        bool orderCaptured = false;
        // bool orderFailed = false;

        return StatefulBuilder(builder: (context2, setState2) {
          return Shortcuts(
            shortcuts: <LogicalKeySet, Intent>{
              LogicalKeySet(LogicalKeyboardKey.enter):
                  const ReceiptCallbackShortcutsIntent(name: 'Ok'),
            },
            child: Actions(
              actions: <Type, Action<Intent>>{
                ReceiptCallbackShortcutsIntent:
                    CallbackAction<ReceiptCallbackShortcutsIntent>(
                        onInvoke: (ReceiptCallbackShortcutsIntent intent) =>
                            intent.name == "Ok"
                                ? Navigator.pop(context2)
                                : print(intent.name)),
              },
              child: Dialog(
                child: SizedBox(
                  width: orderCaptured ? 450 : 500,
                  height: orderCaptured
                      ? 350
                      : checkingForCheckoutStatus
                          ? 400
                          : 350,
                  child: orderCaptured
                      ? Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Expanded(
                                child: SizedBox(
                              height: 20,
                            )),
                            Image.asset(
                              'assets/icons/payment_capture_icon.png',
                              width: 60,
                              height: 60,
                              fit: BoxFit.cover,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            const SizedBox(
                              width: 350,
                              child: Text(
                                'Order Captured',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 18,
                                    color: Colors.black,
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            const SizedBox(
                              width: 350,
                              child: Text(
                                'Approval Code #95210435',
                                textAlign: TextAlign.center,
                                style:
                                    TextStyle(color: Colors.grey, fontSize: 12),
                              ),
                            ),
                            const SizedBox(
                              height: 20,
                            ),
                            Container(
                              height: .5,
                              width: 350,
                              color: Colors.grey.shade500,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 30,
                              width: 350,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Completed Date',
                                    style: TextStyle(
                                      color: Colors.grey.shade500,
                                    ),
                                  ),
                                  const Text(
                                    '21/04/23, 16:26 PM',
                                    style: TextStyle(),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 30,
                              width: 350,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Total Amount',
                                    style: TextStyle(
                                      color: Colors.grey.shade500,
                                    ),
                                  ),
                                  const Text(
                                    'AED 400.00',
                                    style: TextStyle(),
                                  ),
                                ],
                              ),
                            ),
                            const Expanded(
                                child: SizedBox(
                              height: 20,
                            )),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Container(
                                height: 60,
                                padding: const EdgeInsets.all(12),
                                decoration: const BoxDecoration(
                                    color: Colors.grey,
                                    borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(5),
                                        bottomRight: Radius.circular(5))),
                                child: Row(
                                  children: [
                                    // Text(
                                    //   'Tendor $paymentMathodKey',
                                    //   style: GoogleFonts.roboto(fontSize: 18),
                                    // ),
                                    const Expanded(
                                        child: SizedBox(
                                      width: 10,
                                    )),
                                    Container(
                                      height: 40,
                                      width: 100,
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                Colors.grey.shade800),
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                        child: Text(
                                          'Close',
                                          style: GoogleFonts.roboto(
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 5,
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                        border: Border.all(width: 1),
                                        borderRadius: BorderRadius.circular(4),
                                        gradient: const LinearGradient(
                                            end: Alignment.bottomCenter,
                                            colors: [
                                              Color(0xff092F53),
                                              Color(0xff284F70),
                                            ],
                                            begin: Alignment.topCenter),
                                      ),
                                      height: 40,
                                      width: 150,
                                      child: ElevatedButton(
                                        style: ElevatedButton.styleFrom(
                                            backgroundColor:
                                                Colors.transparent),
                                        onPressed: () async {
                                          Navigator.pop(context);
                                        },
                                        child: Text(
                                          'See Order Details',
                                          style: GoogleFonts.roboto(
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          ],
                        )
                      : checkingForCheckoutStatus
                          ? Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                CircularProgressIndicator(
                                  backgroundColor: Colors.grey.shade400,
                                  strokeWidth: 5,
                                ),
                                const SizedBox(
                                  height: 25,
                                ),
                                const SizedBox(
                                  width: 350,
                                  child: Text(
                                    'Waiting for the customer to complete checkout',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 18,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                const SizedBox(
                                  width: 350,
                                  child: Text(
                                    'Please ask the customer to complete payment using the SMS that has been sent to the phone number.',
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.grey, fontSize: 12),
                                  ),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                Container(
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.grey.shade300),
                                      borderRadius: BorderRadius.circular(8)),
                                  width: 350,
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Column(
                                    children: [
                                      SizedBox(
                                        height: 40,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              'Phone Number',
                                              style: TextStyle(
                                                color: Colors.grey.shade500,
                                              ),
                                            ),
                                            Text(
                                              '+${phoneNumber.countryCode} ${phoneNumber.nsn}',
                                              style: const TextStyle(),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: .5,
                                        width: double.maxFinite,
                                        color: Colors.grey.shade500,
                                      ),
                                      SizedBox(
                                        height: 40,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              'Total Amount',
                                              style: TextStyle(
                                                color: Colors.grey.shade500,
                                              ),
                                            ),
                                            Text(
                                              'AED ${dbReceiptData.lineItemTotalData.receiptTotal}',
                                              style: const TextStyle(),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        height: .5,
                                        width: double.maxFinite,
                                        color: Colors.grey.shade500,
                                      ),
                                      SizedBox(
                                        height: 40,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              'Link Expired Time',
                                              style: TextStyle(
                                                color: Colors.grey.shade500,
                                              ),
                                            ),
                                            const Text(
                                              '21/04/23, 16:24 PM',
                                              style: TextStyle(),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            )
                          : sendingCheckoutSms
                              ? Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    CircularProgressIndicator(
                                      backgroundColor: Colors.grey.shade400,
                                      strokeWidth: 5,
                                    ),
                                    const SizedBox(
                                      height: 25,
                                    ),
                                    const Text(
                                      'Please wait, sending SMS to the customer',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.black,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                          border: Border.all(
                                              color: Colors.grey.shade300),
                                          borderRadius:
                                              BorderRadius.circular(8)),
                                      width: 350,
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 15),
                                      child: Column(
                                        children: [
                                          SizedBox(
                                            height: 40,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  'Phone Number',
                                                  style: TextStyle(
                                                    color: Colors.grey.shade500,
                                                  ),
                                                ),
                                                Text(
                                                  '+${phoneNumber.countryCode} ${phoneNumber.nsn}',
                                                  style: const TextStyle(),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            height: .5,
                                            width: double.maxFinite,
                                            color: Colors.grey.shade500,
                                          ),
                                          SizedBox(
                                            height: 40,
                                            child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                Text(
                                                  'Total Amount',
                                                  style: TextStyle(
                                                    color: Colors.grey.shade500,
                                                  ),
                                                ),
                                                Text(
                                                  'AED ${dbReceiptData.lineItemTotalData.receiptTotal}',
                                                  style: const TextStyle(),
                                                ),
                                              ],
                                            ),
                                          ),
                                          // Divider(color: Colors.grey.shade300),
                                        ],
                                      ),
                                    ),
                                  ],
                                )
                              : Form(
                                  key: _formKey,
                                  child: Column(
                                    children: [
                                      Container(
                                        height: 50,
                                        width: double.maxFinite,
                                        padding: const EdgeInsets.all(15),
                                        decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.only(
                                              topLeft: Radius.circular(3),
                                              topRight: Radius.circular(3)),
                                          gradient: LinearGradient(
                                              end: Alignment.bottomCenter,
                                              colors: [
                                                Color.fromARGB(255, 66, 66, 66),
                                                Color.fromARGB(255, 0, 0, 0),
                                              ],
                                              begin: Alignment.topCenter),
                                        ),
                                        child: Text(
                                          'Tamara Checkout',
                                          style: GoogleFonts.roboto(
                                              fontSize: 18,
                                              fontWeight: FontWeight.w400,
                                              color: Colors.white),
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      SizedBox(
                                        width: 400,
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  top: 8.0),
                                              child: Text(
                                                staticTextTranslate(
                                                    'Phone Number'),
                                                style: GoogleFonts.roboto(
                                                  fontSize: 16,
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 240,
                                              child: PhoneFormField(
                                                validator:
                                                    PhoneValidator.compose([
                                                  PhoneValidator.required(
                                                      context),
                                                  PhoneValidator.validMobile(
                                                      context)
                                                ]),
                                                controller: controller,
                                                autovalidateMode:
                                                    AutovalidateMode
                                                        .onUserInteraction,
                                                countrySelectorNavigator:
                                                    const CountrySelectorNavigator
                                                        .modalBottomSheet(),
                                                onChanged: (pn) =>
                                                    setState2(() {
                                                  phoneNumber = pn;
                                                }),
                                                // contextMenuBuilder: (p0, p1) {
                                                //   return SizedBox();
                                                // },
                                                // countryCodeStyle: TextStyle(
                                                //   height: 1.41,
                                                //   fontSize: getMediumFontSize + 2,
                                                // ),
                                                style: GoogleFonts.roboto(
                                                  height: 1.41,
                                                  fontSize:
                                                      getMediumFontSize + 2,
                                                ),
                                                decoration:
                                                    const InputDecoration(
                                                  fillColor: Colors.white,
                                                  filled: true,
                                                  isDense: true,
                                                  contentPadding:
                                                      EdgeInsets.symmetric(
                                                    vertical: 0,
                                                    horizontal: 0,
                                                  ),
                                                  enabledBorder:
                                                      OutlineInputBorder(
                                                    borderSide:
                                                        BorderSide(width: 0.3),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                            bottomRight:
                                                                Radius.circular(
                                                                    4),
                                                            topRight:
                                                                Radius.circular(
                                                                    4),
                                                            bottomLeft:
                                                                Radius.circular(
                                                                    4),
                                                            topLeft:
                                                                Radius.circular(
                                                                    4)),
                                                  ),
                                                  border: OutlineInputBorder(
                                                    borderSide:
                                                        BorderSide(width: 0.3),
                                                    borderRadius:
                                                        BorderRadius.only(
                                                            bottomRight:
                                                                Radius.circular(
                                                                    4),
                                                            topRight:
                                                                Radius.circular(
                                                                    4),
                                                            bottomLeft:
                                                                Radius.circular(
                                                                    4),
                                                            topLeft:
                                                                Radius.circular(
                                                                    4)),
                                                  ),
                                                ),
                                                isCountrySelectionEnabled: true,
                                                isCountryButtonPersistent: true,
                                                countryButtonStyle:
                                                    const CountryButtonStyle(
                                                        showDialCode: true,
                                                        showIsoCode: false,
                                                        showFlag: true,
                                                        flagSize: 16),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      SizedBox(
                                        width: 400,
                                        child: BTextField(
                                          autoFoucs: false,
                                          label: 'Email (Optional)',
                                          onTap: () {
                                            // allSelected = false;
                                            setState2(() {});
                                          },
                                          controller:
                                              emailTextEditingController,
                                          autovalidateMode: AutovalidateMode
                                              .onUserInteraction,
                                          validator: ((value) {
                                            if (value == null || value.isEmpty)
                                              return null;
                                            if (!EmailValidator.validate(
                                                value)) {
                                              return staticTextTranslate(
                                                  'Enter valid email');
                                            }
                                            return null;
                                          }),
                                          onChanged: (val) => setState2(() {}),
                                        ),
                                      ),
                                      const Expanded(
                                        child: SizedBox(
                                          height: 10,
                                        ),
                                      ),
                                      Container(
                                        height: 60,
                                        padding: const EdgeInsets.all(12),
                                        decoration: const BoxDecoration(
                                            color: Colors.grey,
                                            borderRadius: BorderRadius.only(
                                                bottomLeft: Radius.circular(5),
                                                bottomRight:
                                                    Radius.circular(5))),
                                        child: Row(
                                          children: [
                                            // Text(
                                            //   'Tendor $paymentMathodKey',
                                            //   style: GoogleFonts.roboto(fontSize: 18),
                                            // ),
                                            const Expanded(
                                                child: SizedBox(
                                              width: 10,
                                            )),
                                            Container(
                                              height: 40,
                                              width: 100,
                                              child: ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                    backgroundColor:
                                                        Colors.grey.shade800),
                                                onPressed: () {
                                                  // amountTextController.clear()
                                                  Navigator.pop(context);
                                                },
                                                child: Text(
                                                  'Cancel',
                                                  style: GoogleFonts.roboto(
                                                    color: Colors.white,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(
                                              width: 5,
                                            ),
                                            Container(
                                              decoration: BoxDecoration(
                                                border: Border.all(width: 1),
                                                borderRadius:
                                                    BorderRadius.circular(4),
                                                gradient: const LinearGradient(
                                                    end: Alignment.bottomCenter,
                                                    colors: [
                                                      Color(0xff092F53),
                                                      Color(0xff284F70),
                                                    ],
                                                    begin: Alignment.topCenter),
                                              ),
                                              height: 40,
                                              width: 100,
                                              child: ElevatedButton(
                                                style: ElevatedButton.styleFrom(
                                                    backgroundColor:
                                                        Colors.transparent),
                                                onPressed: () async {
                                                  if (_formKey.currentState!
                                                      .validate()) {
                                                    setState2(() {
                                                      sendingCheckoutSms = true;
                                                    });

                                                    await Future.delayed(
                                                        const Duration(
                                                            seconds: 3));

                                                    setState2(() {
                                                      sendingCheckoutSms =
                                                          false;
                                                      checkingForCheckoutStatus =
                                                          true;
                                                    });
                                                    await Future.delayed(
                                                        const Duration(
                                                            seconds: 3));

                                                    setState2(() {
                                                      sendingCheckoutSms =
                                                          false;
                                                      orderCaptured = true;
                                                    });
                                                  }
                                                },
                                                child: Text(
                                                  'Ok',
                                                  style: GoogleFonts.roboto(
                                                    color: Colors.white,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                ),
              ),
            ),
          );
        });
      });
  // if (double.tryParse(amountTextController.text) != null) {
  //   return amountTextController.text;
  // } else {
  return '';
  // }
}
