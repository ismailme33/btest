import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/receipt_quot_create_edit_page.dart';
import 'package:bitpro_hive/shared/constant_data.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/bTextField.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

Future<String?> showTendorAmountDialog(context,
    {required String paymentMathodKey,
    required String dueAmount,
    required String previousAmt}) async {
  TextEditingController amountTextController = TextEditingController(
      text:
          previousAmt.isEmpty || previousAmt == '0' ? dueAmount : previousAmt);
  amountTextController.selection = TextSelection(
      baseOffset: 0, extentOffset: amountTextController.value.text.length);

  bool allSelected = true;

  await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context2, setState2) {
            return Shortcuts(
              shortcuts: <LogicalKeySet, Intent>{
                LogicalKeySet(LogicalKeyboardKey.enter):
                    const ReceiptCallbackShortcutsIntent(name: 'Ok'),
              },
              child: Actions(
                actions: <Type, Action<Intent>>{
                  ReceiptCallbackShortcutsIntent:
                      CallbackAction<ReceiptCallbackShortcutsIntent>(
                          onInvoke: (ReceiptCallbackShortcutsIntent intent) =>
                              intent.name == "Ok"
                                  ? Navigator.pop(context2)
                                  : debugPrint(intent.name)),
                },
                child: Dialog(
                  child: SizedBox(
                    width: 400,
                    height:
                        paymentMathodKey == PaymentMethodKey().cash ? 280 : 220,
                    child: Column(
                      children: [
                        // if (paymentMathodKey == PaymentMethodKey().cash)
                        //   const SizedBox(
                        //     height: 0,
                        //   )
                        // else
                        //   const Expanded(
                        //     child: SizedBox(
                        //       height: 0,
                        //     ),
                        //   ),
                        Container(
                          width: 400,
                          height: 40,
                          color: Color.fromARGB(255, 51, 51, 51),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 10,
                              ),
                              Text(
                                'Tendor $paymentMathodKey',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12),
                          child: BTextField(
                            height: 1.5,
                            autoFoucs: true,
                            label: 'Amount',
                            onTap: () {
                              allSelected = false;
                              setState2(() {});
                            },
                            controller: amountTextController,
                            autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                            validator: ((value) {
                              if (value != null &&
                                  double.tryParse(value) == null) {
                                return staticTextTranslate(
                                    'Enter valid number');
                              }
                              return null;
                            }),
                            onChanged: (val) => setState2(() {}),
                          ),
                        ),
                        const Expanded(
                          child: SizedBox(
                            height: 10,
                          ),
                        ),
                        if (paymentMathodKey == PaymentMethodKey().cash)
                          Align(
                            alignment: Alignment.center,
                            child: SizedBox(
                              width: 400,
                              child: Center(
                                child: Wrap(
                                    spacing: 10,
                                    runSpacing: 10,
                                    children: [5, 10, 50, 100, 200, 500]
                                        .map(
                                          (e) => Container(
                                            decoration: BoxDecoration(
                                              border: Border.all(width: 1),
                                              borderRadius:
                                                  BorderRadius.circular(4),
                                              gradient: const LinearGradient(
                                                  end: Alignment.bottomCenter,
                                                  colors: [
                                                    Color.fromARGB(
                                                        255, 12, 65, 114),
                                                    Color.fromARGB(
                                                        255, 12, 65, 114),
                                                  ],
                                                  begin: Alignment.topCenter),
                                            ),
                                            height: 38,
                                            width: 100,
                                            child: ElevatedButton(
                                              style: ElevatedButton.styleFrom(
                                                  elevation: 0,
                                                  backgroundColor:
                                                      Colors.transparent),
                                              onPressed: () {
                                                if (allSelected) {
                                                  amountTextController.text =
                                                      e.toString();
                                                  allSelected = false;
                                                } else {
                                                  amountTextController
                                                      .text = ((double.tryParse(
                                                                  amountTextController
                                                                      .text) ??
                                                              0) +
                                                          e)
                                                      .toString();
                                                }
                                                setState2(() {});
                                              },
                                              child: Text(e.toString()),
                                            ),
                                          ),
                                        )
                                        .toList()),
                              ),
                            ),
                          ),
                        const Expanded(
                          child: SizedBox(
                            height: 10,
                          ),
                        ),
                        Container(
                          // height: 60,
                          padding: const EdgeInsets.all(10),
                          decoration: const BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(5),
                                  bottomRight: Radius.circular(5))),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              OnPageGreyButton(
                                label: 'Cancel',
                                onPressed: () {
                                  amountTextController.clear();
                                  Navigator.pop(context);
                                },
                              ),
                              const SizedBox(
                                width: 5,
                              ),
                              OnPageButton(
                                label: 'OK',
                                onPressed: () {
                                  if (double.tryParse(
                                          amountTextController.text) !=
                                      null) {
                                    Navigator.pop(context);
                                  }
                                },
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            );
          }));
  if (double.tryParse(amountTextController.text) != null) {
    return amountTextController.text;
  } else {
    return '';
  }
}
