import 'dart:io';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/shared/save_file_and_launch.dart';
import 'package:bitpro_hive/widget/BlackTopPanelForDialogWindow.dart';
import 'package:bitpro_hive/widget/bottom_panel_for_dialog.dart';
import 'package:bitpro_hive/widget/onPage_grey_button.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:excel/excel.dart' hide Border;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:iconsax/iconsax.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart' hide Column, Row, Border;
import 'package:bitpro_hive/model/inventory_data.dart';
import 'package:bitpro_hive/services/hive/import_data_exel/local_receipt_data_excel.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/loading.dart';

showReceiptCreateImportDialog(
    {required BuildContext context,
    required List<InventoryData> allInventoryDataLst}) {
  File? importItem;
  Map<String, dynamic> uploadRes = {};
  bool dialogLoading = false;
  showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setState2) {
            return Dialog(
              backgroundColor: homeBgColor,
              child: SizedBox(
                  height: 380,
                  width: 420,
                  child: dialogLoading
                      ? showLoading()
                      : Column(children: [
                          Expanded(
                            child: Column(
                              children: [
                                BlackTopPanelForDialogWindow(
                                  label: 'Import Items',
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 15),
                                  child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        Row(
                                          children: [
                                            Text(
                                                staticTextTranslate(
                                                    'Download Sample file here.'),
                                                style: GoogleFonts.roboto(
                                                  fontSize: getMediumFontSize,
                                                )),
                                            TextButton(
                                              onPressed: () async {
                                                setState2(() {
                                                  dialogLoading = true;
                                                });
                                                final Workbook workbook =
                                                    Workbook();

                                                final Worksheet sheet =
                                                    workbook.worksheets[0];

                                                sheet
                                                    .getRangeByName('A1')
                                                    .setText('barcode');
                                                sheet
                                                    .getRangeByName('B1')
                                                    .setText('qty');
                                                sheet
                                                    .getRangeByName('C1')
                                                    .setText('price');

                                                final List<int> bytes =
                                                    workbook.saveAsStream();

                                                workbook.dispose();
                                                await saveAndLaunchFile(
                                                    bytes,
                                                    fileExtension: 'xlsx',
                                                    context);

                                                setState2(() {
                                                  dialogLoading = false;
                                                });
                                              },
                                              child: Text(
                                                  staticTextTranslate(
                                                      'Download Now.'),
                                                  style: GoogleFonts.roboto(
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: getMediumFontSize,
                                                    decoration: TextDecoration
                                                        .underline,
                                                  )),
                                            )
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 20,
                                        ),
                                        Row(
                                          children: [
                                            Text(staticTextTranslate('File'),
                                                style: GoogleFonts.roboto(
                                                  fontSize: getMediumFontSize,
                                                )),
                                            const SizedBox(
                                              width: 10,
                                            ),
                                            Expanded(
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            2),
                                                    border: Border.all(
                                                        color: Colors.grey)),
                                                padding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 5,
                                                        vertical: 5),
                                                child: Text(
                                                    importItem != null
                                                        ? importItem!.path
                                                        : staticTextTranslate(
                                                            'No path found'),
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: GoogleFonts.roboto(
                                                      color:
                                                          const Color.fromARGB(
                                                              255, 70, 70, 70),
                                                      fontSize:
                                                          getMediumFontSize,
                                                    )),
                                              ),
                                            ),
                                            const SizedBox(
                                              width: 10,
                                            ),
                                            GestureDetector(
                                              onTap: () async {
                                                setState2(() {
                                                  dialogLoading = true;
                                                });

                                                FilePickerResult? result =
                                                    await FilePicker
                                                        .platform
                                                        .pickFiles(
                                                            allowMultiple:
                                                                false,
                                                            dialogTitle:
                                                                'Import Items',
                                                            allowedExtensions: [
                                                              'xlsx'
                                                            ],
                                                            type: FileType
                                                                .custom);
                                                if (result != null &&
                                                    result.paths.isNotEmpty) {
                                                  importItem =
                                                      File(result.paths.first!);
                                                  var bytes = File(result
                                                          .files.first.path!)
                                                      .readAsBytesSync();
                                                  var excel =
                                                      Excel.decodeBytes(bytes);

                                                  uploadRes =
                                                      localReceiptDataFromExcel(
                                                          excel,
                                                          allInventoryDataLst);
                                                }

                                                setState2(() {
                                                  dialogLoading = false;
                                                });
                                              },
                                              child: Container(
                                                  decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              2),
                                                      border: Border.all(
                                                          color: Colors.grey)),
                                                  padding: const EdgeInsets
                                                      .symmetric(
                                                      horizontal: 10,
                                                      vertical: 5),
                                                  child: Icon(
                                                    Iconsax.folder5,
                                                    size: 20,
                                                  )),
                                            )
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 25,
                                        ),
                                        Text(
                                            uploadRes.isEmpty
                                                ? staticTextTranslate(
                                                    'Items Found : 0')
                                                : '${staticTextTranslate("Items Found")} : ${uploadRes['localVoucherDataLst'].length}',
                                            style: GoogleFonts.roboto(
                                              fontSize: getMediumFontSize,
                                            )),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                        Row(
                                          children: [
                                            Text(staticTextTranslate('Note : '),
                                                style: GoogleFonts.roboto(
                                                  fontSize: getMediumFontSize,
                                                )),
                                            Text(
                                              uploadRes.isNotEmpty
                                                  ? '${uploadRes['dublicate']} ${staticTextTranslate("Duplicate items found")}'
                                                  : staticTextTranslate(
                                                      '0 Duplicate items found'),
                                              style: TextStyle(
                                                  fontSize: getMediumFontSize,
                                                  color: Colors.red[700]),
                                            ),
                                          ],
                                        ),
                                      ]),
                                ),
                              ],
                            ),
                          ),
                          Align(
                              alignment: Alignment.bottomCenter,
                              child: BottomPanelForDialog(buttons: [
                                OnPageGreyButton(
                                  label: 'Cancel',
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                ),
                                const SizedBox(
                                  width: 10,
                                ),
                                OnPageButton(
                                    gradient: uploadRes.isEmpty ||
                                            uploadRes['localVoucherDataLst']
                                                    .length ==
                                                0
                                        ? null
                                        : const LinearGradient(
                                            end: Alignment.bottomCenter,
                                            colors: [
                                              Color.fromARGB(255, 12, 65, 114),
                                              Color.fromARGB(255, 12, 65, 114),
                                            ],
                                            begin: Alignment.topCenter),
                                    backgroundColor: uploadRes.isEmpty ||
                                            uploadRes['localVoucherDataLst']
                                                    .length ==
                                                0
                                        ? Colors.grey
                                        : Colors.transparent,
                                    label: uploadRes['dublicate'] == null ||
                                            uploadRes['dublicate'] == 0
                                        ? staticTextTranslate(' Import')
                                        : staticTextTranslate('Skip & Import'),
                                    onPressed: () async {
                                      // if (uploadRes.isNotEmpty &&
                                      //     uploadRes['localVoucherDataLst']
                                      //             .length !=
                                      //         0) {
                                      //   setState(() {
                                      //     dialogLoading = true;
                                      //   });
                                      //   setState2(() {});

                                      //   selectedLocalReceiptData.addAll(
                                      //       uploadRes['localVoucherDataLst']);
                                      //   var box = Hive.box('bitpro_app');

                                      //   receiptDataSource = ReceiptDataSource(
                                      //       g: selectedLocalReceiptData,
                                      //       maxDiscount: widget
                                      //               .userData
                                      //               .empWorkAndRolesData
                                      //               .discountPercentage ??
                                      //           '',
                                      //       context: context,
                                      //       showBarcodeInReceiptCreate: true,
                                      //       allInventoryDataLst:
                                      //           allInventoryDataLst,
                                      //       showItemCodeInReceiptCreate: true,
                                      //       showOriginalPriceInReceiptCreate:
                                      //           true,
                                      //       taxSettingsData: taxSettingsData);
                                      //   Navigator.pop(context);

                                      //   setState(() {
                                      //     dialogLoading = false;
                                      //   });
                                      //   setState2(() {});
                                      // }
                                    },
                                    icon: Iconsax.save_25)
                              ]))
                        ])),
            );
          }));
}
