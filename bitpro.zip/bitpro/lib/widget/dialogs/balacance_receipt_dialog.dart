import 'package:bitpro_hive/home/02_sales/receipt_and_quotation/create_receipt_quot/receipt_quot_create_edit_page.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:bitpro_hive/widget/onpage_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

Future<void> changeWindowDialog(
    {required String subtotal,
    required String tendered,
    required String change,
    required BuildContext context,
    required bool viewMode}) async {
  await showDialog(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context2, setState2) {
            return Shortcuts(
              shortcuts: <LogicalKeySet, Intent>{
                LogicalKeySet(LogicalKeyboardKey.enter):
                    const ReceiptCallbackShortcutsIntent(
                        name: 'changeWindowDialogEnter'),
              },
              child: Actions(
                actions: <Type, Action<Intent>>{
                  ReceiptCallbackShortcutsIntent:
                      CallbackAction<ReceiptCallbackShortcutsIntent>(
                          onInvoke: (ReceiptCallbackShortcutsIntent intent) {
                    if (!viewMode) {
                      Navigator.pop(context2);
                    }
                    return;
                  }),
                },
                child: Focus(
                  autofocus: true,
                  child: Dialog(
                      backgroundColor: homeBgColor,
                      child: SizedBox(
                          height: 220,
                          width: 530,
                          child: Column(children: [
                            Container(
                              // height: 55,
                              width: double.maxFinite,
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 18, vertical: 10),
                              decoration: const BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(4),
                                      topRight: Radius.circular(4)),
                                  gradient: LinearGradient(
                                      end: Alignment.bottomCenter,
                                      colors: [
                                        Color.fromARGB(255, 51, 51, 51),
                                        Color.fromARGB(255, 51, 51, 51),
                                      ],
                                      begin: Alignment.topCenter)),
                              child: Text(
                                staticTextTranslate('Change Window'),
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: getMediumFontSize + 5),
                              ),
                            ),
                            const Expanded(
                                child: SizedBox(
                              height: 10,
                            )),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(staticTextTranslate('TOTAL'),
                                        style: TextStyle(
                                            fontSize: getMediumFontSize)),
                                    Text(subtotal,
                                        style: TextStyle(
                                            fontSize: getExtraLargeFontSize + 2,
                                            fontWeight: FontWeight.bold)),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(staticTextTranslate('TENDERED'),
                                        style: TextStyle(
                                            fontSize: getMediumFontSize)),
                                    Text(tendered,
                                        style: TextStyle(
                                            fontSize: getExtraLargeFontSize + 2,
                                            fontWeight: FontWeight.bold)),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      staticTextTranslate('CHANGE'),
                                      style: TextStyle(
                                          fontSize: getMediumFontSize,
                                          color: const Color.fromARGB(
                                              255, 25, 84, 27)),
                                    ),
                                    Text(change,
                                        style: TextStyle(
                                            fontSize: getExtraLargeFontSize + 2,
                                            color: const Color.fromARGB(
                                                255, 25, 84, 27),
                                            fontWeight: FontWeight.bold)),
                                  ],
                                )
                              ],
                            ),
                            const Expanded(
                                child: SizedBox(
                              height: 10,
                            )),
                            Container(
                              width: 530,
                              decoration: const BoxDecoration(
                                  color: Color(0xffdddfe8),
                                  borderRadius: BorderRadius.only(
                                      bottomLeft: Radius.circular(6),
                                      bottomRight: Radius.circular(6))),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 10),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  OnPageButton(
                                    width: 510,
                                    label: 'Close',
                                    onPressed: () {
                                      Navigator.pop(context2);
                                    },
                                  )
                                ],
                              ),
                            )
                          ]))),
                ),
              ),
            );
          }));
}
