import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

showNoItemWithBarcodeFoundDialog(BuildContext context, val) {
  showDialog(
      context: context,
      builder: (context) => Dialog(
            child: SizedBox(
              width: 290,
              height: 190,
              child: Column(
                children: [
                  const Expanded(
                    child: SizedBox(
                      height: 10,
                    ),
                  ),
                  Text(
                      '${staticTextTranslate("No item with the barcode")} $val',
                      style: TextStyle(
                          fontSize: getMediumFontSize + 2,
                          fontWeight: FontWeight.w500)),
                  const Expanded(
                    child: SizedBox(
                      height: 10,
                    ),
                  ),
                  Container(
                    height: 60,
                    padding: const EdgeInsets.all(12),
                    decoration: const BoxDecoration(
                        color: Colors.grey,
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(5),
                            bottomRight: Radius.circular(5))),
                    child: Row(
                      children: [
                        const Expanded(
                            child: SizedBox(
                          width: 10,
                        )),
                        Container(
                          decoration: BoxDecoration(
                            border: Border.all(width: 1),
                            borderRadius: BorderRadius.circular(4),
                            gradient: const LinearGradient(
                                end: Alignment.bottomCenter,
                                colors: [
                                  Color(0xff092F53),
                                  Color(0xff284F70),
                                ],
                                begin: Alignment.topCenter),
                          ),
                          height: 40,
                          width: 100,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent),
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text(
                              'Ok',
                              style: GoogleFonts.roboto(
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ),
          ));
}
