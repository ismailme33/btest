import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';

class BlackTopPanelForDialogWindow extends StatelessWidget {
  final String label;
  final double height;
  final double fontSize;
  const BlackTopPanelForDialogWindow({
    this.height = 7,
    this.fontSize = 20,
    required this.label,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: 55,
      width: double.maxFinite,
      padding: EdgeInsets.symmetric(horizontal: 18, vertical: height),
      decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(4), topRight: Radius.circular(4)),
          gradient: LinearGradient(
              end: Alignment.bottomCenter,
              colors: [
                Color.fromARGB(255, 51, 51, 51),
                Color.fromARGB(255, 51, 51, 51),
              ],
              begin: Alignment.topCenter)),
      child: Text(
        staticTextTranslate(label),
        style: TextStyle(
          color: Colors.white,
          fontSize: fontSize,
        ),
      ),
    );
  }
}
