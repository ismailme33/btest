import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class BTextField extends StatelessWidget {
  final String label;
  final double bradius;
  final String? initialValue;
  final Function(String input) onChanged;
  final String? Function(String?)? validator;
  final void Function()? onTap;
  final void Function(String)? onFieldSubmitted;
  final bool autovalidate;
  final double fieldWidth;
  final AutovalidateMode autovalidateMode;
  final dynamic textFieldHeight;
  final bool textFieldReadOnly;
  final TextEditingController? controller;
  final WidgetBuilder? noItemsBuilder;
  final bool autoFoucs;
  final bool obscureText;
  final FocusNode? focusNode;
  final double height;
  final bool enabled;
  final IconData cIcon;
  final Color cColor;
  final bool redStarEnabled;
  final String bottomTxt;
  final IconData? prefixIcon;
  final TextInputType? keyboardType;

  const BTextField(
      {super.key,
      this.onTap,
      this.onFieldSubmitted,
      this.focusNode,
      required this.label,
      this.initialValue,
      required this.onChanged,
      this.validator,
      this.autovalidate = false,
      this.autoFoucs = false,
      this.fieldWidth = 360,
      this.autovalidateMode = AutovalidateMode.disabled,
      this.textFieldHeight = 1,
      this.textFieldReadOnly = false,
      this.obscureText = false,
      this.controller,
      this.noItemsBuilder,
      this.bradius = 2,
      this.height = 1.1,
      this.enabled = true,
      this.cIcon = Icons.warning,
      this.cColor = Colors.red,
      this.redStarEnabled = false,
      this.prefixIcon,
      this.keyboardType,
      this.bottomTxt = ''});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: fieldWidth,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                staticTextTranslate(label),
                style: GoogleFonts.roboto(
                    fontSize: 14, fontWeight: FontWeight.bold),
              ),
              redStarEnabled == true
                  ? Text(
                      ' *',
                      style: GoogleFonts.roboto(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.red),
                    )
                  : const SizedBox(),
            ],
          ),
          SizedBox(
            height: 2,
          ),
          SizedBox(
            child: TextFormField(
              keyboardType: keyboardType,
              enabled: enabled,
              onTap: onTap,
              onFieldSubmitted: onFieldSubmitted,
              focusNode: focusNode,
              autofocus: autoFoucs,
              obscureText: obscureText,
              controller: controller,
              readOnly: textFieldReadOnly,
              autovalidateMode: autovalidateMode,
              initialValue: initialValue,
              maxLines: textFieldHeight,
              style: GoogleFonts.roboto(
                  height: height,
                  fontSize: getMediumFontSize + 1,
                  fontWeight: FontWeight.w400),
              validator: validator,
              decoration: InputDecoration(
                prefixIconConstraints: const BoxConstraints(
                  minWidth: 0,
                  minHeight: 0,
                ),
                prefixIcon: prefixIcon != null
                    ? Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 6.0),
                        child: Icon(
                          prefixIcon,
                          size: 18,
                        ),
                      )
                    : null,
                fillColor: Colors.white,
                filled: true,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(
                  vertical: 9,
                  horizontal: 5,
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(width: 0.3),
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(bradius),
                      topRight: Radius.circular(bradius),
                      bottomLeft: const Radius.circular(2),
                      topLeft: const Radius.circular(2)),
                ),
                border: OutlineInputBorder(
                  borderSide: const BorderSide(width: 0.3),
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(bradius),
                      topRight: Radius.circular(bradius),
                      bottomLeft: const Radius.circular(2),
                      topLeft: const Radius.circular(2)),
                ),
              ),
              onChanged: onChanged,
            ),
          ),
          bottomTxt != ''
              ? SizedBox(
                  height: 2,
                )
              : SizedBox(),
          bottomTxt != ''
              ? Text(
                  staticTextTranslate(bottomTxt),
                  style: GoogleFonts.roboto(fontSize: 11, color: Colors.black),
                )
              : SizedBox(),
          SizedBox(
            height: 8,
          ),
        ],
      ),
    );
  }
}
