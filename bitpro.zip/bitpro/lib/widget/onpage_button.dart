import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';

class OnPageButton extends StatelessWidget {
  final Function() onPressed;
  final IconData? icon;
  final String label;
  final String? imageIcon;
  final double? width;
  final Color backgroundColor;
  final Gradient? gradient;
  final double? imageIconWidth;
  final double iconSize;
  final double height;

  const OnPageButton(
      {super.key,
      required this.label,
      required this.onPressed,
      this.icon,
      this.width,
      this.height = 38,
      this.imageIconWidth,
      this.iconSize = 20,
      this.imageIcon,
      this.backgroundColor = Colors.transparent,
      this.gradient});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(2),
        gradient: gradient ??
            const LinearGradient(
                end: Alignment.bottomCenter,
                colors: [
                  Color.fromARGB(255, 12, 65, 114),
                  Color.fromARGB(255, 12, 65, 114),
                ],
                begin: Alignment.topCenter),
      ),
      height: 38,
      width: width,
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              elevation: 0,
              backgroundColor: backgroundColor,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(3))),
          onPressed: onPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (imageIcon != null) ...[
                  Image.asset(
                    imageIcon!,
                    width: imageIconWidth,
                  ),
                  const SizedBox(
                    width: 10,
                  )
                ],
                if (icon != null) ...[
                  Icon(
                    icon,
                    size: iconSize,
                  ), // Display icon if provided
                  const SizedBox(
                      width: 10), // Add spacing between icon and text
                ],
                Text(staticTextTranslate(label),
                    style: TextStyle(
                      fontSize: getMediumFontSize,
                    )),
              ],
            ),
          )),
    );
  }
}
