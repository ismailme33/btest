import 'package:bitpro_hive/model/receipt/receipt_data.dart';

String getReceiptPaymentType(ReceiptOrQuotationData dbReceiptData) {
  return dbReceiptData.receiptBasicInfo!.allPaymentMethodAmountsInfo.length != 1
      ? 'Split'
      : dbReceiptData.receiptBasicInfo!.allPaymentMethodAmountsInfo.keys.first;
}
