import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';
import 'package:bitpro_hive/shared/global_variables/static_text_translate.dart';
import 'package:flutter/material.dart';

class OnPageGreyButton extends StatelessWidget {
  final Function() onPressed;
  final IconData? icon;
  final Color? iconColor;
  final String label;
  final double? width;

  const OnPageGreyButton(
      {super.key,
      required this.label,
      required this.onPressed,this.iconColor,
      this.icon,
      this.width});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(4),
      ),
      height: 38,
      width: width,
      child: ElevatedButton(
          style: ElevatedButton.styleFrom(
              elevation: 0,
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(3))),
          onPressed: onPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[
                  Icon(icon,color: iconColor,), // Display icon if provided
                  const SizedBox(
                      width: 10), // Add spacing between icon and text
                ],
                Text(staticTextTranslate(label),
                    style: TextStyle(
                        fontSize: getMediumFontSize, color: Colors.black)),
              ],
            ),
          )),
    );
  }
}
