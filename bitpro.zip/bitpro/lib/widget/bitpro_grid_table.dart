import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:syncfusion_flutter_core/theme.dart';
import 'package:syncfusion_flutter_datagrid/datagrid.dart';
import 'package:bitpro_hive/shared/global_variables/color.dart';
import 'package:bitpro_hive/shared/global_variables/font_sizes.dart';

class BitproGridTable extends StatefulWidget {
  final DataGridController dataGridController;
  final DataGridSource source;
  final List<BitproGridColumnModel> bitproGridColumnModel;
  final bool allowEditing;
  final Function onChangeRefershFunction;
  final Function(int)? onChangeSelectedRowIndex;

  //
  final bool allowSorting;
  final bool allowFiltering;
  final bool fillAll;
  final bool showCheckBoxAlso;
  final bool allowMultiSelect;
  final double? width;
  final GlobalKey<SfDataGridState>? sfDataGridKey;

  const BitproGridTable(
      {super.key,
      required this.dataGridController,
      required this.source,
      this.fillAll = false,
      this.allowEditing = true,
      this.allowMultiSelect = false,
      this.showCheckBoxAlso = false,
      this.allowSorting = false,
      this.allowFiltering = false,
      required this.bitproGridColumnModel,
      this.width,
      required this.onChangeRefershFunction,
      this.onChangeSelectedRowIndex,
      this.sfDataGridKey});

  @override
  State<BitproGridTable> createState() => _BitproGridTableState();
}

class _BitproGridTableState extends State<BitproGridTable> {
  late Map<String, double> columnWidths;

  @override
  initState() {
    super.initState();
    columnWidths = {};
    for (var v in widget.bitproGridColumnModel) {
      columnWidths[v.columnName] = v.width;
    }
  }

  @override
  Widget build(BuildContext context) {
    // print(columnWidths);
    if (widget.width != null) {
      return Container(
        width: widget.width,
        child: bodyWidget(),
      );
    }
    return Expanded(child: bodyWidget());
  }

  bodyWidget() {
    return Container(
      margin: const EdgeInsets.all(4),
      decoration: BoxDecoration(
          color: const Color.fromARGB(255, 244, 244, 244),
          border: Border.all(width: 0.3)),
      child: SfDataGridTheme(
        data: SfDataGridThemeData(
          headerColor: const Color.fromARGB(255, 241, 241, 241),
          sortIcon: const Icon(Icons.arrow_drop_down_rounded),
          headerHoverColor: const Color(0xffdddfe8),
          selectionColor: const Color.fromARGB(255, 192, 195, 199),
        ),
        child: SfDataGrid(
            key: widget.sfDataGridKey,
            showCheckboxColumn: widget.showCheckBoxAlso,
            gridLinesVisibility: GridLinesVisibility.both,
            allowEditing: widget.allowEditing,
            selectionMode: widget.allowMultiSelect
                ? SelectionMode.multiple
                : SelectionMode.single,
            editingGestureType: EditingGestureType.tap,
            navigationMode: GridNavigationMode.cell,
            allowSorting: widget.allowSorting,
            allowTriStateSorting: true,
            controller: widget.dataGridController,
            allowColumnsResizing: true,
            columnWidthMode:
                widget.fillAll ? ColumnWidthMode.fill : ColumnWidthMode.none,
            columnResizeMode: ColumnResizeMode.onResize,
            onColumnResizeUpdate: widget.fillAll
                ? null
                : (ColumnResizeUpdateDetails details) {
                    setState(() {
                      columnWidths[details.column.columnName] = details.width;
                    });
                    return true;
                  },
            onCellTap: (details) {
              if (widget.onChangeSelectedRowIndex != null) {
                widget
                    .onChangeSelectedRowIndex!(details.rowColumnIndex.rowIndex);
              }
            },
            onSelectionChanged: (addedRows, removedRows) {
              widget.onChangeRefershFunction();
            },
            isScrollbarAlwaysShown: true,
            rowHeight: 24,
            headerRowHeight: 25,
            headerGridLinesVisibility: GridLinesVisibility.both,
            source: widget.source,
            columns: [
              for (var v in widget.bitproGridColumnModel)
                GridColumn(
                    width: widget.fillAll
                        ? double.nan
                        : columnWidths[v.columnName]!,
                    columnName: v.columnName,
                    visible: v.visible,
                    allowEditing: v.allowEditing,
                    label: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: widget.allowFiltering ? 5 : 10.0),
                        alignment: Alignment.centerLeft,
                        child: Text(
                          v.label,
                          overflow: TextOverflow.ellipsis,
                          style: GoogleFonts.roboto(
                              fontSize: getMediumFontSize,
                              fontWeight: FontWeight.w500),
                        )))
            ]),
      ),
    );
  }
}

class BitproGridColumnModel {
  String columnName;
  String label;
  double width;
  bool visible;
  bool allowEditing;
  BitproGridColumnModel({
    required this.columnName,
    required this.label,
    required this.width,
    this.visible = true,
    this.allowEditing = false,
  });
}
